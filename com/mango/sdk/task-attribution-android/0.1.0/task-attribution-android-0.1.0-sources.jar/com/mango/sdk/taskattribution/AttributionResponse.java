package com.mango.sdk.taskattribution;

/** How a client treats its own backend's answer to an activation report. */
public final class AttributionResponse {
    private AttributionResponse() {}

    /**
     * Final answers stop all further attempts for this install: success, and the refusals that a
     * retry cannot change (400 malformed, 409 already attributed or not eligible, 410 expired,
     * 422 Play proof rejected). Everything else (401/403/404/408/425/429/5xx, transport errors)
     * is retried, a few times in this process and again on the next cold start.
     */
    public static boolean isFinal(int httpStatus) {
        return (httpStatus >= 200 && httpStatus < 300)
                || httpStatus == 400 || httpStatus == 409 || httpStatus == 410 || httpStatus == 422;
    }
}
