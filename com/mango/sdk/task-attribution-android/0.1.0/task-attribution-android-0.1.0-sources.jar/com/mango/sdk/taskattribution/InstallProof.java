package com.mango.sdk.taskattribution;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/**
 * Binds a Play Integrity token to one (install, ticket) pair.
 *
 * <p>The App backend recomputes the same hash and compares it with the decoded token's
 * {@code requestDetails.requestHash}, so a captured token can only replay the same,
 * idempotent activation. Test vector: installId {@code 1234567890abcdef}, ticket of 40 {@code a}
 * gives {@code 3ad30b5b2e1cf9befb7323cfe96f35921cfe6fb67d7bf1ca8389fecfb187a47a}.</p>
 */
public final class InstallProof {
    private InstallProof() {}

    /** SHA-256 hex (lower case) of {@code installId + "\n" + ticket}, UTF-8. */
    public static String requestHash(String installId, String ticket) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest((installId + "\n" + ticket).getBytes(Charset.forName("UTF-8")));
            StringBuilder hex = new StringBuilder(64);
            for (byte b : digest) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }
}
