package com.mango.sdk.taskattribution;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;
import com.google.android.play.core.integrity.IntegrityManagerFactory;
import com.google.android.play.core.integrity.StandardIntegrityManager;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Reports a task-center install once per install: reads the Play Install Referrer ticket, asks
 * Play Integrity for a token bound to (installId, ticket), and hands both to the App's own
 * backend through {@link Submitter}. The backend decides eligibility and talks to the task center.
 *
 * <p>Call {@link #reportIfPresent} on every cold start of a Play-distributed build, after the App
 * knows its install id (and ideally after its launch report succeeded). It returns immediately;
 * all work is asynchronous and never throws. Builds for other stores should not call it: they
 * have no Play referrer and no Play Integrity verdict.</p>
 */
public final class PlayTaskAttribution {
    private static final Object LOCK = new Object();
    private static final String CHECKED = "checked";
    private static final int REFERRER_TIMEOUT_MS = 15_000;
    private static final int PROOF_TIMEOUT_MS = 30_000;
    private static final int MAX_RETRIES_PER_PROCESS = 3;
    private static boolean inFlight;
    private static int retryCount;

    private PlayTaskAttribution() {}

    /** What the App's backend receives. */
    public static final class Activation {
        public final String ticket;
        public final long installBeginTimestampSeconds;
        public final String installId;
        /** Play Integrity Standard API token; send it as the {@code X-Play-Integrity} header. */
        public final String integrityToken;

        Activation(String ticket, long installBeginTimestampSeconds, String installId, String integrityToken) {
            this.ticket = ticket;
            this.installBeginTimestampSeconds = installBeginTimestampSeconds;
            this.installId = installId;
            this.integrityToken = integrityToken;
        }
    }

    /** Sends an activation to the App's own backend. */
    public interface Submitter {
        /** Call exactly one callback method, on any thread. */
        void submit(Activation activation, Callback callback);
    }

    public interface Callback {
        void onResponse(int httpStatus);

        void onTransportFailure();
    }

    public static final class Config {
        final long cloudProjectNumber;
        final String installId;
        final String preferencesName;

        /**
         * @param cloudProjectNumber the Google Cloud project Play Console links to this App for Integrity
         * @param installId          the id this App's backend knows the install by (its launch reports use it)
         * @param preferencesName    where the "already reported" flag lives; keep an existing App's name
         */
        public Config(long cloudProjectNumber, String installId, String preferencesName) {
            this.cloudProjectNumber = cloudProjectNumber;
            this.installId = installId;
            this.preferencesName = preferencesName;
        }
    }

    interface ReferrerSource {
        void read(Context context, ReferrerCallback callback);
    }

    interface ReferrerCallback {
        void onReferrer(String referrer, long installBeginTimestampSeconds);

        void onUnavailable(boolean retry);
    }

    interface ProofSource {
        void token(Context context, long cloudProjectNumber, String requestHash, ProofCallback callback);
    }

    interface ProofCallback {
        void onToken(String token);

        void onFailure();
    }

    static ReferrerSource referrers = new PlayReferrerSource();
    static ProofSource proofs = new PlayProofSource();

    public static void reportIfPresent(Context context, Config config, Submitter submitter) {
        final Context app = context.getApplicationContext();
        if (config.installId == null || config.installId.isEmpty()) return;
        final SharedPreferences prefs = app.getSharedPreferences(config.preferencesName, Context.MODE_PRIVATE);
        if (prefs.getBoolean(CHECKED, false)) return;
        synchronized (LOCK) {
            if (inFlight) return;
            inFlight = true;
        }
        try {
            referrers.read(app, new ReferrerCallback() {
                @Override public void onReferrer(String referrer, long installedAt) {
                    String ticket = TaskTicket.fromReferrer(referrer);
                    if (ticket == null) {
                        // Organic install or another campaign: nothing to attribute, ever.
                        markChecked(prefs);
                        finish(app, config, submitter, false);
                    } else if (installedAt <= 0) {
                        finish(app, config, submitter, true);
                    } else {
                        prove(app, config, submitter, prefs, ticket, installedAt);
                    }
                }

                @Override public void onUnavailable(boolean retry) {
                    if (!retry) markChecked(prefs);
                    finish(app, config, submitter, retry);
                }
            });
        } catch (RuntimeException error) {
            finish(app, config, submitter, true);
        }
    }

    private static void prove(Context app, Config config, Submitter submitter, SharedPreferences prefs,
                              String ticket, long installedAt) {
        AtomicBoolean answered = new AtomicBoolean();
        String hash = InstallProof.requestHash(config.installId, ticket);
        later(() -> {
            if (answered.compareAndSet(false, true)) finish(app, config, submitter, true);
        }, PROOF_TIMEOUT_MS);
        try {
            proofs.token(app, config.cloudProjectNumber, hash, new ProofCallback() {
                @Override public void onToken(String token) {
                    if (answered.compareAndSet(false, true)) {
                        submit(app, config, submitter, prefs,
                                new Activation(ticket, installedAt, config.installId, token));
                    }
                }

                @Override public void onFailure() {
                    if (answered.compareAndSet(false, true)) finish(app, config, submitter, true);
                }
            });
        } catch (RuntimeException error) {
            if (answered.compareAndSet(false, true)) finish(app, config, submitter, true);
        }
    }

    private static void submit(Context app, Config config, Submitter submitter, SharedPreferences prefs,
                               Activation activation) {
        AtomicBoolean answered = new AtomicBoolean();
        try {
            submitter.submit(activation, new Callback() {
                @Override public void onResponse(int httpStatus) {
                    if (!answered.compareAndSet(false, true)) return;
                    if (AttributionResponse.isFinal(httpStatus)) {
                        markChecked(prefs);
                        finish(app, config, submitter, false);
                    } else {
                        finish(app, config, submitter, true);
                    }
                }

                @Override public void onTransportFailure() {
                    if (answered.compareAndSet(false, true)) finish(app, config, submitter, true);
                }
            });
        } catch (RuntimeException error) {
            if (answered.compareAndSet(false, true)) finish(app, config, submitter, true);
        }
    }

    private static void markChecked(SharedPreferences prefs) {
        prefs.edit().putBoolean(CHECKED, true).apply();
    }

    private static void finish(Context app, Config config, Submitter submitter, boolean retry) {
        int delay = 0;
        synchronized (LOCK) {
            inFlight = false;
            if (retry && retryCount < MAX_RETRIES_PER_PROCESS) delay = 10_000 * ++retryCount;
        }
        if (delay > 0) later(() -> reportIfPresent(app, config, submitter), delay);
    }

    private static void later(Runnable action, int milliseconds) {
        new Handler(Looper.getMainLooper()).postDelayed(action, milliseconds);
    }

    /** Test hook: forget per-process state between cases. */
    static void resetForTest() {
        synchronized (LOCK) {
            inFlight = false;
            retryCount = 0;
        }
    }

    private static final class PlayReferrerSource implements ReferrerSource {
        @Override public void read(Context context, ReferrerCallback callback) {
            AtomicBoolean answered = new AtomicBoolean();
            InstallReferrerClient client = InstallReferrerClient.newBuilder(context).build();
            later(() -> {
                if (answered.compareAndSet(false, true)) {
                    close(client);
                    callback.onUnavailable(true);
                }
            }, REFERRER_TIMEOUT_MS);
            client.startConnection(new InstallReferrerStateListener() {
                @Override public void onInstallReferrerSetupFinished(int code) {
                    if (!answered.compareAndSet(false, true)) return;
                    if (code != InstallReferrerClient.InstallReferrerResponse.OK) {
                        close(client);
                        // FEATURE_NOT_SUPPORTED / DEVELOPER_ERROR will not change on retry.
                        callback.onUnavailable(code == InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE);
                        return;
                    }
                    try {
                        ReferrerDetails details = client.getInstallReferrer();
                        long installedAt = details.getInstallBeginTimestampSeconds();
                        if (installedAt <= 0) {
                            installedAt = context.getPackageManager()
                                    .getPackageInfo(context.getPackageName(), 0).firstInstallTime / 1000;
                        }
                        String referrer = details.getInstallReferrer();
                        close(client);
                        callback.onReferrer(referrer, installedAt);
                    } catch (Exception error) {
                        close(client);
                        callback.onUnavailable(true);
                    }
                }

                @Override public void onInstallReferrerServiceDisconnected() {
                    if (answered.compareAndSet(false, true)) {
                        close(client);
                        callback.onUnavailable(true);
                    }
                }
            });
        }

        private static void close(InstallReferrerClient client) {
            try { client.endConnection(); } catch (RuntimeException ignored) { }
        }
    }

    private static final class PlayProofSource implements ProofSource {
        @Override public void token(Context context, long cloudProjectNumber, String requestHash, ProofCallback callback) {
            IntegrityManagerFactory.createStandard(context)
                    .prepareIntegrityToken(StandardIntegrityManager.PrepareIntegrityTokenRequest.builder()
                            .setCloudProjectNumber(cloudProjectNumber).build())
                    .addOnSuccessListener(provider -> provider
                            .request(StandardIntegrityManager.StandardIntegrityTokenRequest.builder()
                                    .setRequestHash(requestHash).build())
                            .addOnSuccessListener(response -> callback.onToken(response.token()))
                            .addOnFailureListener(error -> callback.onFailure()))
                    .addOnFailureListener(error -> callback.onFailure());
        }
    }
}
