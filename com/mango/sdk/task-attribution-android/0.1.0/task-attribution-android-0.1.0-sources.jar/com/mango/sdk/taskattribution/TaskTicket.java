package com.mango.sdk.taskattribution;

import java.net.URLDecoder;

/** The task center ticket a source App puts into the Play Install Referrer. */
public final class TaskTicket {
    /** Referrer parameter the source App writes: {@code referrer=mango_task_ticket%3D<ticket>}. */
    public static final String REFERRER_PARAMETER = "mango_task_ticket";
    private static final String FORMAT = "[A-Za-z0-9_-]{32,100}";

    private TaskTicket() {}

    /** @return the ticket in a raw Play Install Referrer string, or null when absent or malformed */
    public static String fromReferrer(String referrer) {
        if (referrer == null || referrer.isEmpty()) return null;
        for (String part : referrer.split("&")) {
            int equals = part.indexOf('=');
            if (equals <= 0 || !REFERRER_PARAMETER.equals(part.substring(0, equals))) continue;
            try {
                String ticket = URLDecoder.decode(part.substring(equals + 1), "UTF-8");
                return isValid(ticket) ? ticket : null;
            } catch (Exception malformed) {
                return null;
            }
        }
        return null;
    }

    public static boolean isValid(String ticket) {
        return ticket != null && ticket.matches(FORMAT);
    }
}
