package com.mg.translation.engine;

/**
 * 翻译引擎类别
 */
public enum EngineCategory {

    /**
     * AI翻译引擎（Qwen、DeepSeek等）
     * 特点：支持上下文、翻译质量高、有配额限制
     */
    AI,

    /**
     * 免费API翻译（Google、Baidu、Microsoft等）
     * 特点：免费使用、覆盖语言广、有频率限制
     */
    FREE_API,

    /**
     * RapidAPI第三方翻译
     * 特点：需要API Key、有调用次数限制
     */
    RAPID_API,

    /**
     * VIP专属翻译（Microsoft VIP、Google VIP等）
     * 特点：需要VIP权限、质量稳定
     */
    VIP
}
