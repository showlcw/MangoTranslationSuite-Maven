package com.mg.translation.http.req;

public class DeepSeekContentReq {
    private String role;
    private String content;

    public DeepSeekContentReq() {
    }

    public DeepSeekContentReq(String role, String content) {
        this.role = role;
        this.content = content;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
