package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;

/***
 * //    {
 * //        "model": "deepseek-chat",
 * //            "messages": [
 * //        {"role": "system", "content": "You are a helpful assistant."},
 * //        {"role": "user", "content": "Hello!"}
 * //        ],
 * //        "stream": false
 * //    }
 *
 * DeepSeek请求格式
 */
public class DeepSeekTranslateReq extends BaseReq {
    private List<DeepSeekContentReq> messages;
    private String model;
    private boolean stream;
    private float temperature = 0.3f;
    /**
     * DeepSeek V4 思考开关 {@code {"type":"disabled"}}。null 时 Gson 不序列化 ——
     * 本 DTO 被 ZhipuBaseTranslate(GLM)复用,只在 DeepSeek 请求里 set,避免把该参数发给 GLM。
     */
    private Thinking thinking;

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public Thinking getThinking() {
        return thinking;
    }

    public void setThinking(Thinking thinking) {
        this.thinking = thinking;
    }

    /**
     * DeepSeek V4 thinking 开关。deepseek-v4-flash/pro 默认开 thinking,翻译场景需关掉
     * (否则返回 reasoning_content、延迟成本上升,且 thinking 模式下 temperature 失效)。
     */
    public static class Thinking {
        private String type;

        public Thinking(String type) {
            this.type = type;
        }

        public static Thinking disabled() {
            return new Thinking("disabled");
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    public DeepSeekTranslateReq(List<DeepSeekContentReq> messages) {
        this.messages = messages;
    }

    public List<DeepSeekContentReq> getMessages() {
        return messages;
    }

    public void setMessages(List<DeepSeekContentReq> messages) {
        this.messages = messages;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isStream() {
        return stream;
    }

    public void setStream(boolean stream) {
        this.stream = stream;
    }


}
