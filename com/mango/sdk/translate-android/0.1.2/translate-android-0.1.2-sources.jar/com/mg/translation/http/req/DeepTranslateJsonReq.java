package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;


public class DeepTranslateJsonReq extends BaseReq {
    //"q": "Hello World!",
//        "source": "en",
//        "target": "es"
    private List<String> q;
    private String source = "auto";
    private String target;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public List<String> getQ() {
        return q;
    }

    public void setQ(List<String> q) {
        this.q = q;
    }
}
