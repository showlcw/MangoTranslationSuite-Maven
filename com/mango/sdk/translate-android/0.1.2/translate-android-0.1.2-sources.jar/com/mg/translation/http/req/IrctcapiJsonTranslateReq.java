package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;


public class IrctcapiJsonTranslateReq extends BaseReq {

    private List<String> q;
    private String source = "";
    private String target;
    private String format = "text";

    public List<String> getQ() {
        return q;
    }

    public void setQ(List<String> q) {
        this.q = q;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }


}
