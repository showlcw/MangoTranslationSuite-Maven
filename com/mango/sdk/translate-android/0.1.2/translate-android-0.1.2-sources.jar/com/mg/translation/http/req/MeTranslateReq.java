package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;

public class MeTranslateReq extends BaseReq {

    private String tl;
    private String fl = "auto";
    private String[] q;

    public String getTl() {
        return tl;
    }

    public void setTl(String tl) {
        this.tl = tl;
    }

    public String getFl() {
        return fl;
    }

    public void setFl(String fl) {
        this.fl = fl;
    }

    public String[] getQ() {
        return q;
    }

    public void setQ(String[] q) {
        this.q = q;
    }
}
