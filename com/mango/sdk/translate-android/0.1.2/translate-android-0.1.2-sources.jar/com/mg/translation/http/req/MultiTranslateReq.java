package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;


public class MultiTranslateReq extends BaseReq {

    private String q;
    private String from = "auto" ;
    private String to;
    /**
     * rapid-translate-multi requires this field even though its value must stay empty.
     */
    private String e = "";

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getE() {
        return e;
    }

    public void setE(String e) {
        this.e = e == null ? "" : e;
    }
}
