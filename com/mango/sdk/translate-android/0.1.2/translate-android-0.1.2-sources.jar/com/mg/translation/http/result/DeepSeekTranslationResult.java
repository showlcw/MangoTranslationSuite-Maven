package com.mg.translation.http.result;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * //        {"id":"a38abbc7-008b-4efc-8618-4d4ffecab67f","object":"chat.completion","created":1739095363,"model":"deepseek-chat",
 * //        "choices":[{"index":0,"message":{"role":"assistant","content":"今天是个美好的生日。"},
 * //        "logprobs":null,"finish_reason":"stop"}],"usage":{"prompt_tokens":116,"completion_tokens":5,
 * //        "total_tokens":121,"prompt_tokens_details":{"cached_tokens":64},"prompt_cache_hit_tokens":64,"prompt_cache_miss_tokens":52},
 * //        "system_fingerprint":"fp_3a5770e1b4"}
 * <p>
 * deeepseek结果返回
 */
public class DeepSeekTranslationResult {
    private List<DeepSeekChoices> choices;
    private int code;
    private String id;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<DeepSeekChoices> getChoices() {
        return choices;
    }

    public void setChoices(List<DeepSeekChoices> choices) {
        this.choices = choices;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static class DeepSeekChoices {
        private int index;
        private DeepSeekMessageResult message;
        @SerializedName("finish_reason")
        private String finishReason;

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public DeepSeekMessageResult getMessage() {
            return message;
        }

        public void setMessage(DeepSeekMessageResult message) {
            this.message = message;
        }

        public String getFinishReason() {
            return finishReason;
        }

        public void setFinishReason(String finishReason) {
            this.finishReason = finishReason;
        }
    }



}
