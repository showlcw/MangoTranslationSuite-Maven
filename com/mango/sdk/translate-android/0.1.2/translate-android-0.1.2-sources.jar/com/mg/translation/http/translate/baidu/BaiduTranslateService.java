package com.mg.translation.http.translate.baidu;

import com.mg.translation.http.result.BaiduTranslateHttpResult;
import com.mg.translation.translate.vo.TransResultBean;

import java.util.List;
import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface BaiduTranslateService {

    /**
     * 百度翻译
     *
     * @return
     */
    @POST("api/trans/vip/translate")
    Single<BaiduTranslateHttpResult<List<TransResultBean>>> baiduTranslate(@QueryMap Map<String, String> map);


}
