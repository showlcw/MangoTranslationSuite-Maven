package com.mg.translation.http.translate.deep;

import com.mg.translation.translate.vo.DeepTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface DeepTranslateService {

    /**
     * deep  translate
     *
     * @return
     */
    @POST("language/translate/v2")
    Single<DeepTranslateResult> deepTranslate(@Header("X-RapidAPI-Host") String host, @Header("X-RapidAPI-Key") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);

    /**
     * deep  translate  json
     *
     * @return
     */
    @POST("language/translate/v2")
    Single<DeepTranslateResult> deepJsonTranslate(@Header("X-RapidAPI-Host") String host, @Header("X-RapidAPI-Key") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);


}
