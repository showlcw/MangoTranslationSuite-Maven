package com.mg.translation.http.translate.google;

import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface GoogleClientTranslateService {

    /**
     * Google  free  translate
     * client
     *
     * @return
     */
    @POST("translate_a/single")
    Single<String> googleClientTranslate(@QueryMap Map<String, String> map);

}
