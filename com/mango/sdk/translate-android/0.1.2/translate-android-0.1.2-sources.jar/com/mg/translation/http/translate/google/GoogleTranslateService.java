package com.mg.translation.http.translate.google;

import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface GoogleTranslateService {

    /**
     * Google  free  translate
     *
     * @return
     */
    @FormUrlEncoded
    @POST("translate_a/single")
    Single<String> googleTranslate(@FieldMap Map<String, String> map);



}
