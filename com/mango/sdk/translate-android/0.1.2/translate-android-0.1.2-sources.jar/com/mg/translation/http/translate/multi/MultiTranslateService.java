package com.mg.translation.http.translate.multi;

import java.util.List;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface MultiTranslateService {

    /**
     * hebingbing  translate
     *
     * @return
     */
    @POST("t")
    Single<List<List<String>>> multiJsonTranslate(@Header("x-rapidapi-host") String host, @Header("x-rapidapi-key") String key, @Body RequestBody requestBody);


    /**
     * hebingbing  translate
     *
     * @return
     */
    @POST("t")
    Single<List<List<String>>> multiTranslate(@Header("x-rapidapi-host") String host, @Header("x-rapidapi-key") String key, @Body RequestBody requestBody);

}
