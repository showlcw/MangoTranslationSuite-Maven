package com.mg.translation.http.translate.qwen;

import com.mg.translation.http.result.DeepSeekTranslationResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

/** Qwen DashScope OpenAI-compatible Chat Completions API。 */
public interface QwenTranslateService {
    @POST("chat/completions")
    Single<DeepSeekTranslationResult> translate(@Header("Authorization") String apiKey,
                                                @Header("Content-type") String contentType,
                                                @Header("Accept") String accept,
                                                @Header("X-DashScope-DataInspection") String dataInspection,
                                                @Body RequestBody requestBody);
}
