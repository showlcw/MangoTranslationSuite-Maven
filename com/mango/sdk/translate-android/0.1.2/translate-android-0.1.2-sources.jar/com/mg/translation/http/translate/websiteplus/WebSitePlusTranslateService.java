package com.mg.translation.http.translate.websiteplus;

import com.mg.translation.translate.vo.PlusBatchTranslateResult;
import com.mg.translation.translate.vo.PlusTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface WebSitePlusTranslateService {

    /**
     * PLUS  translate  单条文本
     *
     * @return
     */
    @POST("v2/translate")
    Single<PlusTranslateResult> websitePlusTranslate(@Header("X-API-KEY") String key,  @Header("Content-type") String contentType, @Body RequestBody requestBody);

    /**
     * PLUS  translate  批量文本
     *
     * @return
     */
    @POST("v2/translate/batch")
    Single<PlusBatchTranslateResult> websitePlusBatchTranslate(@Header("X-API-KEY") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);

}
