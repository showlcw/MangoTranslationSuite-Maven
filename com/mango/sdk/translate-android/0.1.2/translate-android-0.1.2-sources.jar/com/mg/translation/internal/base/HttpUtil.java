package com.mg.translation.internal.base;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mg.translation.internal.base.http.req.BaseReq;

import java.io.File;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.RequestBody;


/**
 * HttpUtil 工具类，把vo转换成map
 */
public final class HttpUtil {
    private HttpUtil() { }


    /**
     * request转换为Map
     *
     * @param req
     * @return
     */
    public static Map<String, String> convertReq2Params(BaseReq req) {
        Gson gson = new Gson();
        Type type = new TypeToken<Map<String, String>>() {
        }.getType();
        return gson.fromJson(gson.toJson(req), type);
    }

    public static Map<String, String> convertListReq2Params(BaseReq req) {
        Gson gson = new Gson();
        Type type = new TypeToken<Map<String, List<String>>>() {
        }.getType();
        return gson.fromJson(gson.toJson(req), type);
    }

    /**
     * 合并列表为 JSON 数组字符串
     * 使用 Gson 进行安全的 JSON 序列化，防止 JSON 注入
     *
     * @param list 要转换的列表
     * @return JSON 数组字符串
     */
    public static <T> String joinList(List<T> list) {
        if (list == null || list.isEmpty()) {
            return "[]";
        }
        // 使用 Gson 安全地序列化，自动处理特殊字符转义
        Gson gson = new Gson();
        return gson.toJson(list);
    }

    /**
     * 多文件转换为 Map<String, RequestBody> bodyMap
     *
     * @param files
     * @param mediaType 文件类型
     * @return
     */
    public static Map<String, RequestBody> convertVo2BodyMap(List<File> files, String mediaType) {
        Map<String, RequestBody> bodyMap = new HashMap<>();
        for (int i = 0; i < files.size(); i++) {
            bodyMap.put("file" + i + "\"; filename=\"" + files.get(i).getName(), RequestBody.create(MediaType.parse(mediaType), files.get(i)));
        }
        return bodyMap;
    }


    /**
     * 将map转换为URL参数字符串
     * 对 key 和 value 进行 URL 编码，防止特殊字符破坏参数格式
     *
     * @param mParamMap 参数Map
     * @return URL编码后的参数字符串
     */
    public static String mapToParamString(Map<String, String> mParamMap) {
        if (mParamMap == null || mParamMap.isEmpty()) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        boolean first = true;

        for (Map.Entry<String, String> entry : mParamMap.entrySet()) {
            if (!first) {
                sb.append("&");
            }
            first = false;

            String key = entry.getKey();
            String val = entry.getValue();

            try {
                // URL 编码 key 和 value，防止特殊字符破坏参数格式
                sb.append(java.net.URLEncoder.encode(key, "UTF-8"));
                sb.append("=");
                if (val != null) {
                    sb.append(java.net.URLEncoder.encode(val, "UTF-8"));
                }
            } catch (java.io.UnsupportedEncodingException e) {
                // UTF-8 always supported, but handle just in case
                sb.append(key);
                sb.append("=");
                if (val != null) {
                    sb.append(val);
                }
            }
        }

        return sb.toString();
    }
}
