package com.mg.translation.internal.base;


import android.util.Log;

/**
 * 日志管理类 - 性能优化版
 *
 * 优化点：
 * 1. 使用静态final变量，编译器可内联优化
 * 2. 提供isLoggable()方法，避免不必要的字符串拼接
 * 3. Release版本通过ProGuard完全移除日志调用
 *
 * 使用建议：
 * Never pass credentials, source text, translated text, Provider bodies or full URLs.
 *
 * @author lichunwei
 */
public final class LogManager {
    private static final String TAG = "MangoTranslation";

    /**
     * 是否启用日志 - 使用静态final以便编译器优化
     * Release版本会被ProGuard优化掉
     */
    // SDK does not package BuildConfig because a host may retain the historical
    // com.mg.translation namespace. Provider bodies and credentials must not be logged.
    private static final boolean ENABLED = false;

    private LogManager() { }

    /**
     * 检查日志是否可用 - 用于热路径避免字符串拼接开销
     * 在Release版本中，此方法会被内联为false，相关代码块会被编译器优化掉
     */
    public static boolean isLoggable() {
        return ENABLED;
    }

    // ==================== Error级别 ====================

    public static void e(String msg) {
        if (ENABLED) {
            Log.e(TAG, msg);
        }
    }

    public static void e(String tag, String msg) {
        if (ENABLED) {
            Log.e(tag, msg);
        }
    }

    // ==================== Warning级别 ====================

    public static void w(String msg) {
        if (ENABLED) {
            Log.w(TAG, msg);
        }
    }

    public static void w(String tag, String msg) {
        if (ENABLED) {
            Log.w(tag, msg);
        }
    }

    // ==================== Debug级别 ====================

    public static void d(String msg) {
        if (ENABLED) {
            Log.d(TAG, msg);
        }
    }

    public static void d(String tag, String msg) {
        if (ENABLED) {
            Log.d(tag, msg);
        }
    }

    // ==================== Verbose级别 ====================

    public static void v(String msg) {
        if (ENABLED) {
            Log.v(TAG, msg);
        }
    }

    public static void v(String tag, String msg) {
        if (ENABLED) {
            Log.v(tag, msg);
        }
    }

    // ==================== Info级别 ====================

    public static void i(String msg) {
        if (ENABLED) {
            Log.i(TAG, msg);
        }
    }

    public static void i(String tag, String msg) {
        if (ENABLED) {
            Log.i(tag, msg);
        }
    }
}
