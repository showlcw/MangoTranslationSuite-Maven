package com.mg.translation.internal.base;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** MD5 helper required by the Baidu Provider signing protocol. */
public final class MD5Utils {
    private MD5Utils() { }

    public static String md5Hex(String value) {
        if (value == null) throw new IllegalArgumentException("value is required");
        try {
            byte[] digest = MessageDigest.getInstance("MD5")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder(digest.length * 2);
            for (byte item : digest) {
                result.append(Character.forDigit((item >>> 4) & 0x0f, 16));
                result.append(Character.forDigit(item & 0x0f, 16));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("Android runtime does not provide MD5", impossible);
        }
    }
}
