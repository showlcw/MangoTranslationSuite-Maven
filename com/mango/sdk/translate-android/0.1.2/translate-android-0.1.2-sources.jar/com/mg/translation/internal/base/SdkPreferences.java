package com.mg.translation.internal.base;

import android.content.Context;
import android.content.SharedPreferences;

/** SDK-private Provider cooldown and request-gate persistence. */
public final class SdkPreferences {
    private static volatile SdkPreferences instance;
    private final SharedPreferences preferences;

    private SdkPreferences(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(
                "mango_translation_sdk", Context.MODE_PRIVATE);
    }

    public static SdkPreferences getInstance(Context context) {
        if (instance == null) {
            synchronized (SdkPreferences.class) {
                if (instance == null) instance = new SdkPreferences(context);
            }
        }
        return instance;
    }

    public long getLong(String key, long fallback) { return preferences.getLong(key, fallback); }
    public void put(String key, long value) { preferences.edit().putLong(key, value).apply(); }
}
