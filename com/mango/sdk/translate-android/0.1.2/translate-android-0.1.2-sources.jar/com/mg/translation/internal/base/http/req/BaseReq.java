package com.mg.translation.internal.base.http.req;


/**
 * 请求服务器接口的参数对象
 */
public class BaseReq {

}
