package com.mg.translation.internal.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** SDK-internal mutable state for an ordered batch translation. */
public final class BatchTranslationTask extends TranslationTask {
    private List<String> sourceTexts;
    private List<String> translations;

    public BatchTranslationTask() {
    }

    public BatchTranslationTask(List<String> sourceTexts, String sourceLanguageId,
                                String targetLanguageId) {
        super(sourceLanguageId, targetLanguageId);
        setSourceTexts(sourceTexts);
    }

    public List<String> getSourceTexts() {
        return sourceTexts == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(sourceTexts);
    }

    public void setSourceTexts(List<String> sourceTexts) {
        this.sourceTexts = sourceTexts == null ? new ArrayList<>() : new ArrayList<>(sourceTexts);
        this.translations = new ArrayList<>(Collections.nCopies(this.sourceTexts.size(), null));
    }

    public List<String> getTranslations() {
        return translations == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(translations);
    }

    public String getTranslation(int index) {
        return translations.get(index);
    }

    public void setTranslation(int index, String translation) {
        translations.set(index, translation);
    }

    @Override
    public String getTranslatedText() {
        if (translations == null || translations.isEmpty()) {
            return null;
        }
        StringBuilder stringBuffer = new StringBuilder();
        for (String translation : translations) {
            if (translation != null) {
                stringBuffer.append(translation);
            }
            stringBuffer.append("\n");
        }
        return stringBuffer.toString().trim();
    }
}
