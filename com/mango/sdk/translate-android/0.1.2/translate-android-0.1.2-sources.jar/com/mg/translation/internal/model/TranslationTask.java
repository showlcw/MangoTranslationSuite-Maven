package com.mg.translation.internal.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/** SDK-internal mutable state for one translation and its fallback attempts. */
public class TranslationTask {
    private String content;
    private String sourceLanguageId;
    private String targetLanguageId;
    private List<Integer> attemptedEngineIds;
    private String translatedText;

    public TranslationTask() {
    }

    public TranslationTask(String content, String sourceLanguageId, String targetLanguageId) {
        this.content = content;
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }

    public TranslationTask(String sourceLanguageId, String targetLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }


    public String getTranslatedText() {
        return translatedText;
    }

    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceLanguageId() {
        return sourceLanguageId;
    }

    public void setSourceLanguageId(String sourceLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
    }

    public String getTargetLanguageId() {
        return targetLanguageId;
    }

    public void setTargetLanguageId(String targetLanguageId) {
        this.targetLanguageId = targetLanguageId;
    }

    public List<Integer> getAttemptedEngineIds() {
        return attemptedEngineIds == null ? Collections.emptyList()
                : Collections.unmodifiableList(attemptedEngineIds);
    }

    public void setAttemptedEngineIds(List<Integer> attemptedEngineIds) {
        this.attemptedEngineIds = attemptedEngineIds == null ? new ArrayList<>()
                : new ArrayList<>(attemptedEngineIds);
    }

}
