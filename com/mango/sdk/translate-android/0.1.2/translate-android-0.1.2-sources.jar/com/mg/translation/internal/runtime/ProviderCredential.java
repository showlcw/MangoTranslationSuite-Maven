package com.mg.translation.internal.runtime;

/** SDK 内部一次 Provider 请求使用的同组地址与密钥。 */
public final class ProviderCredential {
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    private final String domains;
    private final boolean dataInspectionEnabled;

    ProviderCredential(String baseUrl, String apiKey, String model, String domains,
                       boolean dataInspectionEnabled) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
        this.domains = domains;
        this.dataInspectionEnabled = dataInspectionEnabled;
    }

    public String getBaseUrl() { return baseUrl; }
    public String getApiKey() { return apiKey; }
    public String getModel() { return model; }
    public String getDomains() { return domains; }
    public boolean isDataInspectionEnabled() { return dataInspectionEnabled; }
}
