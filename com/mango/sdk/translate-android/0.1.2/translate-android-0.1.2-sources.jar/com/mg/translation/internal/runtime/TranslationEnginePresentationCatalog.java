package com.mg.translation.internal.runtime;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** SDK-owned localized brand names, descriptions and display order for active engines. */
public final class TranslationEnginePresentationCatalog {
    public static final class Entry {
        public final TranslatorId id;
        public final int nameRes;
        public final int descriptionRes;
        public final boolean slow;

        Entry(TranslatorId id, int nameRes, int descriptionRes, boolean slow) {
            this.id = id;
            this.nameRes = nameRes;
            this.descriptionRes = descriptionRes;
            this.slow = slow;
        }
    }

    private static final List<Entry> ENTRIES = Collections.unmodifiableList(Arrays.asList(
            new Entry(TranslatorId.GOOGLE_CLIENT, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.SELF_HOSTED_GOOGLE,
                    R.string.brand_google_translate, R.string.translate_desc_google, false),
            new Entry(TranslatorId.GOOGLE, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.GOOGLE_V, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.BAIDU, R.string.brand_baidu_translate,
                    R.string.translate_desc_baidu, false),
            new Entry(TranslatorId.BD, R.string.brand_baidu_translate,
                    R.string.translate_desc_baidu, false),
            new Entry(TranslatorId.MICROSOFT, R.string.brand_microsoft_translator,
                    R.string.translate_desc_microsoft, false),
            new Entry(TranslatorId.MICROSOFT_VIP, R.string.brand_microsoft_translator,
                    R.string.translate_desc_microsoft, false),
            new Entry(TranslatorId.MYMEMORY, R.string.brand_mymemory,
                    R.string.translate_desc_mymemory, false),
            new Entry(TranslatorId.YOUDAO_ME, R.string.brand_youdao_translate,
                    R.string.translate_desc_youdao, false),
            new Entry(TranslatorId.YOUDAO, R.string.brand_youdao_translate,
                    R.string.translate_desc_youdao, false),
            new Entry(TranslatorId.DEEPSEEK, R.string.brand_deepseek,
                    R.string.translate_desc_deepseek, true),
            new Entry(TranslatorId.ZHIPU_FLASH, R.string.brand_glm,
                    R.string.translate_desc_zhipu, true),
            new Entry(TranslatorId.QWEN, R.string.brand_qwen_mt,
                    R.string.translate_desc_qwen, true),
            new Entry(TranslatorId.RAPID_AI, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.RAPID_DEEP, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.RAPID_PLUS, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.RAPID_WEBSITE_PLUS, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.RAPID_MULTI, R.string.brand_google_translate,
                    R.string.translate_desc_google, false),
            new Entry(TranslatorId.RAPID_IRCTCAPI, R.string.brand_google_translate,
                    R.string.translate_desc_google, false)
    ));

    private TranslationEnginePresentationCatalog() { }

    public static List<Entry> entries() { return ENTRIES; }

    public static Entry find(int legacyCode) {
        for (Entry entry : ENTRIES) {
            if (entry.id.legacyCode == legacyCode) return entry;
        }
        return null;
    }
}
