package com.mg.translation.internal.runtime;

import com.mango.sdk.translation.R;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.sdk.TranslationErrorCategory;
import com.mg.translation.sdk.TranslationErrorCode;

public final class TranslationErrorMapper {
    private TranslationErrorMapper() { }

    public static TranslationError fromInternalCode(int providerCode, int engineId) {
        switch (providerCode) {
            case TranslationErrorCode.INVALID_REQUEST:
                return error(providerCode, TranslationErrorCategory.VALIDATION,
                        R.string.translation_error_invalid_request, engineId, 0, false, false);
            case TranslationErrorCode.SDK_NOT_INITIALIZED:
                return error(providerCode, TranslationErrorCategory.SDK_STATE,
                        R.string.translation_error_sdk_not_initialized, engineId, 0,
                        false, false);
            case TranslationErrorCode.ENGINE_NOT_CONFIGURED:
                return error(providerCode, TranslationErrorCategory.CONFIGURATION,
                        R.string.translation_error_engine_not_configured, engineId, 0,
                        false, false);
            case TranslationErrorCode.ENGINE_RETIRED:
                return error(providerCode, TranslationErrorCategory.CONFIGURATION,
                        R.string.translation_error_engine_retired, engineId, 0,
                        false, false);
            case TranslationErrorCode.UNSUPPORTED_LANGUAGE:
                return error(providerCode, TranslationErrorCategory.LANGUAGE,
                        R.string.translation_error_unsupported_language, engineId, 0,
                        false, false);
            case TranslationErrorCode.VIP_REQUIRED:
                return error(TranslationErrorCode.VIP_REQUIRED,
                        TranslationErrorCategory.ENTITLEMENT,
                        R.string.translation_error_vip_required, engineId, 0,
                        false, true);
            case TranslationErrorCode.QUOTA_EXHAUSTED:
                return error(providerCode, TranslationErrorCategory.QUOTA,
                        R.string.translation_error_quota_exhausted, engineId, 0, false, true);
            case TranslationErrorCode.NETWORK_UNAVAILABLE:
                return error(TranslationErrorCode.NETWORK_UNAVAILABLE,
                        TranslationErrorCategory.NETWORK,
                        R.string.translation_error_network_unavailable, engineId, 0,
                        true, false);
            case TranslationErrorCode.REQUEST_TIMEOUT:
            case 408:
            case 504:
                return error(TranslationErrorCode.REQUEST_TIMEOUT,
                        TranslationErrorCategory.NETWORK,
                        R.string.translation_error_timeout, engineId,
                        providerCode == TranslationErrorCode.REQUEST_TIMEOUT ? 0 : providerCode,
                        true, false);
            case TranslationErrorCode.RATE_LIMITED:
            case 429:
                return error(TranslationErrorCode.RATE_LIMITED,
                        TranslationErrorCategory.PROVIDER,
                        R.string.translation_error_rate_limited, engineId,
                        providerCode == TranslationErrorCode.RATE_LIMITED ? 0 : providerCode,
                        true, false);
            case TranslationErrorCode.PROVIDER_AUTHENTICATION_FAILED:
            case 401:
            case 403:
                return error(TranslationErrorCode.PROVIDER_AUTHENTICATION_FAILED,
                        TranslationErrorCategory.PROVIDER,
                        R.string.translation_error_provider_authentication, engineId,
                        providerCode == TranslationErrorCode.PROVIDER_AUTHENTICATION_FAILED
                                ? 0 : providerCode,
                        false, false);
            case TranslationErrorCode.PROVIDER_UNAVAILABLE:
            case 404:
            case 500:
            case 502:
            case 503:
                return error(TranslationErrorCode.PROVIDER_UNAVAILABLE,
                        TranslationErrorCategory.PROVIDER,
                        R.string.translation_error_provider_unavailable, engineId,
                        providerCode == TranslationErrorCode.PROVIDER_UNAVAILABLE
                                ? 0 : providerCode,
                        true, false);
            case TranslationErrorCode.INVALID_PROVIDER_RESPONSE:
            case 400:
            case 422:
                return error(TranslationErrorCode.INVALID_PROVIDER_RESPONSE,
                        TranslationErrorCategory.PROVIDER,
                        R.string.translation_error_invalid_response, engineId,
                        providerCode == TranslationErrorCode.INVALID_PROVIDER_RESPONSE
                                ? 0 : providerCode,
                        true, false);
            case TranslationErrorCode.ALL_ENGINES_FAILED:
                return error(TranslationErrorCode.ALL_ENGINES_FAILED,
                        TranslationErrorCategory.PROVIDER,
                        R.string.translation_error_all_engines_failed, engineId, 0,
                        true, false);
            case TranslationErrorCode.CANCELLED:
                return error(providerCode, TranslationErrorCategory.CANCELLED,
                        R.string.translation_error_cancelled, engineId, 0, false, false);
            case TranslationErrorCode.UNKNOWN:
                return error(providerCode, TranslationErrorCategory.UNKNOWN,
                        R.string.translation_error_unknown, engineId, 0, false, false);
            default:
                return new TranslationError(TranslationErrorCode.UNKNOWN,
                        TranslationErrorCategory.UNKNOWN,
                        TranslationRuntime.get().string(R.string.translation_error_unknown),
                        engineId, providerCode, false, false);
        }
    }

    public static TranslationError vipRequired(int engineId) {
        return error(TranslationErrorCode.VIP_REQUIRED,
                TranslationErrorCategory.ENTITLEMENT,
                R.string.translation_error_vip_required, engineId, 0, false, true);
    }

    public static TranslationError invalidRequest(int engineId) {
        return error(TranslationErrorCode.INVALID_REQUEST,
                TranslationErrorCategory.VALIDATION,
                R.string.translation_error_invalid_request, engineId, 0, false, false);
    }

    private static TranslationError error(int code, TranslationErrorCategory category,
                                          int messageRes, int engineId, int providerCode,
                                          boolean retryable, boolean purchaseRequired) {
        return new TranslationError(code, category, TranslationRuntime.get().string(messageRes),
                engineId, providerCode, retryable, purchaseRequired);
    }
}
