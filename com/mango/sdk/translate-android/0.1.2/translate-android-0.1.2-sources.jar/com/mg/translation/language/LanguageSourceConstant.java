package com.mg.translation.language;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/8 15:43
 */
public final class LanguageSourceConstant {

    // A
    private static final String Abkhaz_local = "аҧсуа";
    private static final String Abkhazian_local = "аҧсуа";
    private static final String Aceh_local = "Acèh";
    private static final String Acehnese_local = "Acèh";
    private static final String Acholi_local = "Acholi";
    private static final String Adangme_local = "Adangme";
    private static final String Afar_local = "Afar";
    private static final String Afrikaans_local = "Afrikaans";
    private static final String Afrikaans_Namibia_local = "Afrikaans (Namibia)";
    private static final String Aghem_local = "Aghem";
    private static final String Akan_local = "Akan";
    private static final String Albanian_local = "Shqiptare";
    private static final String Algerian_Arabic_local = "الآلبريا";
    private static final String Alur_local = "Alur";
    private static final String Amharic_local = "አማርኛ";
    private static final String Ancient_Greek_local = "Ἑλληνική";
    private static final String Angika_local = "अंगिका";
    private static final String Arabic_local = "عربي";
    private static final String Arabic_Oman_local = "العربية (عمان)";
    private static final String Arabic_Yemen_local = "العربية (اليمن)";
    private static final String Aragonese_local = "Aragonés";
    private static final String Aragorn_local = "Aragorn";
    private static final String Armenian_local = "հայերեն";
    private static final String Assamese_local = "অসমীয়া";
    private static final String Asturian_local = "Asturianu";
    private static final String Avar_local = "авар";
    private static final String Awadhi_local = "अवधी";
    private static final String Aymara_local = "Aymara";
    private static final String Azerbaijani_local = "Azərbaycan";

    // B
    private static final String Balinese_local = "Bali";
    private static final String Baluchi_local = "بلوچی";
    private static final String Bambara_local = "Bamanankan";
    private static final String Baoule_local = "Baoulé";
    private static final String Bashkir_local = "башҡорт";
    private static final String Basque_local = "Euskara";
    private static final String Bassa_local = "Bassa";
    private static final String Batak_Karo_local = "Karo";
    private static final String Batak_Simalungun_local = "Simalungun";
    private static final String Batak_Toba_local = "Batak Toba";
    private static final String Bavarian_local = "Boarisch";
    private static final String Belarusian_local = "беларуская";
    private static final String Bemba_local = "Ichibemba";
    private static final String Bengali_local = "বাংলা";
    private static final String Berber_local = "Tamazight";
    private static final String Betawi_local = "Betawi";
    private static final String Bgojpur_local = "भोजपुरी";
    private static final String Bhojpur_local = "भोजपुर के ह";
    private static final String Bhojpuri_local = "भोजपुरी";
    private static final String Bikol_local = "Bikol";
    private static final String Biling_local = "Blin";
    private static final String Bislama_local = "Bislama";
    private static final String Bodo_local = "बड़ो";
    private static final String Bosnian_local = "Bosanski";
    private static final String Breton_local = "Brezhoneg";
    private static final String Bulgarian_local = "български";
    private static final String Bulu_local = "Bulu";
    private static final String Bumba_local = "Ichibemba";
    private static final String Burmese_local = "မြန်မာ";
    private static final String Buryat_local = "буряад";

    // C
    private static final String Caddo_local = "Caddo";
    private static final String Cantonese_local = "粵語";
    private static final String Catalan_local = "Català";
    private static final String Cebuano_local = "Cebuano";
    private static final String Cham_local = "Cham";
    private static final String Chamorro_local = "Chamoru";
    private static final String Chechen_local = "нохчийн";
    private static final String Cherokee_local = "ᏣᎳᎩ";
    private static final String Chichewa_local = "Chichewa";
    private static final String Chiga_local = "Rukiga";
    private static final String Chinese_local = "中文";
    private static final String Chuukese_local = "Chuuk";
    private static final String Chuvash_local = "чӑваш";
    private static final String Congo_local = "Kongo";
    private static final String Cornish_local = "Kernowek";
    private static final String Corsican_local = "Corsu";
    private static final String Creek_local = "Mvskoke";
    private static final String Crimean_Tatar_local = "Qırımtatar";
    private static final String Crimean_Tatar_Latin_local = "Qırımtatar (Latin)";
    private static final String Croatian_local = "Hrvatski";
    private static final String Czech_local = "čeština";

    // D
    private static final String Danish_local = "Dansk";
    private static final String Dari_local = "دری";
    private static final String Dhivehi_local = "ދިވެހި";
    private static final String Dinka_local = "Thuɔŋjäŋ";
    private static final String Dogri_local = "डोगरी";
    private static final String Dombe_local = "ChiDombe";
    private static final String Dutch_local = "Nederlands";
    private static final String Dyula_local = "Dyula";
    private static final String Dzongkha_local = "རྫོང་ཁ";

    // E
    private static final String Eastern_Huasteca_Nahuatl_local = "Huasteco del este";
    private static final String English_local = "English";
    private static final String Esperanto_local = "Esperanto";
    private static final String Estonian_local = "Eesti keel";
    private static final String Ewe_local = "Èʋegbe";

    // F
    private static final String Faroese_local = "Farsisk";
    private static final String Fijian_local = "Na vosa Vakaviti";
    private static final String Filipino_local = "Pilipino";
    private static final String Finnish_local = "Finsk";
    private static final String Fon_local = "Fon";
    private static final String French_local = "Français";
    private static final String French_Canada_local = "Français (Canada)";
    private static final String Frisian_local = "Frisian";
    private static final String Friuli_local = "Furlan";
    private static final String Friulian_local = "Furlan";
    private static final String Fula_local = "Fulfulde";
    private static final String Fulani_local = "Fulfulde";

    // G
    private static final String Ga_local = "Ga";
    private static final String Gaelic_local = "Ghàidhlig";
    private static final String Galician_local = "Galego";
    private static final String Georgian_local = "ქართული";
    private static final String German_local = "Deutsch";
    private static final String Greek_local = "Ελληνικά";
    private static final String Greenlandic_local = "Kalaallisut";
    private static final String Guarani_local = "Guaraní";
    private static final String Gujarati_local = "ગુજરાતી";

    // H
    private static final String Hakachin_local = "Hakha Chin";
    private static final String Hakha_Chin_local = "Hakha Chin";
    private static final String Haitian_local = "Ayisyen";
    private static final String Hausa_local = "Hausa";
    private static final String Hawaiian_local = "Ōlelo Hawaiʻi";
    private static final String Hebrew_local = "עִברִית";
    private static final String Highland_Sorbian_local = "Hornjoserbšćina";
    private static final String Hiligaynon_local = "Ilonggo";
    private static final String Hiliganun_local = "Ilonggo";
    private static final String Hill_Mari_local = "кырык мары";
    private static final String Hindi_local = "हिंदी";
    private static final String Hmong_local = "Hmoob";
    private static final String Hungarian_local = "Magyar";
    private static final String Hunsrik_local = "Hunsrik";
    private static final String Hupa_local = "Hupa";

    // I
    private static final String Iban_local = "Jaku Iban";
    private static final String Icelandic_local = "íslenskur";
    private static final String Ido_local = "Ido";
    private static final String Igbo_local = "Igbo";
    private static final String Ilocano_local = "Ilocano";
    private static final String Indonesian_local = "Bahasa Indonesia";
    private static final String Ingush_local = "ГӀалгӀай";
    private static final String Inter_local = "Interlingua";
    private static final String Inuktitut_local = "ᐃᓄᒃᑎᑐᑦ";
    private static final String Inuktut_local = "ᐃᓄᒃᑎᑐᑦ";
    private static final String Inuktut_Latin_local = "Inuktut (Latin)";
    private static final String Iranian_local = "فارسی";
    private static final String Irish_local = "Gaeilge";
    private static final String Italian_local = "Italiano";

    // J
    private static final String Jamaican_Patois_local = "Jamaican Patois";
    private static final String Japanese_local = "日本";
    private static final String Javanese_local = "Basa jawa";
    private static final String Jingpo_local = "Jingpho";

    // K
    private static final String Kabyle_local = "Taqbaylit";
    private static final String Kalaallisut_local = "Kalaallisut";
    private static final String Kannada_local = "ಕನ್ನಡ";
    private static final String Kanuri_local = "Kanuri";
    private static final String Kapampangan_local = "Kapampangan";
    private static final String Kashmiri_local = "कॉशुर";
    private static final String Kashubian_local = "Kaszëbsczi";
    private static final String Kazakh_local = "ҚАЗАҚ";
    private static final String Kekchi_local = "Q'eqchi'";
    private static final String Khasi_local = "Khasi";
    private static final String Khmer_local = "ខ្មែរ";
    private static final String Kiga_local = "Rukiga";
    private static final String Kinyarwanda_local = "Kinyarwanda";
    private static final String Kirundi_local = "Kirundi";
    private static final String Kituba_local = "Kituba";
    private static final String Klingon_local = "tlhIngan Hol";
    private static final String Kokborok_local = "Kokborok";
    private static final String Komi_local = "коми";
    private static final String Konkani_local = "कोंकणी";
    private static final String Kongo_local = "Kongo";
    private static final String Korean_local = "한국어";
    private static final String Krio_local = "Krio";
    private static final String Kurdish_local = "Kurdî";
    private static final String Kurdish_Sorani_local = "سۆرانی";
    private static final String Kyrgyz_local = "Кыргызча";

    // L
    private static final String Lao_local = "ພາສາລາວ";
    private static final String Latgalian_local = "Latgalīšu";
    private static final String Latjalai_local = "Latgalīšu";
    private static final String Latin_local = "Latinus";
    private static final String Latvian_local = "Latviski";
    private static final String Ligurian_local = "Ligure";
    private static final String Limburgish_local = "Limburgs";
    private static final String Lingala_local = "Ngala";
    private static final String Lithuanian_local = "Lietuvių";
    private static final String Logical_language_local = "Lojban";
    private static final String Lombard_local = "Lombard";
    private static final String Lower_Sorbian_local = "dolnoserbšćina";
    private static final String Luba_Kasai_local = "Tshiluba";
    private static final String Luganda_local = "Luganda";
    private static final String Luo_local = "Dholuo";
    private static final String Luxembourgish_local = "Lëtzebuergesch";

    // M
    private static final String Macedonian_local = "македонски";
    private static final String Madurese_local = "Madhurâ";
    private static final String Makasar_local = "Makassar";
    private static final String Makassar_local = "Makassar";
    private static final String Makhuwa_local = "Makhuwa";
    private static final String Malagasy_local = "Malagasy";
    private static final String Malay_local = "Melayu";
    private static final String Malay_Arabic_local = "ملايو (عربي)";
    private static final String Malay_Jawi_local = "ملايو (جاوي)";
    private static final String Malayalam_local = "മലയാളം";
    private static final String Maltese_local = "Malti";
    private static final String Mam_local = "Mam";
    private static final String Manipuri_Bengali_local = "মৈতৈলোন্";
    private static final String Manks_local = "Manx";
    private static final String Manx_local = "Manx";
    private static final String Maori_local = "Maori";
    private static final String Marathi_local = "मराठी";
    private static final String Mari_local = "марий";
    private static final String Marshallese_local = "Ebon";
    private static final String Marwari_local = "मारवाड़ी";
    private static final String Mauritian_Creole_local = "Kreyòl Morisyen";
    private static final String Meadow_Mari_local = "олык марий";
    private static final String Meiteilon_local = "মৈতৈলোন্";
    private static final String Mende_local = "Mɛnde";
    private static final String Minangkabau_local = "Minangkabau";
    private static final String Mizo_local = "Mizo tawng";
    private static final String Mongolian_local = "Монгол";
    private static final String Montenegrin_local = "Crnogorski";

    // N
    private static final String Nahuatl_local = "Nahuatl";
    private static final String Navajo_local = "Diné bizaad";
    private static final String Ndau_local = "chiNdau";
    private static final String Neapolitan_local = "Napulitano";
    private static final String Nepali_local = "नेपाली";
    private static final String Newari_local = "नेवारी";
    private static final String Nko_local = "ߒߞߏ";
    private static final String Northern_Sami_local = "Davvisámegiella";
    private static final String Northern_Sotho_local = "Sesotho sa Leboa";
    private static final String Northern_Sptho_local = "Sesotho sa Leboa";
    private static final String Norwegian_local = "Norsk";
    private static final String Nuer_local = "Thok Naath";
    private static final String Nuer_Ethiopia_local = "Thok Naath (Ethiopia)";
    private static final String Nyanja_local = "Chichewa, Chinyanja";
    private static final String Nyankole_local = "Runyankore";

    // O
    private static final String Occitan_local = "Occitan, lenga d'òc, provençal";
    private static final String Ojibwa_local = "Anishinaabemowin, ᐊᓂᔑᓈᐯᒧᐎᓐ";
    private static final String Ojibwe_local = "Anishinaabemowin";
    private static final String Oriya_local = "ଓଡ଼ିଆ";
    private static final String Oromo_local = "Afaan Oromoo";
    private static final String Ossetian_local = "Осетион";

    // P
    private static final String Pampanga_local = "Kapampangan";
    private static final String Pangasinan_local = "Pangasinan";
    private static final String Pangwa_local = "Ekipangwa";
    private static final String Papiamento_local = "Papiamentu";
    private static final String Pashto_local = "پښتو";
    private static final String Persian_local = "فارسی";
    private static final String Polish_local = "Polski";
    private static final String Portuguese_local = "Português";
    private static final String Portuguese_Brazil_local = "Português (Brasil)";
    private static final String Portuguese_Portugal_local = "Português (Portugal)";
    private static final String Punjabi_local = "ਪੰਜਾਬੀ";
    private static final String Punjabi_Arabic_local = "پنجابی (عربی)";

    // Q
    private static final String Qeqchi_local = "Q'eqchi'";
    private static final String Quechua_local = "Kechua / Runa Simi";

    // R
    private static final String Romani_local = "Romani";
    private static final String Romanian_local = "Română";
    private static final String Romansh_local = "Rumantsch";
    private static final String Romany_local = "Romanie";
    private static final String Rundi_local = "Kirundi";
    private static final String Russian_local = "русский";
    private static final String Rusynian_local = "русиньскый";

    // S
    private static final String Saho_local = "Saho";
    private static final String Sakha_local = "саха";
    private static final String Sami_local = "Sámegiella";
    private static final String Samoan_local = "Samoa";
    private static final String Sango_local = "yângâ tî sängö";
    private static final String Sanskrit_local = "संस्कृत";
    private static final String Santali_local = "ᱥᱟᱱᱛᱟᱲᱤ";
    private static final String Santali_Latin_local = "Santali (Latin)";
    private static final String Sardinian_local = "Sardu";
    private static final String Scottish_Gaelic_local = "Gàidhlig";
    private static final String Scots_local = "Scots";
    private static final String Sepedi_local = "Sepedi";
    private static final String Serbian_local = "Српски";
    private static final String Seychellois_Creole_local = "Kreol Seselwa";
    private static final String Shan_local = "ၵႂၢမ်းတႆး";
    private static final String Shona_local = "Shona";
    private static final String Sicilian_local = "Sicilianu";
    private static final String Silesian_local = "Ślōnski";
    private static final String Sindhi_local = "سنڌي";
    private static final String Sinhala_local = "සිංහල";
    private static final String Slovak_local = "Slovenský";
    private static final String Slovenian_local = "Slovenščina";
    private static final String Somali_local = "Soomaali";
    private static final String Songhai_local = "Songhay";
    private static final String Sorani_local = "سۆرانی";
    private static final String South_Ndebele_local = "isiNdebele";
    private static final String Southern_Ndebele_local = "isiNdebele";
    private static final String Southern_Sotho_local = "Sesotho";
    private static final String Spanish_local = "Español";
    private static final String Sundanese_local = "Basa Sunda";
    private static final String Susu_local = "Susu";
    private static final String Swahili_local = "Swahili";
    private static final String Swati_local = "siSwati";
    private static final String Swedish_local = "Svenska";
    private static final String Syriac_local = "ܣܘܪܝܝܐ";

    // T
    private static final String Tagalog_local = "Tagalog";
    private static final String Tahitian_local = "Reo Tahiti";
    private static final String Tajik_local = "тоҷикӣ";
    private static final String Tamazight_local = "Tamazight";
    private static final String Tamazight_Latin_local = "Tamazight (Latin)";
    private static final String Tamil_local = "தமிழ்";
    private static final String Tatar_local = "Татар";
    private static final String Telugu_local = "తెలుగు";
    private static final String Teton_local = "Lakȟótiyapi";
    private static final String Tetum_local = "Tetun";
    private static final String Thai_local = "ไทย";
    private static final String Tibetan_local = "བོད་ཡིག";
    private static final String Tigrinya_local = "ትግሪኛ";
    private static final String Tiv_local = "Tiv";
    private static final String Tok_Pisin_local = "Tok Pisin";
    private static final String Tongan_local = "lea fakatonga";
    private static final String Traditional_Chinese_local = "中文繁體";
    private static final String Tsonga_local = "Xitsonga";
    private static final String Tsunga_local = "Xitsonga";
    private static final String Tswana_local = "Setswana";
    private static final String Tulu_local = "ತುಳು";
    private static final String Tumbuka_local = "chiTumbuka";
    private static final String Tunisian_Arabic_local = "تونسي";
    private static final String Turkish_local = "Türk";
    private static final String Turkmen_local = "Türkmenler";
    private static final String Tuvan_local = "тыва";
    private static final String Twi_local = "Twi";

    // U
    private static final String Udmurt_local = "удмурт";
    private static final String Ukrainian_local = "український";
    private static final String Urdu_local = "اردو";
    private static final String Uyghur_local = "ئۇيغۇرچە";
    private static final String Uzbek_local = "o'zbek";

    // V
    private static final String Venda_local = "Tshivenḓa";
    private static final String Venetian_local = "Vèneto";
    private static final String Vietnamese_local = "Tiếng Việt";

    // W
    private static final String Walloon_local = "Walon";
    private static final String Waray_local = "Winaray";
    private static final String Welsh_local = "Cymraeg";
    private static final String Western_Frisian_local = "Frysk";
    private static final String Wolof_local = "Wolof";

    // X
    private static final String Xhosa_local = "IsiXhosa";

    // Y
    private static final String Yiddish_local = "יידיש";
    private static final String Yoruba_local = "Yoruba";
    private static final String Yucatec_Maya_local = "Màaya T'àan";

    // Z
    private static final String Zande_local = "Zande";
    private static final String Zapotec_local = "Zapoteco";
    private static final String Zazaqi_local = "Zazaki";
    private static final String Zhuang_local = "壯語";
    private static final String Zulu_local = "Zulu";

    // Recognition identifiers added after the original Voice mapping table.
    private static final String Limburgan_local = "Lèmbörgs";
    private static final String Maithili_local = "मैथिली";
    private static final String Punjabi_Shahmukhi_local = "پنجابی (شاہ مکھی)";
    private static final String Egyptian_Arabic_local = "العربية المصرية";
    private static final String Mesopotamian_Arabic_local = "العربية العراقية";
    private static final String Moroccan_Arabic_local = "العربية المغربية";
    private static final String Najdi_Arabic_local = "العربية النجدية";
    private static final String North_Levantine_Arabic_local = "العربية الشامية الشمالية";
    private static final String South_Levantine_Arabic_local = "العربية الشامية الجنوبية";
    private static final String Taizzi_Adeni_Arabic_local = "العربية التعزية العدنية";
    private static final String Norwegian_Bokmal_local = "Norsk bokmål";
    private static final String Norwegian_Nynorsk_local = "Norsk nynorsk";
    private static final String Bambara_Nko_local = "ߓߡߊߣߊߣߞߊߣ (ߒߞߏ)";
    private static final String Spanish_Mexico_local = "Español (México)";
    private static final String Chhattisgarhi_local = "छत्तीसगढ़ी";
    private static final String Inuinnaqtun_local = "Inuinnaqtun";
    private static final String Kurdish_Northern_local = "Kurmancî";
    private static final String Literary_Chinese_local = "文言文";
    private static final String Mongolian_Cyrillic_local = "Монгол (кирилл)";
    private static final String Mongolian_Traditional_local = "ᠮᠣᠩᠭᠣᠯ ᠬᠡᠯᠡ";
    private static final String Queretaro_Otomi_local = "Hñäñho";
    private static final String Serbian_Latin_local = "Srpski (latinica)";
    private static final String Serbian_Cyrillic_local = "Српски (ћирилица)";
    private static final String Klingon_Piqad_local = "tlhIngan Hol (pIqaD)";
    private static final String Old_English_local = "Ænglisc";
    private static final String Middle_French_local = "Moyen français";
    private static final String Low_German_local = "Plattdüütsch";
    private static final String Serbo_Croatian_local = "Srpskohrvatski / Српскохрватски";

    // Special
    private static final String Auto_local = "Auto";


    public static String getOriginalLanguage(String language) {

        if (LanguageConstant.LIMBURGAN.equals(language)) return Limburgan_local;
        if (LanguageConstant.MAITHILI.equals(language)) return Maithili_local;
        if (LanguageConstant.PUNJABI_SHAHMUKHI.equals(language)) return Punjabi_Shahmukhi_local;
        if (LanguageConstant.EGYPTIAN_ARABIC.equals(language)) return Egyptian_Arabic_local;
        if (LanguageConstant.MESOPOTAMIAN_ARABIC.equals(language)) return Mesopotamian_Arabic_local;
        if (LanguageConstant.MOROCCAN_ARABIC.equals(language)) return Moroccan_Arabic_local;
        if (LanguageConstant.NAJDI_ARABIC.equals(language)) return Najdi_Arabic_local;
        if (LanguageConstant.NORTH_LEVANTINE_ARABIC.equals(language)) return North_Levantine_Arabic_local;
        if (LanguageConstant.SOUTH_LEVANTINE_ARABIC.equals(language)) return South_Levantine_Arabic_local;
        if (LanguageConstant.TAIZZI_ADENI_ARABIC.equals(language)) return Taizzi_Adeni_Arabic_local;
        if (LanguageConstant.NORWEGIAN_BOKMAL.equals(language)) return Norwegian_Bokmal_local;
        if (LanguageConstant.NORWEGIAN_NYNORSK.equals(language)) return Norwegian_Nynorsk_local;
        if (LanguageConstant.BAMBARA_NKO.equals(language)) return Bambara_Nko_local;
        if (LanguageConstant.SPANISH_MEXICO.equals(language)) return Spanish_Mexico_local;
        if (LanguageConstant.CHHATTISGARHI.equals(language)) return Chhattisgarhi_local;
        if (LanguageConstant.INUINNAQTUN.equals(language)) return Inuinnaqtun_local;
        if (LanguageConstant.KURDISH_NORTHERN.equals(language)) return Kurdish_Northern_local;
        if (LanguageConstant.LITERARY_CHINESE.equals(language)) return Literary_Chinese_local;
        if (LanguageConstant.MONGOLIAN_CYRILLIC.equals(language)) return Mongolian_Cyrillic_local;
        if (LanguageConstant.MONGOLIAN_TRADITIONAL.equals(language)) return Mongolian_Traditional_local;
        if (LanguageConstant.QUERETARO_OTOMI.equals(language)) return Queretaro_Otomi_local;
        if (LanguageConstant.SERBIAN_LATIN.equals(language)) return Serbian_Latin_local;
        if (LanguageConstant.SERBIAN_CYRILLIC.equals(language)) return Serbian_Cyrillic_local;
        if (LanguageConstant.KLINGON_PIQAD.equals(language)) return Klingon_Piqad_local;
        if (LanguageConstant.OLD_ENGLISH.equals(language)) return Old_English_local;
        if (LanguageConstant.MIDDLE_FRENCH.equals(language)) return Middle_French_local;
        if (LanguageConstant.LOW_GERMAN.equals(language)) return Low_German_local;
        if (LanguageConstant.SERBO_CROATIAN.equals(language)) return Serbo_Croatian_local;

        // A
        if (LanguageConstant.ABKHAZ.equals(language)) {
            return LanguageSourceConstant.Abkhaz_local;
        }
        if (LanguageConstant.ABKHAZIAN.equals(language)) {
            return LanguageSourceConstant.Abkhazian_local;
        }
        if (LanguageConstant.ACEH.equals(language)) {
            return LanguageSourceConstant.Aceh_local;
        }
        if (LanguageConstant.ACEHNESE.equals(language)) {
            return LanguageSourceConstant.Acehnese_local;
        }
        if (LanguageConstant.ACHOLI.equals(language)) {
            return LanguageSourceConstant.Acholi_local;
        }
        if (LanguageConstant.ADANGME.equals(language)) {
            return LanguageSourceConstant.Adangme_local;
        }
        if (LanguageConstant.AFAR.equals(language)) {
            return LanguageSourceConstant.Afar_local;
        }
        if (LanguageConstant.AFRIKAANS.equals(language)) {
            return LanguageSourceConstant.Afrikaans_local;
        }
        if (LanguageConstant.AFRIKAANS_NAMIBIA.equals(language)) {
            return LanguageSourceConstant.Afrikaans_Namibia_local;
        }
        if (LanguageConstant.AGHEM.equals(language)) {
            return LanguageSourceConstant.Aghem_local;
        }
        if (LanguageConstant.AKAN.equals(language)) {
            return LanguageSourceConstant.Akan_local;
        }
        if (LanguageConstant.ALBANIAN.equals(language)) {
            return LanguageSourceConstant.Albanian_local;
        }
        if (LanguageConstant.ALGERIAN_ARABIC.equals(language)) {
            return LanguageSourceConstant.Algerian_Arabic_local;
        }
        if (LanguageConstant.ALUR.equals(language)) {
            return LanguageSourceConstant.Alur_local;
        }
        if (LanguageConstant.AMHARIC.equals(language)) {
            return LanguageSourceConstant.Amharic_local;
        }
        if (LanguageConstant.ANCIENT_GREEK.equals(language)) {
            return LanguageSourceConstant.Ancient_Greek_local;
        }
        if (LanguageConstant.ANGIKA.equals(language)) {
            return LanguageSourceConstant.Angika_local;
        }
        if (LanguageConstant.ARABIC.equals(language)) {
            return LanguageSourceConstant.Arabic_local;
        }
        if (LanguageConstant.ARABIC_OMAN.equals(language)) {
            return LanguageSourceConstant.Arabic_Oman_local;
        }
        if (LanguageConstant.ARABIC_YEMEN.equals(language)) {
            return LanguageSourceConstant.Arabic_Yemen_local;
        }
        if (LanguageConstant.ARAGONESE.equals(language)) {
            return LanguageSourceConstant.Aragonese_local;
        }
        if (LanguageConstant.ARAGORN.equals(language)) {
            return LanguageSourceConstant.Aragorn_local;
        }
        if (LanguageConstant.ARMENIAN.equals(language)) {
            return LanguageSourceConstant.Armenian_local;
        }
        if (LanguageConstant.ASSAMESE.equals(language)) {
            return LanguageSourceConstant.Assamese_local;
        }
        if (LanguageConstant.ASTURIAN.equals(language)) {
            return LanguageSourceConstant.Asturian_local;
        }
        if (LanguageConstant.AVAR.equals(language)) {
            return LanguageSourceConstant.Avar_local;
        }
        if (LanguageConstant.AWADHI.equals(language)) {
            return LanguageSourceConstant.Awadhi_local;
        }
        if (LanguageConstant.AYMARA.equals(language)) {
            return LanguageSourceConstant.Aymara_local;
        }
        if (LanguageConstant.AZERBAIJANI.equals(language)) {
            return LanguageSourceConstant.Azerbaijani_local;
        }

        // B
        if (LanguageConstant.BALINESE.equals(language)) {
            return LanguageSourceConstant.Balinese_local;
        }
        if (LanguageConstant.BALUCHI.equals(language)) {
            return LanguageSourceConstant.Baluchi_local;
        }
        if (LanguageConstant.BAMBARA.equals(language)) {
            return LanguageSourceConstant.Bambara_local;
        }
        if (LanguageConstant.BAOULE.equals(language)) {
            return LanguageSourceConstant.Baoule_local;
        }
        if (LanguageConstant.BASHKIR.equals(language)) {
            return LanguageSourceConstant.Bashkir_local;
        }
        if (LanguageConstant.BASQUE.equals(language)) {
            return LanguageSourceConstant.Basque_local;
        }
        if (LanguageConstant.BASSA.equals(language)) {
            return LanguageSourceConstant.Bassa_local;
        }
        if (LanguageConstant.BATAK_KARO.equals(language)) {
            return LanguageSourceConstant.Batak_Karo_local;
        }
        if (LanguageConstant.BATAK_SIMALUNGUN.equals(language)) {
            return LanguageSourceConstant.Batak_Simalungun_local;
        }
        if (LanguageConstant.BATAK_TOBA.equals(language)) {
            return LanguageSourceConstant.Batak_Toba_local;
        }
        if (LanguageConstant.BAVARIAN.equals(language)) {
            return LanguageSourceConstant.Bavarian_local;
        }
        if (LanguageConstant.BELARUSIAN.equals(language)) {
            return LanguageSourceConstant.Belarusian_local;
        }
        if (LanguageConstant.BEMBA.equals(language)) {
            return LanguageSourceConstant.Bemba_local;
        }
        if (LanguageConstant.BENGALI.equals(language)) {
            return LanguageSourceConstant.Bengali_local;
        }
        if (LanguageConstant.BERBER.equals(language)) {
            return LanguageSourceConstant.Berber_local;
        }
        if (LanguageConstant.BETAWI.equals(language)) {
            return LanguageSourceConstant.Betawi_local;
        }
        if (LanguageConstant.BGOJPUR.equals(language)) {
            return LanguageSourceConstant.Bgojpur_local;
        }
        if (LanguageConstant.BHOJPURI.equals(language)) {
            return LanguageSourceConstant.Bhojpuri_local;
        }
        if (LanguageConstant.BIKOL.equals(language)) {
            return LanguageSourceConstant.Bikol_local;
        }
        if (LanguageConstant.BILING.equals(language)) {
            return LanguageSourceConstant.Biling_local;
        }
        if (LanguageConstant.BISLAMA.equals(language)) {
            return LanguageSourceConstant.Bislama_local;
        }
        if (LanguageConstant.BODO.equals(language)) {
            return LanguageSourceConstant.Bodo_local;
        }
        if (LanguageConstant.BOSNIAN.equals(language)) {
            return LanguageSourceConstant.Bosnian_local;
        }
        if (LanguageConstant.BRETON.equals(language)) {
            return LanguageSourceConstant.Breton_local;
        }
        if (LanguageConstant.BULGARIAN.equals(language)) {
            return LanguageSourceConstant.Bulgarian_local;
        }
        if (LanguageConstant.BULU.equals(language)) {
            return LanguageSourceConstant.Bulu_local;
        }
        if (LanguageConstant.BUMBA.equals(language)) {
            return LanguageSourceConstant.Bumba_local;
        }
        if (LanguageConstant.BURMESE.equals(language)) {
            return LanguageSourceConstant.Burmese_local;
        }
        if (LanguageConstant.BURYAT.equals(language)) {
            return LanguageSourceConstant.Buryat_local;
        }

        // C
        if (LanguageConstant.CADDO.equals(language)) {
            return LanguageSourceConstant.Caddo_local;
        }
        if (LanguageConstant.CANTONESE.equals(language)) {
            return LanguageSourceConstant.Cantonese_local;
        }
        if (LanguageConstant.CATALAN.equals(language)) {
            return LanguageSourceConstant.Catalan_local;
        }
        if (LanguageConstant.CEBUANO.equals(language)) {
            return LanguageSourceConstant.Cebuano_local;
        }
        if (LanguageConstant.CHAM.equals(language)) {
            return LanguageSourceConstant.Cham_local;
        }
        if (LanguageConstant.CHAMORRO.equals(language)) {
            return LanguageSourceConstant.Chamorro_local;
        }
        if (LanguageConstant.CHECHEN.equals(language)) {
            return LanguageSourceConstant.Chechen_local;
        }
        if (LanguageConstant.CHEROKEE.equals(language)) {
            return LanguageSourceConstant.Cherokee_local;
        }
        if (LanguageConstant.CHICHEWA.equals(language)) {
            return LanguageSourceConstant.Chichewa_local;
        }
        if (LanguageConstant.CHIGA.equals(language)) {
            return LanguageSourceConstant.Chiga_local;
        }
        if (LanguageConstant.CHINESE.equals(language)) {
            return LanguageSourceConstant.Chinese_local;
        }
        if (LanguageConstant.CHUUKESE.equals(language)) {
            return LanguageSourceConstant.Chuukese_local;
        }
        if (LanguageConstant.CHUVASH.equals(language)) {
            return LanguageSourceConstant.Chuvash_local;
        }
        if (LanguageConstant.CONGO.equals(language)) {
            return LanguageSourceConstant.Congo_local;
        }
        if (LanguageConstant.CORNISH.equals(language)) {
            return LanguageSourceConstant.Cornish_local;
        }
        if (LanguageConstant.CORSICAN.equals(language)) {
            return LanguageSourceConstant.Corsican_local;
        }
        if (LanguageConstant.CREEK.equals(language)) {
            return LanguageSourceConstant.Creek_local;
        }
        if (LanguageConstant.CRIMEAN_TATAR.equals(language)) {
            return LanguageSourceConstant.Crimean_Tatar_local;
        }
        if (LanguageConstant.CRIMEAN_TATAR_LATIN.equals(language)) {
            return LanguageSourceConstant.Crimean_Tatar_Latin_local;
        }
        if (LanguageConstant.CROATIAN.equals(language)) {
            return LanguageSourceConstant.Croatian_local;
        }
        if (LanguageConstant.CZECH.equals(language)) {
            return LanguageSourceConstant.Czech_local;
        }

        // D
        if (LanguageConstant.DANISH.equals(language)) {
            return LanguageSourceConstant.Danish_local;
        }
        if (LanguageConstant.DARI.equals(language)) {
            return LanguageSourceConstant.Dari_local;
        }
        if (LanguageConstant.DHIVEHI.equals(language)) {
            return LanguageSourceConstant.Dhivehi_local;
        }
        if (LanguageConstant.DINKA.equals(language)) {
            return LanguageSourceConstant.Dinka_local;
        }
        if (LanguageConstant.DOGRI.equals(language)) {
            return LanguageSourceConstant.Dogri_local;
        }
        if (LanguageConstant.DOMBE.equals(language)) {
            return LanguageSourceConstant.Dombe_local;
        }
        if (LanguageConstant.DUTCH.equals(language)) {
            return LanguageSourceConstant.Dutch_local;
        }
        if (LanguageConstant.DYULA.equals(language)) {
            return LanguageSourceConstant.Dyula_local;
        }
        if (LanguageConstant.DZONGKHA.equals(language)) {
            return LanguageSourceConstant.Dzongkha_local;
        }

        // E
        if (LanguageConstant.EASTERN_HUASTECA_NAHUATL.equals(language)) {
            return LanguageSourceConstant.Eastern_Huasteca_Nahuatl_local;
        }
        if (LanguageConstant.ENGLISH.equals(language)) {
            return LanguageSourceConstant.English_local;
        }
        if (LanguageConstant.ESPERANTO.equals(language)) {
            return LanguageSourceConstant.Esperanto_local;
        }
        if (LanguageConstant.ESTONIAN.equals(language)) {
            return LanguageSourceConstant.Estonian_local;
        }
        if (LanguageConstant.EWE.equals(language)) {
            return LanguageSourceConstant.Ewe_local;
        }

        // F
        if (LanguageConstant.FAROESE.equals(language)) {
            return LanguageSourceConstant.Faroese_local;
        }
        if (LanguageConstant.FIJIAN.equals(language)) {
            return LanguageSourceConstant.Fijian_local;
        }
        if (LanguageConstant.FILIPINO.equals(language)) {
            return LanguageSourceConstant.Filipino_local;
        }
        if (LanguageConstant.FINNISH.equals(language)) {
            return LanguageSourceConstant.Finnish_local;
        }
        if (LanguageConstant.FON.equals(language)) {
            return LanguageSourceConstant.Fon_local;
        }
        if (LanguageConstant.FRENCH.equals(language)) {
            return LanguageSourceConstant.French_local;
        }
        if (LanguageConstant.FRENCH_CANADA.equals(language)) {
            return LanguageSourceConstant.French_Canada_local;
        }
        if (LanguageConstant.FRISIAN.equals(language)) {
            return LanguageSourceConstant.Frisian_local;
        }
        if (LanguageConstant.FRIULI.equals(language)) {
            return LanguageSourceConstant.Friuli_local;
        }
        if (LanguageConstant.FRIULIAN.equals(language)) {
            return LanguageSourceConstant.Friulian_local;
        }
        if (LanguageConstant.FULA.equals(language)) {
            return LanguageSourceConstant.Fula_local;
        }
        if (LanguageConstant.FULANI.equals(language)) {
            return LanguageSourceConstant.Fulani_local;
        }

        // G
        if (LanguageConstant.GA.equals(language)) {
            return LanguageSourceConstant.Ga_local;
        }
        if (LanguageConstant.GAELIC.equals(language)) {
            return LanguageSourceConstant.Gaelic_local;
        }
        if (LanguageConstant.GALICIAN.equals(language)) {
            return LanguageSourceConstant.Galician_local;
        }
        if (LanguageConstant.GEORGIAN.equals(language)) {
            return LanguageSourceConstant.Georgian_local;
        }
        if (LanguageConstant.GERMAN.equals(language)) {
            return LanguageSourceConstant.German_local;
        }
        if (LanguageConstant.GREEK.equals(language)) {
            return LanguageSourceConstant.Greek_local;
        }
        if (LanguageConstant.GREENLANDIC.equals(language)) {
            return LanguageSourceConstant.Greenlandic_local;
        }
        if (LanguageConstant.GUARANI.equals(language)) {
            return LanguageSourceConstant.Guarani_local;
        }
        if (LanguageConstant.GUJARATI.equals(language)) {
            return LanguageSourceConstant.Gujarati_local;
        }

        // H
        if (LanguageConstant.HAKACHIN.equals(language)) {
            return LanguageSourceConstant.Hakachin_local;
        }
        if (LanguageConstant.HAKHA_CHIN.equals(language)) {
            return LanguageSourceConstant.Hakha_Chin_local;
        }
        if (LanguageConstant.HAITIAN.equals(language)) {
            return LanguageSourceConstant.Haitian_local;
        }
        if (LanguageConstant.HAUSA.equals(language)) {
            return LanguageSourceConstant.Hausa_local;
        }
        if (LanguageConstant.HAWAIIAN.equals(language)) {
            return LanguageSourceConstant.Hawaiian_local;
        }
        if (LanguageConstant.HEBREW.equals(language)) {
            return LanguageSourceConstant.Hebrew_local;
        }
        if (LanguageConstant.HIGHLAND_SORBIAN.equals(language)) {
            return LanguageSourceConstant.Highland_Sorbian_local;
        }
        if (LanguageConstant.HILIGAYNON.equals(language)) {
            return LanguageSourceConstant.Hiligaynon_local;
        }
        if (LanguageConstant.HILIGANUN.equals(language)) {
            return LanguageSourceConstant.Hiliganun_local;
        }
        if (LanguageConstant.HILL_MARI.equals(language)) {
            return LanguageSourceConstant.Hill_Mari_local;
        }
        if (LanguageConstant.HINDI.equals(language)) {
            return LanguageSourceConstant.Hindi_local;
        }
        if (LanguageConstant.HMONG.equals(language)) {
            return LanguageSourceConstant.Hmong_local;
        }
        if (LanguageConstant.HUNGARIAN.equals(language)) {
            return LanguageSourceConstant.Hungarian_local;
        }
        if (LanguageConstant.HUNSRIK.equals(language)) {
            return LanguageSourceConstant.Hunsrik_local;
        }
        if (LanguageConstant.HUPA.equals(language)) {
            return LanguageSourceConstant.Hupa_local;
        }

        // I
        if (LanguageConstant.IBAN.equals(language)) {
            return LanguageSourceConstant.Iban_local;
        }
        if (LanguageConstant.ICELANDIC.equals(language)) {
            return LanguageSourceConstant.Icelandic_local;
        }
        if (LanguageConstant.IDO.equals(language)) {
            return LanguageSourceConstant.Ido_local;
        }
        if (LanguageConstant.IGBO.equals(language)) {
            return LanguageSourceConstant.Igbo_local;
        }
        if (LanguageConstant.ILOCANO.equals(language)) {
            return LanguageSourceConstant.Ilocano_local;
        }
        if (LanguageConstant.INDONESIAN.equals(language)) {
            return LanguageSourceConstant.Indonesian_local;
        }
        if (LanguageConstant.INGUSH.equals(language)) {
            return LanguageSourceConstant.Ingush_local;
        }
        if (LanguageConstant.INTER.equals(language)) {
            return LanguageSourceConstant.Inter_local;
        }
        if (LanguageConstant.INUKTITUT.equals(language)) {
            return LanguageSourceConstant.Inuktitut_local;
        }
        if (LanguageConstant.INUKTUT.equals(language)) {
            return LanguageSourceConstant.Inuktut_local;
        }
        if (LanguageConstant.INUKTUT_LATIN.equals(language)) {
            return LanguageSourceConstant.Inuktut_Latin_local;
        }
        if (LanguageConstant.IRANIAN.equals(language)) {
            return LanguageSourceConstant.Iranian_local;
        }
        if (LanguageConstant.IRISH.equals(language)) {
            return LanguageSourceConstant.Irish_local;
        }
        if (LanguageConstant.ITALIAN.equals(language)) {
            return LanguageSourceConstant.Italian_local;
        }

        // J
        if (LanguageConstant.JAMAICAN_PATOIS.equals(language)) {
            return LanguageSourceConstant.Jamaican_Patois_local;
        }
        if (LanguageConstant.JAPANESE.equals(language)) {
            return LanguageSourceConstant.Japanese_local;
        }
        if (LanguageConstant.JAVANESE.equals(language)) {
            return LanguageSourceConstant.Javanese_local;
        }
        if (LanguageConstant.JINGPO.equals(language)) {
            return LanguageSourceConstant.Jingpo_local;
        }

        // K
        if (LanguageConstant.KABYLE.equals(language)) {
            return LanguageSourceConstant.Kabyle_local;
        }
        if (LanguageConstant.KALAALLISUT.equals(language)) {
            return LanguageSourceConstant.Kalaallisut_local;
        }
        if (LanguageConstant.KANNADA.equals(language)) {
            return LanguageSourceConstant.Kannada_local;
        }
        if (LanguageConstant.KANURI.equals(language)) {
            return LanguageSourceConstant.Kanuri_local;
        }
        if (LanguageConstant.KAPAMPANGAN.equals(language)) {
            return LanguageSourceConstant.Kapampangan_local;
        }
        if (LanguageConstant.KASHMIRI.equals(language)) {
            return LanguageSourceConstant.Kashmiri_local;
        }
        if (LanguageConstant.KASHUBIAN.equals(language)) {
            return LanguageSourceConstant.Kashubian_local;
        }
        if (LanguageConstant.KAZAKH.equals(language)) {
            return LanguageSourceConstant.Kazakh_local;
        }
        if (LanguageConstant.KEKCHI.equals(language)) {
            return LanguageSourceConstant.Kekchi_local;
        }
        if (LanguageConstant.KHASI.equals(language)) {
            return LanguageSourceConstant.Khasi_local;
        }
        if (LanguageConstant.KHMER.equals(language)) {
            return LanguageSourceConstant.Khmer_local;
        }
        if (LanguageConstant.KIGA.equals(language)) {
            return LanguageSourceConstant.Kiga_local;
        }
        if (LanguageConstant.KINYARWANDA.equals(language)) {
            return LanguageSourceConstant.Kinyarwanda_local;
        }
        if (LanguageConstant.KIRUNDI.equals(language)) {
            return LanguageSourceConstant.Kirundi_local;
        }
        if (LanguageConstant.KITUBA.equals(language)) {
            return LanguageSourceConstant.Kituba_local;
        }
        if (LanguageConstant.KLINGON.equals(language)) {
            return LanguageSourceConstant.Klingon_local;
        }
        if (LanguageConstant.KOKBOROK.equals(language)) {
            return LanguageSourceConstant.Kokborok_local;
        }
        if (LanguageConstant.KOMI.equals(language)) {
            return LanguageSourceConstant.Komi_local;
        }
        if (LanguageConstant.KONKANI.equals(language)) {
            return LanguageSourceConstant.Konkani_local;
        }
        if (LanguageConstant.KONGO.equals(language)) {
            return LanguageSourceConstant.Kongo_local;
        }
        if (LanguageConstant.KOREAN.equals(language)) {
            return LanguageSourceConstant.Korean_local;
        }
        if (LanguageConstant.KRIO.equals(language)) {
            return LanguageSourceConstant.Krio_local;
        }
        if (LanguageConstant.KURDISH.equals(language)) {
            return LanguageSourceConstant.Kurdish_local;
        }
        if (LanguageConstant.KURDISH_SORANI.equals(language)) {
            return LanguageSourceConstant.Kurdish_Sorani_local;
        }
        if (LanguageConstant.KYRGYZ.equals(language)) {
            return LanguageSourceConstant.Kyrgyz_local;
        }

        // L
        if (LanguageConstant.LAO.equals(language)) {
            return LanguageSourceConstant.Lao_local;
        }
        if (LanguageConstant.LATGALIAN.equals(language)) {
            return LanguageSourceConstant.Latgalian_local;
        }
        if (LanguageConstant.LATJALAI.equals(language)) {
            return LanguageSourceConstant.Latjalai_local;
        }
        if (LanguageConstant.LATIN.equals(language)) {
            return LanguageSourceConstant.Latin_local;
        }
        if (LanguageConstant.LATVIAN.equals(language)) {
            return LanguageSourceConstant.Latvian_local;
        }
        if (LanguageConstant.LIGURIAN.equals(language)) {
            return LanguageSourceConstant.Ligurian_local;
        }
        if (LanguageConstant.LIMBURGISH.equals(language)) {
            return LanguageSourceConstant.Limburgish_local;
        }
        if (LanguageConstant.LINGALA.equals(language)) {
            return LanguageSourceConstant.Lingala_local;
        }
        if (LanguageConstant.LITHUANIAN.equals(language)) {
            return LanguageSourceConstant.Lithuanian_local;
        }
        if (LanguageConstant.LOGICAL_LANGUAGE.equals(language)) {
            return LanguageSourceConstant.Logical_language_local;
        }
        if (LanguageConstant.LOMBARD.equals(language)) {
            return LanguageSourceConstant.Lombard_local;
        }
        if (LanguageConstant.LOWER_SORBIAN.equals(language)) {
            return LanguageSourceConstant.Lower_Sorbian_local;
        }
        if (LanguageConstant.LUBA_KASAI.equals(language)) {
            return LanguageSourceConstant.Luba_Kasai_local;
        }
        if (LanguageConstant.LUGANDA.equals(language)) {
            return LanguageSourceConstant.Luganda_local;
        }
        if (LanguageConstant.LUO.equals(language)) {
            return LanguageSourceConstant.Luo_local;
        }
        if (LanguageConstant.LUXEMBOURGISH.equals(language)) {
            return LanguageSourceConstant.Luxembourgish_local;
        }

        // M
        if (LanguageConstant.MACEDONIAN.equals(language)) {
            return LanguageSourceConstant.Macedonian_local;
        }
        if (LanguageConstant.MADURESE.equals(language)) {
            return LanguageSourceConstant.Madurese_local;
        }
        if (LanguageConstant.MAKASAR.equals(language)) {
            return LanguageSourceConstant.Makasar_local;
        }
        if (LanguageConstant.MAKASSAR.equals(language)) {
            return LanguageSourceConstant.Makassar_local;
        }
        if (LanguageConstant.MAKHUWA.equals(language)) {
            return LanguageSourceConstant.Makhuwa_local;
        }
        if (LanguageConstant.MALAGASY.equals(language)) {
            return LanguageSourceConstant.Malagasy_local;
        }
        if (LanguageConstant.MALAY.equals(language)) {
            return LanguageSourceConstant.Malay_local;
        }
        if (LanguageConstant.MALAY_ARABIC.equals(language)) {
            return LanguageSourceConstant.Malay_Arabic_local;
        }
        if (LanguageConstant.MALAY_JAWI.equals(language)) {
            return LanguageSourceConstant.Malay_Jawi_local;
        }
        if (LanguageConstant.MALAYALAM.equals(language)) {
            return LanguageSourceConstant.Malayalam_local;
        }
        if (LanguageConstant.MALTESE.equals(language)) {
            return LanguageSourceConstant.Maltese_local;
        }
        if (LanguageConstant.MAM.equals(language)) {
            return LanguageSourceConstant.Mam_local;
        }
        if (LanguageConstant.MANIPURI_BENGALI.equals(language)) {
            return LanguageSourceConstant.Manipuri_Bengali_local;
        }
        if (LanguageConstant.MANKS.equals(language)) {
            return LanguageSourceConstant.Manks_local;
        }
        if (LanguageConstant.MANX.equals(language)) {
            return LanguageSourceConstant.Manx_local;
        }
        if (LanguageConstant.MAORI.equals(language)) {
            return LanguageSourceConstant.Maori_local;
        }
        if (LanguageConstant.MARATHI.equals(language)) {
            return LanguageSourceConstant.Marathi_local;
        }
        if (LanguageConstant.MARI.equals(language)) {
            return LanguageSourceConstant.Mari_local;
        }
        if (LanguageConstant.MARSHALLESE.equals(language)) {
            return LanguageSourceConstant.Marshallese_local;
        }
        if (LanguageConstant.MARWARI.equals(language)) {
            return LanguageSourceConstant.Marwari_local;
        }
        if (LanguageConstant.MAURITIAN_CREOLE.equals(language)) {
            return LanguageSourceConstant.Mauritian_Creole_local;
        }
        if (LanguageConstant.MEADOW_MARI.equals(language)) {
            return LanguageSourceConstant.Meadow_Mari_local;
        }
        if (LanguageConstant.MEITEILON.equals(language)) {
            return LanguageSourceConstant.Meiteilon_local;
        }
        if (LanguageConstant.MENDE.equals(language)) {
            return LanguageSourceConstant.Mende_local;
        }
        if (LanguageConstant.MINANGKABAU.equals(language)) {
            return LanguageSourceConstant.Minangkabau_local;
        }
        if (LanguageConstant.MIZO.equals(language)) {
            return LanguageSourceConstant.Mizo_local;
        }
        if (LanguageConstant.MONGOLIAN.equals(language)) {
            return LanguageSourceConstant.Mongolian_local;
        }
        if (LanguageConstant.MONTENEGRIN.equals(language)) {
            return LanguageSourceConstant.Montenegrin_local;
        }

        // N
        if (LanguageConstant.NAHUATL.equals(language)) {
            return LanguageSourceConstant.Nahuatl_local;
        }
        if (LanguageConstant.NAVAJO.equals(language)) {
            return LanguageSourceConstant.Navajo_local;
        }
        if (LanguageConstant.NDAU.equals(language)) {
            return LanguageSourceConstant.Ndau_local;
        }
        if (LanguageConstant.NEAPOLITAN.equals(language)) {
            return LanguageSourceConstant.Neapolitan_local;
        }
        if (LanguageConstant.NEPALI.equals(language)) {
            return LanguageSourceConstant.Nepali_local;
        }
        if (LanguageConstant.NEWARI.equals(language)) {
            return LanguageSourceConstant.Newari_local;
        }
        if (LanguageConstant.NKO.equals(language)) {
            return LanguageSourceConstant.Nko_local;
        }
        if (LanguageConstant.NORTHERN_SAMI.equals(language)) {
            return LanguageSourceConstant.Northern_Sami_local;
        }
        if (LanguageConstant.NORTHERN_SPTHO.equals(language)) {
            return LanguageSourceConstant.Northern_Sptho_local;
        }
        if (LanguageConstant.NORWEGIAN.equals(language)) {
            return LanguageSourceConstant.Norwegian_local;
        }
        if (LanguageConstant.NUER.equals(language)) {
            return LanguageSourceConstant.Nuer_local;
        }
        if (LanguageConstant.NUER_ETHIOPIA.equals(language)) {
            return LanguageSourceConstant.Nuer_Ethiopia_local;
        }
        if (LanguageConstant.NYANJA.equals(language)) {
            return LanguageSourceConstant.Nyanja_local;
        }
        if (LanguageConstant.NYANKOLE.equals(language)) {
            return LanguageSourceConstant.Nyankole_local;
        }

        // O
        if (LanguageConstant.OCCITAN.equals(language)) {
            return LanguageSourceConstant.Occitan_local;
        }
        if (LanguageConstant.OJIBWA.equals(language)) {
            return LanguageSourceConstant.Ojibwa_local;
        }
        if (LanguageConstant.OJIBWE.equals(language)) {
            return LanguageSourceConstant.Ojibwe_local;
        }
        if (LanguageConstant.ORIYA.equals(language)) {
            return LanguageSourceConstant.Oriya_local;
        }
        if (LanguageConstant.OROMO.equals(language)) {
            return LanguageSourceConstant.Oromo_local;
        }
        if (LanguageConstant.OSSETIAN.equals(language)) {
            return LanguageSourceConstant.Ossetian_local;
        }

        // P
        if (LanguageConstant.PAMPANGA.equals(language)) {
            return LanguageSourceConstant.Pampanga_local;
        }
        if (LanguageConstant.PANGASINAN.equals(language)) {
            return LanguageSourceConstant.Pangasinan_local;
        }
        if (LanguageConstant.PANGWA.equals(language)) {
            return LanguageSourceConstant.Pangwa_local;
        }
        if (LanguageConstant.PAPIAMENTO.equals(language)) {
            return LanguageSourceConstant.Papiamento_local;
        }
        if (LanguageConstant.PASHTO.equals(language)) {
            return LanguageSourceConstant.Pashto_local;
        }
        if (LanguageConstant.PERSIAN.equals(language)) {
            return LanguageSourceConstant.Persian_local;
        }
        if (LanguageConstant.POLISH.equals(language)) {
            return LanguageSourceConstant.Polish_local;
        }
        if (LanguageConstant.PORTUGUESE.equals(language)) {
            return LanguageSourceConstant.Portuguese_local;
        }
        if (LanguageConstant.PORTUGUESE_BR.equals(language)) {
            return LanguageSourceConstant.Portuguese_Brazil_local;
        }
        if (LanguageConstant.PORTUGUESE_PORTUGAL.equals(language)) {
            return LanguageSourceConstant.Portuguese_Portugal_local;
        }
        if (LanguageConstant.PUNJABI.equals(language)) {
            return LanguageSourceConstant.Punjabi_local;
        }
        if (LanguageConstant.PUNJABI_ARABIC.equals(language)) {
            return LanguageSourceConstant.Punjabi_Arabic_local;
        }

        // Q
        if (LanguageConstant.QEQCHI.equals(language)) {
            return LanguageSourceConstant.Qeqchi_local;
        }
        if (LanguageConstant.QUECHUA.equals(language)) {
            return LanguageSourceConstant.Quechua_local;
        }

        // R
        if (LanguageConstant.ROMANI.equals(language)) {
            return LanguageSourceConstant.Romani_local;
        }
        if (LanguageConstant.ROMANIAN.equals(language)) {
            return LanguageSourceConstant.Romanian_local;
        }
        if (LanguageConstant.ROMANSH.equals(language)) {
            return LanguageSourceConstant.Romansh_local;
        }
        if (LanguageConstant.ROMANY.equals(language)) {
            return LanguageSourceConstant.Romany_local;
        }
        if (LanguageConstant.RUNDI.equals(language)) {
            return LanguageSourceConstant.Rundi_local;
        }
        if (LanguageConstant.RUSSIAN.equals(language)) {
            return LanguageSourceConstant.Russian_local;
        }
        if (LanguageConstant.RUSYNIAN.equals(language)) {
            return LanguageSourceConstant.Rusynian_local;
        }

        // S
        if (LanguageConstant.SAHO.equals(language)) {
            return LanguageSourceConstant.Saho_local;
        }
        if (LanguageConstant.SAKHA.equals(language)) {
            return LanguageSourceConstant.Sakha_local;
        }
        if (LanguageConstant.SAMI.equals(language)) {
            return LanguageSourceConstant.Sami_local;
        }
        if (LanguageConstant.SAMOAN.equals(language)) {
            return LanguageSourceConstant.Samoan_local;
        }
        if (LanguageConstant.SANGO.equals(language)) {
            return LanguageSourceConstant.Sango_local;
        }
        if (LanguageConstant.SANSKRIT.equals(language)) {
            return LanguageSourceConstant.Sanskrit_local;
        }
        if (LanguageConstant.SANTALI.equals(language)) {
            return LanguageSourceConstant.Santali_local;
        }
        if (LanguageConstant.SANTALI_LATIN.equals(language)) {
            return LanguageSourceConstant.Santali_Latin_local;
        }
        if (LanguageConstant.SARDINIAN.equals(language)) {
            return LanguageSourceConstant.Sardinian_local;
        }
        if (LanguageConstant.SCOTTISH_GAELIC.equals(language)) {
            return LanguageSourceConstant.Scottish_Gaelic_local;
        }
        if (LanguageConstant.SCOTS.equals(language)) {
            return LanguageSourceConstant.Scots_local;
        }
        if (LanguageConstant.SEPEDI.equals(language)) {
            return LanguageSourceConstant.Sepedi_local;
        }
        if (LanguageConstant.SERBIAN.equals(language)) {
            return LanguageSourceConstant.Serbian_local;
        }
        if (LanguageConstant.SEYCHELLOIS_CREOLE.equals(language)) {
            return LanguageSourceConstant.Seychellois_Creole_local;
        }
        if (LanguageConstant.SHAN.equals(language)) {
            return LanguageSourceConstant.Shan_local;
        }
        if (LanguageConstant.SHONA.equals(language)) {
            return LanguageSourceConstant.Shona_local;
        }
        if (LanguageConstant.SICILIAN.equals(language)) {
            return LanguageSourceConstant.Sicilian_local;
        }
        if (LanguageConstant.SILESIAN.equals(language)) {
            return LanguageSourceConstant.Silesian_local;
        }
        if (LanguageConstant.SINDHI.equals(language)) {
            return LanguageSourceConstant.Sindhi_local;
        }
        if (LanguageConstant.SINHALA.equals(language)) {
            return LanguageSourceConstant.Sinhala_local;
        }
        if (LanguageConstant.SLOVAK.equals(language)) {
            return LanguageSourceConstant.Slovak_local;
        }
        if (LanguageConstant.SLOVENIAN.equals(language)) {
            return LanguageSourceConstant.Slovenian_local;
        }
        if (LanguageConstant.SOMALI.equals(language)) {
            return LanguageSourceConstant.Somali_local;
        }
        if (LanguageConstant.SONGHAI.equals(language)) {
            return LanguageSourceConstant.Songhai_local;
        }
        if (LanguageConstant.SORANI.equals(language)) {
            return LanguageSourceConstant.Sorani_local;
        }
        if (LanguageConstant.SOUTH_NDEBELE.equals(language)) {
            return LanguageSourceConstant.South_Ndebele_local;
        }
        if (LanguageConstant.SOUTHERN_NDEBELE.equals(language)) {
            return LanguageSourceConstant.Southern_Ndebele_local;
        }
        if (LanguageConstant.SOUTHERN_SOTHO.equals(language)) {
            return LanguageSourceConstant.Southern_Sotho_local;
        }
        if (LanguageConstant.SPANISH.equals(language)) {
            return LanguageSourceConstant.Spanish_local;
        }
        if (LanguageConstant.SUNDANESE.equals(language)) {
            return LanguageSourceConstant.Sundanese_local;
        }
        if (LanguageConstant.SUSU.equals(language)) {
            return LanguageSourceConstant.Susu_local;
        }
        if (LanguageConstant.SWAHILI.equals(language)) {
            return LanguageSourceConstant.Swahili_local;
        }
        if (LanguageConstant.SWATI.equals(language)) {
            return LanguageSourceConstant.Swati_local;
        }
        if (LanguageConstant.SWEDISH.equals(language)) {
            return LanguageSourceConstant.Swedish_local;
        }
        if (LanguageConstant.SYRIAC.equals(language)) {
            return LanguageSourceConstant.Syriac_local;
        }

        // T
        if (LanguageConstant.TAGALOG.equals(language)) {
            return LanguageSourceConstant.Tagalog_local;
        }
        if (LanguageConstant.TAHITIAN.equals(language)) {
            return LanguageSourceConstant.Tahitian_local;
        }
        if (LanguageConstant.TAJIK.equals(language)) {
            return LanguageSourceConstant.Tajik_local;
        }
        if (LanguageConstant.TAMAZIGHT.equals(language)) {
            return LanguageSourceConstant.Tamazight_local;
        }
        if (LanguageConstant.TAMAZIGHT_LATIN.equals(language)) {
            return LanguageSourceConstant.Tamazight_Latin_local;
        }
        if (LanguageConstant.TAMIL.equals(language)) {
            return LanguageSourceConstant.Tamil_local;
        }
        if (LanguageConstant.TATAR.equals(language)) {
            return LanguageSourceConstant.Tatar_local;
        }
        if (LanguageConstant.TELUGU.equals(language)) {
            return LanguageSourceConstant.Telugu_local;
        }
        if (LanguageConstant.TETON.equals(language)) {
            return LanguageSourceConstant.Teton_local;
        }
        if (LanguageConstant.TETUM.equals(language)) {
            return LanguageSourceConstant.Tetum_local;
        }
        if (LanguageConstant.THAI.equals(language)) {
            return LanguageSourceConstant.Thai_local;
        }
        if (LanguageConstant.TIBETAN.equals(language)) {
            return LanguageSourceConstant.Tibetan_local;
        }
        if (LanguageConstant.TIGRINYA.equals(language)) {
            return LanguageSourceConstant.Tigrinya_local;
        }
        if (LanguageConstant.TIV.equals(language)) {
            return LanguageSourceConstant.Tiv_local;
        }
        if (LanguageConstant.TOK_PISIN.equals(language)) {
            return LanguageSourceConstant.Tok_Pisin_local;
        }
        if (LanguageConstant.TONGAN.equals(language)) {
            return LanguageSourceConstant.Tongan_local;
        }
        if (LanguageConstant.TRADITIONAL_CHINESE.equals(language)) {
            return LanguageSourceConstant.Traditional_Chinese_local;
        }
        if (LanguageConstant.TSONGA.equals(language)) {
            return LanguageSourceConstant.Tsonga_local;
        }
        if (LanguageConstant.TSUNGA.equals(language)) {
            return LanguageSourceConstant.Tsunga_local;
        }
        if (LanguageConstant.TSWANA.equals(language)) {
            return LanguageSourceConstant.Tswana_local;
        }
        if (LanguageConstant.TULU.equals(language)) {
            return LanguageSourceConstant.Tulu_local;
        }
        if (LanguageConstant.TUMBUKA.equals(language)) {
            return LanguageSourceConstant.Tumbuka_local;
        }
        if (LanguageConstant.TUNISIAN_ARABIC.equals(language)) {
            return LanguageSourceConstant.Tunisian_Arabic_local;
        }
        if (LanguageConstant.TURKISH.equals(language)) {
            return LanguageSourceConstant.Turkish_local;
        }
        if (LanguageConstant.TURKMEN.equals(language)) {
            return LanguageSourceConstant.Turkmen_local;
        }
        if (LanguageConstant.TUVAN.equals(language)) {
            return LanguageSourceConstant.Tuvan_local;
        }
        if (LanguageConstant.TWI.equals(language)) {
            return LanguageSourceConstant.Twi_local;
        }

        // U
        if (LanguageConstant.UDMURT.equals(language)) {
            return LanguageSourceConstant.Udmurt_local;
        }
        if (LanguageConstant.UKRAINIAN.equals(language)) {
            return LanguageSourceConstant.Ukrainian_local;
        }
        if (LanguageConstant.URDU.equals(language)) {
            return LanguageSourceConstant.Urdu_local;
        }
        if (LanguageConstant.UYGHUR.equals(language)) {
            return LanguageSourceConstant.Uyghur_local;
        }
        if (LanguageConstant.UZBEK.equals(language)) {
            return LanguageSourceConstant.Uzbek_local;
        }

        // V
        if (LanguageConstant.VENDA.equals(language)) {
            return LanguageSourceConstant.Venda_local;
        }
        if (LanguageConstant.VENETIAN.equals(language)) {
            return LanguageSourceConstant.Venetian_local;
        }
        if (LanguageConstant.VIETNAMESE.equals(language)) {
            return LanguageSourceConstant.Vietnamese_local;
        }

        // W
        if (LanguageConstant.WALLOON.equals(language)) {
            return LanguageSourceConstant.Walloon_local;
        }
        if (LanguageConstant.WARAY.equals(language)) {
            return LanguageSourceConstant.Waray_local;
        }
        if (LanguageConstant.WELSH.equals(language)) {
            return LanguageSourceConstant.Welsh_local;
        }
        if (LanguageConstant.WESTERN_FRISIAN.equals(language)) {
            return LanguageSourceConstant.Western_Frisian_local;
        }
        if (LanguageConstant.WOLOF.equals(language)) {
            return LanguageSourceConstant.Wolof_local;
        }

        // X
        if (LanguageConstant.XHOSA.equals(language)) {
            return LanguageSourceConstant.Xhosa_local;
        }

        // Y
        if (LanguageConstant.YIDDISH.equals(language)) {
            return LanguageSourceConstant.Yiddish_local;
        }
        if (LanguageConstant.YORUBA.equals(language)) {
            return LanguageSourceConstant.Yoruba_local;
        }
        if (LanguageConstant.YUCATEC_MAYA.equals(language)) {
            return LanguageSourceConstant.Yucatec_Maya_local;
        }

        // Z
        if (LanguageConstant.ZANDE.equals(language)) {
            return LanguageSourceConstant.Zande_local;
        }
        if (LanguageConstant.ZAPOTEC.equals(language)) {
            return LanguageSourceConstant.Zapotec_local;
        }
        if (LanguageConstant.ZAZAQI.equals(language)) {
            return LanguageSourceConstant.Zazaqi_local;
        }
        if (LanguageConstant.ZHUANG.equals(language)) {
            return LanguageSourceConstant.Zhuang_local;
        }
        if (LanguageConstant.ZULU.equals(language)) {
            return LanguageSourceConstant.Zulu_local;
        }

        // Special
        if (LanguageConstant.AUTO.equals(language)) {
            return LanguageSourceConstant.Auto_local;
        }

        return null;
    }

    private LanguageSourceConstant() { }

}
