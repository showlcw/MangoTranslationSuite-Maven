package com.mg.translation.language;

import androidx.annotation.NonNull;

import java.util.Objects;

/**
 * Created by lion on 2016/10/28.
 * 语言简写配置，目前的几种语言使用的是google翻译的标准
 */
public class LanguageVO implements Cloneable {

    public static final int RECOGNITION_QUALITY_UNKNOWN = 0;
    public static final int RECOGNITION_QUALITY_HIGH = 1;
    public static final int RECOGNITION_QUALITY_MEDIUM = 2;
    public static final int RECOGNITION_QUALITY_LOW = 3;

    private String value;
    private int country;
    private String key;
    private boolean vip;
    private boolean isDownload;
    private int ocrFlag = -1;
    private String topTitle;

    private String sourceCountryName;//原来的语言名称

    private int languageCountry;//国家
    private String languageKey;//语言
    private String voiceValue;
    private int recognitionQuality = RECOGNITION_QUALITY_HIGH;

    public LanguageVO(String topTitle) {
        this.topTitle = topTitle;
    }

    public LanguageVO(String key, int country, String value) {
        this.value = value;
        this.country = country;
        this.key = key;
    }

    public LanguageVO(String key, int country, String value, String voiceValue) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.voiceValue = voiceValue;
    }

    public LanguageVO(String key, int country, String value, String languageKey, int languageCountry) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.languageKey = languageKey;
        this.languageCountry = languageCountry;
    }


    public LanguageVO(String key, int country, String value, boolean vip) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.vip = vip;
    }

    public LanguageVO(String key, int country, String value, int ocrFlag) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.ocrFlag = ocrFlag;
    }

    public LanguageVO(String key, int country, String value, boolean vip, boolean isDownload) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.vip = vip;
        this.isDownload = isDownload;
    }

    public LanguageVO(String key, int country, String value, int ocrFlag, boolean vip) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.ocrFlag = ocrFlag;
        this.vip = vip;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LanguageVO)) return false;
        LanguageVO that = (LanguageVO) o;
        return key != null && Objects.equals(key, that.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }

    public int getLanguageCountry() {
        return languageCountry;
    }

    public String getVoiceValue() {
        return voiceValue;
    }

    public void setVoiceValue(String voiceValue) {
        this.voiceValue = voiceValue;
    }

    public void setLanguageCountry(int languageCountry) {
        this.languageCountry = languageCountry;
    }

    public String getLanguageKey() {
        return languageKey;
    }

    public void setLanguageKey(String languageKey) {
        this.languageKey = languageKey;
    }

    public String getSourceLanguageIdName() {
        return sourceCountryName;
    }

    public void setSourceLanguageIdName(String sourceCountryName) {
        this.sourceCountryName = sourceCountryName;
    }

    public String getTopTitle() {
        return topTitle;
    }

    public void setTopTitle(String topTitle) {
        this.topTitle = topTitle;
    }

    public boolean isDownload() {
        return isDownload;
    }

    public int getOcrFlag() {
        return ocrFlag;
    }

    public void setOcrFlag(int ocrFlag) {
        this.ocrFlag = ocrFlag;
    }

    public void setDownload(boolean download) {
        isDownload = download;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getCountry() {
        return country;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getRecognitionQuality() {
        return recognitionQuality;
    }

    public void setRecognitionQuality(int recognitionQuality) {
        if (recognitionQuality < RECOGNITION_QUALITY_UNKNOWN
                || recognitionQuality > RECOGNITION_QUALITY_LOW) {
            throw new IllegalArgumentException("unsupported recognition quality");
        }
        this.recognitionQuality = recognitionQuality;
    }

    public boolean hasHighQualityRecognition() {
        return recognitionQuality == RECOGNITION_QUALITY_HIGH;
    }

    public boolean isLowQualityRecognition() {
        return recognitionQuality == RECOGNITION_QUALITY_LOW;
    }

    public int getRecognitionQualityDescriptionResId() {
        switch (recognitionQuality) {
            case RECOGNITION_QUALITY_HIGH:
                return com.mango.sdk.translation.R.string.recognition_quality_high;
            case RECOGNITION_QUALITY_MEDIUM:
                return com.mango.sdk.translation.R.string.recognition_quality_medium;
            case RECOGNITION_QUALITY_LOW:
                return com.mango.sdk.translation.R.string.recognition_quality_low;
            default:
                return com.mango.sdk.translation.R.string.recognition_quality_unknown;
        }
    }

    @NonNull
    @Override
    public LanguageVO clone() throws CloneNotSupportedException {
        return (LanguageVO) super.clone();
    }
}
