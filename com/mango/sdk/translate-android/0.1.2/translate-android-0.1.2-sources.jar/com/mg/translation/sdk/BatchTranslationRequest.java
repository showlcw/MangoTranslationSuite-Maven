package com.mg.translation.sdk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable ordered batch translation request. */
public final class BatchTranslationRequest {
    private final List<String> texts;
    private final String sourceLanguageId;
    private final String targetLanguageId;

    public BatchTranslationRequest(List<String> texts, String sourceLanguageId,
                                   String targetLanguageId) {
        if (texts == null || texts.isEmpty()) {
            throw new IllegalArgumentException("texts are required");
        }
        for (String text : texts) {
            if (text == null || text.trim().isEmpty()) {
                throw new IllegalArgumentException("batch text is required");
            }
        }
        if (sourceLanguageId == null || sourceLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("sourceLanguageId is required");
        }
        if (targetLanguageId == null || targetLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("targetLanguageId is required");
        }
        this.texts = Collections.unmodifiableList(new ArrayList<>(texts));
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }

    public List<String> getTexts() { return texts; }
    public String getSourceLanguageId() { return sourceLanguageId; }
    public String getTargetLanguageId() { return targetLanguageId; }
}
