package com.mg.translation.sdk;

/** Decrypts one App-bound Provider ciphertext without exposing the App encryption key. */
@FunctionalInterface
public interface CredentialDecryptor {
    /**
     * @param ciphertext one encrypted value from the standard App translation config
     * @return decrypted STRING or JSON Provider value; never persist or log this value
     * @throws RuntimeException when identity verification or decryption fails
     */
    String decrypt(String ciphertext);
}
