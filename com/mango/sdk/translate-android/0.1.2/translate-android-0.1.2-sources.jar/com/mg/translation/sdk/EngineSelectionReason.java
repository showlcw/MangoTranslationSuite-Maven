package com.mg.translation.sdk;

/** 请求的整数引擎 ID 未被采用时的明确原因。 */
public enum EngineSelectionReason {
    NONE,
    INVALID_ID,
    RETIRED_ENGINE,
    NOT_CONFIGURED,
    NOT_SELECTABLE,
    VIP_REQUIRED,
    NO_AVAILABLE_ENGINE
}
