package com.mg.translation.sdk;

/** 选择结果同时保留请求 ID、最终 ID、操作结果和未采用原因。 */
public final class EngineSelectionResult {
    public static final int NO_ENGINE = -1;

    private final int requestedId;
    private final int previousId;
    private final int selectedId;
    private final EngineSelectionOutcome outcome;
    private final EngineSelectionReason reason;

    EngineSelectionResult(int requestedId, int previousId, int selectedId,
                          EngineSelectionOutcome outcome, EngineSelectionReason reason) {
        this.requestedId = requestedId;
        this.previousId = previousId;
        this.selectedId = selectedId;
        this.outcome = outcome;
        this.reason = reason;
    }

    public int getRequestedId() { return requestedId; }
    public int getPreviousId() { return previousId; }
    public int getSelectedId() { return selectedId; }
    public EngineSelectionOutcome getOutcome() { return outcome; }
    public EngineSelectionReason getReason() { return reason; }
    public boolean isApplied() {
        return outcome == EngineSelectionOutcome.APPLIED
                || outcome == EngineSelectionOutcome.UNCHANGED;
    }
}
