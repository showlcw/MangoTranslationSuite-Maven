package com.mg.translation.sdk;

public interface TranslationCallback {
    void onSuccess(TranslationResult result);
    void onError(TranslationError error);
}
