package com.mg.translation.sdk;

/**
 * 翻译 SDK 向宿主 App 请求的最小能力集合。
 *
 * <p>这里不能出现任何单个翻译引擎的实现方法。智谱、Google、百度、RapidAPI 等
 * Provider 的协议都由 SDK 内对应 Translator 负责，App 不重复对接。</p>
 */
public interface TranslationHost {

    /**
     * 返回由 App 持有的翻译凭据解密器。
     *
     * <p>SDK 会逐条把 {@code engines[].keys[]} 中的密文交给它。实现方必须复用 App
     * 已有的 native/受保护解密流程；不能把 App 的原始 AES Key 返回或保存到 SDK。</p>
     */
    CredentialDecryptor getCredentialDecryptor();

    /**
     * 校验当前运行包名/签名是否与 App 受保护身份一致。
     *
     * <p>该能力用于替代“把正确签名字符串暴露给 SDK”。native 保护层不可用或检测到
     * 二次打包时返回 {@code false}。</p>
     */
    boolean isAppIdentityValid();

    /**
     * 返回用户当前实时会员状态；SDK 不缓存或持久化该状态。
     */
    boolean isVip();

    /**
     * 标识当前构建是否按“可直连 Google 服务”的渠道处理。
     * 保留 Voice 原有国内/海外构建分流规则；未覆盖时默认 {@code true}。
     */
    default boolean isGoogleBuild() { return true; }

    /** 可选元数据事件钩子；事件不包含凭据、原文、译文或 Provider 响应。 */
    default void onEvent(String eventId) { }
}
