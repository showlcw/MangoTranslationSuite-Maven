package com.mg.translation.sdk;

/** Immutable single-text translation request. */
public final class TranslationRequest {
    private final String text;
    private final String sourceLanguageId;
    private final String targetLanguageId;

    public TranslationRequest(String text, String sourceLanguageId, String targetLanguageId) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("text is required");
        }
        if (sourceLanguageId == null || sourceLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("sourceLanguageId is required");
        }
        if (targetLanguageId == null || targetLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("targetLanguageId is required");
        }
        this.text = text;
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }

    public String getText() { return text; }
    public String getSourceLanguageId() { return sourceLanguageId; }
    public String getTargetLanguageId() { return targetLanguageId; }
}
