package com.mg.translation.sdk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable translation result for both single and batch requests. */
public final class TranslationResult {
    private final List<String> translations;
    private final int actualEngineId;
    private final boolean batch;

    public TranslationResult(List<String> translations, int actualEngineId, boolean batch) {
        if (translations == null || translations.isEmpty()) {
            throw new IllegalArgumentException("translations are required");
        }
        if (!batch && translations.size() != 1) {
            throw new IllegalArgumentException("single translation result must contain one item");
        }
        for (String translation : translations) {
            if (translation == null) {
                throw new IllegalArgumentException("translation item is required");
            }
        }
        this.translations = Collections.unmodifiableList(new ArrayList<>(translations));
        this.actualEngineId = actualEngineId;
        this.batch = batch;
    }

    public String getTranslatedText() {
        return translations.isEmpty() ? null : translations.get(0);
    }

    public List<String> getTranslations() { return translations; }
    public int getActualEngineId() { return actualEngineId; }
    public boolean isBatch() { return batch; }
}
