package com.mg.translation.sdk;

public interface Translator extends AutoCloseable {
    int getEngineId();
    void translate(TranslationRequest request, TranslationCallback callback);
    void translate(BatchTranslationRequest request, TranslationCallback callback);

    @Override
    void close();
}
