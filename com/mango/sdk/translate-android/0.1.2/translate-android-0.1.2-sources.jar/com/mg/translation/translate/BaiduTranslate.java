package com.mg.translation.translate;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;

import static com.mg.translation.utils.TranslateUtils.getSourceText;

import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.BaseUtils;
import com.mg.translation.internal.base.LogManager;
import com.mg.translation.internal.base.MD5Utils;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.req.BaiduTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.translate.vo.TransResultBean;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/7 10:15
 */
public class BaiduTranslate extends BaseTranslateControl {

    private final Context mContext;
    private List<LanguageVO> mDestLanguageList;

    public BaiduTranslate(Context context) {
        mContext = context;
    }

    private static List<BaiduTranslationSegment> createBaiduSegments(List<String> sourceTexts) {
        List<BaiduTranslationSegment> segments = new ArrayList<>(sourceTexts.size());
        for (String sourceText : sourceTexts) {
            segments.add(new BaiduTranslationSegment(sourceText));
        }
        return segments;
    }

    private static void applyBaiduTranslations(BatchTranslationTask request,
                                                List<BaiduTranslationSegment> segments) {
        for (int i = 0; i < segments.size(); i++) {
            request.setTranslation(i, segments.get(i).getTranslatedText());
        }
    }

    static int findBaiduSegmentIndex(List<BaiduTranslationSegment> segments, String sourceText) {
        for (int i = 0; i < segments.size(); i++) {
            BaiduTranslationSegment segment = segments.get(i);
            if (isEmpty(segment.getTranslatedText())
                    && sourceText != null
                    && sourceText.equalsIgnoreCase(segment.getSourceText())) {
                return i;
            }
        }
        return -1;
    }

    private static boolean isEmpty(String text) {
        return text == null || text.isEmpty();
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }

        String mAppId = TranslateUtils.getBaiduIdKey(mContext);
        String mAppSecret = TranslateUtils.getBaiduSecretKey(mContext);
        if (TextUtils.isEmpty(mAppId) || TextUtils.isEmpty(mAppSecret)) {
            errorDealGoogle(translateListener);
            return;
        }

        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, mAppId, mAppSecret, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, mAppId, mAppSecret, translateListener);
    }

    /**
     * 翻译
     */
    public synchronized void translateListApi(BatchTranslationTask batchTask, String appid, String appSecret,
                                              TranslateListener translateListener) {
        List<BaiduTranslationSegment> results = createBaiduSegments(batchTask.getSourceTexts());
        String content = getSourceText(batchTask.getSourceTexts(), "\n");
        BaseReq baseReq = createBaiduBaseReq(content, batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId(), appid, appSecret);

        executeRequest(TranslateRepository.getInstance().baiduTranslate(baseReq), baiduTranslateResult -> {
            if (baiduTranslateResult == null ||
                    baiduTranslateResult.getData() == null ||
                    baiduTranslateResult.getErrorCode() != 0) {
                errorDealGoogle(translateListener);
                return;
            }
            int size = baiduTranslateResult.getData().size();
            boolean isChina = TranslateUtils.isNeedTextSpace(batchTask.getTargetLanguageId());
            if (size == results.size()) {//没有问题
                BaiduTranslationSegment baiduSegment = null;
                for (int i = 0; i < size; i++) {
                    baiduSegment = results.get(i);
                    String dest = baiduTranslateResult.getData().get(i).getDst();
                    baiduSegment.setTranslatedText(dest);
                }
                applyBaiduTranslations(batchTask, results);
                translateListener.onSuccess(batchTask, getTranslateType(), true);
                return;
            }

            BaiduTranslationSegment baiduSegment = null;
            List<BaiduTranslationSegment> unmatchedSegments = new ArrayList<>();
            TransResultBean transResultBean = null;
            boolean isHasSuccess = false;

            for (int i = 0; i < size; i++) {
                baiduSegment = new BaiduTranslationSegment();
                transResultBean = baiduTranslateResult.getData().get(i);
                baiduSegment.setSourceText(transResultBean.getSrc().trim());
                int index = findBaiduSegmentIndex(results, baiduSegment.getSourceText());
                String dest = transResultBean.getDst().trim();
                if (index != -1) {
                    results.get(index).setTranslatedText(dest);
                    isHasSuccess = true;
                } else {//记录下来找不到对于源数据的数据
                    baiduSegment.setTranslatedText(dest);
                    unmatchedSegments.add(baiduSegment);
                }
            }

            BaiduTranslationSegment candidateSegment = null;
            StringBuilder stringBuffer = null;
            for (BaiduTranslationSegment segment : results) {
                if (!TextUtils.isEmpty(segment.getTranslatedText())) {//已经有值的不处理
                    continue;
                }
                String source = segment.getSourceText().trim();
                if (TextUtils.isEmpty(source)) {
                    continue;
                }
                if (unmatchedSegments.isEmpty()) {
                    continue;
                }

                int unKnowSize = unmatchedSegments.size();
                stringBuffer = new StringBuilder();
                for (int i = 0; i < unKnowSize; i++) {
                    candidateSegment = unmatchedSegments.get(i);
                    if (TextUtils.isEmpty(candidateSegment.getTranslatedText()) || TextUtils.isEmpty(candidateSegment.getSourceText())) {
                        continue;
                    }
                    if (source.toLowerCase(Locale.ROOT).contains(candidateSegment.getSourceText().toLowerCase(Locale.ROOT))) {
                        isHasSuccess = true;
//                        stringBuffer.append(candidateSegment.getTranslatedText().trim());
                        if (isChina) {
                            stringBuffer.append(candidateSegment.getTranslatedText().trim());
                        } else {
                            stringBuffer.append(" ").append(candidateSegment.getTranslatedText().trim());
                        }
                        candidateSegment.setTranslatedText("");//已经使用 需要先置空
                    }
                }
                segment.setTranslatedText(stringBuffer.toString());
            }

            if (isHasSuccess) {
                unmatchedSegments.clear();
                applyBaiduTranslations(batchTask, results);
                translateListener.onSuccess(batchTask, getTranslateType(), true);
                return;
            }

            if (size == 1) {
                String resultDest = baiduTranslateResult.getData().get(0).getDst();
                String resultSource = baiduTranslateResult.getData().get(0).getSrc();

                if (!TextUtils.isEmpty(resultDest) && !TextUtils.isEmpty(resultSource)) {
                    String[] strsDest = resultDest.split("\n");
                    String[] strsSource = resultSource.split("\n");
                    if (strsDest.length == results.size()) {
                        for (int i = 0; i < strsDest.length; i++) {
                            baiduSegment = results.get(i);
                            baiduSegment.setTranslatedText(strsDest[i].trim());
                        }
                    } else {
                        if (strsDest.length == strsSource.length) {
                            unmatchedSegments.clear();
                            for (int i = 0; i < strsSource.length; i++) {
                                baiduSegment = new BaiduTranslationSegment();
                                String lineText = strsSource[i].trim();//源数据
                                if (lineText.endsWith("\n")) {
                                    lineText = BaseUtils.replaceLast(lineText);
                                }
                                baiduSegment.setSourceText(lineText);
                                String dest = strsDest[i].trim();//翻译数据
                                int index = findBaiduSegmentIndex(results, baiduSegment.getSourceText());
                                if (index != -1) {
                                    results.get(index).setTranslatedText(dest);
                                    isHasSuccess = true;
                                } else {//记录下来找不到对于源数据的数据
                                    baiduSegment.setTranslatedText(dest);
                                    unmatchedSegments.add(baiduSegment);
                                }
                            }
                            StringBuilder oneStringBuffer = null;
                            for (BaiduTranslationSegment segment : results) {
                                if (!TextUtils.isEmpty(segment.getTranslatedText())) {//已经有值的不处理
                                    continue;
                                }
                                String source = segment.getSourceText();
                                if (TextUtils.isEmpty(source)) {
                                    continue;
                                }
                                if (unmatchedSegments.size() == 0) {
                                    continue;
                                }

                                oneStringBuffer = new StringBuilder();
                                for (BaiduTranslationSegment unmatchedSegment : unmatchedSegments) {
                                    if (TextUtils.isEmpty(unmatchedSegment.getTranslatedText()) || TextUtils.isEmpty(unmatchedSegment.getSourceText())) {
                                        LogManager.e("====null=======:");
                                        continue;
                                    }
                                    if (source.toLowerCase(Locale.ROOT).contains(unmatchedSegment.getSourceText().trim().toLowerCase(Locale.ROOT))) {
                                        isHasSuccess = true;
//                                        oneStringBuffer.append(unmatchedSegment.getTranslatedText()).append(" ");

                                        if (isChina) {
                                            oneStringBuffer.append(unmatchedSegment.getTranslatedText().trim());
                                        } else {
                                            oneStringBuffer.append(" ").append(unmatchedSegment.getTranslatedText().trim());
                                        }
                                        unmatchedSegment.setTranslatedText("");//已经使用 需要先置空
                                    }
                                }
                                segment.setTranslatedText(oneStringBuffer.toString().trim());
                            }
                        } else {//数据不一致
                            errorDealGoogle(translateListener);
                            return;
                        }
                    }
                } else {
                    LogManager.e("=========翻译出现问题==:");
                    errorDealGoogle(translateListener);
                    return;
                }
            } else {
                for (int i = 0; i < size; i++) {
                    String lineText = baiduTranslateResult.getData().get(i).getSrc().trim();//源数据
                    if (lineText.endsWith("\n")) {
                        lineText = BaseUtils.replaceLast(lineText);
                    }
                    String dest = baiduTranslateResult.getData().get(i).getDst().trim();//翻译数据
                    for (BaiduTranslationSegment segment : results) {
                        if (!TextUtils.isEmpty(segment.getTranslatedText()) || TextUtils.isEmpty(segment.getSourceText())) {
                            continue;
                        }
                        if (segment.getSourceText().trim().contains(lineText)) {
                            isHasSuccess = true;
                            segment.setTranslatedText(dest);
                            break;
                        }
                    }
                }

                if (!isHasSuccess) {
                    errorDealGoogle(translateListener);
                    return;
                }
            }
            unmatchedSegments.clear();
            applyBaiduTranslations(batchTask, results);
            translateListener.onSuccess(batchTask, getTranslateType(), true);
        }, () -> dealTranslateError(mContext, batchTask, translateListener));
    }

    public void translateContent(TranslationTask task, String appid, String appSecret, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }
        BaseReq baseReq = createBaiduBaseReq(task.getContent(), task.getSourceLanguageId(), task.getTargetLanguageId(), appid, appSecret);
        executeRequest(TranslateRepository.getInstance().baiduTranslate(baseReq), baiduTranslateResult -> {
            if (baiduTranslateResult == null ||
                    baiduTranslateResult.getData() == null || baiduTranslateResult.getErrorCode() != 0) {
                errorDealGoogle(translateListener);
                return;
            }
            StringBuilder stringBuffer = new StringBuilder();
            if (baiduTranslateResult.getData() != null) {
                for (TransResultBean transResultBean : baiduTranslateResult.getData()) {
                    stringBuffer.append(transResultBean.getDst()).append("\n");
                }
            }
            task.setTranslatedText(stringBuffer.toString().trim());
            translateListener.onSuccess(task, getTranslateType(), false);
        }, () -> dealTranslateError(mContext, task, translateListener));
    }

    public BaseReq createBaiduBaseReq(String content, String sourceCountry, String toCountry, String appid, String appSecret) {
        BaiduTranslateReq baiduTranslateReq = new BaiduTranslateReq();
        LanguageVO toLanguageVO = getSelectLanguageVO(toCountry, false);
        String tolanguage = "";
        if (toLanguageVO != null) {
            tolanguage = toLanguageVO.getValue();
        }
        baiduTranslateReq.setAppid(appid);
        baiduTranslateReq.setTo(tolanguage);
        baiduTranslateReq.setSalt((int) (System.currentTimeMillis() / 100000));
        baiduTranslateReq.setQ(content);
        String signParams = appid + content + baiduTranslateReq.getSalt() + appSecret;
        String sign = MD5Utils.md5Hex(signParams);
        baiduTranslateReq.setSign(sign);
        return baiduTranslateReq;
    }

    /**
     * 出现错误的时候处理逻辑
     */
    public void errorDealGoogle(TranslateListener translateListener) {
        translateListener.onFail(TranslationErrorCode.PROVIDER_UNAVAILABLE,
                mContext.getString(R.string.translation_error_provider_unavailable));
    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }

    @Override
    public void close() {
        super.close();
    }


    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_baidu);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.BAIDU.legacyCode;
    }

    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        // Baidu general translation catalog (201 languages), verified 2026-09-01.
        // eno, frm, log, sec, src and wyw require distinct shared identifiers; auto is source-only.
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ara"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish, "gle"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OCCITAN, R.string.language_Occitan, "oci"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian, "alb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALGERIAN_ARABIC, R.string.language_Algerian_Arabic, "arq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan, "aka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARAGORN, R.string.language_Aragorn, "arg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic, "amh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese, "asm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AYMARA, R.string.language_Aymara, "aym"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "aze"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASTURIAN, R.string.language_Asturian, "ast"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OSSETIAN, R.string.language_Ossetian, "oss"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian, "est"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OJIBWE, R.string.language_Ojibwe, "oji"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya, "ori"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo, "orm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish, "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian, "per"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BRETON, R.string.language_Breton, "bre"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASHKIR, R.string.language_Bashkir, "bak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "baq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese_Brazil, "pot"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "bel"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BERBER, R.string.language_Berber, "ber"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAMPANGA, R.string.language_Pampanga, "pam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgaria, "bul"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORTHERN_SAMI, R.string.language_Northern_Sami, "sme"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORTHERN_SPTHO, R.string.language_Northern_Sotho, "ped"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BUMBA, R.string.language_Bumba, "bem"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BILING, R.string.language_Biling, "bli"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BISLAMA, R.string.language_Bislama, "bis"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BALUCHI, R.string.language_Baluchi, "bal"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "ice"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bos"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BGOJPUR, R.string.language_Bhojpur, "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHUVASH, R.string.language_Chuvash, "chv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSUNGA, R.string.language_Tsunga, "tso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish, "dan"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar, "tat"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHAN, R.string.language_Shan, "sha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TETON, R.string.language_Teton, "tet"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi, "div"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fra"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino, "fil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish, "fin"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit, "san"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRIULI, R.string.language_Friuli, "fri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FULANI, R.string.language_Fulani, "ful"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FAROESE, R.string.language_Faroese, "fao"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic, "gla"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CONGO, R.string.language_Congo, "kon"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HIGHLAND_SORBIAN, R.string.language_Highland_Sorbian, "ups"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer, "hkm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREENLANDIC, R.string.language_Greenlandic, "kal"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian, "geo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati, "guj"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ANCIENT_GREEK, R.string.language_Ancient_Greek, "gra"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani, "grn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "kor"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUPA, R.string.language_Hupa, "hup"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAKACHIN, R.string.language_Hakachin, "hak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian, "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONTENEGRIN, R.string.language_Montenegrin, "mot"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa, "hau"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz, "kir"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "glg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH_CANADA, R.string.language_French_Canadian, "frn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan, "cat"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech, "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KABYLE, R.string.language_Kabyle, "kab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada, "kan"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANURI, R.string.language_Kanuri, "kau"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KASHUBIAN, R.string.language_Kashubian, "kah"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORNISH, R.string.language_Cornish, "cor"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa, "xho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican, "cos"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CREEK, R.string.language_Creek, "cre"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CRIMEAN_TATAR, R.string.language_Crimean_Tatar, "cri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KLINGON, R.string.language_Klingon, "kli"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian, "hrv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.QUECHUA, R.string.language_Quechua, "que"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KASHMIRI, R.string.language_Kashmiri, "kas"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani, "kok"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish, "kur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin, "lat"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao, "lao"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian, "rom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATJALAI, R.string.language_Latjalai, "lag"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian, "lav"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIMBURGISH, R.string.language_Limburgish, "lim"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala, "lin"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda, "lug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "ltz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSYNIAN, R.string.language_Rusynian, "ruy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda, "kin"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lit"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANSH, R.string.language_Romansh, "roh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANI, R.string.language_Romani, "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOGICAL_LANGUAGE, R.string.language_Logical_language, "loj"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay, "may"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese, "bur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "mal"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mac"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARSHALLESE, R.string.language_Marshallese, "mah"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili, "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MANKS, R.string.language_Manks, "glv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAURITIAN_CREOLE, R.string.language_Mauritian_Creole, "mau"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori, "mao"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali, "ben"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese, "mlt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong, "hmn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "nor"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEAPOLITAN, R.string.language_Neapolitan, "nea"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTH_NDEBELE, R.string.language_South_Ndebele, "nbl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "afr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho, "sot"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali, "nep"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi, "pan"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAPIAMENTO, R.string.language_Papiamento, "pap"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto, "pus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa, "nya"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TWI, R.string.language_Twi, "twi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHEROKEE, R.string.language_Cherokee, "chr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "jp"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish, "swe"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SARDINIAN, R.string.language_Sardinian, "srd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan, "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian, "srp"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SONGHAI, R.string.language_Songhai, "sol"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "sin"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto, "epo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN_BOKMAL, R.string.language_Norwegian_Bokmal, "nob"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "slo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili, "swa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali, "som"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SCOTS, R.string.language_Scots, "sco"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish, "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik, "tgk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil, "tam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog, "tgl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya, "tir"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu, "tel"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TUNISIAN_ARABIC, R.string.language_Tunisian_Arabic, "tua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen, "tuk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "ukr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WALLOON, R.string.language_Walloon, "wln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "wel"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VENDA, R.string.language_Venda, "ven"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WOLOF, R.string.language_Wolof, "wol"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu, "urd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "spa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew, "heb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek, "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian, "fry"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SILESIAN, R.string.language_Silesian, "sil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HILIGANUN, R.string.language_Hiliganun, "hil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOWER_SORBIAN, R.string.language_Lower_Sorbian, "los"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian, "haw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN_NYNORSK, R.string.language_Norwegian_Nynorsk, "nno"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NKO, R.string.language_Nko, "nqo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "snd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona, "sna"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SYRIAC, R.string.language_Syriac, "syr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese, "sun"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi, "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vie"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish, "yid"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INTER, R.string.language_Inter, "ina"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACEH, R.string.language_Aceh, "ach"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INGUSH, R.string.language_Ingush, "ing"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo, "ibo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IDO, R.string.language_Ido, "ido"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba, "yor"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian, "arm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUKTITUT, R.string.language_Inuktitut, "iku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "cht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CANTONESE, R.string.language_Cantonese, "yue"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZAZAQI, R.string.language_Zazaqi, "zaz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu, "zul"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese, "jav"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OLD_ENGLISH, R.string.language_Old_English, "eno"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MIDDLE_FRENCH, R.string.language_Middle_French, "frm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOW_GERMAN, R.string.language_Low_German, "log"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBO_CROATIAN, R.string.language_Serbo_Croatian, "sec"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN_CYRILLIC, R.string.language_Serbian_Cyrillic, "src"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITERARY_CHINESE, R.string.language_Literary_Chinese, "wyw"));
    }

}
