package com.mg.translation.translate;

/** Internal segment used only while reconciling Google Client batch responses. */
final class GoogleClientTranslationSegment {
    private String sourceText;
    private String translatedText;

    GoogleClientTranslationSegment() {
    }

    GoogleClientTranslationSegment(String sourceText) {
        this.sourceText = sourceText;
    }

    String getSourceText() {
        return sourceText;
    }

    void setSourceText(String sourceText) {
        this.sourceText = sourceText;
    }

    String getTranslatedText() {
        return translatedText;
    }

    void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

}
