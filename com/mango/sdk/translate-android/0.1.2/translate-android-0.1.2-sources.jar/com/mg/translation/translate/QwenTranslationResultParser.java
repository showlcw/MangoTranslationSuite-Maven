package com.mg.translation.translate;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;

/** SubFlowAI 同口径的 Qwen-MT 索引 JSON/旧数组响应解析。 */
final class QwenTranslationResultParser {
    private QwenTranslationResultParser() { }

    static List<String> parse(String content, int expectedCount) {
        if (content == null || content.trim().isEmpty() || expectedCount <= 0) return null;
        String objectText = extractContainer(content, '{', '}');
        if (objectText != null) {
            try {
                JsonObject object = JsonParser.parseString(
                        normalizeStructure(objectText)).getAsJsonObject();
                List<String> result = new ArrayList<>(expectedCount);
                for (int i = 0; i < expectedCount; i++) {
                    JsonElement value = object.get(String.valueOf(i));
                    if (value == null || !value.isJsonPrimitive()
                            || !value.getAsJsonPrimitive().isString()) return null;
                    result.add(value.getAsString());
                }
                return result;
            } catch (Exception ignored) {
                // Fall through to the legacy array response.
            }
        }
        String arrayText = extractContainer(content, '[', ']');
        if (arrayText == null) return null;
        try {
            JsonArray array = JsonParser.parseString(
                    normalizeStructure(arrayText)).getAsJsonArray();
            if (array.size() != expectedCount) return null;
            List<String> result = new ArrayList<>(expectedCount);
            for (JsonElement value : array) {
                if (value == null || !value.isJsonPrimitive()
                        || !value.getAsJsonPrimitive().isString()) return null;
                result.add(value.getAsString());
            }
            return result;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String extractContainer(String content, char open, char close) {
        for (int start = content.indexOf(open); start >= 0;
             start = content.indexOf(open, start + 1)) {
            int depth = 0;
            char expectedQuote = 0;
            for (int i = start; i < content.length(); i++) {
                char current = content.charAt(i);
                if (expectedQuote != 0) {
                    if (current == '\\' && i + 1 < content.length()) i++;
                    else if (current == expectedQuote) expectedQuote = 0;
                    continue;
                }
                char quoteEnd = quoteEnd(current);
                if (quoteEnd != 0) expectedQuote = quoteEnd;
                else if (current == open) depth++;
                else if (current == close && --depth == 0) return content.substring(start, i + 1);
            }
        }
        return null;
    }

    private static String normalizeStructure(String value) {
        StringBuilder normalized = new StringBuilder(value.length());
        char expectedQuote = 0;
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (expectedQuote != 0) {
                if (current == '\\' && i + 1 < value.length()) {
                    normalized.append(current).append(value.charAt(++i));
                } else if (current == expectedQuote) {
                    normalized.append('"');
                    expectedQuote = 0;
                } else {
                    normalized.append(current);
                }
                continue;
            }
            char quoteEnd = quoteEnd(current);
            if (quoteEnd != 0) {
                normalized.append('"');
                expectedQuote = quoteEnd;
            } else if (current == '،' || current == '，' || current == '、') {
                normalized.append(',');
            } else if (current == '：') {
                normalized.append(':');
            } else {
                normalized.append(current);
            }
        }
        return removeTrailingSeparators(normalized.toString());
    }

    private static String removeTrailingSeparators(String value) {
        StringBuilder result = new StringBuilder(value.length());
        boolean inString = false;
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (current == '"' && (i == 0 || value.charAt(i - 1) != '\\')) inString = !inString;
            if (!inString && current == ',') {
                int next = i + 1;
                while (next < value.length() && Character.isWhitespace(value.charAt(next))) next++;
                if (next < value.length() && (value.charAt(next) == '}' || value.charAt(next) == ']')) {
                    continue;
                }
            }
            result.append(current);
        }
        return result.toString();
    }

    private static char quoteEnd(char start) {
        switch (start) {
            case '"':
            case '\'': return start;
            case '“': return '”';
            case '‘': return '’';
            case '«': return '»';
            default: return 0;
        }
    }
}
