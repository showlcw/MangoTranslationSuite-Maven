package com.mg.translation.translate;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.mango.sdk.translation.R;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.utils.TranslateUtils;

/**
 * @author LiChunWei
 * @description: 会员提醒翻译  翻译
 * @date :2021/5/7 10:15
 */
public class VipTipsTranslate extends BaseTranslateControl {


    private final Context mContext;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public VipTipsTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        boolean isVip = TranslateUtils.isVip(mContext);
        if (isVip) {
            translateListener.onFail(TranslationErrorCode.PROVIDER_UNAVAILABLE,
                    mContext.getString(R.string.translation_error_provider_unavailable));
        } else {
            mHandler.postDelayed(() -> translateListener.onFail(
                    TranslationErrorCode.VIP_REQUIRED,
                    mContext.getString(R.string.translation_error_vip_required)), 200);
        }
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_google);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.TIPS.legacyCode;
    }
}
