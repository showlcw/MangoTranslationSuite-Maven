package com.mg.translation.translate;

import com.mg.translation.engine.TranslatorId;

import static com.mg.translation.utils.TranslationPreferenceKeys.YD_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslateUtils.getListStringSourceText;

import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.LogManager;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.req.MeTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.runtime.TranslationTelemetry;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author LiChunWei
 * @description: google  翻译
 * @date :2021/5/7 10:15
 */
public class YdTranslate extends BaseTranslateControl {
    private final Context mContext;
    private List<LanguageVO> mDestLanguageList;

    public YdTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        if (!TranslateUtils.hasEnabledTranslationEngine()) {
            LogManager.e(" Yd translate   不能使用");
            dealTranslateError(mContext, task, translateListener);
            return;
        }

        if (!TranslateUtils.getYdApiState(mContext)) {//
            LogManager.e(" Yd translate   error");
            dealTranslateError(mContext, task, translateListener);
            return;
        }

        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, translateListener);
    }

    /**
     * 翻译
     */
    public synchronized void translateListApi(BatchTranslationTask batchTask, TranslateListener translateListener) {
        LogManager.e(" Yd translate   translateListApi");
        List<String> sourceTexts = batchTask.getSourceTexts();
        LanguageVO sourceLanguageVO = getSelectLanguageVO(batchTask.getSourceLanguageId(), false);
        if (sourceLanguageVO == null && !LanguageConstant.AUTO.equals(batchTask.getSourceLanguageId())) {
            LogManager.e("yd  bu  support");
            dealTranslateError(mContext, batchTask, translateListener);
            return;
        }

        if (!TranslateUtils.hasEnabledTranslationEngine()) {
            LogManager.e(" Yd translate   不能使用");
            dealTranslateError(mContext, batchTask, translateListener);
            return;
        }

        List<String> content = getListStringSourceText(sourceTexts);
        executeRequest(TranslateRepository.getInstance().ydTranslate(createJsonBaseReq(content, batchTask.getTargetLanguageId())), meTranslateHttpResult -> {
            LogManager.e(" Yd translate   list  state ");
            if (meTranslateHttpResult.isSuccess()) {
                String[] textString = meTranslateHttpResult.getTexts();
                if (sourceTexts.size() == textString.length) {
                    for (int i = 0; i < sourceTexts.size(); i++) {
                        batchTask.setTranslation(i, textString[i]);
                    }
                    translateListener.onSuccess(batchTask, getTranslateType(), true);
                    return;
                } else {
                    LogManager.e("Youdao batch result count mismatch");
                    TranslationTelemetry.event("youdao_direct_result_count_mismatch");
                    SdkPreferences.getInstance(mContext).put(YD_TRANSLATE_STATE, System.currentTimeMillis());
                }
            } else {
                LogManager.e("Youdao batch request failed");
                SdkPreferences.getInstance(mContext).put(YD_TRANSLATE_STATE, System.currentTimeMillis());
            }
            dealTranslateError(mContext, batchTask, translateListener);
        }, () -> dealTranslateError(mContext, batchTask, translateListener));
    }

    public void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }
        LanguageVO sourceLanguageVO = getSelectLanguageVO(task.getSourceLanguageId(), false);
        if (sourceLanguageVO == null && !LanguageConstant.AUTO.equals(task.getSourceLanguageId())) {
            LogManager.e("yd  bu  support");
            dealTranslateError(mContext, task, translateListener);
            return;
        }

        String[] strings = task.getContent().split("\n");

        List<String> list = new ArrayList<>();
        Collections.addAll(list, strings);
        executeRequest(TranslateRepository.getInstance().ydTranslate(createJsonBaseReq(list, task.getTargetLanguageId())), meTranslateHttpResult -> {
            if (meTranslateHttpResult.isSuccess()) {
                String[] textString = meTranslateHttpResult.getTexts();
                StringBuilder stringBuffer = new StringBuilder();
                for (String str : textString) {
                    stringBuffer.append(str).append("\n");
                }
                task.setTranslatedText(stringBuffer.toString().trim());
                translateListener.onSuccess(task, getTranslateType(), false);
            } else {
                SdkPreferences.getInstance(mContext).put(YD_TRANSLATE_STATE, System.currentTimeMillis());
                dealTranslateError(mContext, task, translateListener);
            }
        }, () -> dealTranslateError(mContext, task, translateListener));
    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }


    public BaseReq createJsonBaseReq(List<String> content, String toCountry) {

        MeTranslateReq googleTranslateReq = new MeTranslateReq();
        LanguageVO tolanguageVO = getSelectLanguageVO(toCountry, false);
        if (tolanguageVO != null) {
            googleTranslateReq.setTl(tolanguageVO.getValue());
        }
        String[] strArray1 = new String[content.size()];
        String[] strArray2 = content.toArray(strArray1);
        googleTranslateReq.setQ(strArray2);

        return googleTranslateReq;
    }


    @Override
    public void close() {
        super.close();
    }


    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-CHS"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.name_youdao_str);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.YOUDAO_ME.legacyCode;
    }
}
