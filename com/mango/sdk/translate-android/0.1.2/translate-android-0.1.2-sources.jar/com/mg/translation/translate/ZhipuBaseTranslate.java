package com.mg.translation.translate;

import static com.mg.translation.utils.TranslateUtils.getListStringSourceText;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.LogManager;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.req.DeepSeekContentReq;
import com.mg.translation.http.req.DeepSeekTranslateReq;
import com.mg.translation.http.result.DeepSeekMessageResult;
import com.mg.translation.http.result.DeepSeekTranslationResult;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.utils.TranslateUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

abstract class ZhipuBaseTranslate extends BaseTranslateControl {

    private static final float DEFAULT_TEMPERATURE = 0.3f;

    protected final Context mContext;
    private final Resources mResources;
    private List<LanguageVO> mDestLanguageList;

    ZhipuBaseTranslate(Context context) {
        mContext = context;
        Configuration configuration = new Configuration(mContext.getResources().getConfiguration());
        configuration.setLocale(Locale.CHINA);
        mResources = mContext.createConfigurationContext(configuration).getResources();
    }

    protected abstract String getModel();

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }

        if (TranslationSdk.isVipOnly(getTranslateType()) && !TranslateUtils.isVip(mContext)) {
            translateListener.onFail(TranslationErrorCode.VIP_REQUIRED,
                    mContext.getString(R.string.translation_error_vip_required));
            return;
        }

        if (task instanceof BatchTranslationTask) {
            translateListApi((BatchTranslationTask) task, translateListener);
            return;
        }

        translateContent(task, translateListener);
    }

    private void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }

        executeRequest(
                TranslateRepository.getInstance().zhipuTranslateText(
                        mContext,
                        createBaseReq(task.getContent(), task.getSourceLanguageId(), task.getTargetLanguageId())
                ),
                result -> {
                    DeepSeekMessageResult message = getFirstMessage(result);
                    if (message == null || TextUtils.isEmpty(message.getContent())) {
                        dealTranslateError(mContext, task, translateListener);
                        return;
                    }

                    task.setTranslatedText(message.getContent());
                    translateListener.onSuccess(task, getTranslateType(), false);
                }, () -> dealTranslateError(mContext, task, translateListener));
    }

    private synchronized void translateListApi(BatchTranslationTask batchTask, TranslateListener translateListener) {
        List<String> sourceTexts = batchTask.getSourceTexts();
        List<String> sourceList = getListStringSourceText(sourceTexts);

        executeRequest(
                TranslateRepository.getInstance().zhipuTranslateText(
                        mContext,
                        createBaseListReq(sourceList, batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId())
                ),
                result -> {
                    DeepSeekMessageResult message = getFirstMessage(result);
                    if (message == null || TextUtils.isEmpty(message.getContent())) {
                        dealTranslateError(mContext, batchTask, translateListener);
                        return;
                    }

                    String stringResult = message.getContent().trim();
                    if (applyIndexedJsonResult(batchTask, stringResult)) {
                        translateListener.onSuccess(batchTask, getTranslateType(), true);
                        return;
                    }

                    if (applyArrayResult(batchTask, stringResult)) {
                        translateListener.onSuccess(batchTask, getTranslateType(), true);
                        return;
                    }

                    LogManager.e("AI Provider response parsing failed");
                    dealTranslateError(mContext, batchTask, translateListener);
                }, () -> dealTranslateError(mContext, batchTask, translateListener));
    }

    private DeepSeekMessageResult getFirstMessage(DeepSeekTranslationResult result) {
        if (result == null || result.getCode() != 0) {
            return null;
        }
        List<DeepSeekTranslationResult.DeepSeekChoices> choices = result.getChoices();
        if (choices == null || choices.isEmpty() || choices.get(0) == null) {
            return null;
        }
        return choices.get(0).getMessage();
    }

    private boolean applyIndexedJsonResult(@NonNull BatchTranslationTask request, @NonNull String content) {
        try {
            JSONObject jsonObject = new JSONObject(content);
            List<String> sourceTexts = request.getSourceTexts();
            int matchCount = 0;
            for (int i = 0; i < sourceTexts.size(); i++) {
                String key = String.valueOf(i);
                if (jsonObject.has(key)) {
                    request.setTranslation(i, jsonObject.getString(key));
                    matchCount++;
                } else {
                    request.setTranslation(i, sourceTexts.get(i));
                }
            }
            return matchCount > 0;
        } catch (Exception ignore) {
            return false;
        }
    }

    private boolean applyArrayResult(@NonNull BatchTranslationTask request, @NonNull String content) {
        try {
            JSONArray jsonArray = new JSONArray(content);
            List<String> sourceTexts = request.getSourceTexts();
            if (jsonArray.length() != sourceTexts.size()) {
                return false;
            }
            for (int i = 0; i < jsonArray.length(); i++) {
                request.setTranslation(i, jsonArray.getString(i));
            }
            return true;
        } catch (Exception ignore) {
            return false;
        }
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }

    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian,
                "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic,
                "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian,
                "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese,
                "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani,
                "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara,
                "bm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque,
                "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian,
                "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali,
                "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri,
                "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian,
                "bs"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian,
                "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan,
                "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano,
                "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese,
                "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican,
                "co"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian,
                "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish,
                "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi,
                "dv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri,
                "doi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto,
                "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian,
                "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino,
                "fil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish,
                "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian,
                "fy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician,
                "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian,
                "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek,
                "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani,
                "gn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian,
                "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa,
                "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian,
                "haw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong,
                "hmn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN,
                R.string.language_Hungarian,
                "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic,
                "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo,
                "ig"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ILOCANO, R.string.language_Ilocano,
                "ilo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN,
                R.string.language_Indonesian,
                "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish,
                "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese,
                "jv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada,
                "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh,
                "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer,
                "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda,
                "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani,
                "gom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KRIO, R.string.language_Krio,
                "kri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish,
                "ku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SORANI, R.string.language_Sorani,
                "ckb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz,
                "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao,
                "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin,
                "la"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian,
                "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian,
                "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda,
                "lg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish,
                "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian,
                "mk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili,
                "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy,
                "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese,
                "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori,
                "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi,
                "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian,
                "mn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali,
                "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN,
                R.string.language_Norwegian,
                "no"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa,
                "ny"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya,
                "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo,
                "om"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto,
                "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian,
                "fa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE,
                R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi,
                "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian,
                "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan,
                "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit,
                "sa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic,
                "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi,
                "nso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian,
                "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho,
                "st"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona,
                "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi,
                "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala,
                "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak,
                "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian,
                "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali,
                "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese,
                "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili,
                "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish,
                "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog,
                "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik,
                "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai,
                "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga,
                "ts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen,
                "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur,
                "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek,
                "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh,
                "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa,
                "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish,
                "yi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba,
                "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu,
                "zu"));
    }

    private BaseReq createBaseListReq(List<String> stringList, String source, String to) {
        List<DeepSeekContentReq> contents = getContents(to, true);
        LinkedHashMap<String, String> indexedMap = new LinkedHashMap<>();
        for (int i = 0; i < stringList.size(); i++) {
            indexedMap.put(String.valueOf(i), stringList.get(i));
        }
        contents.add(new DeepSeekContentReq("user", GsonUtil.toJson(indexedMap)));

        DeepSeekTranslateReq req = new DeepSeekTranslateReq(contents);
        req.setModel(getModel());
        req.setTemperature(DEFAULT_TEMPERATURE);
        return req;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        List<DeepSeekContentReq> contents = getContents(to, false);
        contents.add(new DeepSeekContentReq("user", content));

        DeepSeekTranslateReq req = new DeepSeekTranslateReq(contents);
        req.setModel(getModel());
        req.setTemperature(DEFAULT_TEMPERATURE);
        return req;
    }

    @NonNull
    private List<DeepSeekContentReq> getContents(String to, boolean isList) {
        List<DeepSeekContentReq> contentList = new ArrayList<>();
        String toLanguage = null;
        LanguageVO toLanguageVO = getSelectLanguageVO(to, false);
        if (toLanguageVO != null) {
            toLanguage = mResources.getString(toLanguageVO.getCountry());
        }

        DeepSeekContentReq system = new DeepSeekContentReq();
        system.setRole("system");
        system.setContent(isList ? buildBatchTranslatePrompt(toLanguage) : buildSingleTranslatePrompt(toLanguage));
        contentList.add(system);
        return contentList;
    }

    private String buildSingleTranslatePrompt(String targetLanguage) {
        return "You are a professional translation assistant. Translate the user input into "
                + targetLanguage
                + ". Preserve meaning, formatting, punctuation, line breaks, and terminology. Return only the translation.";
    }

    private String buildBatchTranslatePrompt(String targetLanguage) {
        return "You are a professional translation assistant. The user will provide a JSON object indexed by string keys. "
                + "Translate every value into " + targetLanguage
                + " and return a JSON object with exactly the same keys. Return only valid JSON.";
    }
}
