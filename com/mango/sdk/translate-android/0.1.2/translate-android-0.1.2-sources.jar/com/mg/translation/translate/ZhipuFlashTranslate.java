package com.mg.translation.translate;

import com.mg.translation.engine.TranslatorId;


import android.content.Context;
import android.text.TextUtils;

import com.mango.sdk.translation.R;
import com.mg.translation.utils.TranslateUtils;

public class ZhipuFlashTranslate extends ZhipuBaseTranslate {

    private static final String DEFAULT_MODEL = "glm-5.3-flash";

    public ZhipuFlashTranslate(Context context) {
        super(context);
    }

    @Override
    protected String getModel() {
        String configuredModel = TranslateUtils.getZhipuModel(mContext);
        return TextUtils.isEmpty(configuredModel) ? DEFAULT_MODEL : configuredModel.trim();
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.zhipu_flash_name);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.ZHIPU_FLASH.legacyCode;
    }
}
