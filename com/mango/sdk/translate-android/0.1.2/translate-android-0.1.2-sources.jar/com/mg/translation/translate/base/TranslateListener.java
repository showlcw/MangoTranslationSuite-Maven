package com.mg.translation.translate.base;

import com.mg.translation.internal.model.TranslationTask;

/**
 * Created
 */
public interface TranslateListener {
    void onSuccess(TranslationTask task, int translateType, boolean isList);

    void onFail(int code, String message);
}
