package com.mg.translation.utils;

import com.mg.translation.engine.TranslatorId;

import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_TRANSLATE_LAST_USER_TIME;

import android.content.Context;
import android.os.SystemClock;

import com.mg.translation.internal.base.SdkPreferences;

/**
 * GOOGLE_CLIENT 与 GOOGLE 共用的免费接口请求闸门。
 *
 * <p>Voice 原规则要求请求间隔至少 6 秒。这里将原先分散的“读取时间→判断→写入”合并为
 * 一个同步原子操作，防止多个翻译请求并发穿透。进程内使用单调时钟，SDK 私有时间戳用于
 * App 重启后的间隔延续。</p>
 */
public final class FreeGoogleRequestGate {
    private static long lastReservedElapsedMs;

    private FreeGoogleRequestGate() { }

    public static synchronized boolean isReady(Context context) {
        return remainingMs(context, System.currentTimeMillis(), SystemClock.elapsedRealtime()) == 0L;
    }

    public static synchronized boolean tryAcquire(Context context, int engineId) {
        if (engineId != TranslatorId.GOOGLE_CLIENT.legacyCode && engineId != TranslatorId.GOOGLE.legacyCode) return true;
        long nowWall = System.currentTimeMillis();
        long nowElapsed = SystemClock.elapsedRealtime();
        if (remainingMs(context, nowWall, nowElapsed) > 0L) return false;
        lastReservedElapsedMs = nowElapsed;
        String key = engineId == TranslatorId.GOOGLE_CLIENT.legacyCode
                ? GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME : GOOGLE_TRANSLATE_LAST_USER_TIME;
        SdkPreferences.getInstance(context).put(key, nowWall);
        return true;
    }

    private static long remainingMs(Context context, long nowWall, long nowElapsed) {
        long lastClient = SdkPreferences.getInstance(context)
                .getLong(GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME, 0L);
        long lastGoogle = SdkPreferences.getInstance(context)
                .getLong(GOOGLE_TRANSLATE_LAST_USER_TIME, 0L);
        long wallElapsed = nowWall - Math.max(lastClient, lastGoogle);
        long monotonicElapsed = lastReservedElapsedMs == 0L
                ? Long.MAX_VALUE : nowElapsed - lastReservedElapsedMs;
        long elapsed = Math.min(wallElapsed, monotonicElapsed);
        return elapsed >= TranslateUtils.TRANSLATE_SPACE_TIME
                ? 0L : TranslateUtils.TRANSLATE_SPACE_TIME - Math.max(0L, elapsed);
    }

    static synchronized void resetForTest() {
        lastReservedElapsedMs = 0L;
    }
}
