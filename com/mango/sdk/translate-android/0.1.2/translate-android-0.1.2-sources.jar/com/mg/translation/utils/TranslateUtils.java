package com.mg.translation.utils;

import com.mg.translation.engine.TranslatorId;


import static com.mg.translation.utils.TranslationPreferenceKeys.AI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.BD_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEPSEEK_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_CLIENT_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_TRANSLATE_LAST_USER_TIME;
import static com.mg.translation.utils.TranslationPreferenceKeys.SELF_HOSTED_GOOGLE_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.IRCTCAPI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MEMORY_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_VIP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MULTI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.PLUS_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.QWEN_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.WEBSITE_PLUS_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.YD_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.YOUDAO_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.ZHIPU_TRANSLATE_STATE;

import android.content.Context;

import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.internal.base.BaseUtils;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateFactory;
import com.mg.translation.internal.model.TranslationTask;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TranslateUtils {
    private TranslateUtils() { }

    public static final int TRANSLATE_SPACE_TIME = 6000;//翻译间隔时间

    /**
     * 唯一自动降级顺序。用户主动选择的引擎由上层先执行；此数组只用于失败后的本次请求，
     * 绝不修改或持久化用户选择的 Legacy Code。
     */
    private static final int[] FALLBACK_ORDER = {
            TranslatorId.GOOGLE_CLIENT.legacyCode,
            TranslatorId.SELF_HOSTED_GOOGLE.legacyCode,
            TranslatorId.GOOGLE.legacyCode,
            TranslatorId.QWEN.legacyCode,
            TranslatorId.ZHIPU_FLASH.legacyCode,
            TranslatorId.MYMEMORY.legacyCode,
            TranslatorId.RAPID_IRCTCAPI.legacyCode,
            TranslatorId.RAPID_MULTI.legacyCode,
            TranslatorId.RAPID_WEBSITE_PLUS.legacyCode,
            TranslatorId.MICROSOFT.legacyCode,
            TranslatorId.YOUDAO.legacyCode,
            TranslatorId.BD.legacyCode,
            TranslatorId.RAPID_AI.legacyCode,
            TranslatorId.DEEPSEEK.legacyCode,
            TranslatorId.RAPID_PLUS.legacyCode,
            TranslatorId.RAPID_DEEP.legacyCode,
            TranslatorId.GOOGLE_V.legacyCode,
            TranslatorId.MICROSOFT_VIP.legacyCode,
            TranslatorId.BAIDU.legacyCode
    };

    private static TranslateControl selectFallback(Context context, String source, String target,
                                                    List<Integer> attempted, boolean batch) {
        for (int engineId : FALLBACK_ORDER) {
        if (batch && !supportsBatch(engineId)) continue;
            TranslateControl control = tryFallbackEngine(
                    context, engineId, source, target, attempted);
            if (control != null) return control;
        }
        return null;
    }

    private static TranslateControl tryFallbackEngine(Context context, int engineId,
                                                       String source, String target,
                                                       List<Integer> attempted) {
        if (attempted.contains(engineId) || !TranslationSdk.isEngineEnabled(engineId)) {
            return null;
        }
        boolean member = TranslationRuntime.get().host().isVip();
        if (TranslationSdk.isVipOnly(engineId) && !member) {
            return null;
        }
        if (!isEngineHealthy(context, engineId)) return null;
        return getTranslateByType(engineId, source, target, context);
    }

    private static boolean supportsBatch(int engineId) {
        TranslatorId translatorId = TranslatorId.fromLegacyCode(engineId);
        return translatorId != null && translatorId.supportsBatch();
    }

    private static boolean isEngineHealthy(Context context, int engineId) {
        TranslatorId translatorId = TranslatorId.fromLegacyCode(engineId);
        if (translatorId == null) return false;
        switch (translatorId) {
            case GOOGLE_CLIENT:
                return isCanUseGoogleApi(context) && getGoogleClientState(context)
                        && FreeGoogleRequestGate.isReady(context);
            case SELF_HOSTED_GOOGLE:
                return getSelfHostedGoogleApiState(context);
            case GOOGLE:
                return isCanUseGoogleApi(context) && getGoogleApiState(context)
                        && FreeGoogleRequestGate.isReady(context);
            case QWEN: return getQwenApiState(context);
            case ZHIPU_FLASH: return getZhipuApiState(context);
            case MYMEMORY: return getMemoryApiState(context);
            case RAPID_IRCTCAPI: return getRapidIrctcapiApiState(context);
            case RAPID_MULTI: return getRapidMultiApiState(context);
            case RAPID_WEBSITE_PLUS: return getWebSitePlusApiState(context);
            case MICROSOFT: return getMicrosoftApiState(context);
            case YOUDAO: return getYoudaoApiState(context);
            case BD: return getBdApiState(context);
            case RAPID_AI: return getRapidAiApiState(context);
            case DEEPSEEK: return getDeepSeekApiState(context);
            case RAPID_PLUS: return getRapidPlusApiState(context);
            case RAPID_DEEP: return getRapidDeepApiState(context);
            case MICROSOFT_VIP: return getMicrosoftVIPApiState(context);
            case GOOGLE_V:
            case BAIDU:
                return true;
            default: return false;
        }
    }

    /**
     * qwen-mt 领域/风格提示(服务端可下发热更措辞;null/空时由 QwenTranslate 用内置默认)
     */
    public static String getQwenMtDomains(Context context) {
        return TranslationRuntime.get().qwenDomains();
    }

    /**
     * 获取当前可以使用的翻译方式
     */
    public static TranslateControl getCanTranslateType(Context context,
                                                        TranslationTask task,
                                                        boolean isList) {
        if (task == null || task.getAttemptedEngineIds().isEmpty()) {
            return null;
        }
        return selectFallback(context, task.getSourceLanguageId(),
                task.getTargetLanguageId(), task.getAttemptedEngineIds(), isList);
    }

    public static boolean isCanUseGoogleApi(Context context) {
        return TranslationRuntime.get().host().isGoogleBuild()
                && hasEnabledTranslationEngine();
    }

    /**
     * 是否可以使用免费的百度或者有道翻译
     *
     * @param context
     * @return
     */
    public static boolean hasEnabledTranslationEngine() {
        return TranslationRuntime.get().hasEnabledEngines();
    }


    public static boolean isVip(Context context) {
        return TranslationRuntime.get().host().isVip();
    }


    public static boolean isLocalVip(Context context) {
        return TranslationRuntime.get().host().isVip();
    }

    /**
     * 判断Qwen（千问）翻译是否可以使用
     */
    public static boolean getQwenApiState(Context context) {
        return engineState(context, QWEN_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.QWEN);
    }

    public static boolean getDeepSeekApiState(Context context) {
        return engineState(context, DEEPSEEK_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.DEEPSEEK);
    }

    public static boolean getZhipuApiState(Context context) {
        return engineState(context, ZHIPU_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.ZHIPU_FLASH);
    }

    // ==================== 通用状态检查方法 ====================

    /**
     * 通用翻译API状态检查方法
     * @param context 上下文
     * @param stateKey 状态存储的key
     * @param timeoutMs 超时时间（毫秒），超过此时间后可以重新使用
     * @return true: 可以使用, false: 暂时不可用
     */
    public static boolean getTranslateApiState(Context context, String stateKey, long timeoutMs) {
        long errorTime = SdkPreferences.getInstance(context).getLong(stateKey, 0L);
        long elapsedTime = System.currentTimeMillis() - errorTime;
        if (elapsedTime > timeoutMs) {
            SdkPreferences.getInstance(context).put(stateKey, 0L);
            return true;
        }
        return false;
    }

    private static boolean engineState(Context context, String stateKey,
                                       com.mg.translation.engine.TranslatorId engine) {
        return getTranslateApiState(context, stateKey, engine.defaultCooldownMs);
    }

    /**
     * 获取Google api 是否可以使用
     */
    public static boolean getGoogleApiState(Context context) {
        return engineState(context, GOOGLE_FREE_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.GOOGLE);
    }

    public static boolean getSelfHostedGoogleApiState(Context context) {
        return engineState(context, SELF_HOSTED_GOOGLE_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.SELF_HOSTED_GOOGLE);
    }

    /**
     * 获取Google Client api 是否可以使用
     */
    public static boolean getGoogleClientState(Context context) {
        return engineState(context, GOOGLE_FREE_CLIENT_STATE,
                com.mg.translation.engine.TranslatorId.GOOGLE_CLIENT);
    }

    /**
     * 获取Bd是否可以使用
     */
    public static boolean getBdApiState(Context context) {
        return engineState(context, BD_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.BD);
    }

    public static boolean getYdApiState(Context context) {
        return engineState(context, YD_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.YOUDAO_ME);
    }


    /**
     * 获取Memory是否可以使用
     */
    public static boolean getMemoryApiState(Context context) {
        return engineState(context, MEMORY_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MYMEMORY);
    }


    /**
     * 获取youdao是否可以使用
     */
    public static boolean getYoudaoApiState(Context context) {
        return engineState(context, YOUDAO_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.YOUDAO);
    }

    /**
     * 判断plus是否可以使用
     */
    public static boolean getRapidPlusApiState(Context context) {
        return engineState(context, PLUS_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_PLUS);
    }

    /** TranslatePlus direct subscription state. */
    public static boolean getWebSitePlusApiState(Context context) {
        return engineState(context, WEBSITE_PLUS_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_WEBSITE_PLUS);
    }


    /**
     * 判断deep是否可以使用
     */
    public static boolean getRapidDeepApiState(Context context) {
        return engineState(context, DEEP_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_DEEP);
    }

    /**
     * 判断deep是否可以使用
     */
    public static boolean getRapidIrctcapiApiState(Context context) {
        return engineState(context, IRCTCAPI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_IRCTCAPI);
    }

    /**
     * 判断Multi是否可以使用
     */
    public static boolean getRapidMultiApiState(Context context) {
        return engineState(context, MULTI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_MULTI);
    }


    /**
     * 判断ai是否可以使用
     */
    public static boolean getRapidAiApiState(Context context) {
        return engineState(context, AI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_AI);
    }


    /**
     * 判断Microsoft是否可用（超时1小时）
     */
    public static boolean getMicrosoftApiState(Context context) {
        return engineState(context, MICROSOFT_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MICROSOFT);
    }

    public static boolean getMicrosoftVIPApiState(Context context) {
        return engineState(context, MICROSOFT_VIP_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MICROSOFT_VIP);
    }


    /**
     * 通过类型获取翻译类
     */
    public static TranslateControl getTranslateByType(int type, String sourceCountry, String toCountry, Context context) {
        // The App-specific backend configuration is the only availability authority. This gate
        // also applies to transports that do not put the configured value on the wire.
        if (!TranslationSdk.isEngineEnabled(type)) {
            return null;
        }
        TranslateControl translateControl = TranslateFactory.createTranslate(context, type);
        if (translateControl == null) {
            return null;
        }
        List<LanguageVO> languageVOList = translateControl.getSupportLanguage();//百度支持的语言
        if (languageVOList == null || languageVOList.isEmpty()) {
            return null;
        }
        if (LanguageConstant.AUTO.equals(sourceCountry)) {//自动识别模式  需要判断下当前翻译类型是否支持自动识别
            if (!translateControl.isSupportAuto()) {//不支持自动识别模式
                return null;
            }
        } else {
            if (!isCanUser(sourceCountry, languageVOList)) {//识别语言不支持
                return null;
            }
        }

        if (!isCanUser(toCountry, languageVOList)) {//翻译语言语言不支持
            return null;
        }
        return translateControl;
    }


    public static int getFirstTranslateType(Context context) {
        return TranslationRuntime.get().firstTranslateType();
    }

    public static String getAiRapidApiKey(Context context) {
        return TranslationRuntime.get().aiRapidKey();
    }

    public static boolean isGoogle() {
        return TranslationRuntime.get().host().isGoogleBuild();
    }

    public static String getIrctcapiRapidApiKey(Context context) {
        return TranslationRuntime.get().irctcapiRapidKey();
    }


    public static String getDeepSeekApiKey(Context context) {
        return TranslationRuntime.get().deepSeekKey();
    }

    public static String getZhipuApiKey(Context context) {
        return TranslationRuntime.get().zhipuKey();
    }

    public static String getZhipuModel(Context context) {
        return TranslationRuntime.get().zhipuModel();
    }

    public static String getPlusRapidApiKey(Context context) {
        return TranslationRuntime.get().plusRapidKey();
    }

    public static String getWebSitePlusKey(Context context) {
        return TranslationRuntime.get().websitePlusKey();
    }


    public static List<String> getRecentlyHistoryList(Context context, boolean source) {
        return TranslationRuntime.get().recentLanguages(source);
    }

    public static void saveRecentlyHistoryList(Context context, String languageKey, boolean source) {
        TranslationRuntime.get().saveRecentLanguage(languageKey, source);
    }

    public static String getDeepRapidApiKey(Context context) {
        return TranslationRuntime.get().deepRapidKey();
    }

    public static String getBaiduIdKey(Context context) {
        return TranslationRuntime.get().baiduAppId();
    }

    public static String getBaiduSecretKey(Context context) {
        return TranslationRuntime.get().baiduSecret();
    }


//
//
//    public static String getBaiDuVoiceSecret(Context context) {
//        Legacy Voice-specific credential access intentionally remains outside the SDK.
//    }

    public static String getYouDaoIdKey(Context context) {
        return TranslationRuntime.get().youdaoAppId();
    }


    public static String getYouDaoSecretKey(Context context) {
        return TranslationRuntime.get().youdaoSecret();
    }

    public static String getMultiRapidApiKey(Context context) {
        return TranslationRuntime.get().multiRapidKey();
    }

    public static String getFreeMicrosoftApiKey(Context context) {
        return TranslationRuntime.get().freeMicrosoftKey();
    }

    public static String getMicrosoftApiKey(Context context) {
        return TranslationRuntime.get().microsoftKey();
    }

    public static String getGoogleVipApiKey(Context context) {
        return TranslationRuntime.get().googleVipKey();
    }


    public static String getAppSignatureSha1(Context context) {
        return BaseUtils.getAppSignatureSha1(context);
    }


    /**
     * 判断是否包含特殊字符
     *
     * @return false:未包含 true：包含
     */
    public static boolean inputJudge(String editText) {
        String speChat = "[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’↠。，↡→、？]";
        Pattern pattern = Pattern.compile(speChat);
        Matcher matcher = pattern.matcher(editText);
        return matcher.find();
    }

    public static String getSourceText(List<String> sourceTexts, String space) {
        StringBuilder stringBuffer = new StringBuilder();
        int size = sourceTexts.size();
        for (int i = 0; i < size; i++) {
            String str = sourceTexts.get(i);
            if (i == size - 1) {
                stringBuffer.append(str);
            } else {
                stringBuffer.append(str).append(space);
            }
        }
        return stringBuffer.toString();
    }


    public static List<String> getListStringSourceText(List<String> sourceTexts) {
        return new ArrayList<>(sourceTexts);
    }


    public static String[] getStringListText(List<String> sourceTexts) {
        return sourceTexts.toArray(new String[0]);
    }

    private static boolean isCanUser(String language, List<LanguageVO> languageVOList) {
        int index = -1;
        index = languageVOList.indexOf(new LanguageVO(language, 0, ""));
        return index != -1;
    }

    public static boolean isChina(String translateCountry) {
        return translateCountry != null && (translateCountry.equals(LanguageConstant.CHINESE) || translateCountry.equals(LanguageConstant.KOREAN) || translateCountry.equals(LanguageConstant.TRADITIONAL_CHINESE) || translateCountry.equals(LanguageConstant.JAPANESE));
    }

    /**
     * 是否是从右到左显示的语言
     *
     * @param translateCountry
     * @return
     */
    public static boolean isRightToLeftLanguage(String translateCountry) {
        return translateCountry != null && (translateCountry.equals(LanguageConstant.ARABIC) ||
                translateCountry.equals(LanguageConstant.PERSIAN) ||
                translateCountry.equals(LanguageConstant.HEBREW) ||
                translateCountry.equals(LanguageConstant.PASHTO) ||
                translateCountry.equals(LanguageConstant.UYGHUR));
    }

    /**
     * 文本之间是否需要间隔
     *
     * @param translateCountry 国家
     * @return
     */
    public static boolean isNeedTextSpace(String translateCountry) {
        return translateCountry != null && (translateCountry.equals(LanguageConstant.CHINESE) ||
                translateCountry.equals(LanguageConstant.TRADITIONAL_CHINESE) ||
                translateCountry.equals(LanguageConstant.KOREAN) ||
                translateCountry.equals(LanguageConstant.JAPANESE) ||
                translateCountry.equals(LanguageConstant.THAI));
    }

    /**
     * 文本之间是否需要间隔
     *
     * @param language 语言缩写
     * @return
     */
    public static boolean isNeedTextSpaceByLanguageType(String language) {
        return language != null && (language.equals("zh-CHS") ||
                language.equals("zh") ||
                language.equals("ko") ||
                language.equals("zh-CHT") ||
                language.equals("ja") ||
                language.equals("th"));
    }


    public static String truncate(String imageStr) {
        if (imageStr == null) {
            return null;
        }
        int len = imageStr.length();
        return len <= 20 ? imageStr : (imageStr.substring(0, 10) + len + imageStr.substring(len - 10, len));
    }

    /**
     * 判断是否有网络
     */
    public static boolean isNetworkConnected(Context context) {
        return NetworkUtils.isConnectedAvailableNetwork(context);
    }
}
