package com.mg.translation.http.req;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;

/***
 * //    {
 * //        "model": "deepseek-chat",
 * //            "messages": [
 * //        {"role": "system", "content": "You are a helpful assistant."},
 * //        {"role": "user", "content": "Hello!"}
 * //        ],
 * //        "stream": false
 * //    }
 *
 * DeepSeek请求格式
 */
public class DeepSeekTranslateReq extends BaseReq {
    private List<DeepSeekContentReq> messages;
    private String model;
    private boolean stream;
    private float temperature = 0.3f;

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public DeepSeekTranslateReq(List<DeepSeekContentReq> messages) {
        this.messages = messages;
    }

    public List<DeepSeekContentReq> getMessages() {
        return messages;
    }

    public void setMessages(List<DeepSeekContentReq> messages) {
        this.messages = messages;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isStream() {
        return stream;
    }

    public void setStream(boolean stream) {
        this.stream = stream;
    }


}
