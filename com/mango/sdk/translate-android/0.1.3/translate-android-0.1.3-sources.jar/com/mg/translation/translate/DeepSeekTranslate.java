package com.mg.translation.translate;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;


import static com.mg.translation.utils.TranslateUtils.getListStringSourceText;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.req.DeepSeekContentReq;
import com.mg.translation.http.req.DeepSeekTranslateReq;
import com.mg.translation.http.result.DeepSeekMessageResult;
import com.mg.translation.http.result.DeepSeekTranslationResult;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.utils.TranslateUtils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;


/**
 * @author LiChunWei
 * @description: deepseek  翻译  1秒
 * @date :2021/5/7 10:15
 */
public class DeepSeekTranslate extends BaseTranslateControl {

    /**
     * DeepSeek 翻译模型。旧别名 deepseek-chat 将于 2026-07-24 15:59 UTC 停用并不可访问,
     * 迁到 V4-Flash。Provider 特有的推理关闭参数由 HTTP 适配层添加，
     * 不进入被 GLM 等 OpenAI 兼容引擎复用的通用请求 DTO。
     */
    private static final String MODEL = "deepseek-v4-flash";

    private final Context mContext;
    private final TranslatorId translatorId;
    private List<LanguageVO> mDestLanguageList;
    private Resources mResources;

    @SuppressLint("AppBundleLocaleChanges") // 仅创建中文 Resources 上下文，不修改 App 全局 Locale。
    public DeepSeekTranslate(Context context) {
        this(context, TranslatorId.DEEPSEEK);
    }

    public DeepSeekTranslate(Context context, TranslatorId translatorId) {
        if (translatorId == null || !translatorId.isOpenAiCompatibleTranslation()) {
            throw new IllegalArgumentException("OpenAI-compatible translation engine is required");
        }
        mContext = context;
        this.translatorId = translatorId;
        // 先拷贝再 setLocale：getConfiguration() 返回的是共享对象，直接改会污染进程级 Configuration。
        Configuration configuration = new Configuration(mContext.getResources().getConfiguration());
        configuration.setLocale(Locale.CHINA);
        mResources = mContext.createConfigurationContext(configuration).getResources();
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }

        if (TranslationSdk.isVipOnly(getTranslateType()) && !TranslateUtils.isVip(mContext)) {
            translateListener.onFail(TranslationErrorCode.VIP_REQUIRED,
                    mContext.getString(R.string.translation_error_vip_required));
            return;
        }

        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, translateListener);
    }


    public void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }

        executeRequest(TranslateRepository.getInstance().aiCompatibleTranslateText(mContext,
                translatorId.legacyCode, createBaseReq(task.getContent(), task.getSourceLanguageId(), task.getTargetLanguageId())), heBingBingTranslateResult -> {
            if (heBingBingTranslateResult == null || heBingBingTranslateResult.getCode() != 0) {
                dealTranslateError(mContext, task, translateListener);
                return;
            }
            List<DeepSeekTranslationResult.DeepSeekChoices> deepSeekChoicesList = heBingBingTranslateResult.getChoices();
            if (deepSeekChoicesList == null || deepSeekChoicesList.isEmpty()) {
                dealTranslateError(mContext, task, translateListener);
                return;
            }

            DeepSeekTranslationResult.DeepSeekChoices deepSeekChoices = deepSeekChoicesList.get(0);
            if (deepSeekChoices == null) {
                dealTranslateError(mContext, task, translateListener);
                return;
            }
            DeepSeekMessageResult deepSeekMessage = deepSeekChoices.getMessage();

            if (deepSeekMessage == null) {
                dealTranslateError(mContext, task, translateListener);
                return;
            }
            String translatedText = deepSeekMessage.getContent();
            task.setTranslatedText(translatedText);
            translateListener.onSuccess(task, getTranslateType(), false);
        }, () -> dealTranslateError(mContext, task, translateListener));

    }

    /**
     * 翻译
     */
    public synchronized void translateListApi(BatchTranslationTask batchTask,
                                              TranslateListener translateListener) {
        List<String> sourceTexts = batchTask.getSourceTexts();

        List<String> reStringList = getListStringSourceText(sourceTexts);

        executeRequest(TranslateRepository.getInstance().aiCompatibleTranslateText(mContext,
                translatorId.legacyCode, createBaseListReq(reStringList, batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId())), heBingBingTranslateResult -> {
            if (heBingBingTranslateResult == null || heBingBingTranslateResult.getCode() != 0) {
                dealTranslateError(mContext, batchTask, translateListener);
                return;
            }
            List<DeepSeekTranslationResult.DeepSeekChoices> deepSeekChoicesList = heBingBingTranslateResult.getChoices();
            if (deepSeekChoicesList == null || deepSeekChoicesList.isEmpty()) {
                dealTranslateError(mContext, batchTask, translateListener);
                return;
            }

            DeepSeekTranslationResult.DeepSeekChoices deepSeekChoices = deepSeekChoicesList.get(0);
            if (deepSeekChoices == null) {
                dealTranslateError(mContext, batchTask, translateListener);
                return;
            }
            DeepSeekMessageResult deepSeekMessage = deepSeekChoices.getMessage();

            if (deepSeekMessage == null) {
                dealTranslateError(mContext, batchTask, translateListener);
                return;
            }

            String stringResult = deepSeekMessage.getContent();

            if (TextUtils.isEmpty(stringResult)) {
                dealTranslateError(mContext, batchTask, translateListener);
                return;
            }

            try {
                JSONArray jsonArray = new JSONArray(stringResult);

                if (jsonArray.length() == sourceTexts.size()) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        batchTask.setTranslation(i, jsonArray.getString(i));
                    }
                    translateListener.onSuccess(batchTask, getTranslateType(), true);
                } else {
                    dealTranslateError(mContext, batchTask, translateListener);
                }
            } catch (Exception e) {
                dealTranslateError(mContext, batchTask, translateListener);
            }
        }, () -> dealTranslateError(mContext, batchTask, translateListener));


    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }


    @Override
    public void close() {
        super.close();
    }


    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian,
                "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic,
                "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian,
                "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese,
                "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AYMARA, R.string.language_Aymara,
                "ay"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani,
                "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara,
                "bm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque,
                "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian,
                "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali,
                "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri,
                "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian,
                "bs"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian,
                "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan,
                "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano,
                "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese,
                "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican,
                "co"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian,
                "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish,
                "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi,
                "dv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri,
                "doi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto,
                "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian,
                "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EWE, R.string.language_Ewe,
                "ee"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino,
                "fil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish,
                "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian,
                "fy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician,
                "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian,
                "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek,
                "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani,
                "gn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian,
                "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa,
                "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian,
                "haw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong,
                "hmn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN,
                R.string.language_Hungarian,
                "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic,
                "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo,
                "ig"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ILOCANO, R.string.language_Ilocano,
                "ilo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN,
                R.string.language_Indonesian,
                "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish,
                "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese,
                "jv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada,
                "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh,
                "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer,
                "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda,
                "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani,
                "gom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KRIO, R.string.language_Krio,
                "kri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish,
                "ku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SORANI, R.string.language_Sorani,
                "ckb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz,
                "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao,
                "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin,
                "la"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian,
                "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala,
                "ln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian,
                "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda,
                "lg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish,
                "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian,
                "mk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili,
                "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy,
                "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam,
                "ml"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese,
                "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori,
                "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi,
                "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MEITEILON, R.string.language_Meiteilon,
                "mni-Mtei"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MIZO, R.string.language_Mizo,
                "lus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian,
                "mn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese,
                "my"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali,
                "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN,
                R.string.language_Norwegian,
                "no"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa,
                "ny"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya,
                "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo,
                "om"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto,
                "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian,
                "fa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE,
                R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi,
                "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.QUECHUA, R.string.language_Quechua,
                "qu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian,
                "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan,
                "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit,
                "sa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic,
                "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi,
                "nso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian,
                "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho,
                "st"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona,
                "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi,
                "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala,
                "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak,
                "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian,
                "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali,
                "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese,
                "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili,
                "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish,
                "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog,
                "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik,
                "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar,
                "tt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai,
                "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya,
                "ti"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga,
                "ts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen,
                "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan,
                "ak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur,
                "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek,
                "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh,
                "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa,
                "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish,
                "yi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba,
                "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu,
                "zu"));
        if (translatorId == TranslatorId.HY_MT2) {
            Set<String> supported = new java.util.HashSet<>(java.util.Arrays.asList(
                    "zh-CN", "zh-TW", "en", "fr", "pt", "es", "ja", "tr", "ru",
                    "ar", "ko", "th", "it", "de", "vi", "ms", "id", "fil", "tl",
                    "hi", "pl", "cs", "nl", "km", "my", "fa", "gu", "ur", "te",
                    "mr", "he", "bn", "ta", "uk", "kk", "mn", "ug"));
            mDestLanguageList.removeIf(language -> !supported.contains(language.getValue()));
        }
    }

    @Override
    public String getTranslateTypeName() {
        switch (translatorId) {
            case HY_MT2: return "Hunyuan";
            case GPT_4O_MINI: return "ChatGPT";
            case GEMMA: return "Gemma";
            case GEMINI: return "Gemini";
            default: return mContext.getString(R.string.deepSeek_name);
        }
    }

    public BaseReq createBaseListReq(List<String> stringList, String source, String to) {
        List<DeepSeekContentReq> deepSeekContentList = translatorId == TranslatorId.HY_MT2
                ? new ArrayList<>() : getDeepSeekContents(to, true);
        DeepSeekContentReq userDeepSeekContent = new DeepSeekContentReq();
        userDeepSeekContent.setRole("user");
        String batchContent = GsonUtil.toJson(stringList);
        userDeepSeekContent.setContent(translatorId == TranslatorId.HY_MT2
                ? buildBatchTranslatePrompt(resolveTargetLanguage(to)) + "\n\n" + batchContent
                : batchContent);
        deepSeekContentList.add(userDeepSeekContent);
        DeepSeekTranslateReq deepSeekTranslateReq = new DeepSeekTranslateReq(deepSeekContentList);
        deepSeekTranslateReq.setModel(MODEL);
        return deepSeekTranslateReq;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        List<DeepSeekContentReq> deepSeekContentList = translatorId == TranslatorId.HY_MT2
                ? new ArrayList<>() : getDeepSeekContents(to, false);
        DeepSeekContentReq userDeepSeekContent = new DeepSeekContentReq();
        userDeepSeekContent.setRole("user");
        userDeepSeekContent.setContent(translatorId == TranslatorId.HY_MT2
                ? buildSingleTranslatePrompt(resolveTargetLanguage(to)) + "\n\n" + content
                : content);
        deepSeekContentList.add(userDeepSeekContent);
        DeepSeekTranslateReq deepSeekTranslateReq = new DeepSeekTranslateReq(deepSeekContentList);
        deepSeekTranslateReq.setModel(MODEL);
        return deepSeekTranslateReq;
    }

    /**
     * 构建单文本翻译的System Prompt
     * 优化后的Prompt包含角色设定、详细要求和示例
     */
    @NonNull
    private String buildSingleTranslatePrompt(String targetLanguage) {
        return "你是一位专业的翻译助手。请将用户输入的文本翻译为" + targetLanguage + "。\n\n" +
                "翻译要求：\n" +
                "1. 准确理解原文含义，提供自然流畅的翻译\n" +
                "2. 保持原文格式（换行、标点、空格等）\n" +
                "3. 专业术语保持一致性\n" +
                "4. 根据语境选择最合适的表达方式\n" +
                "5. 只输出翻译结果，不要添加任何解释或注释\n" +
                "6. 如果原文包含多种语言，分别处理并保持原有结构\n\n" +
                "示例：\n" +
                "输入: Hello, how are you?\n" +
                "输出: 你好，你好吗？";
    }

    /**
     * 构建批量翻译的System Prompt
     * 针对批量翻译场景优化，确保 JSON 格式正确
     */
    @NonNull
    private String buildBatchTranslatePrompt(String targetLanguage) {
        return "你是一位专业的翻译助手。用户将提供一个JSON数组，包含多个需要翻译的文本。\n\n" +
                "任务要求：\n" +
                "1. 将数组中的每个文本翻译为" + targetLanguage + "\n" +
                "2. 保持数组顺序和长度不变\n" +
                "3. 保持每个文本的格式（换行、标点等）\n" +
                "4. 返回格式必须是标准JSON数组\n" +
                "5. 不要添加任何解释，只返回翻译后的JSON数组\n\n" +
                "输入格式示例：\n" +
                "[\"Hello\", \"Good morning\", \"Thank you\"]\n\n" +
                "输出格式示例：\n" +
                "[\"你好\", \"早上好\", \"谢谢\"]\n\n" +
                "注意：输出必须是有效的JSON数组，可以直接被解析。";
    }

    @NonNull
    private List<DeepSeekContentReq> getDeepSeekContents(String to, boolean isList) {
        List<DeepSeekContentReq> deepSeekContentList = new ArrayList<>();
        DeepSeekContentReq systemDeepSeekContent = new DeepSeekContentReq();
        systemDeepSeekContent.setRole("system");

        String toLanguage = resolveTargetLanguage(to);

        // 使用优化后的Prompt构建方法
        if (isList) {
            systemDeepSeekContent.setContent(buildBatchTranslatePrompt(toLanguage));
        } else {
            systemDeepSeekContent.setContent(buildSingleTranslatePrompt(toLanguage));
        }

        deepSeekContentList.add(systemDeepSeekContent);
        return deepSeekContentList;
    }

    private String resolveTargetLanguage(String to) {
        LanguageVO language = getSelectLanguageVO(to, false);
        return language == null ? to : mResources.getString(language.getCountry());
    }

    @Override
    public int getTranslateType() {
        return translatorId.legacyCode;
    }
}
