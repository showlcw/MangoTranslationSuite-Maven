package com.mg.translation.translate.base;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.runtime.EntitlementCheckingTranslateControl;
import com.mg.translation.internal.runtime.DailyLimitTranslateControl;
import com.mg.translation.internal.runtime.TranslationRuntime;


import android.content.Context;

import com.mg.translation.translate.BaiduTranslate;
import com.mg.translation.translate.BdTranslate;
import com.mg.translation.translate.DeepSeekTranslate;
import com.mg.translation.translate.QwenTranslate;
import com.mg.translation.translate.GoogleClientTranslate;
import com.mg.translation.translate.GoogleTranslate;
import com.mg.translation.translate.GoogleVTranslate;
import com.mg.translation.translate.SelfHostedGoogleTranslate;
import com.mg.translation.translate.MicrosoftTranslate;
import com.mg.translation.translate.MicrosoftVipTranslate;
import com.mg.translation.translate.MyMemoryTranslate;
import com.mg.translation.translate.RapidAiTranslate;
import com.mg.translation.translate.RapidApiDeepTranslate;
import com.mg.translation.translate.RapidApiIrctcapiTranslate;
import com.mg.translation.translate.RapidApiPlusTranslate;
import com.mg.translation.translate.RapidMultiTranslate;
import com.mg.translation.translate.WebSitePlusTranslate;
import com.mg.translation.translate.VipTipsTranslate;
import com.mg.translation.translate.YdTranslate;
import com.mg.translation.translate.YoudaoTranslate;
import com.mg.translation.translate.ZhipuFlashTranslate;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/6 18:27
 */
public final class TranslateFactory {
    private TranslateFactory() { }

    public static TranslateControl createTranslate(Context context, int type) {
        TranslatorId translatorId = TranslatorId.fromLegacyCode(type);
        if (!com.mg.translation.sdk.TranslationSdk.isInitialized()
                || translatorId == null
                || translatorId.isRetired()
                || !com.mg.translation.sdk.TranslationSdk.isEngineEnabled(type)) {
            return new GoogleClientTranslate(context);
        }
        TranslateControl control;
        switch (translatorId) {
            case BAIDU: control = new BaiduTranslate(context); break;
            case GOOGLE: control = new GoogleTranslate(context); break;
            case SELF_HOSTED_GOOGLE: control = new SelfHostedGoogleTranslate(context); break;
            case MICROSOFT: control = new MicrosoftTranslate(context); break;
            case MICROSOFT_VIP: control = new MicrosoftVipTranslate(context); break;
            case RAPID_DEEP: control = new RapidApiDeepTranslate(context); break;
            case BD: control = new BdTranslate(context); break;
            case RAPID_AI: control = new RapidAiTranslate(context); break;
            case RAPID_PLUS: control = new RapidApiPlusTranslate(context); break;
            case GOOGLE_CLIENT: control = new GoogleClientTranslate(context); break;
            case GOOGLE_V: control = new GoogleVTranslate(context); break;
            case YOUDAO_ME: control = new YdTranslate(context); break;
            case YOUDAO: control = new YoudaoTranslate(context); break;
            case MYMEMORY: control = new MyMemoryTranslate(context); break;
            case RAPID_WEBSITE_PLUS: control = new WebSitePlusTranslate(context); break;
            case TIPS: control = new VipTipsTranslate(context); break;
            case RAPID_MULTI: control = new RapidMultiTranslate(context); break;
            case RAPID_IRCTCAPI: control = new RapidApiIrctcapiTranslate(context); break;
            case DEEPSEEK: control = new DeepSeekTranslate(context); break;
            case HY_MT2:
            case GPT_4O_MINI:
            case GEMMA:
            case GEMINI:
                control = new DeepSeekTranslate(context, translatorId); break;
            case ZHIPU_FLASH: control = new ZhipuFlashTranslate(context); break;
            case QWEN: control = new QwenTranslate(context); break;
            default: return new GoogleClientTranslate(context);
        }
        Integer dailyLimit = TranslationRuntime.get().dailyLimit(type);
        if (dailyLimit != null) {
            control = new DailyLimitTranslateControl(context, control, type, dailyLimit);
        }
        boolean accessControlled = com.mg.translation.sdk.TranslationSdk.isVipOnly(type);
        return accessControlled
                ? new EntitlementCheckingTranslateControl(control, translatorId)
                : control;
    }

}
