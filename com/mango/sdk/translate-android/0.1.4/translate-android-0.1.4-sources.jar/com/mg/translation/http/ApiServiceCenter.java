package com.mg.translation.http;


import com.mg.translation.internal.base.http.RetrofitServiceManager;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.http.translate.ai.AiTranslateService;
import com.mg.translation.http.translate.baidu.BaiduTranslateService;
import com.mg.translation.http.translate.deep.DeepTranslateService;
import com.mg.translation.http.translate.google.GoogleClientTranslateService;
import com.mg.translation.http.translate.google.GoogleTranslateService;
import com.mg.translation.http.translate.google.GoogleVipTranslateService;
import com.mg.translation.http.translate.irctcapi.IrctcapiTranslateService;
import com.mg.translation.http.translate.me.MeTranslateService;
import com.mg.translation.http.translate.memory.MemoryTranslateService;
import com.mg.translation.http.translate.microsoft.MicrosoftTranslateService;
import com.mg.translation.http.translate.multi.MultiTranslateService;
import com.mg.translation.http.translate.plus.PlusTranslateService;
import com.mg.translation.http.translate.websiteplus.WebSitePlusTranslateService;
import com.mg.translation.http.translate.youdao.YoudaoService;
import com.mg.translation.http.translate.zhipu.ZhipuTranslateService;

public final class ApiServiceCenter {
    // 使用 volatile 保证多线程可见性
    private static volatile ApiServiceCenter mInstance = null;
    private GoogleTranslateService mGoogleTranslateService = null;

    private GoogleClientTranslateService mGoogleClientTranslateService = null;

    private MeTranslateService mMeTranslateService = null;
    private YoudaoService mYoudaoTranslateService = null;
    private BaiduTranslateService mBaiduTranslateService = null;
    private GoogleVipTranslateService mGoogleVipTranslateService = null;
    private DeepTranslateService mDeepTranslateService = null;
    private MicrosoftTranslateService mMicrosoftTranslateService = null;
    private AiTranslateService mAiTranslateService = null;
    private PlusTranslateService mPlusTranslateService = null;

    private MemoryTranslateService mMemoryTranslateService;
    private WebSitePlusTranslateService mWebSitePlusTranslateService;

    private MultiTranslateService mMultiTranslateService = null;

    private IrctcapiTranslateService mIrctcapiTranslateService = null;

    private ZhipuTranslateService mZhipuTranslateService;

    /**
     * 双重检查锁定单例模式（线程安全）
     */
    public static ApiServiceCenter getInstance() {
        if (mInstance == null) {
            synchronized (ApiServiceCenter.class) {
                if (mInstance == null) {
                    mInstance = new ApiServiceCenter();
                }
            }
        }
        return mInstance;
    }

    private ApiServiceCenter() {
        mGoogleTranslateService = RetrofitServiceManager.getInstance().createString(TranslateRepository.GOOGLE_TRANSLATE_URL, GoogleTranslateService.class);
        mGoogleClientTranslateService = RetrofitServiceManager.getInstance().createString(TranslateRepository.GOOGLE_TRANSLATE_CLIENT_URL, GoogleClientTranslateService.class);

        mMeTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.ME_TRANSLATE_URL, MeTranslateService.class);
        mYoudaoTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.YOUDAO_TRANSLATE_URL, YoudaoService.class);
        mBaiduTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.BAIDU_URL, BaiduTranslateService.class);
        mGoogleVipTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.GOOGLE_TRANSLATE_VIP_URL, GoogleVipTranslateService.class);
        mDeepTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.DEEP_TRANSLATE_URL, DeepTranslateService.class);
        mMicrosoftTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.MICROSOFT_TRANSLATE_URL, MicrosoftTranslateService.class);
        mAiTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.AI_TRANSLATE_URL, AiTranslateService.class);
        mPlusTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.PLUS_TRANSLATE_URL, PlusTranslateService.class);
        mMemoryTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.MEMORY_TRANSLATE_URL, MemoryTranslateService.class);
        mWebSitePlusTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.WEBSITE_PLUS_TRANSLATE_URL, WebSitePlusTranslateService.class);

        mMultiTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.MULTI_TRANSLATE_URL, MultiTranslateService.class);

        mIrctcapiTranslateService = RetrofitServiceManager.getInstance().createTranslate(TranslateRepository.IRCTCAPI_TRANSLATE_URL, IrctcapiTranslateService.class);
        // LLM Provider 使用独立的10秒整体超时，避免普通 Provider 的3秒快速失败策略误杀。
        mZhipuTranslateService = RetrofitServiceManager.getInstance().createLlmTranslate(TranslateRepository.ZHIPU_TRANSLATE_URL, ZhipuTranslateService.class);
    }

    public ZhipuTranslateService getZhipuTranslateService() {
        return mZhipuTranslateService;
    }


    public IrctcapiTranslateService getIrctcapiTranslateService() {
        return mIrctcapiTranslateService;
    }

    public WebSitePlusTranslateService getWebSitePlusTranslateService() {
        return mWebSitePlusTranslateService;
    }
    public MemoryTranslateService getMemoryTranslateService() {
        return mMemoryTranslateService;
    }

    public GoogleTranslateService getGoogleTranslateService() {
        return mGoogleTranslateService;
    }


    public MeTranslateService getMeTranslateService() {
        return mMeTranslateService;
    }


    public GoogleClientTranslateService getGoogleClientTranslateService() {
        return mGoogleClientTranslateService;
    }

    public YoudaoService getYoudaoTranslateService() {
        return mYoudaoTranslateService;
    }

    public BaiduTranslateService getBaiduTranslateService() {
        return mBaiduTranslateService;
    }

    public GoogleVipTranslateService getGoogleVipTranslateService() {
        return mGoogleVipTranslateService;
    }

    public DeepTranslateService getDeepTranslateService() {
        return mDeepTranslateService;
    }


    public MicrosoftTranslateService getMicrosoftTranslateService() {
        return mMicrosoftTranslateService;
    }

    public AiTranslateService getAiTranslateService() {
        return mAiTranslateService;
    }


    public MultiTranslateService getMultiTranslateService() {
        return mMultiTranslateService;
    }

    public PlusTranslateService getPlusTranslateService() {
        return mPlusTranslateService;
    }


}
