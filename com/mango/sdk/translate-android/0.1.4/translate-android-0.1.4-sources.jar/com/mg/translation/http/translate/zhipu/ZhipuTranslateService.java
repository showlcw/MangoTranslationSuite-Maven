package com.mg.translation.http.translate.zhipu;

import com.mg.translation.http.ai.OpenAiChatResponse;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ZhipuTranslateService {

    @POST("chat/completions")
    Single<OpenAiChatResponse> translate(@Header("Authorization") String apiKey,
                                         @Header("Content-type") String contentType,
                                         @Header("Accept") String accept,
                                         @Body RequestBody requestBody);
}
