package com.mg.translation.internal.base.http;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

/**
 * 优化后的网络管理器 - 适配弱网和跨国环境
 */
public final class RetrofitServiceManager {
    /** AI 翻译整体超时；超时后由具体 Translator 进入统一降级链。 */
    private static final int LLM_TIMEOUT = 10;

    // 基础超时配置 - 统一超时时间，快速失败切换策略
    private static final int TRANSLATE_TIMEOUT = 3;   // 所有非 AI 翻译统一3秒
    // 连接池配置 - 针对翻译应用优化
    private static final int MAX_IDLE_CONNECTIONS = 12; // 从8增加到12，支持更多并发翻译
    private static final int KEEP_ALIVE_DURATION = 600; // 从5分钟增加到10分钟，减少重连
    private static final int MAX_RETROFIT_INSTANCES = 64;

    private final OkHttpClient mTranslateClient;  // 非 AI 翻译客户端（3秒超时）
    // Retrofit实例缓存
    private final OkHttpClient mLlmClient;
    private final ConcurrentHashMap<String, Retrofit> mRetrofitCache = new ConcurrentHashMap<>();

    private RetrofitServiceManager() {
        // 共享连接池和调度器
        ConnectionPool connectionPool = new ConnectionPool(MAX_IDLE_CONNECTIONS,
                KEEP_ALIVE_DURATION,
                TimeUnit.SECONDS);

        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(64);           // 增加并发请求数
        dispatcher.setMaxRequestsPerHost(16);    // 增加每个主机的并发数

        // 所有非 AI Provider 统一3秒；AI Provider 单独10秒。
        mTranslateClient = createOkHttpClient(TRANSLATE_TIMEOUT, connectionPool, dispatcher);
        mLlmClient = createOkHttpClient(LLM_TIMEOUT, connectionPool, dispatcher);
    }

    private OkHttpClient createOkHttpClient(int timeout,
                                            ConnectionPool connectionPool,
                                            Dispatcher dispatcher) {
        return new OkHttpClient.Builder()
                .connectionPool(connectionPool)
                .dispatcher(dispatcher)
                .callTimeout(timeout, TimeUnit.SECONDS)
                .connectTimeout(timeout, TimeUnit.SECONDS)
                .readTimeout(timeout, TimeUnit.SECONDS)
                .writeTimeout(timeout, TimeUnit.SECONDS)
                .retryOnConnectionFailure(false)
                // Provider credentials must never be forwarded through redirects.
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
    }

    private static class SingletonHolder {
        private static final RetrofitServiceManager INSTANCE = new RetrofitServiceManager();
    }

    public static RetrofitServiceManager getInstance() {
        return SingletonHolder.INSTANCE;
    }

    /**
     * 获取非 AI 翻译服务HTTP客户端（统一3秒超时）
     */
    private OkHttpClient getTranslateClient() {
        return mTranslateClient;
    }

    /**
     * 获取缓存的Retrofit实例（非 AI 翻译服务，3秒超时）
     */
    private Retrofit getRetrofitInstance(String baseUrl, boolean useStringConverter) {
        String validatedBaseUrl = validateBaseUrl(baseUrl);
        String cacheKey = validatedBaseUrl + "_translate_" + useStringConverter;
        ensureCacheCapacity(cacheKey);
        return mRetrofitCache.computeIfAbsent(cacheKey, key -> {
            OkHttpClient client = getTranslateClient();
            Retrofit.Builder builder = new Retrofit.Builder()
                    .client(client)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .baseUrl(validatedBaseUrl);

            if (useStringConverter) {
                builder.addConverterFactory(ScalarsConverterFactory.create());
            } else {
                builder.addConverterFactory(GsonConverterFactory.create());
            }

            return builder.build();
        });
    }

    /**
     * 翻译服务创建 - 自动选择最优客户端
     */
    public <T> T createTranslate(String baseUrl, Class<T> service) {
        return getRetrofitInstance(baseUrl, false).create(service);
    }

    public <T> T createLlmTranslate(String baseUrl, Class<T> service) {
        String validatedBaseUrl = validateBaseUrl(baseUrl);
        String cacheKey = validatedBaseUrl + "_llm_translate";
        ensureCacheCapacity(cacheKey);
        Retrofit retrofit = mRetrofitCache.computeIfAbsent(cacheKey, key -> new Retrofit.Builder()
                .client(mLlmClient)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(validatedBaseUrl)
                .build());
        return retrofit.create(service);
    }

    /**
     * 字符串响应服务创建
     */
    public <T> T createString(String baseUrl, Class<T> service) {
        return getRetrofitInstance(baseUrl, true).create(service);
    }

    private String validateBaseUrl(String baseUrl) {
        HttpUrl parsed = baseUrl == null ? null : HttpUrl.parse(baseUrl);
        if (parsed == null || !"https".equalsIgnoreCase(parsed.scheme())) {
            throw new IllegalArgumentException("Provider base URL must use HTTPS");
        }
        return parsed.toString();
    }

    private void ensureCacheCapacity(String cacheKey) {
        if (!mRetrofitCache.containsKey(cacheKey)
                && mRetrofitCache.size() >= MAX_RETROFIT_INSTANCES) {
            throw new IllegalStateException("too many Provider endpoints in this process");
        }
    }

}
