package com.mg.translation.translate.ai.qwen;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;

import static com.mg.translation.internal.text.TranslationText.copy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.internal.base.BaseConstants;
import com.mg.translation.http.ai.OpenAiChatMessage;
import com.mg.translation.http.translate.qwen.dto.QwenMtTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/**
 * Qwen-MT(千问) 翻译（DashScope OpenAI-compatible chat/completions）。
 */
public class QwenTranslate extends BaseTranslateControl {

    private final Context mContext;
    private final Resources mResources;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    @SuppressLint("AppBundleLocaleChanges") // 仅创建中文 Resources 上下文，不修改 App 全局 Locale。
    public QwenTranslate(Context context) {
        mContext = context;

        // 先拷贝再 setLocale：getConfiguration() 返回的是 Resources 内部共享对象，
        // 直接 setLocale 会污染进程级 Configuration，导致非中文设备翻译若干次后 getString 取到中文。
        Configuration configuration = new Configuration(mContext.getResources().getConfiguration());
        configuration.setLocale(Locale.CHINA);
        mResources = mContext.createConfigurationContext(configuration).getResources();
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }

        // 是否会员专享完全服从 App 后台下发的 vip 字段，不在 Translator 内硬编码。
        boolean vipOnly = TranslationSdk.isVipOnly(getTranslateType());
        if (!task.isEmergencyRequest() && vipOnly && !TranslateUtils.isVip(mContext)) {
            translateListener.onFail(TranslationErrorCode.VIP_REQUIRED,
                    mContext.getString(R.string.translation_error_vip_required));
            return;
        }

        if (task instanceof BatchTranslationTask) {
            translateListApi((BatchTranslationTask) task, translateListener);
            return;
        }

        translateContent(task, translateListener);
    }

    private void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }

        executeRequest(TranslateRepository.getInstance().qwenTranslateText(
                mContext, getTranslateType(), createBaseReq(task.getContent(),
                        task.getSourceLanguageId(), task.getTargetLanguageId())), result -> {
                    if (result == null || result.getCode() != 0 || result.getChoices() == null
                            || result.getChoices().isEmpty() || result.getChoices().get(0) == null) {
                        dealTranslateError(mContext, task, translateListener);
                        return;
                    }
                    OpenAiChatMessage message = result.getChoices().get(0).getMessage();
                    if (message == null || TextUtils.isEmpty(message.getContent())) {
                        dealTranslateError(mContext, task, translateListener);
                        return;
                    }
                    String translatedText = message.getContent();
                    task.setTranslatedText(translatedText);
                    translateListener.onSuccess(task, getTranslateType(), false);
                }, () -> dealTranslateError(mContext, task, translateListener));
    }

    private synchronized void translateListApi(BatchTranslationTask batchTask, TranslateListener translateListener) {
        List<String> sourceTexts = batchTask.getSourceTexts();
        List<String> sourceList = copy(sourceTexts);

        executeRequest(TranslateRepository.getInstance().qwenTranslateText(
                mContext, getTranslateType(), createBaseListReq(sourceList,
                        batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId())), result -> {
                    if (result == null || result.getCode() != 0 || result.getChoices() == null
                            || result.getChoices().isEmpty() || result.getChoices().get(0) == null) {
                        dealTranslateError(mContext, batchTask, translateListener);
                        return;
                    }
                    OpenAiChatMessage message = result.getChoices().get(0).getMessage();
                    if (message == null || TextUtils.isEmpty(message.getContent())) {
                        dealTranslateError(mContext, batchTask, translateListener);
                        return;
                    }
                    String content = message.getContent().trim();
                    List<String> translations =
                            QwenTranslationResultParser.parse(content, sourceTexts.size());
                    if (translations == null || translations.size() != sourceTexts.size()) {
                        dealTranslateError(mContext, batchTask, translateListener);
                        return;
                    }
                    for (int i = 0; i < translations.size(); i++) {
                        batchTask.setTranslation(i, translations.get(i));
                    }
                    translateListener.onSuccess(batchTask, getTranslateType(), true);
                }, () -> dealTranslateError(mContext, batchTask, translateListener));
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguage();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.qwen_name);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.QWEN.legacyCode;
    }

    private BaseReq createBaseListReq(List<String> stringList, String source, String to) {
        List<OpenAiChatMessage> contents = new ArrayList<>();
        LinkedHashMap<String, String> indexedMap = new LinkedHashMap<>();
        for (int i = 0; i < stringList.size(); i++) {
            indexedMap.put(String.valueOf(i), stringList.get(i));
        }
        contents.add(new OpenAiChatMessage("user", GsonUtil.toJson(indexedMap)));

        QwenMtTranslateReq req = new QwenMtTranslateReq(contents);
        req.setModel(BaseConstants.QWEN_DEFAULT_MODEL);
        req.setTranslationOptions(buildTranslationOptions(source, to));
        return req;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        List<OpenAiChatMessage> contents = new ArrayList<>();
        // Qwen-MT（qwen-mt-plus / qwen-mt-flash）是翻译专用模型，DashScope 侧硬性约束：
        //   messages 数组只能 1 条 user 消息，源/目标语言通过 translation_options 传递，不接受对话上下文。
        contents.add(new OpenAiChatMessage("user", content));

        QwenMtTranslateReq req = new QwenMtTranslateReq(contents);
        req.setModel(BaseConstants.QWEN_DEFAULT_MODEL);
        req.setTranslationOptions(buildTranslationOptions(source, to));
        return req;
    }

    /**
     * qwen-mt domains(领域/风格提示,英文)——告诉模型这是"屏幕文本/字幕、口语场景",
     * 输出更地道简洁、保留专名,避免直译腔。与视频链服务端 prompt 同一条质量提升线。
     * 注:qwen-mt 的 translation_options 与自定义 prompt 互斥,这里只走官方参数、不加 system prompt。
     * 内置默认值;服务端可经 app_config.qwenMtDomains 下发热更措辞(见 {@link TranslateUtils#getQwenMtDomains})。
     */
    private static final String QWEN_MT_DOMAINS =
            "The input is short on-screen text or a subtitle line from apps, videos, games, "
            + "comics or live streams. Translate it into natural, idiomatic and conversational "
            + "language that a native speaker would actually use, kept concise enough to read at "
            + "a glance. Keep proper nouns, brand names and UI labels unchanged, and avoid stiff "
            + "word-for-word literal translation.";

    @NonNull
    private QwenMtTranslateReq.TranslationOptions buildTranslationOptions(String source, String to) {
        String sourceLang = getSourceLangValue(source);
        String targetLang = getTargetLangValue(to);
        QwenMtTranslateReq.TranslationOptions options =
                new QwenMtTranslateReq.TranslationOptions(sourceLang, targetLang);
        String domains = TranslateUtils.getQwenMtDomains(mContext);
        options.setDomains(TextUtils.isEmpty(domains) ? QWEN_MT_DOMAINS : domains);
        return options;
    }

    @NonNull
    private String getSourceLangValue(String source) {
        if (TextUtils.isEmpty(source) || LanguageConstant.AUTO.equals(source)) {
            return "auto";
        }
        LanguageVO sourceLanguageVO = getSelectLanguageVO(source, false);
        if (sourceLanguageVO != null && !TextUtils.isEmpty(sourceLanguageVO.getValue())) {
            return sourceLanguageVO.getValue();
        }
        return "auto";
    }

    @NonNull
    private String getTargetLangValue(String to) {
        LanguageVO toLanguageVO = getSelectLanguageVO(to, true);
        if (toLanguageVO != null && !TextUtils.isEmpty(toLanguageVO.getValue())) {
            return toLanguageVO.getValue();
        }
        return "en";
    }

    /**
     * 千问翻译语言列表：参考 Qwen-MT 官方支持语言（92种）。
     */
    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh_tw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay, "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi, "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew, "he"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese, "my"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil, "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu, "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali, "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish, "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish, "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer, "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao, "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CANTONESE, R.string.language_Cantonese, "yue"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech, "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek, "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish, "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish, "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian, "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian, "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu, "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian, "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese, "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASTURIAN, R.string.language_Asturian, "ast"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan, "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian, "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EGYPTIAN_ARABIC, R.string.language_Egyptian_Arabic, "arz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian, "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati, "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese, "jv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada, "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili, "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese, "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MESOPOTAMIAN_ARABIC, R.string.language_Mesopotamian_Arabic, "acm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MOROCCAN_ARABIC, R.string.language_Moroccan_Arabic, "ary"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NAJDI_ARABIC, R.string.language_Najdi_Arabic, "ars"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali, "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORTH_LEVANTINE_ARABIC, R.string.language_North_Levantine_Arabic, "apc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN_BOKMAL, R.string.language_Norwegian_Bokmal, "nb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN_NYNORSK, R.string.language_Norwegian_Nynorsk, "nn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OCCITAN, R.string.language_Occitan, "oc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya, "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PANGASINAN, R.string.language_Pangasinan, "pag"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SICILIAN, R.string.language_Sicilian, "scn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTH_LEVANTINE_ARABIC, R.string.language_South_Levantine_Arabic, "ajp"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili, "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog, "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAIZZI_ADENI_ARABIC, R.string.language_Taizzi_Adeni_Arabic, "acq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian, "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TUNISIAN_ARABIC, R.string.language_Tunisian_Arabic, "aeb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VENETIAN, R.string.language_Venetian, "vec"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WARAY, R.string.language_Waray, "war"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian, "fa"));
    }
}
