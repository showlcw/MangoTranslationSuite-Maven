package com.mg.translation.utils;

import com.mg.translation.engine.TranslatorId;


import static com.mg.translation.utils.TranslationPreferenceKeys.AI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.BD_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEPSEEK_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_CLIENT_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_TRANSLATE_LAST_USER_TIME;
import static com.mg.translation.utils.TranslationPreferenceKeys.SELF_HOSTED_GOOGLE_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.IRCTCAPI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MEMORY_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_VIP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MULTI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.PLUS_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.QWEN_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.WEBSITE_PLUS_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.YOUDAO_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.ZHIPU_TRANSLATE_STATE;

import android.content.Context;

import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.internal.text.TranslationText;
import com.mg.translation.internal.base.BaseUtils;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateFactory;
import com.mg.translation.internal.model.TranslationTask;

import java.util.List;

public final class TranslateUtils {
    private TranslateUtils() { }

    public static final int TRANSLATE_SPACE_TIME = 6000;//翻译间隔时间

    /**
     * 唯一自动降级顺序。用户主动选择的引擎由上层先执行；此数组只用于失败后的本次请求，
     * 绝不修改或持久化用户选择的 Legacy Code。
     * AI 段综合翻译质量与公开价格排序；模型、质量结论或价格变化时需随 SDK 版本复核。
     */
    private static final int[] FALLBACK_ORDER = {
            TranslatorId.GOOGLE_CLIENT.legacyCode,
            TranslatorId.SELF_HOSTED_GOOGLE.legacyCode,
            TranslatorId.SELF_HOSTED_YOUDAO.legacyCode,
            TranslatorId.GOOGLE.legacyCode,
            TranslatorId.DEEPSEEK.legacyCode,
            TranslatorId.HY_MT2.legacyCode,
            TranslatorId.QWEN.legacyCode,
            TranslatorId.GEMINI.legacyCode,
            TranslatorId.GPT_4O_MINI.legacyCode,
            TranslatorId.ZHIPU_FLASH.legacyCode,
            TranslatorId.MYMEMORY.legacyCode,
            TranslatorId.RAPID_IRCTCAPI.legacyCode,
            TranslatorId.RAPID_MULTI.legacyCode,
            TranslatorId.RAPID_WEBSITE_PLUS.legacyCode,
            TranslatorId.MICROSOFT.legacyCode,
            TranslatorId.YOUDAO.legacyCode,
            TranslatorId.BD.legacyCode,
            TranslatorId.RAPID_AI.legacyCode,
            TranslatorId.RAPID_PLUS.legacyCode,
            TranslatorId.RAPID_DEEP.legacyCode,
            TranslatorId.GOOGLE_V.legacyCode,
            TranslatorId.MICROSOFT_VIP.legacyCode,
            TranslatorId.BAIDU.legacyCode,
            TranslatorId.GEMMA.legacyCode
    };

    private static TranslateControl selectFallback(Context context, TranslationTask task,
                                                    boolean batch) {
        for (int engineId : FALLBACK_ORDER) {
            TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
            if (engine == null || (batch && !engine.supportsBatch())
                    || task.remainingBudgetMs() <= 0L) continue;
            TranslateControl control = tryFallbackEngine(
                    context, engineId, task.getSourceLanguageId(),
                    task.getTargetLanguageId(), task.getAttemptedEngineIds(),
                    task.isFreeOnlyForRequest());
            if (control != null) return control;
        }
        return null;
    }

    /** Final rescue candidates; never selected by the ordinary fallback chain. */
    public static TranslateControl getEmergencyFallback(Context context, TranslationTask task,
                                                         boolean batch) {
        int[] emergency = {TranslatorId.BAIDU.legacyCode, TranslatorId.QWEN.legacyCode};
        return getEmergencyFallback(context, task, batch, 0, emergency);
    }

    public static TranslateControl getEmergencyFallback(Context context, TranslationTask task,
                                                         boolean batch, int attempt) {
        int[] emergency = {TranslatorId.BAIDU.legacyCode, TranslatorId.QWEN.legacyCode};
        return getEmergencyFallback(context, task, batch, attempt, emergency);
    }

    private static TranslateControl getEmergencyFallback(Context context, TranslationTask task,
                                                          boolean batch, int attempt, int[] emergency) {
        if (attempt < 0 || attempt >= emergency.length) return null;
        int engineId = emergency[attempt];
        TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
        if (engine == null || (batch && !engine.supportsBatch())) return null;
        // Final rescue is independent from membership, ordinary cooldown and ordinary
        // fallback state. Configuration and language support remain mandatory.
        if (!TranslationSdk.isEngineEnabled(engineId)) return null;
        return getTranslateByType(engineId, task.getSourceLanguageId(),
                task.getTargetLanguageId(), context);
    }

    private static TranslateControl tryFallbackEngine(Context context, int engineId,
                                                       String source, String target,
                                                       List<Integer> attempted,
                                                       boolean freeOnlyForRequest) {
        if (attempted.contains(engineId)) return null;
        String reason = engineSkipReason(context, engineId, freeOnlyForRequest);
        if (reason != null) {
            com.mg.translation.internal.runtime.ProviderAttemptTelemetry.skipped(engineId, reason);
            return null;
        }
        return getTranslateByType(engineId, source, target, context);
    }

    private static boolean isEngineHealthy(Context context, int engineId) {
        TranslatorId translatorId = TranslatorId.fromLegacyCode(engineId);
        if (translatorId == null) return false;
        switch (translatorId) {
            case GOOGLE_CLIENT:
                return getGoogleClientState(context) && isCanUseGoogleApi(context, engineId)
                        && FreeGoogleRequestGate.isReady(context);
            case SELF_HOSTED_GOOGLE:
                return getSelfHostedGoogleApiState(context);
            case SELF_HOSTED_YOUDAO:
                return getSelfHostedYoudaoApiState(context);
            case GOOGLE:
                return getGoogleApiState(context) && isCanUseGoogleApi(context, engineId)
                        && FreeGoogleRequestGate.isReady(context);
            case QWEN: return getQwenApiState(context);
            case ZHIPU_FLASH: return getZhipuApiState(context);
            case MYMEMORY: return getMemoryApiState(context);
            case RAPID_IRCTCAPI: return getRapidIrctcapiApiState(context);
            case RAPID_MULTI: return getRapidMultiApiState(context);
            case RAPID_WEBSITE_PLUS: return getWebSitePlusApiState(context);
            case MICROSOFT: return getMicrosoftApiState(context);
            case YOUDAO: return getYoudaoApiState(context);
            case BD: return getBdApiState(context);
            case RAPID_AI: return getRapidAiApiState(context);
            case DEEPSEEK: return getDeepSeekApiState(context);
            case HY_MT2: return getAiEngineApiState(context, TranslatorId.HY_MT2);
            case GPT_4O_MINI: return getAiEngineApiState(context, TranslatorId.GPT_4O_MINI);
            case GEMMA: return getAiEngineApiState(context, TranslatorId.GEMMA);
            case GEMINI: return getAiEngineApiState(context, TranslatorId.GEMINI);
            case RAPID_PLUS: return getRapidPlusApiState(context);
            case RAPID_DEEP: return getRapidDeepApiState(context);
            case MICROSOFT_VIP: return getMicrosoftVIPApiState(context);
            case GOOGLE_V:
            case BAIDU:
                return true;
            default: return false;
        }
    }

    private static boolean getAiEngineApiState(Context context, TranslatorId engineId) {
        return engineState(context,
                TranslationPreferenceKeys.aiEngineState(engineId.legacyCode), engineId);
    }

    /**
     * qwen-mt 领域/风格提示(服务端可下发热更措辞;null/空时由 QwenTranslate 用内置默认)
     */
    public static String getQwenMtDomains(Context context) {
        return TranslationRuntime.get().qwenDomains();
    }

    /**
     * 获取当前可以使用的翻译方式
     */
    public static TranslateControl getCanTranslateType(Context context,
                                                        TranslationTask task,
                                                        boolean isList) {
        if (task == null || task.getAttemptedEngineIds().isEmpty()) {
            return null;
        }
        return selectFallback(context, task, isList);
    }

    /** Shared eligibility for fallback and warm-up; reading the gate never reserves it. */
    public static String engineSkipReason(Context context, int engineId, boolean freeOnlyForRequest) {
        if (!TranslationSdk.isEngineEnabled(engineId)) return "not_configured";
        boolean member = TranslationRuntime.get().host().isVip();
        if (TranslationSdk.isVipOnly(engineId)
                && (freeOnlyForRequest || !member)) return "vip";
        if (com.mg.translation.internal.runtime.ProviderFailurePolicy.isAttemptCoolingDown(context, engineId)) return "cooldown";
        if (engineId == TranslatorId.GOOGLE_CLIENT.legacyCode
                || engineId == TranslatorId.GOOGLE.legacyCode) {
            boolean healthy = engineId == TranslatorId.GOOGLE_CLIENT.legacyCode
                    ? getGoogleClientState(context) : getGoogleApiState(context);
            if (!healthy) return "cooldown";
            if (!FreeGoogleRequestGate.isReady(context)) return "gate";
            return isCanUseGoogleApi(context, engineId) ? null : "unreachable";
        }
        return isEngineHealthy(context, engineId) ? null : "cooldown";
    }

    /** Independent copy; the canonical fallback order cannot be mutated by callers. */
    public static int[] fallbackOrder() { return FALLBACK_ORDER.clone(); }

    /** First configured non-VIP engine in the same order used by request fallback. */
    public static TranslatorId firstFreeEngine() {
        for (int engineId : FALLBACK_ORDER) {
            if (TranslationSdk.isEngineEnabled(engineId)
                    && !TranslationSdk.isVipOnly(engineId)) {
                return TranslatorId.fromLegacyCode(engineId);
            }
        }
        return null;
    }

    public static boolean isCanUseGoogleApi(Context context) {
        return isCanUseGoogleApi(context, TranslatorId.GOOGLE_CLIENT.legacyCode);
    }

    private static boolean isCanUseGoogleApi(Context context, int engineId) {
        TranslationRuntime runtime = TranslationRuntime.get();
        return runtime.host().isGoogleReachable() && hasEnabledTranslationEngine()
                && runtime.googleReachability().isReachable(engineId);
    }

    /**
     * 是否可以使用免费的百度或者有道翻译
     *
     * @param context
     * @return
     */
    public static boolean hasEnabledTranslationEngine() {
        return TranslationRuntime.get().hasEnabledEngines();
    }


    public static boolean isVip(Context context) {
        return TranslationRuntime.get().host().isVip();
    }


    public static boolean isLocalVip(Context context) {
        return TranslationRuntime.get().host().isVip();
    }

    /**
     * 判断Qwen（千问）翻译是否可以使用
     */
    public static boolean getQwenApiState(Context context) {
        return engineState(context, QWEN_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.QWEN);
    }

    public static boolean getDeepSeekApiState(Context context) {
        return engineState(context, DEEPSEEK_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.DEEPSEEK);
    }

    public static boolean getZhipuApiState(Context context) {
        return engineState(context, ZHIPU_TRANSLATE_STATE, com.mg.translation.engine.TranslatorId.ZHIPU_FLASH);
    }

    // ==================== 通用状态检查方法 ====================

    /**
     * 通用翻译API状态检查方法
     * @param context 上下文
     * @param stateKey 状态存储的key
     * @param timeoutMs 超时时间（毫秒），超过此时间后可以重新使用
     * @return true: 可以使用, false: 暂时不可用
     */
    public static boolean getTranslateApiState(Context context, String stateKey, long timeoutMs) {
        SdkPreferences preferences = SdkPreferences.getInstance(context);
        return preferences.isCooldownReady(stateKey, timeoutMs, System.currentTimeMillis());
    }

    private static boolean engineState(Context context, String stateKey,
                                       com.mg.translation.engine.TranslatorId engine) {
        long minimumMs = engine == TranslatorId.GOOGLE || engine == TranslatorId.GOOGLE_CLIENT
                ? engine.defaultCooldownMs : 300_000L;
        return SdkPreferences.getInstance(context).isCooldownReady(
                stateKey, engine.defaultCooldownMs, System.currentTimeMillis(), minimumMs);
    }

    /**
     * 获取Google api 是否可以使用
     */
    public static boolean getGoogleApiState(Context context) {
        return engineState(context, GOOGLE_FREE_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.GOOGLE);
    }

    public static boolean getSelfHostedGoogleApiState(Context context) {
        return engineState(context, SELF_HOSTED_GOOGLE_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.SELF_HOSTED_GOOGLE);
    }

    public static boolean getSelfHostedYoudaoApiState(Context context) {
        return engineState(context, TranslationPreferenceKeys.SELF_HOSTED_YOUDAO_TRANSLATE_STATE,
                TranslatorId.SELF_HOSTED_YOUDAO);
    }

    /**
     * 获取Google Client api 是否可以使用
     */
    public static boolean getGoogleClientState(Context context) {
        return engineState(context, GOOGLE_FREE_CLIENT_STATE,
                com.mg.translation.engine.TranslatorId.GOOGLE_CLIENT);
    }

    /**
     * 获取Bd是否可以使用
     */
    public static boolean getBdApiState(Context context) {
        return engineState(context, BD_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.BD);
    }

    /**
     * 获取Memory是否可以使用
     */
    public static boolean getMemoryApiState(Context context) {
        return engineState(context, MEMORY_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MYMEMORY);
    }


    /**
     * 获取youdao是否可以使用
     */
    public static boolean getYoudaoApiState(Context context) {
        return engineState(context, YOUDAO_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.YOUDAO);
    }

    /**
     * 判断plus是否可以使用
     */
    public static boolean getRapidPlusApiState(Context context) {
        return engineState(context, PLUS_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_PLUS);
    }

    /** TranslatePlus direct subscription state. */
    public static boolean getWebSitePlusApiState(Context context) {
        return engineState(context, WEBSITE_PLUS_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_WEBSITE_PLUS);
    }


    /**
     * 判断deep是否可以使用
     */
    public static boolean getRapidDeepApiState(Context context) {
        return engineState(context, DEEP_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_DEEP);
    }

    /**
     * 判断deep是否可以使用
     */
    public static boolean getRapidIrctcapiApiState(Context context) {
        return engineState(context, IRCTCAPI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_IRCTCAPI);
    }

    /**
     * 判断Multi是否可以使用
     */
    public static boolean getRapidMultiApiState(Context context) {
        return engineState(context, MULTI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_MULTI);
    }


    /**
     * 判断ai是否可以使用
     */
    public static boolean getRapidAiApiState(Context context) {
        return engineState(context, AI_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.RAPID_AI);
    }


    /**
     * 判断Microsoft是否可用（超时1小时）
     */
    public static boolean getMicrosoftApiState(Context context) {
        return engineState(context, MICROSOFT_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MICROSOFT);
    }

    public static boolean getMicrosoftVIPApiState(Context context) {
        return engineState(context, MICROSOFT_VIP_TRANSLATE_STATE,
                com.mg.translation.engine.TranslatorId.MICROSOFT_VIP);
    }


    /**
     * 通过类型获取翻译类
     */
    public static TranslateControl getTranslateByType(int type, String sourceCountry, String toCountry, Context context) {
        // The App-specific backend configuration is the only availability authority. This gate
        // also applies to transports that do not put the configured value on the wire.
        if (!TranslationSdk.isEngineEnabled(type)) {
            return null;
        }
        TranslateControl translateControl = TranslateFactory.createTranslate(context, type);
        if (translateControl == null) {
            return null;
        }
        List<LanguageVO> languageVOList = translateControl.getSupportLanguage();//百度支持的语言
        if (languageVOList == null || languageVOList.isEmpty()) {
            return null;
        }
        if (LanguageConstant.AUTO.equals(sourceCountry)) {//自动识别模式  需要判断下当前翻译类型是否支持自动识别
            if (!translateControl.isSupportAuto()) {//不支持自动识别模式
                return null;
            }
        } else {
            if (!isCanUser(sourceCountry, languageVOList)) {//识别语言不支持
                return null;
            }
        }

        if (!isCanUser(toCountry, languageVOList)) {//翻译语言语言不支持
            return null;
        }
        return translateControl;
    }


    public static int getFirstTranslateType(Context context) {
        return TranslationRuntime.get().firstTranslateType();
    }

    public static String getAiRapidApiKey(Context context) {
        return TranslationRuntime.get().aiRapidKey();
    }

    public static boolean isGoogle() {
        return TranslationRuntime.get().host().isGoogleBuild();
    }

    public static String getIrctcapiRapidApiKey(Context context) {
        return TranslationRuntime.get().irctcapiRapidKey();
    }


    public static String getDeepSeekApiKey(Context context) {
        return TranslationRuntime.get().deepSeekKey();
    }

    public static String getPlusRapidApiKey(Context context) {
        return TranslationRuntime.get().plusRapidKey();
    }

    public static String getWebSitePlusKey(Context context) {
        return TranslationRuntime.get().websitePlusKey();
    }


    public static List<String> getRecentlyHistoryList(Context context, boolean source) {
        return TranslationRuntime.get().recentLanguages(source);
    }

    public static void saveRecentlyHistoryList(Context context, String languageKey, boolean source) {
        TranslationRuntime.get().saveRecentLanguage(languageKey, source);
    }

    public static String getDeepRapidApiKey(Context context) {
        return TranslationRuntime.get().deepRapidKey();
    }

    public static String getBaiduIdKey(Context context) {
        return TranslationRuntime.get().baiduAppId();
    }

    public static String getBaiduSecretKey(Context context) {
        return TranslationRuntime.get().baiduSecret();
    }


//
//
//    public static String getBaiDuVoiceSecret(Context context) {
//        Legacy Voice-specific credential access intentionally remains outside the SDK.
//    }

    public static String getYouDaoIdKey(Context context) {
        return TranslationRuntime.get().youdaoAppId();
    }


    public static String getYouDaoSecretKey(Context context) {
        return TranslationRuntime.get().youdaoSecret();
    }

    public static String getMultiRapidApiKey(Context context) {
        return TranslationRuntime.get().multiRapidKey();
    }

    public static String getFreeMicrosoftApiKey(Context context) {
        return TranslationRuntime.get().freeMicrosoftKey();
    }

    public static String getMicrosoftApiKey(Context context) {
        return TranslationRuntime.get().microsoftKey();
    }

    public static String getGoogleVipApiKey(Context context) {
        return TranslationRuntime.get().googleVipKey();
    }


    public static String getAppSignatureSha1(Context context) {
        return BaseUtils.getAppSignatureSha1(context);
    }


    /**
     * 判断是否包含特殊字符
     *
     * @return false:未包含 true：包含
     */
    public static boolean inputJudge(String editText) {
        return TranslationText.containsSpecialCharacter(editText);
    }

    public static String getSourceText(List<String> sourceTexts, String space) {
        return TranslationText.join(sourceTexts, space);
    }


    public static List<String> getListStringSourceText(List<String> sourceTexts) {
        return TranslationText.copy(sourceTexts);
    }


    public static String[] getStringListText(List<String> sourceTexts) {
        return TranslationText.toArray(sourceTexts);
    }

    private static boolean isCanUser(String language, List<LanguageVO> languageVOList) {
        int index = -1;
        index = languageVOList.indexOf(new LanguageVO(language, 0, ""));
        return index != -1;
    }

    public static boolean isChina(String translateCountry) {
        return TranslationText.isCjk(translateCountry);
    }

    /**
     * 是否是从右到左显示的语言
     *
     * @param translateCountry
     * @return
     */
    public static boolean isRightToLeftLanguage(String translateCountry) {
        return TranslationText.isRightToLeft(translateCountry);
    }

    /**
     * 文本之间是否需要间隔
     *
     * @param translateCountry 国家
     * @return
     */
    public static boolean isNeedTextSpace(String translateCountry) {
        return TranslationText.usesCompactSpacing(translateCountry);
    }

    /**
     * 文本之间是否需要间隔
     *
     * @param language 语言缩写
     * @return
     */
    public static boolean isNeedTextSpaceByLanguageType(String language) {
        return TranslationText.providerCodeUsesCompactSpacing(language);
    }


    public static String truncate(String imageStr) {
        return TranslationText.summarize(imageStr);
    }

    /**
     * 判断是否有网络
     */
    public static boolean isNetworkConnected(Context context) {
        return NetworkUtils.isConnectedAvailableNetwork(context);
    }
}
