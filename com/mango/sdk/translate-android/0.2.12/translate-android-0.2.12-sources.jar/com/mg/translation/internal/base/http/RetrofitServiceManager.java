package com.mg.translation.internal.base.http;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.io.IOException;

import com.mg.translation.internal.runtime.ProviderAttemptTelemetry;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

/**
 * 优化后的网络管理器 - 适配弱网和跨国环境
 */
public final class RetrofitServiceManager {
    /** AI 翻译整体超时；超时后由具体 Translator 进入统一降级链。 */
    private static final int LLM_TIMEOUT = 10;

    // 基础超时配置 - 统一超时时间，快速失败切换策略
    private static final int TRANSLATE_TIMEOUT = 3;   // 所有非 AI 翻译统一3秒
    // 连接池配置 - 针对翻译应用优化
    private static final int MAX_IDLE_CONNECTIONS = 12; // 从8增加到12，支持更多并发翻译
    private static final int KEEP_ALIVE_DURATION = 600; // 从5分钟增加到10分钟，减少重连
    private static final int MAX_RETROFIT_INSTANCES = 64;
    private static final int MAX_SERVICE_INSTANCES = 128;
    private static final int PRECONNECT_TIMEOUT_MS = 3_000;
    private static final long PRECONNECT_DEDUP_NANOS = TimeUnit.MINUTES.toNanos(5);
    private static final long PRECONNECT_IN_FLIGHT = Long.MIN_VALUE;

    private final OkHttpClient mTranslateClient;  // 非 AI 翻译客户端（3秒超时）
    // Retrofit实例缓存
    private final OkHttpClient mLlmClient;
    private volatile SelfHostedTransport selfHostedTransport;
    private final java.util.Map<String, Retrofit> mRetrofitCache = boundedCache(MAX_RETROFIT_INSTANCES);
    private final java.util.Map<String, Object> mServiceCache = boundedCache(MAX_SERVICE_INSTANCES);
    private final ConcurrentHashMap<String, Long> mPreconnectState = new ConcurrentHashMap<>();
    private long preconnectNetwork = Long.MIN_VALUE;
    private long preconnectGeneration;

    private RetrofitServiceManager() {
        // 共享连接池和调度器
        ConnectionPool connectionPool = new ConnectionPool(MAX_IDLE_CONNECTIONS,
                KEEP_ALIVE_DURATION,
                TimeUnit.SECONDS);

        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(16);           // Shared async transport cap, including probes
        dispatcher.setMaxRequestsPerHost(4);     // Avoid one origin monopolizing the transport

        // 所有非 AI Provider 统一3秒；AI Provider 单独10秒。
        mTranslateClient = createOkHttpClient(TRANSLATE_TIMEOUT, connectionPool, dispatcher);
        mLlmClient = createOkHttpClient(LLM_TIMEOUT, connectionPool, dispatcher);
    }

    private OkHttpClient createOkHttpClient(int timeout,
                                            ConnectionPool connectionPool,
                                            Dispatcher dispatcher) {
        return new OkHttpClient.Builder()
                .connectionPool(connectionPool)
                .dispatcher(dispatcher)
                .eventListenerFactory(call -> NetworkRequestEvents.translation())
                .callTimeout(timeout, TimeUnit.SECONDS)
                .connectTimeout(timeout, TimeUnit.SECONDS)
                .readTimeout(timeout, TimeUnit.SECONDS)
                .writeTimeout(timeout, TimeUnit.SECONDS)
                .retryOnConnectionFailure(false)
                // Provider credentials must never be forwarded through redirects.
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
    }

    private static class SingletonHolder {
        private static final RetrofitServiceManager INSTANCE = new RetrofitServiceManager();
    }

    public static RetrofitServiceManager getInstance() {
        return SingletonHolder.INSTANCE;
    }

    /** Probe the actual free Google origin, without credentials, text, quota or redirects. */
    public void probeGoogle(int engineId, java.util.function.Consumer<Boolean> completion) {
        String origin;
        if (engineId == com.mg.translation.engine.TranslatorId.GOOGLE_CLIENT.legacyCode) {
            origin = com.mg.translation.http.translate.TranslateRepository.GOOGLE_TRANSLATE_CLIENT_URL;
        } else if (engineId == com.mg.translation.engine.TranslatorId.GOOGLE.legacyCode) {
            origin = com.mg.translation.http.translate.TranslateRepository.GOOGLE_TRANSLATE_URL;
        } else { throw new IllegalArgumentException("Not a free Google engine"); }
        OkHttpClient probeClient = mTranslateClient.newBuilder()
                .eventListenerFactory(call -> new NetworkRequestEvents(engineId, "probe")).build();
        enqueueGoogleProbe(probeClient, new Request.Builder().url(origin).head().build(), engineId, completion);
    }

    static void enqueueGoogleProbe(OkHttpClient client, Request request, int engineId,
                                   java.util.function.Consumer<Boolean> completion) {
        long started = System.nanoTime();
        long network = com.mg.translation.internal.runtime.NetworkFailureScope.network();
        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException failure) {
                if (com.mg.translation.internal.runtime.ProviderFailurePolicy.isNetworkFailure(failure)) {
                    com.mg.translation.internal.runtime.NetworkFailureScope.run(network, () -> completion.accept(false));
                } else completion.accept(false);
                ProviderAttemptTelemetry.report(engineId,
                        "probe_" + ProviderAttemptTelemetry.outcome(failure, call.isCanceled()), started, 0);
            }
            @Override public void onResponse(Call call, Response response) {
                int status = response.code();
                response.close();
                // Root HEAD 404/405 is normal; blocking, throttling, redirects and server errors are not.
                boolean usable = (status >= 200 && status < 300) || status == 404 || status == 405;
                completion.accept(usable);
                ProviderAttemptTelemetry.report(engineId,
                        usable ? "probe_response" : "probe_http_error", started, status);
            }
        });
    }

    /**
     * 获取非 AI 翻译服务HTTP客户端（统一3秒超时）
     */
    private OkHttpClient getTranslateClient() {
        return mTranslateClient;
    }

    /**
     * 获取缓存的Retrofit实例（非 AI 翻译服务，3秒超时）
     */
    private Retrofit getRetrofitInstance(String validatedBaseUrl, boolean useStringConverter) {
        String cacheKey = validatedBaseUrl + "_translate_" + useStringConverter;
        Retrofit cached = mRetrofitCache.get(cacheKey);
        if (cached != null) return cached;
        synchronized (this) {
            cached = mRetrofitCache.get(cacheKey);
            if (cached != null) return cached;
            OkHttpClient client = getTranslateClient();
            Retrofit.Builder builder = new Retrofit.Builder()
                    .callFactory(deadlineCalls(client))
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createAsync())
                    .baseUrl(validatedBaseUrl);

            if (useStringConverter) {
                builder.addConverterFactory(ScalarsConverterFactory.create());
            } else {
                builder.addConverterFactory(GsonConverterFactory.create());
            }

            cached = builder.build();
            mRetrofitCache.put(cacheKey, cached);
            return cached;
        }
    }

    /**
     * 翻译服务创建 - 自动选择最优客户端
     */
    public <T> T createTranslate(String baseUrl, Class<T> service) {
        String validatedBaseUrl = validateBaseUrl(baseUrl);
        return getOrCreateService(validatedBaseUrl + "_translate_false", service,
                getRetrofitInstance(validatedBaseUrl, false));
    }

    public <T> T createSelfHostedTranslate(String baseUrl, Class<T> service) {
        String url = validateBaseUrl(baseUrl);
        int timeout = com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().selfHostedCallMs;
        String key = url + "|" + service.getName();
        SelfHostedTransport transport = selfHostedTransport;
        Object cached = transport == null || transport.timeoutMs != timeout
                ? null : transport.services.get(key);
        if (cached != null) return service.cast(cached);
        synchronized (this) {
            transport = selfHostedTransport;
            if (transport == null || transport.timeoutMs != timeout) {
                transport = new SelfHostedTransport(timeout, mTranslateClient);
                selfHostedTransport = transport;
            }
            cached = transport.services.get(key);
            if (cached != null) return service.cast(cached);
            cached = new Retrofit.Builder()
                .callFactory(deadlineCalls(transport.client)).baseUrl(url)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.createAsync())
                .addConverterFactory(GsonConverterFactory.create()).build().create(service);
            transport.services.put(key, cached);
            return service.cast(cached);
        }
    }

    private static final class SelfHostedTransport {
        final int timeoutMs;
        final OkHttpClient client;
        final java.util.Map<String, Object> services = boundedCache(MAX_SERVICE_INSTANCES);
        SelfHostedTransport(int timeout, OkHttpClient shared) {
            timeoutMs = timeout;
            client = shared.newBuilder().callTimeout(timeout, TimeUnit.MILLISECONDS)
                    .addInterceptor(new SelfHostedBudgetInterceptor())
                    .addNetworkInterceptor(new SelfHostedBudgetInterceptor.Network())
                    .connectTimeout(timeout, TimeUnit.MILLISECONDS).readTimeout(timeout, TimeUnit.MILLISECONDS)
                    .writeTimeout(timeout, TimeUnit.MILLISECONDS)
                    .eventListenerFactory(call -> new SelfHostedRequestEvents()).build();
        }
    }

    public <T> T createLlmTranslate(String baseUrl, Class<T> service) {
        String validatedBaseUrl = validateBaseUrl(baseUrl);
        String cacheKey = validatedBaseUrl + "_llm_translate";
        Retrofit retrofit = getLlmRetrofitInstance(validatedBaseUrl, cacheKey);
        return getOrCreateService(cacheKey, service, retrofit);
    }

    /**
     * 字符串响应服务创建
     */
    public <T> T createString(String baseUrl, Class<T> service) {
        String validatedBaseUrl = validateBaseUrl(baseUrl);
        return getOrCreateService(validatedBaseUrl + "_translate_true", service,
                getRetrofitInstance(validatedBaseUrl, true));
    }

    /**
     * Starts one unauthenticated HEAD request against the Provider origin. The derived client
     * shares the exact SDK connection pool and dispatcher with subsequent translation calls.
     */
    public boolean preconnect(String baseUrl, boolean llm, int engineId) {
        HttpUrl origin = preconnectOrigin(baseUrl);
        String key = preconnectKey(origin, llm);
        long now = System.nanoTime();
        while (true) {
            Long state = mPreconnectState.get(key);
            if (state != null && (state == PRECONNECT_IN_FLIGHT || now < state)) return true;
            boolean reserved = state == null
                    ? mPreconnectState.putIfAbsent(key, PRECONNECT_IN_FLIGHT) == null
                    : mPreconnectState.replace(key, state, PRECONNECT_IN_FLIGHT);
            if (reserved) break;
        }

        OkHttpClient baseClient = llm ? mLlmClient : mTranslateClient;
        OkHttpClient client = baseClient.newBuilder()
                .eventListenerFactory(call -> new NetworkRequestEvents(engineId, "preconnect"))
                .callTimeout(PRECONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .connectTimeout(PRECONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .readTimeout(PRECONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .writeTimeout(PRECONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .build();
        Request request = new Request.Builder().url(origin).head().build();
        long startedNanos = System.nanoTime();
        try {
            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException failure) {
                    mPreconnectState.remove(key, PRECONNECT_IN_FLIGHT);
                    ProviderAttemptTelemetry.reportDuration(engineId,
                            "preconnect_" + ProviderAttemptTelemetry.outcome(
                                    failure, call.isCanceled()),
                            ProviderAttemptTelemetry.elapsedMs(startedNanos), 0);
                }

                @Override public void onResponse(Call call, Response response) {
                    int status = response.code();
                    boolean reusable = !"close".equalsIgnoreCase(response.header("Connection"));
                    response.close();
                    if (reusable) {
                        mPreconnectState.replace(key, PRECONNECT_IN_FLIGHT,
                                System.nanoTime() + PRECONNECT_DEDUP_NANOS);
                    } else {
                        mPreconnectState.remove(key, PRECONNECT_IN_FLIGHT);
                    }
                    ProviderAttemptTelemetry.reportDuration(
                            engineId, "preconnect_response",
                            ProviderAttemptTelemetry.elapsedMs(startedNanos), status);
                }
            });
            return true;
        } catch (RuntimeException scheduleFailure) {
            mPreconnectState.remove(key, PRECONNECT_IN_FLIGHT);
            return false;
        }
    }

    static HttpUrl preconnectOrigin(String baseUrl) {
        HttpUrl parsed = HttpUrl.parse(baseUrl);
        if (parsed == null || !"https".equalsIgnoreCase(parsed.scheme())
                || !parsed.username().isEmpty() || !parsed.password().isEmpty()) {
            throw new IllegalArgumentException("Provider preconnect URL must be a secure HTTPS origin");
        }
        return parsed.newBuilder().encodedPath("/").query(null).fragment(null).build();
    }

    private synchronized String preconnectKey(HttpUrl origin, boolean llm) {
        return preconnectKey(origin, llm, com.mg.translation.internal.runtime.NetworkFailureScope.network());
    }

    synchronized String preconnectKey(HttpUrl origin, boolean llm, long network) {
        if (network != preconnectNetwork) {
            preconnectNetwork = network;
            preconnectGeneration++;
            mPreconnectState.clear();
        }
        return preconnectGeneration + "|" + (llm ? "llm|" : "translate|") + origin;
    }

    private Retrofit getLlmRetrofitInstance(
            String validatedBaseUrl, String cacheKey) {
        Retrofit cached = mRetrofitCache.get(cacheKey);
        if (cached != null) return cached;
        synchronized (this) {
            cached = mRetrofitCache.get(cacheKey);
            if (cached != null) return cached;
            cached = new Retrofit.Builder()
                    .callFactory(deadlineCalls(mLlmClient))
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createAsync())
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(validatedBaseUrl)
                    .build();
            mRetrofitCache.put(cacheKey, cached);
            return cached;
        }
    }

    private <T> T getOrCreateService(
            String retrofitKey, Class<T> service, Retrofit retrofit) {
        String serviceKey = retrofitKey + "_" + service.getName();
        Object cached = mServiceCache.get(serviceKey);
        if (cached != null) return service.cast(cached);
        synchronized (this) {
            cached = mServiceCache.get(serviceKey);
            if (cached != null) return service.cast(cached);
            cached = retrofit.create(service);
            mServiceCache.put(serviceKey, cached);
            return service.cast(cached);
        }
    }

    static Call.Factory deadlineCalls(OkHttpClient client) {
        return request -> {
            Call call = client.newCall(request);
            long deadline = RequestContext.deadline();
            if (deadline != Long.MAX_VALUE) {
                long remaining = Math.max(1L, deadline - System.nanoTime());
                long engineTimeout = TimeUnit.MILLISECONDS.toNanos(client.callTimeoutMillis());
                call.timeout().timeout(engineTimeout > 0 ? Math.min(remaining, engineTimeout) : remaining,
                        TimeUnit.NANOSECONDS);
                call.timeout().deadlineNanoTime(deadline);
            }
            return call;
        };
    }

    private String validateBaseUrl(String baseUrl) {
        HttpUrl parsed = baseUrl == null ? null : HttpUrl.parse(baseUrl);
        if (parsed == null || !"https".equalsIgnoreCase(parsed.scheme())) {
            throw new IllegalArgumentException("Provider base URL must use HTTPS");
        }
        return parsed.toString();
    }

    private static <V> java.util.Map<String, V> boundedCache(int capacity) {
        return java.util.Collections.synchronizedMap(new java.util.LinkedHashMap<String, V>(16, .75f, true) {
            @Override protected boolean removeEldestEntry(java.util.Map.Entry<String, V> eldest) {
                return size() > capacity;
            }
        });
    }

}
