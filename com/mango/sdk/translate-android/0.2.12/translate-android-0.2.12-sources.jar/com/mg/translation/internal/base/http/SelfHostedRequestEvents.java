package com.mg.translation.internal.base.http;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.sdk.TranslationHost;
import okhttp3.Call;
import okhttp3.Response;
import java.io.IOException;
import java.io.InterruptedIOException;

/** Captures transport outcomes even when Rx disposal suppresses the business callback. */
final class SelfHostedRequestEvents extends NetworkRequestEvents {
    SelfHostedRequestEvents() { super(-1, "translation"); }
    private long started;
    private int status;
    private TranslationHost host;
    private boolean reported;
    @Override public void callStart(Call call) {
        super.callStart(call);
        started = System.nanoTime();
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        host = runtime == null ? null : runtime.host();
        String path = call.request().url().encodedPath();
        engineId = path.endsWith("/api/baidu/translate") ? TranslatorId.BD.legacyCode
                : path.endsWith("/api/youdao/translate") ? TranslatorId.SELF_HOSTED_YOUDAO.legacyCode
                : TranslatorId.SELF_HOSTED_GOOGLE.legacyCode;
    }
    @Override public void responseHeadersEnd(Call call, Response response) { super.responseHeadersEnd(call, response); status = response.code(); }
    @Override public void callEnd(Call call) { super.callEnd(call); report(status >= 400 ? "http_error" : "http_success"); }
    @Override public void callFailed(Call call, IOException error) { super.callFailed(call, error); report(classify(error, call.isCanceled())); }
    static String classify(IOException error, boolean cancelled) {
        if (error instanceof java.net.SocketTimeoutException
                || error instanceof InterruptedIOException && ("timeout".equalsIgnoreCase(error.getMessage())
                || "deadline reached".equalsIgnoreCase(error.getMessage()))) return "timeout";
        return cancelled ? "cancelled" : "network_error";
    }
    private synchronized void report(String outcome) {
        if (reported) return;
        reported = true;
        if (host != null) {
            try { host.onRequestFinished(engineId, outcome, (System.nanoTime() - started) / 1_000_000L, status); }
            catch (RuntimeException ignored) { /* Host telemetry must not break translation. */ }
        }
    }
}
