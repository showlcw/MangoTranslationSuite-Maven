package com.mg.translation.http.translate.ai.dto;

import java.util.List;

public class RapidAiBatchTranslateResult {
    private List<String> texts;
    private int code;

    public List<String> getTexts() {
        return texts;
    }

    public boolean isSuccess() {
        return code == 200;
    }

    public void setTexts(List<String> texts) {
        this.texts = texts;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
