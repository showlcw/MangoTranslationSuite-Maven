package com.mg.translation.http.translate.ai.dto;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;


public class RapidAiTranslateReq extends BaseReq {

    private List<String> texts;
    private String sl = "auto";
    private String tl;

    public List<String> getTexts() {
        return texts;
    }

    public void setTexts(List<String> texts) {
        this.texts = texts;
    }

    public String getSl() {
        return sl;
    }

    public void setSl(String sl) {
        this.sl = sl;
    }

    public String getTl() {
        return tl;
    }

    public void setTl(String tl) {
        this.tl = tl;
    }
}
