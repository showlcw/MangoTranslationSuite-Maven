package com.mg.translation.http.translate.baidu.dto;

import com.google.gson.annotations.SerializedName;
import com.mg.translation.internal.base.BaseConstants;


/**
 * Created by Shurrik on 2017/11/22.
 */

public class BaiduTranslateHttpResult<T> {

    @SerializedName("error_code")
    private int errorCode;
    @SerializedName("error_msg")
    private String errorMsg;
    @SerializedName("trans_result")
    private T data;

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return errorCode == BaseConstants.ServerCode.SUCCESS;
    }

}
