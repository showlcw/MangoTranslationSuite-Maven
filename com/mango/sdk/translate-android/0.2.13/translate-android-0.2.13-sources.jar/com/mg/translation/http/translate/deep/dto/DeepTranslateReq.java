package com.mg.translation.http.translate.deep.dto;

import com.mg.translation.internal.base.http.req.BaseReq;


public class DeepTranslateReq extends BaseReq {
//"q": "Hello World!",
//        "source": "en",
//        "target": "es"
    private String q ;
    private String source = "auto";
    private String target ;

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
}
