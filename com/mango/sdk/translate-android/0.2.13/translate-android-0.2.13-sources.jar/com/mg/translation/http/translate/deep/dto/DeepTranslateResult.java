package com.mg.translation.http.translate.deep.dto;

import java.util.ArrayList;

public class DeepTranslateResult {

    private Data data;
    private String message;
    private int code = 0;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public static final class Data {
        private Translations translations;

        public Translations getTranslations() {
            return translations;
        }

        public void setTranslations(Translations translations) {
            this.translations = translations;
        }
    }

    public static final class Translations {
        private ArrayList<String> translatedText;

        public ArrayList<String> getTranslatedText() {
            return translatedText;
        }

        public void setTranslatedText(ArrayList<String> translatedText) {
            this.translatedText = translatedText;
        }
    }
}
