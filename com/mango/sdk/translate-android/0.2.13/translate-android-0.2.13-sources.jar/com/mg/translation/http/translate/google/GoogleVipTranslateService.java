package com.mg.translation.http.translate.google;

import com.mg.translation.http.translate.google.dto.GoogleTranslateResult;

import java.util.Map;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface GoogleVipTranslateService {
    @POST("language/translate/v2")
    Single<GoogleTranslateResult> googleTranslateVip(@Header("X-Android-Package") String packgae, @Header("X-Android-Cert") String cert, @QueryMap Map<String, String> map, @Body RequestBody requestBody);
}
