package com.mg.translation.http.translate.irctcapi.dto;

import com.mg.translation.internal.base.http.req.BaseReq;


public class IrctcapiTranslateReq extends BaseReq {

    private String q;
    private String source = "";
    private String target;
    private String format = "text";


    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }


}
