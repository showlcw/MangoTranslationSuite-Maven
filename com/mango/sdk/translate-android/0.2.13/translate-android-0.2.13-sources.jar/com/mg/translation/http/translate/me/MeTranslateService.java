package com.mg.translation.http.translate.me;

import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface MeTranslateService {

    /**
     * 自己服务器的翻译
     *
     * @return
     */
    @POST("api/baidu/translate")
    Single<MeTranslateHttpResult> meTranslate(@Body RequestBody requestBody);


    /**
     * 自己服务器的翻译
     *
     * @return
     */
    @POST("api/youdao/translate")
    Single<MeTranslateHttpResult> youdaoTranslate(@Body RequestBody requestBody);



}
