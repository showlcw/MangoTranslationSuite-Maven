package com.mg.translation.http.translate.memory.dto;


public class MemoryTranslateResult {
    private ResponseData responseData;
    private int responseStatus;
    private String responseDetails;

    public String getResponseDetails() {
        return responseDetails;
    }

    public void setResponseDetails(String responseDetails) {
        this.responseDetails = responseDetails;
    }

    public boolean isSuccess() {
        return responseStatus == 200;
    }

    public ResponseData getResponseData() {
        return responseData;
    }

    public void setResponseData(ResponseData responseData) {
        this.responseData = responseData;
    }

    public int getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(int responseStatus) {
        this.responseStatus = responseStatus;
    }

    public static final class ResponseData {
        private String translatedText;
        private float match;

        public String getTranslatedText() {
            return translatedText;
        }

        public void setTranslatedText(String translatedText) {
            this.translatedText = translatedText;
        }

        public float getMatch() {
            return match;
        }

        public void setMatch(float match) {
            this.match = match;
        }
    }
}
