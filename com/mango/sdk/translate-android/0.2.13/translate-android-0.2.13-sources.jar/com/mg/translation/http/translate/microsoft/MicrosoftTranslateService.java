package com.mg.translation.http.translate.microsoft;

import com.mg.translation.http.translate.microsoft.dto.MicrosoftTranslateItemResult;

import java.util.List;
import java.util.Map;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface MicrosoftTranslateService {

    /**
     * microsoft  translate
     *
     * @return
     */
    @POST("translate")
    Single<List<MicrosoftTranslateItemResult>> microsoftTranslate(@Header("Ocp-Apim-Subscription-Region") String region, @Header("Ocp-Apim-Subscription-Key") String key, @Header("Content-type") String contentType, @QueryMap Map<String, String> map, @Body RequestBody requestBody);


}
