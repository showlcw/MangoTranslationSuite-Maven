package com.mg.translation.http.translate.microsoft.dto;

import com.google.gson.annotations.SerializedName;
import com.mg.translation.internal.base.http.req.BaseReq;

public class MicrosoftTranslateReq extends BaseReq {

    @SerializedName("api-version")
    private String apiVersion = "3.0";

    private String from = "auto";
    private String to = "to";

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }
}
