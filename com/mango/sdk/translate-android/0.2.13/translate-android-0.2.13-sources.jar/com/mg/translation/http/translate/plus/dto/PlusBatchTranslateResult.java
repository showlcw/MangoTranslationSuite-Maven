package com.mg.translation.http.translate.plus.dto;

import java.util.List;

/**
 * translate-plus  批量翻译返回体
 * {
 *   "translations":[
 *      {"text":"...","translation":"...","source":"en","target":"fr","success":true},
 *      ...
 *   ],
 *   "total":3,"successful":3,"failed":0
 * }
 * localErrorCode 非接口返回,仅供 {@link com.mg.translation.http.translate.TranslateRepository} 标记本地错误用;
 * 声明 transient 且不叫 code,避免服务端未来在成功响应里加顶层 code 字段被 Gson 填充后误判失败。
 */
public class PlusBatchTranslateResult {

    private List<TranslationItem> translations;
    private transient int localErrorCode;

    public List<TranslationItem> getTranslations() {
        return translations;
    }

    public void setTranslations(List<TranslationItem> translations) {
        this.translations = translations;
    }

    public int getLocalErrorCode() {
        return localErrorCode;
    }

    public void setLocalErrorCode(int localErrorCode) {
        this.localErrorCode = localErrorCode;
    }

    public static class TranslationItem {
        private String text;
        private String translation;
        private boolean success;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getTranslation() {
            return translation;
        }

        public void setTranslation(String translation) {
            this.translation = translation;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }
    }
}
