package com.mg.translation.http.translate.qwen;

import com.mg.translation.http.ai.OpenAiChatResponse;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

/** Qwen DashScope OpenAI-compatible Chat Completions API。 */
public interface QwenTranslateService {
    @POST("chat/completions")
    Single<OpenAiChatResponse> translate(@Header("Authorization") String apiKey,
                                         @Header("Content-type") String contentType,
                                         @Header("Accept") String accept,
                                         @Header("X-DashScope-DataInspection") String dataInspection,
                                         @Body RequestBody requestBody);
}
