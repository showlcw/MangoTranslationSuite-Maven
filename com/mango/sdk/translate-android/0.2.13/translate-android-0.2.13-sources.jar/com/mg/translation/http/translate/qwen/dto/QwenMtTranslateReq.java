package com.mg.translation.http.translate.qwen.dto;

import com.google.gson.annotations.SerializedName;
import com.mg.translation.http.ai.OpenAiChatMessage;
import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;

/**
 * Qwen-MT OpenAI-compatible chat/completions request.
 * <p>
 * Doc: https://help.aliyun.com/zh/model-studio/qwen-mt-api
 */
public class QwenMtTranslateReq extends BaseReq {

    private String model;
    private List<OpenAiChatMessage> messages;

    @SerializedName("translation_options")
    private TranslationOptions translationOptions;

    public QwenMtTranslateReq(List<OpenAiChatMessage> messages) {
        this.messages = messages;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public List<OpenAiChatMessage> getMessages() {
        return messages;
    }

    public void setMessages(List<OpenAiChatMessage> messages) {
        this.messages = messages;
    }

    public TranslationOptions getTranslationOptions() {
        return translationOptions;
    }

    public void setTranslationOptions(TranslationOptions translationOptions) {
        this.translationOptions = translationOptions;
    }

    public static class TranslationOptions {

        @SerializedName("source_lang")
        private String sourceLang;

        @SerializedName("target_lang")
        private String targetLang;

        /** qwen-mt 领域/风格提示(英文自由文本);null 时 Gson 默认不序列化,向后兼容。 */
        @SerializedName("domains")
        private String domains;

        public TranslationOptions(String sourceLang, String targetLang) {
            this.sourceLang = sourceLang;
            this.targetLang = targetLang;
        }

        public String getSourceLang() {
            return sourceLang;
        }

        public void setSourceLang(String sourceLang) {
            this.sourceLang = sourceLang;
        }

        public String getTargetLang() {
            return targetLang;
        }

        public void setTargetLang(String targetLang) {
            this.targetLang = targetLang;
        }

        public String getDomains() {
            return domains;
        }

        public void setDomains(String domains) {
            this.domains = domains;
        }
    }
}
