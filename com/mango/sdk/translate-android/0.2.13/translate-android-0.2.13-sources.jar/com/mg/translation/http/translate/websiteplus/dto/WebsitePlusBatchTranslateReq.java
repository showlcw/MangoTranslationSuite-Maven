package com.mg.translation.http.translate.websiteplus.dto;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;


/**
 * WebsitePlus 批量翻译请求：
 * {"source":"auto","target":"fr","texts":["...","..."]}
 */
public class WebsitePlusBatchTranslateReq extends BaseReq {

    private List<String> texts;
    private String source = "auto";
    private String target;

    public List<String> getTexts() {
        return texts;
    }

    public void setTexts(List<String> texts) {
        this.texts = texts;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
}
