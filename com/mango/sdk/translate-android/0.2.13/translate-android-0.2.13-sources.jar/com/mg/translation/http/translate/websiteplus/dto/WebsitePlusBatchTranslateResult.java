package com.mg.translation.http.translate.websiteplus.dto;

import java.util.List;

/** WebsitePlus 批量翻译响应；localErrorCode 仅表示 SDK 本地错误。 */
public class WebsitePlusBatchTranslateResult {

    private List<TranslationItem> translations;
    private transient int localErrorCode;

    public List<TranslationItem> getTranslations() {
        return translations;
    }

    public void setTranslations(List<TranslationItem> translations) {
        this.translations = translations;
    }

    public int getLocalErrorCode() {
        return localErrorCode;
    }

    public void setLocalErrorCode(int localErrorCode) {
        this.localErrorCode = localErrorCode;
    }

    public static class TranslationItem {
        private String text;
        private String translation;
        private boolean success;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getTranslation() {
            return translation;
        }

        public void setTranslation(String translation) {
            this.translation = translation;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }
    }
}
