package com.mg.translation.http.translate.websiteplus.dto;


public class WebsitePlusTranslateResult {

    private TranslationData translations;
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
    public TranslationData getTranslations() {
        return translations;
    }

    public void setTranslations(TranslationData translations) {
        this.translations = translations;
    }

    public static final class TranslationData {
        private String text;
        private String translation;

        public String getTranslation() {
            return translation;
        }

        public void setTranslation(String translation) {
            this.translation = translation;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }
    }
}
