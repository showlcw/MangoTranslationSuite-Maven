package com.mg.translation.internal.base;

/** Shared response values still used by active Provider DTOs. */
public final class BaseConstants {
    public static final String QWEN_DEFAULT_MODEL = "qwen-mt-flash";

    public interface ServerCode {
        int SUCCESS = 0;
    }

    private BaseConstants() { }
}
