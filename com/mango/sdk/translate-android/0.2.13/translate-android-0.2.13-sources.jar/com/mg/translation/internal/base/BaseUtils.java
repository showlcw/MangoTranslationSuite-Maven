package com.mg.translation.internal.base;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import androidx.annotation.NonNull;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Small text and package-signature helpers used by active translation Providers. */
public final class BaseUtils {
    private BaseUtils() { }

    @SuppressWarnings("deprecation")
    public static String getAppSignatureSha1(@NonNull Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), PackageManager.GET_SIGNATURES);
            if (info.signatures == null || info.signatures.length == 0) return null;
            return signatureDigest(info.signatures[0]);
        } catch (PackageManager.NameNotFoundException error) {
            return null;
        }
    }

    private static String signatureDigest(Signature signature) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA1").digest(signature.toByteArray());
            StringBuilder value = new StringBuilder(digest.length * 2);
            for (byte item : digest) value.append(String.format("%02x", item & 0xff));
            return value.toString();
        } catch (NoSuchAlgorithmException error) {
            return null;
        }
    }

    public static String replaceLast(String lineText) {
        if (lineText != null && lineText.endsWith("\n")) {
            int lastIndex = lineText.lastIndexOf("\n");
            if (lastIndex != -1) lineText = lineText.substring(0, lastIndex);
        }
        return lineText;
    }
}
