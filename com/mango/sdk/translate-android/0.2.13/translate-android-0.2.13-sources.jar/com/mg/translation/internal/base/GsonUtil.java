package com.mg.translation.internal.base;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import java.lang.reflect.Type;

public final class GsonUtil {
    private GsonUtil() { }

    // 缓存 Gson 实例，避免重复创建（Gson 是线程安全的）
    private static final Gson GSON_INSTANCE = new GsonBuilder()
            .disableHtmlEscaping()
            .create();

    /**
     * 将对象转换为String
     */
    public static String toJson(Object o) {
        return GSON_INSTANCE.toJson(o);
    }

    /**
     * 解析数据是object的情况
     */
    public static <T> T convert(String str, Class<T> cls) throws JsonSyntaxException {
        return GSON_INSTANCE.fromJson(str, cls);
    }

    public static <T> T convert(String str, Type type) throws JsonSyntaxException {
        return GSON_INSTANCE.fromJson(str, type);
    }

    /**
     * 获取 Gson 实例
     * @return 缓存的 Gson 实例
     */
    public static Gson getGson() {
        return GSON_INSTANCE;
    }

}
