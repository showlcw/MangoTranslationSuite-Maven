package com.mg.translation.internal.runtime;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;

import java.util.List;

/** TranslateControl wrapper that blocks unauthorized requests before any Provider call. */
public final class EntitlementCheckingTranslateControl implements TranslateControl {
    private final TranslateControl delegate;
    private final TranslatorId engine;

    public EntitlementCheckingTranslateControl(TranslateControl delegate, TranslatorId engine) {
        this.delegate = delegate;
        this.engine = engine;
    }

    @Override
    public void translate(TranslationTask request, TranslateListener listener) {
        boolean rescue = request != null && request.isEmergencyRequest()
                && (engine == com.mg.translation.engine.TranslatorId.BAIDU
                || engine == com.mg.translation.engine.TranslatorId.QWEN);
        TranslationError restriction = rescue ? null : currentRestriction();
        if (restriction != null) {
            if (listener != null) listener.onFail(restriction.getCode(), restriction.getMessage());
            return;
        }
        delegate.translate(request, listener);
    }

    private TranslationError currentRestriction() {
        if (TranslationRuntime.get().configStore().isVipOnly(engine.legacyCode)
                && !TranslationRuntime.get().host().isVip()) {
            return TranslationErrorMapper.vipRequired(engine.legacyCode);
        }
        return null;
    }

    @Override public BaseReq createBaseReq(String content, String source, String to) {
        return delegate.createBaseReq(content, source, to);
    }
    @Override public List<LanguageVO> getSupportLanguage() { return delegate.getSupportLanguage(); }
    @Override public int getIndexByLanguage(String language, boolean useDefault) {
        return delegate.getIndexByLanguage(language, useDefault);
    }
    @Override public LanguageVO getSelectLanguageVO(String country, boolean useDefault) {
        return delegate.getSelectLanguageVO(country, useDefault);
    }
    @Override public String getTranslateTypeName() { return delegate.getTranslateTypeName(); }
    @Override public int getTranslateType() { return delegate.getTranslateType(); }
    @Override public boolean isSupportAuto() { return delegate.isSupportAuto(); }
    @Override public void close() { delegate.close(); }
}
