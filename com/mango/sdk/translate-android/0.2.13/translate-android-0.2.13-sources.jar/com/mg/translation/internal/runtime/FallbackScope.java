package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** Owns dynamically created fallback controllers, including their nested fallback scopes. */
public final class FallbackScope implements AutoCloseable {
    private final AtomicBoolean closed = new AtomicBoolean();
    private final Set<Entry> active = ConcurrentHashMap.newKeySet();

    public boolean isClosed() { return closed.get(); }

    public void execute(TranslateControl control, TranslationTask task, TranslateListener listener) {
        Entry entry = new Entry(control);
        active.add(entry);
        if (closed.get()) { release(entry); return; }
        if (!task.isRuntimeCurrent()) {
            release(entry);
            listener.onFail(com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, "Translation runtime changed");
            return;
        }
        TranslationTask attempt = task.copyForAttempt();
        try {
            // Keep the task's total deadline for fallback accounting, but bound this
            // individual provider attempt so a slow provider cannot consume the whole chain.
            long attemptDeadline = attemptDeadline(task, control);
            TranslationRuntime.withSnapshot(task.getRuntimeSnapshot(), () ->
            com.mg.translation.internal.base.http.RequestContext.withDeadline(attemptDeadline,
                    () -> com.mg.translation.internal.base.http.RequestContext.withTrace(task.getTraceId(),
                    () -> control.translate(attempt, new TranslateListener() {
                @Override public void onSuccess(TranslationTask result, int id, boolean batch) {
                    if (closed.get() || entry.terminal.get()) return;
                    // Validate before consuming the terminal gate or closing the Provider.
                    // Its executeRequest failure handler must remain able to start the next fallback.
                    TranslationResultValidation.map(task, result, id, batch);
                    if (!entry.terminal.compareAndSet(false, true)) return;
                    try { if (!closed.get()) listener.onSuccess(result, id, batch); }
                    finally { release(entry); }
                }
                @Override public void onFail(int code, String message) {
                    if (!entry.terminal.compareAndSet(false, true)) return;
                    try { if (!closed.get()) listener.onFail(code, message); }
                    finally { release(entry); }
                }
            }))));
        } catch (RuntimeException failure) {
            entry.terminal.set(true);
            release(entry);
            throw failure;
        }
    }

    private static long attemptDeadline(TranslationTask task, TranslateControl control) {
        long totalDeadline = task.getDeadlineNanos();
        TranslatorId id = TranslatorId.fromLegacyCode(control.getTranslateType());
        if (id == null || totalDeadline == Long.MAX_VALUE) return totalDeadline;
        long attemptMs = id.requestTimeoutMs();
        if (attemptMs <= 0L) return totalDeadline;
        long now = System.nanoTime();
        long attemptDeadline = now + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(attemptMs);
        // Saturation protects the deadline calculation from an unlikely nanoTime overflow.
        if (attemptDeadline < now) attemptDeadline = Long.MAX_VALUE;
        return Math.min(totalDeadline, attemptDeadline);
    }

    private void release(Entry entry) {
        active.remove(entry);
        if (entry.released.compareAndSet(false, true)) entry.control.close();
    }

    @Override public void close() {
        closed.set(true);
        for (Entry entry : active) {
            entry.terminal.set(true);
            release(entry);
        }
    }

    private static final class Entry {
        final TranslateControl control;
        final AtomicBoolean terminal = new AtomicBoolean();
        final AtomicBoolean released = new AtomicBoolean();
        Entry(TranslateControl control) { this.control = control; }
    }
}
