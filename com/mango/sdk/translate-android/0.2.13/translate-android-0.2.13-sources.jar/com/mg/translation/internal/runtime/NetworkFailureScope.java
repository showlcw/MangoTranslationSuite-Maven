package com.mg.translation.internal.runtime;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;

/** Marks only transport failures as network-scoped; HTTP rejection and TLS validation stay global. */
public final class NetworkFailureScope {
    private static final ThreadLocal<Long> NETWORK = new ThreadLocal<>();
    private NetworkFailureScope() { }
    public static Long current() { return NETWORK.get(); }
    public static long network(Context context) {
        if (context == null) return -1;
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network active = manager == null ? null : manager.getActiveNetwork();
        return active == null ? -1 : active.getNetworkHandle();
    }
    public static long network() {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        return network(runtime == null ? null : runtime.context());
    }
    public static void run(long network, Runnable action) {
        Long previous = NETWORK.get();
        NETWORK.set(network);
        try { action.run(); }
        finally { if (previous == null) NETWORK.remove(); else NETWORK.set(previous); }
    }
}
