package com.mg.translation.internal.runtime;

import com.google.gson.JsonObject;

/** SDK 内部一次 Provider 请求使用的同组地址与密钥。 */
public final class ProviderCredential {
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    private final String domains;
    private final boolean dataInspectionEnabled;
    private final String protocol;
    private final boolean reasoningEnabled;
    private final JsonObject providerRouting;

    ProviderCredential(String baseUrl, String apiKey, String model, String domains,
                       boolean dataInspectionEnabled, String protocol,
                       boolean reasoningEnabled, JsonObject providerRouting) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.model = model;
        this.domains = domains;
        this.dataInspectionEnabled = dataInspectionEnabled;
        this.protocol = protocol;
        this.reasoningEnabled = reasoningEnabled;
        this.providerRouting = providerRouting == null ? null : providerRouting.deepCopy();
    }

    public String getBaseUrl() { return baseUrl; }
    public String getApiKey() { return apiKey; }
    public String getModel() { return model; }
    public String getDomains() { return domains; }
    public boolean isDataInspectionEnabled() { return dataInspectionEnabled; }
    public String getProtocol() { return protocol; }
    public boolean isReasoningEnabled() { return reasoningEnabled; }
    public JsonObject getProviderRouting() {
        return providerRouting == null ? null : providerRouting.deepCopy();
    }
}
