package com.mg.translation.internal.runtime;

import android.content.Context;
import android.content.SharedPreferences;

/** Persists only the encrypted Platform JSON payload; decrypted Provider values are never cached. */
public final class TranslationConfigCache {
    private static final String PREFERENCES = "mango_translation_sdk_config";
    private static final String PAYLOAD = "encrypted_config_json";
    private static final String UPDATED_AT = "updated_at";

    private TranslationConfigCache() { }

    public static String load(Context context) {
        return preferences(context).getString(PAYLOAD, null);
    }

    public static void save(Context context, String encryptedConfigJson) {
        preferences(context).edit()
                .putString(PAYLOAD, encryptedConfigJson)
                .putLong(UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    public static void clear(Context context) {
        preferences(context).edit().clear().apply();
    }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(
                PREFERENCES, Context.MODE_PRIVATE);
    }
}
