package com.mg.translation.internal.runtime;

/** Emits metadata-only SDK events through the host integration. */
public final class TranslationTelemetry {
    private TranslationTelemetry() { }

    public static void event(String eventId) {
        if (eventId == null || eventId.trim().isEmpty()) return;
        TranslationRuntime.get().host().onEvent(eventId);
    }
}
