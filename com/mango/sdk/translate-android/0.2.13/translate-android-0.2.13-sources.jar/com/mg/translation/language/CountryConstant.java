package com.mg.translation.language;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/8 15:43
 */
public final class CountryConstant {

    public static final String ISRAEL = "Israel";//阿拉伯语 (以色列)
    public static final String JORDAN = "Jordan";//阿拉伯语(约旦)
    public static final String UNITED_ARAB_EMIRATES = "United Arab Emirates";//阿拉伯语 阿拉伯联合酋长国
    public static final String BAHRAIN = "Bahrain";//阿拉伯语  巴林
    public static final String ALGERIA = "Algeria";//阿拉伯语  阿尔及利亚
    public static final String IRAQ = "Iraq";//阿拉伯语  伊拉克
    public static final String KUWAIT = "Kuwait";//阿拉伯语  科威特
    public static final String MOROCCO = "Morocco";//阿拉伯语  摩洛哥
    public static final String TUNISIA = "Tunisia";//阿拉伯语  突尼斯
    public static final String OMAN = "Oman";//阿拉伯语  阿曼
    public static final String STATE_OF_PALESTINE = "State of palestine";//阿拉伯语  巴勒斯坦国
    public static final String QATAR = "Qatar";//阿拉伯语  卡塔尔
    public static final String LEBANON = "Lebanon";//阿拉伯语  黎巴嫩
    public static final String EGYPT = "Egypt";//阿拉伯语  埃及
    public static final String SAUDI_ARABIA = "Saudi Arabia";//阿拉伯语  沙特阿拉伯

    public static final String FRANCE = "France";//法国
    public static final String CANADA = "Canada";//加拿大
    public static final String BRAZIL = "Brazil";//巴西
    public static final String PORTUGAL = "Portugal";//葡萄牙
    public static final String INDIA = "India";//印度
    public static final String SINGAPORE = "Singapore";//新加坡
    public static final String SRI_LANKA = "Sri Lanka";//斯里兰卡
    public static final String MALAYSIA = "Malaysia";//马来西亚
    public static final String SPAIN = "Spain";//西班牙
    public static final String ARGENTINA = "Argentina";//阿根廷
    public static final String BOLIVIA = "Bolivia";//玻利维亚
    public static final String CHILE = "Chile";//智利
    public static final String COLOMBIA = "Colombia";//哥伦比亚
    public static final String COSTA_RICA = "Costa Rica";//哥斯达黎加
    public static final String ECUADOR = "Ecuador";//厄瓜多尔
    public static final String EL_SALVADOR = "El Salvador";//萨尔瓦多
    public static final String USA = "USA";//美国
    public static final String GUATEMALA = "Guatemala";//危地马拉

    public static final String HONDURAS = "Honduras";//洪都拉斯
    public static final String MEXICO = "Mexico";//墨西哥

    public static final String NICARAGUA = "Nicaragua";//尼加拉瓜

    public static final String PANAMA = "Panama";//巴拿马
    public static final String PARAGUAY = "Paraguay";//巴拉圭
    public static final String PERU = "Peru";//秘鲁
    public static final String PUERTO_RICO = "Puerto Rico";//波多黎各
    public static final String DOMINICAN_REPUBLIC = "Dominican_Republic";//多米尼加共和国

    public static final String URUGUAY = "Uruguay";//乌拉圭
    public static final String VENEZUELA = "Venezuela";//委内瑞拉

    public static final String BENGAL = "Bengal";//孟加拉

    public static final String PAKISTAN = "Pakistan";//巴基斯坦

    private CountryConstant() { }
}
