package com.mg.translation.language;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/8 15:43
 */
public final class LanguageConstant {
    public static final String CHINESE = "Chinese";//中文
    public static final String ENGLISH = "English";//英文
    public static final String JAPANESE = "Japanese";//日语
    public static final String FRENCH = "French";//法语
    public static final String SPANISH = "Spanish";//西班牙语
    public static final String KOREAN = "Korean";//韩文
    public static final String PORTUGUESE = "Portuguese";//葡萄牙文

    public static final String PORTUGUESE_BR = "Portuguese_Brazil";//葡萄牙文(巴西)


    public static final String ITALIAN = "Italian";//意大利文
    public static final String GERMAN = "German";//德文
    public static final String RUSSIAN = "Russian";//俄文

    public static final String ARABIC = "Arabic";//阿拉伯语
    public static final String ALBANIAN = "Albanian";//阿尔巴尼亚语
    public static final String ARAGORN = "Aragorn";//阿拉贡语
    public static final String AYMARA = "Aymara";//艾马拉语
    public static final String OSSETIAN = "Ossetian";//奥塞梯语
    public static final String ORIYA = "Oriya";//奥里亚语
    public static final String IRISH = "irish";//爱尔兰语
    public static final String ALGERIAN_ARABIC = "Algerian_Arabic";//阿尔及利亚阿拉伯语
    public static final String AMHARIC = "Amharic";//阿姆哈拉语
    public static final String AZERBAIJANI = "Azerbaijani";//阿塞拜疆语
    public static final String OROMO = "Oromo";//奥罗莫语
    public static final String OCCITAN = "Occitan";//奥克语
    public static final String AKAN = "Akan";//阿肯语
    public static final String ASSAMESE = "Assamese";//阿萨姆语
    public static final String DANISH = "Danish";//丹麦语
    public static final String FINNISH = "Finnish";//芬兰语
    public static final String POLISH = "Polish";//波兰语
    public static final String SWEDISH = "Swedish";//瑞典语
    public static final String THAI = "Thai";//泰语
    public static final String TRADITIONAL_CHINESE = "Traditional_Chinese";//中文繁体
    public static final String MALAY = "Malay";//马来语
    public static final String NORWEGIAN = "Norwegian";//挪威语
    public static final String VIETNAMESE = "Vietnamese";//越南语
    public static final String CZECH = "Czech";//捷克语
    public static final String GREEK = "Greek";//希腊语
    public static final String HEBREW = "Hebrew";//希伯来语
    public static final String HINDI = "Hindi";//印地语
    public static final String INDONESIAN = "Indonesian";//印尼语
    public static final String ROMANIAN = "Romanian";//罗马尼亚语
    public static final String SERBIAN = "Serbian";//塞尔维亚语
    public static final String FILIPINO = "Filipino";//菲律宾语
    public static final String KHMER = "Khmer";//高棉语
    public static final String BURMESE = "Burmese";//缅甸语
    public static final String TAMIL = "Tamil";//泰米尔语
    public static final String HUNGARIAN = "Hungarian";//匈牙利语
    public static final String DUTCH = "Dutch";//荷兰语
    public static final String PERSIAN = "Persian";//波斯语
    public static final String SLOVAK = "Slovak";//斯洛伐克语
    public static final String ESTONIAN = "Estonian";//爱沙尼亚语
    public static final String LATVIAN = "Latvian";//拉脱维亚语
    public static final String AFRIKAANS = "Afrikaans";//南非荷兰语
    public static final String ARMENIAN = "Armenian";//亚美尼亚语
    public static final String CATALAN = "Catalan";//加泰罗尼亚语
    public static final String CROATIAN = "Croatian";//克罗地亚语
    public static final String ICELANDIC = "Icelandic";//冰岛语
    public static final String LITHUANIAN = "Lithuanian";//立陶宛语
    public static final String TURKISH = "Turkish";//土耳其
    public static final String BULGARIAN = "Bulgaria";//保加利亚语
    public static final String BENGALI = "Bengali";//孟加拉语
    public static final String WELSH = "Welsh";//威尔士语
    public static final String GUJARATI = "Gujarati";//古吉拉特语
    public static final String KANNADA = "Kannada";//卡纳达语
    public static final String MACEDONIAN = "Macedonian";//马其顿语
    public static final String MALAYALAM = "Malayalam";//马拉亚拉姆语
    public static final String MARATHI = "Marathi";//马拉提语
    public static final String PUNJABI = "Punjabi";//旁遮普语
    public static final String SLOVENIAN = "Slovenian";//斯洛文尼亚语
    public static final String SOMALI = "Somali";//索马里
    public static final String TELUGU = "Telugu";//泰卢固语
    public static final String TAGALOG = "Tagalog";//他加禄语
    public static final String UKRAINIAN = "Ukrainian";//乌克兰语
    public static final String URDU = "Urdu";//乌尔都语
    public static final String BHOJPURI = "Bhojpuri";//博杰普里
    public static final String DOGRI = "Dogri";//多格拉语
    public static final String HMONG = "Hmong";//苗语
    public static final String ILOCANO = "Ilocano";//Ilocano


    public static final String BASHKIR = "Bashkir";//巴什基尔语
    public static final String BELARUSIAN = "Belarusian";//白俄罗斯语
    public static final String BUMBA = "Bumba";//本巴语
    public static final String BALUCHI = "Baluchi";//俾路支语
    public static final String BGOJPUR = "Bhojpur";//博杰普尔语
    public static final String BERBER = "Berber";//柏柏尔语
    public static final String NORTHERN_SAMI = "Northern_Sami";//北方萨米语
    public static final String BILING = "Biling";//比林语
    public static final String BRETON = "Breton";//布列塔尼语
    public static final String PAMPANGA = "Pampanga";//邦板牙语
    public static final String NORTHERN_SPTHO = "Northern_Sotho";//北索托语
    public static final String BISLAMA = "Bislama";//比斯拉马语
    public static final String BOSNIAN = "Bosnian";//波斯尼亚语
    public static final String CHUVASH = "Chuvash";//楚瓦什语
    public static final String TSUNGA = "Tsunga";//聪加语
    public static final String SHAN = "Shan";//掸语
    public static final String TETON = "Teton";//德顿语


    public static final String TATAR = "Tatar";//鞑靼语
    public static final String DHIVEHI = "Dhivehi";//迪维希语
    public static final String SANSKRIT = "Sanskrit";//梵语
    public static final String FAROESE = "Faroese";//法罗语
    public static final String FRIULI = "Friuli";//弗留利语
    public static final String FULANI = "Fulani";//富拉尼语
    public static final String GAELIC = "Gaelic";//盖尔语
    public static final String GUARANI = "Guarani";//瓜拉尼语
    public static final String CONGO = "Congo";//刚果语
    public static final String GREENLANDIC = "Greenlandic";//格陵兰语
    public static final String ANCIENT_GREEK = "Ancient_Greek";//古希腊语
    public static final String HIGHLAND_SORBIAN = "Highland_Sorbian";//高地索布语
    public static final String GEORGIAN = "Georgian";//格鲁吉亚语
    public static final String HAKACHIN = "Hakachin";//哈卡钦语
    public static final String HAUSA = "Hausa";//豪萨语
    public static final String MONTENEGRIN = "Montenegrin";//黑山语
    public static final String HUPA = "Hupa";//胡帕语
    public static final String HAITIAN = "Haitian";//海地语
    public static final String KYRGYZ = "Kyrgyz";//吉尔吉斯语
    public static final String GALICIAN = "Galician";//加利西亚语
    public static final String KABYLE = "Kabyle";//卡拜尔语
    public static final String KASHUBIAN = "Kashubian";//卡舒比语
    public static final String CORSICAN = "Corsican";//科西嘉语
    public static final String KLINGON = "Klingon";//克林贡语
    public static final String KASHMIRI = "Kashmiri";//克什米尔语
    public static final String CORNISH = "Cornish";//康瓦尔语
    public static final String CREEK = "Creek";//克里克语
    public static final String KONKANI = "Konkani";//孔卡尼语
    public static final String KANURI = "Kanuri";//卡努里语
    public static final String XHOSA = "Xhosa";//科萨语
    public static final String QUECHUA = "Quechua";//克丘亚语
    public static final String KURDISH = "Kurdish";//库尔德语
    public static final String KURDISH_SORANI = "Kurdish_Sorani";//库尔德语(索拉尼)
    public static final String LATIN = "Latin";//拉丁语
    public static final String LATJALAI = "Latjalai";//拉特加莱语
    public static final String LINGALA = "Lingala";//林加拉语
    public static final String RUSYNIAN = "Rusynian";//卢森尼亚语
    public static final String ROMANSH = "Romansh";//罗曼什语
    public static final String LAO = "Lao";//老挝语
    public static final String LUGANDA = "Luganda";//卢干达语
    public static final String KINYARWANDA = "Kinyarwanda";//卢旺达语
    public static final String ROMANI = "Romani";//罗姆语
    public static final String LIMBURGISH = "Limburgish";//林堡语
    public static final String LIMBURGAN = "Limburgan";//林堡语
    public static final String LUXEMBOURGISH = "Luxembourgish";//卢森堡语
    public static final String LOGICAL_LANGUAGE = "Logical_language";//逻辑语
    public static final String MANKS = "Manks";//曼克斯语
    public static final String PASHTO = "Pashto";//普什图语
    public static final String MALAGASY = "Malagasy";//马拉加斯语
    public static final String MARSHALLESE = "Marshallese";//马绍尔语
    public static final String MAURITIAN_CREOLE = "Mauritian_Creole";//毛里求斯克里奥尔语
    public static final String MALTESE = "Maltese";//马耳他语
    public static final String MAORI = "Maori";//毛利语
    public static final String NEAPOLITAN = "Neapolitan";//那不勒斯语
    public static final String NEPALI = "Nepali";//尼泊尔语
    public static final String PAPIAMENTO = "Papiamento";//帕皮阿门托语
    public static final String CHICHEWA = "Chichewa";//齐切瓦语
    public static final String TWI = "Twi";//契维语
    public static final String CHEROKEE = "Cherokee";//切罗基语
    public static final String SARDINIAN = "Sardinian";//萨丁尼亚语
    public static final String SAMOAN = "Samoan";//萨摩亚语
    public static final String SONGHAI = "Songhai";//桑海语
    public static final String SWAHILI = "Swahili";//斯瓦希里语
    public static final String TUNISIAN_ARABIC = "Tunisian_Arabic";//突尼斯阿拉伯语
    public static final String SINHALA = "Sinhala";//僧伽罗语
    public static final String TAJIK = "Tajik";//塔吉克语
    public static final String TIGRINYA = "Tigrinya";//提格利尼亚语


    public static final String TURKMEN = "Turkmen";//土库曼语
    public static final String VENDA = "Venda";//文达语
    public static final String WALLOON = "Walloon";//瓦隆语
    public static final String WOLOF = "Wolof";//沃洛夫语

    public static final String LOWER_SORBIAN = "Lower_Sorbian";//下索布语
    public static final String CEBUANO = "Cebuano";//宿务语
    public static final String SILESIAN = "Silesian";//西里西亚语
    public static final String HAWAIIAN = "Hawaiian";//夏威夷语
    public static final String SINDHI = "Sindhi";//信德语
    public static final String SYRIAC = "Syriac";//叙利亚语
    public static final String HILIGANUN = "Hiliganun";//希利盖农语
    public static final String SHONA = "Shona";//修纳语
    public static final String SUNDANESE = "Sundanese";//巽他语
    public static final String INTER = "Inter";//因特语
    public static final String IGBO = "Igbo";//伊博语
    public static final String IRANIAN = "Iranian";//伊朗语
    public static final String ACEH = "Aceh";//亚齐语
    public static final String IDO = "Ido";//伊多语
    public static final String INUKTITUT = "Inuktitut";//伊努克提图特语
    public static final String YIDDISH = "Yiddish";//意第绪语
    public static final String INGUSH = "Ingush";//印古什语
    public static final String YORUBA = "Yoruba";//约鲁巴语
    public static final String ZULU = "Zulu";//祖鲁语
    public static final String ZAZAQI = "Zazaqi";//扎扎其语
    public static final String JAVANESE = "Javanese";//爪哇语
    public static final String AUTO = "Auto";//自动

    public static final String BAMBARA = "Bambara";//班巴拉

    public static final String EWE = "Ewe";//母羊
    public static final String HILIGAYNON = "Hiligaynon";//希利盖农
    public static final String KALAALLISUT = "Kalaallisut";//卡拉利苏特
    public static final String KONGO = "Kongo";//金刚
    public static final String MANX = "Manx";//Iban

    public static final String NYANJA = "Nyanja";//尼亚佳
    public static final String OJIBWA = "Ojibwa";//奥吉布瓦
    public static final String ROMANY = "Romany";//罗姆语
    public static final String SANGO = "Sango";//桑戈语
    public static final String SCOTS = "Scots";//苏格兰语
    public static final String SCOTTISH_GAELIC = "Scottish_Gaelic";//苏格兰盖尔语
    public static final String SOUTHERN_SOTHO = "Southern_Sotho";//南索托语
    public static final String TSONGA = "Tsonga";//松加语
    public static final String WESTERN_FRISIAN = "Western_Frisian";//西弗里斯兰语
    public static final String ZAPOTEC = "Zapotec";//尼扬科莱
    public static final String KAZAKH = "Kazakh";//哈萨克语
    public static final String UYGHUR = "Uyghur";//维吾尔语
    public static final String MONGOLIAN = "Mongolian ";//蒙古
    public static final String BASQUE = "Basque ";//巴斯克语
    public static final String UZBEK = "Uzbek ";//乌兹别克语
    public static final String ESPERANTO = "Esperanto ";//世界语
    public static final String FRISIAN = "Frisian";//弗里斯兰语
    public static final String KRIO = "Krio";//Krio
    public static final String SORANI = "Sorani";//Sorani
    public static final String MAITHILI = "Maithili";////迈蒂利语
    public static final String MEITEILON = "Meiteilon";//Meiteilon
    public static final String MIZO = "Mizo";//Mizo
    public static final String SEPEDI = "Sepedi";//Sepedi

    // 高优先级语言
    public static final String CANTONESE = "Cantonese";//粤语
    public static final String FIJIAN = "Fijian";//斐济语
    public static final String DZONGKHA = "Dzongkha";//不丹语

    // 中优先级语言
    public static final String BALINESE = "Balinese";//巴厘语
    public static final String NEWARI = "Newari";//尼瓦尔语
    public static final String ABKHAZIAN = "Abkhazian";//阿布哈兹语
    public static final String ACEHNESE = "Acehnese";//亚齐语
    public static final String ACHOLI = "Acholi";//阿乔利语
    public static final String ALUR = "Alur";//阿卢尔语
    public static final String AWADHI = "Awadhi";//阿瓦德语
    public static final String BATAK_TOBA = "Batak_Toba";//托巴巴塔克语
    public static final String BEMBA = "Bemba";//本巴语
    public static final String BETAWI = "Betawi";//贝塔维语
    public static final String BIKOL = "Bikol";//比科尔语
    public static final String BATAK_SIMALUNGUN = "Batak_Simalungun";//西马隆贡巴塔克语
    public static final String BATAK_KARO = "Batak_Karo";//卡罗巴塔克语
    public static final String BURYAT = "Buryat";//布里亚特语
    public static final String CHIGA = "Chiga";//奇加语
    public static final String MARI = "Mari";//马里语
    public static final String HILL_MARI = "Hill_Mari";//山地马里语
    public static final String HAKHA_CHIN = "Hakha_Chin";//哈卡钦语
    public static final String CRIMEAN_TATAR = "Crimean_Tatar";//克里米亚鞑靼语
    public static final String SEYCHELLOIS_CREOLE = "Seychellois_Creole";//塞舌尔克里奥尔语
    public static final String DINKA = "Dinka";//丁卡语
    public static final String DOMBE = "Dombe";//东贝语
    public static final String GA = "Ga";//加语
    public static final String HUNSRIK = "Hunsrik";//洪斯里克语
    public static final String LIGURIAN = "Ligurian";//利古里亚语
    public static final String LOMBARD = "Lombard";//伦巴第语
    public static final String LATGALIAN = "Latgalian";//拉特加莱语
    public static final String LUO = "Luo";//卢奥语
    public static final String MAKASAR = "Makasar";//望加锡语
    public static final String MINANGKABAU = "Minangkabau";//米南加保语
    public static final String MALAY_JAWI = "Malay_Jawi";//马来语(爪夷文)
    public static final String SOUTH_NDEBELE = "South_Ndebele";//南恩德贝莱语
    public static final String NUER = "Nuer";//努尔语
    public static final String PUNJABI_ARABIC = "Punjabi_Arabic";//旁遮普语(阿拉伯文)
    public static final String PUNJABI_SHAHMUKHI = "Punjabi_Shahmukhi";//旁遮普语(沙姆基文)
    public static final String PANGASINAN = "Pangasinan";//邦阿西楠语
    public static final String KIRUNDI = "Kirundi";//基隆迪语
    public static final String SICILIAN = "Sicilian";//西西里语
    public static final String SWATI = "Swati";//斯瓦蒂语
    public static final String TETUM = "Tetum";//德顿语
    public static final String TSWANA = "Tswana";//茨瓦纳语
    public static final String YUCATEC_MAYA = "Yucatec_Maya";//尤卡坦玛雅语

    // 低优先级语言（40个）
    public static final String AFAR = "Afar";//阿法尔语
    public static final String ADANGME = "Adangme";//阿当梅语
    public static final String AFRIKAANS_NAMIBIA = "Afrikaans_Namibia";//南非荷兰语(纳米比亚)
    public static final String AGHEM = "Aghem";//阿格姆语
    public static final String ANGIKA = "Angika";//昂加语
    public static final String ARAGONESE = "Aragonese";//阿拉贡语
    public static final String ARABIC_OMAN = "Arabic_Oman";//阿拉伯语(阿曼)
    public static final String ARABIC_YEMEN = "Arabic_Yemen";//阿拉伯语(也门)
    public static final String ASTURIAN = "Asturian";//阿斯图里亚斯语
    public static final String BASSA = "Bassa";//巴萨语
    public static final String BAVARIAN = "Bavarian";//巴伐利亚语
    public static final String BODO = "Bodo";//博多语
    public static final String BULU = "Bulu";//布鲁语
    public static final String CADDO = "Caddo";//卡多语
    public static final String CHAM = "Cham";//占语
    public static final String MAKHUWA = "Makhuwa";//马夸语
    public static final String MANIPURI_BENGALI = "Manipuri_Bengali";//曼尼普尔语(孟加拉文)
    public static final String MEADOW_MARI = "Meadow_Mari";//草原马里语
    public static final String MENDE = "Mende";//门德语
    public static final String NAHUATL = "Nahuatl";//纳瓦特尔语
    public static final String NAVAJO = "Navajo";//纳瓦霍语
    public static final String NDAU = "Ndau";//恩道语
    public static final String NKO = "Nko";//西非书面语
    public static final String NUER_ETHIOPIA = "Nuer_Ethiopia";//努尔语(埃塞俄比亚)
    public static final String NYANKOLE = "Nyankole";//尼扬科勒语
    public static final String OJIBWE = "Ojibwe";//奥吉布瓦语
    public static final String PANGWA = "Pangwa";//庞瓦语
    public static final String RUNDI = "Rundi";//隆迪语
    public static final String SAHO = "Saho";//萨霍语
    public static final String TAMAZIGHT = "Tamazight";//塔马齐格特语
    public static final String TIV = "Tiv";//蒂夫语
    public static final String TUMBUKA = "Tumbuka";//通布卡语
    public static final String ZANDE = "Zande";//赞德语

    // Additional languages from aibit missing list
    public static final String ABKHAZ = "Abkhaz";//阿布哈兹语
    public static final String AVAR = "Avar";//阿瓦尔语
    public static final String BAOULE = "Baoule";//巴乌莱语
    public static final String CHAMORRO = "Chamorro";//查莫罗语
    public static final String CHECHEN = "Chechen";//车臣语
    public static final String CHUUKESE = "Chuukese";//楚克语
    public static final String CRIMEAN_TATAR_LATIN = "Crimean_Tatar_Latin";//克里米亚鞑靼语(拉丁文)
    public static final String DARI = "Dari";//达里语
    public static final String DYULA = "Dyula";//迪乌拉语
    public static final String EASTERN_HUASTECA_NAHUATL = "Eastern_Huasteca_Nahuatl";//东华斯特卡纳瓦特尔语
    public static final String FON = "Fon";//丰语
    public static final String FRENCH_CANADA = "French_Canada";//法语(加拿大)
    public static final String FRIULIAN = "Friulian";//弗留利语
    public static final String FULA = "Fula";//富拉语
    public static final String IBAN = "Iban";//伊班语
    public static final String INUKTUT = "Inuktut";//因纽特语
    public static final String INUKTUT_LATIN = "Inuktut_Latin";//因纽特语(拉丁文)
    public static final String JAMAICAN_PATOIS = "Jamaican_Patois";//牙买加帕图瓦语
    public static final String JINGPO = "Jingpo";//景颇语
    public static final String KAPAMPANGAN = "Kapampangan";//卡帕姆潘甘语
    public static final String KEKCHI = "Kekchi";//凯克奇语
    public static final String KHASI = "Khasi";//卡西语
    public static final String KIGA = "Kiga";//基加语
    public static final String KITUBA = "Kituba";//基图巴语
    public static final String KOKBOROK = "Kokborok";//科克博罗克语
    public static final String KOMI = "Komi";//科米语
    public static final String LUBA_KASAI = "Luba_Kasai";//卢巴-卡塞语
    public static final String MADURESE = "Madurese";//马都拉语
    public static final String MAKASSAR = "Makassar";//望加锡语
    public static final String MALAY_ARABIC = "Malay_Arabic";//马来语(阿拉伯文)
    public static final String MAM = "Mam";//马姆语
    public static final String MARWARI = "Marwari";//马尔瓦里语
    public static final String PORTUGUESE_PORTUGAL = "Portuguese_Portugal";//葡萄牙语(葡萄牙)
    public static final String QEQCHI = "Qeqchi";//凯克奇语
    public static final String SAKHA = "Sakha";//萨哈语
    public static final String SAMI = "Sami";//萨米语
    public static final String SANTALI = "Santali";//桑塔利语
    public static final String SANTALI_LATIN = "Santali_Latin";//桑塔利语(拉丁文)
    public static final String SOUTHERN_NDEBELE = "Southern_Ndebele";//南恩德贝勒语
    public static final String SUSU = "Susu";//苏苏语
    public static final String TAHITIAN = "Tahitian";//塔希提语
    public static final String TAMAZIGHT_LATIN = "Tamazight_Latin";//塔马齐格特语(拉丁文)
    public static final String TIBETAN = "Tibetan";//藏语
    public static final String TOK_PISIN = "Tok_Pisin";//托克皮辛语
    public static final String TONGAN = "Tongan";//汤加语
    public static final String TULU = "Tulu";//图卢语
    public static final String TUVAN = "Tuvan";//图瓦语
    public static final String UDMURT = "Udmurt";//乌德穆尔特语
    public static final String VENETIAN = "Venetian";//威尼斯语
    public static final String WARAY = "Waray";//瓦瑞语
    public static final String ZHUANG = "Zhuang";//壮语

    // Qwen-MT 支持的阿拉伯语变体
    public static final String EGYPTIAN_ARABIC = "Egyptian_Arabic";//埃及阿拉伯语
    public static final String MESOPOTAMIAN_ARABIC = "Mesopotamian_Arabic";//美索不达米亚阿拉伯语
    public static final String MOROCCAN_ARABIC = "Moroccan_Arabic";//摩洛哥阿拉伯语
    public static final String NAJDI_ARABIC = "Najdi_Arabic";//内志阿拉伯语
    public static final String NORTH_LEVANTINE_ARABIC = "North_Levantine_Arabic";//北黎凡特阿拉伯语
    public static final String SOUTH_LEVANTINE_ARABIC = "South_Levantine_Arabic";//南黎凡特阿拉伯语
    public static final String TAIZZI_ADENI_ARABIC = "Taizzi_Adeni_Arabic";//塔伊兹-亚丁阿拉伯语

    // Qwen-MT 支持的挪威语变体
    public static final String NORWEGIAN_BOKMAL = "Norwegian_Bokmal";//挪威语(书面语)
    public static final String NORWEGIAN_NYNORSK = "Norwegian_Nynorsk";//挪威语(新挪威语)

    // Provider 新增语言与文字/地区变体（跨引擎复用）
    public static final String BAMBARA_NKO = "Bambara_Nko";//班巴拉语(西非书面文字)
    public static final String SPANISH_MEXICO = "Spanish_Mexico";//西班牙语(墨西哥)
    public static final String CHHATTISGARHI = "Chhattisgarhi";//恰蒂斯加尔语
    public static final String INUINNAQTUN = "Inuinnaqtun";//因纽因纳克顿语
    public static final String KURDISH_NORTHERN = "Kurdish_Northern";//北部库尔德语
    public static final String LITERARY_CHINESE = "Literary_Chinese";//文言文
    public static final String MONGOLIAN_CYRILLIC = "Mongolian_Cyrillic";//蒙古语(西里尔文)
    public static final String MONGOLIAN_TRADITIONAL = "Mongolian_Traditional";//蒙古语(传统文字)
    public static final String QUERETARO_OTOMI = "Queretaro_Otomi";//克雷塔罗奥托米语
    public static final String SERBIAN_LATIN = "Serbian_Latin";//塞尔维亚语(拉丁文)
    public static final String SERBIAN_CYRILLIC = "Serbian_Cyrillic";//塞尔维亚语(西里尔文)
    public static final String KLINGON_PIQAD = "Klingon_Piqad";//克林贡语(pIqaD文字)
    public static final String OLD_ENGLISH = "Old_English";//古英语
    public static final String MIDDLE_FRENCH = "Middle_French";//中古法语
    public static final String LOW_GERMAN = "Low_German";//低地德语
    public static final String SERBO_CROATIAN = "Serbo_Croatian";//塞尔维亚-克罗地亚语

    public static final List<String> COMMON_LANGUAGE_IDS = Collections.unmodifiableList(
            Arrays.asList(AUTO, ENGLISH, CHINESE, TRADITIONAL_CHINESE, JAPANESE, FRENCH,
                    KOREAN, RUSSIAN, GERMAN, THAI, FILIPINO, VIETNAMESE, INDONESIAN,
                    ARABIC));

    private LanguageConstant() { }
}
