package com.mg.translation.sdk;

/** 一次引擎选择操作对当前运行时产生的最终结果。 */
public enum EngineSelectionOutcome {
    APPLIED,
    UNCHANGED,
    REJECTED
}
