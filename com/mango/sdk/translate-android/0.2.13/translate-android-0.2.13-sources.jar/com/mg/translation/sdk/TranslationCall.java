package com.mg.translation.sdk;

/** One subscription. Cancellation suppresses delivery and cancels I/O when no subscribers remain. */
public interface TranslationCall {
    void cancel();
    boolean isCancelled();
}
