package com.mg.translation.sdk;

import androidx.annotation.DrawableRes;

import com.mg.translation.engine.EngineCategory;

/** App 可展示的不可变翻译引擎信息；id 始终是 SDK 权威整数 Legacy Code。 */
public final class TranslationEngineInfo {
    private final int id;
    private final String name;
    private final String description;
    private final int iconRes;
    private final EngineCategory category;
    private final boolean vipOnly;
    private final boolean locked;
    private final boolean ai;
    private final boolean slow;
    private final boolean supportsAutoSource;

    TranslationEngineInfo(int id, String name, String description, @DrawableRes int iconRes,
                          EngineCategory category,
                          boolean vipOnly, boolean locked, boolean ai, boolean slow,
                          boolean supportsAutoSource) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.iconRes = iconRes;
        this.category = category;
        this.vipOnly = vipOnly;
        this.locked = locked;
        this.ai = ai;
        this.slow = slow;
        this.supportsAutoSource = supportsAutoSource;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    @DrawableRes public int getIconRes() { return iconRes; }
    public EngineCategory getCategory() { return category; }
    public boolean isVipOnly() { return vipOnly; }
    public boolean isLocked() { return locked; }
    public boolean isAi() { return ai; }
    public boolean isSlow() { return slow; }
    public boolean supportsAutoSource() { return supportsAutoSource; }
}
