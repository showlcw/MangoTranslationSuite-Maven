package com.mg.translation.sdk;

/** Immutable, user-safe translation failure information. */
public final class TranslationError {
    private final int code;
    private final TranslationErrorCategory category;
    private final String message;
    private final int engineId;
    private final int providerCode;
    private final boolean retryable;
    private final boolean purchaseRequired;

    public TranslationError(int code, TranslationErrorCategory category, String message,
                            int engineId, int providerCode, boolean retryable,
                            boolean purchaseRequired) {
        if (code <= 0) throw new IllegalArgumentException("code must be positive");
        if (category == null) throw new IllegalArgumentException("category is required");
        if (message == null || message.trim().isEmpty()) {
            throw new IllegalArgumentException("message is required");
        }
        this.code = code;
        this.category = category;
        this.message = message;
        this.engineId = engineId;
        this.providerCode = providerCode;
        this.retryable = retryable;
        this.purchaseRequired = purchaseRequired;
    }

    public int getCode() { return code; }
    public TranslationErrorCategory getCategory() { return category; }
    public String getMessage() { return message; }
    public int getEngineId() { return engineId; }
    /** Original Provider error code; zero when no upstream call was made. */
    public int getProviderCode() { return providerCode; }
    public boolean isRetryable() { return retryable; }
    public boolean isPurchaseRequired() { return purchaseRequired; }

    /** Suggested UI or recovery action; Apps may adapt it to their own navigation. */
    public TranslationErrorAction getSuggestedAction() {
        switch (code) {
            case TranslationErrorCode.INVALID_REQUEST:
                return TranslationErrorAction.CORRECT_REQUEST;
            case TranslationErrorCode.SDK_NOT_INITIALIZED:
                return TranslationErrorAction.INITIALIZE_SDK;
            case TranslationErrorCode.ENGINE_NOT_CONFIGURED:
            case TranslationErrorCode.ENGINE_RETIRED:
            case TranslationErrorCode.UNSUPPORTED_LANGUAGE:
                return TranslationErrorAction.SELECT_ANOTHER_ENGINE;
            case TranslationErrorCode.VIP_REQUIRED:
            case TranslationErrorCode.QUOTA_EXHAUSTED:
                return TranslationErrorAction.PURCHASE_MEMBERSHIP;
            case TranslationErrorCode.NETWORK_UNAVAILABLE:
                return TranslationErrorAction.CHECK_NETWORK;
            case TranslationErrorCode.REQUEST_TIMEOUT:
            case TranslationErrorCode.RATE_LIMITED:
            case TranslationErrorCode.PROVIDER_UNAVAILABLE:
            case TranslationErrorCode.INVALID_PROVIDER_RESPONSE:
            case TranslationErrorCode.ALL_ENGINES_FAILED:
                return TranslationErrorAction.RETRY;
            case TranslationErrorCode.PROVIDER_AUTHENTICATION_FAILED:
                return TranslationErrorAction.CONTACT_SUPPORT;
            default:
                return TranslationErrorAction.NONE;
        }
    }
}
