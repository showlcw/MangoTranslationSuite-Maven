package com.mg.translation.sdk;

/** Recommended App response to a translation failure. */
public enum TranslationErrorAction {
    CORRECT_REQUEST,
    INITIALIZE_SDK,
    SELECT_ANOTHER_ENGINE,
    PURCHASE_MEMBERSHIP,
    CHECK_NETWORK,
    RETRY,
    CONTACT_SUPPORT,
    NONE
}
