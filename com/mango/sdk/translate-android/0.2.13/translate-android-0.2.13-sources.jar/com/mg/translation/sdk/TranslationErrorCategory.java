package com.mg.translation.sdk;

public enum TranslationErrorCategory {
    VALIDATION,
    SDK_STATE,
    CONFIGURATION,
    LANGUAGE,
    ENTITLEMENT,
    QUOTA,
    NETWORK,
    PROVIDER,
    CANCELLED,
    UNKNOWN
}
