package com.mg.translation.sdk;

/** Stable public error codes returned by translation callbacks. */
public final class TranslationErrorCode {
    public static final int INVALID_REQUEST = 1000;
    public static final int SDK_NOT_INITIALIZED = 1001;
    public static final int ENGINE_NOT_CONFIGURED = 1002;
    public static final int ENGINE_RETIRED = 1003;
    public static final int UNSUPPORTED_LANGUAGE = 1004;

    public static final int VIP_REQUIRED = 2001;
    public static final int QUOTA_EXHAUSTED = 2003;

    public static final int NETWORK_UNAVAILABLE = 3001;
    public static final int REQUEST_TIMEOUT = 3002;
    public static final int RATE_LIMITED = 3003;

    public static final int PROVIDER_AUTHENTICATION_FAILED = 4001;
    public static final int PROVIDER_UNAVAILABLE = 4002;
    public static final int INVALID_PROVIDER_RESPONSE = 4003;
    public static final int ALL_ENGINES_FAILED = 4004;

    public static final int CANCELLED = 5001;
    public static final int UNKNOWN = 9000;

    private TranslationErrorCode() { }
}
