package com.mg.translation.sdk;

/**
 * 翻译 SDK 向宿主 App 请求的最小能力集合。
 *
 * <p>这里不能出现任何单个翻译引擎的实现方法。智谱、Google、百度、RapidAPI 等
 * Provider 的协议都由 SDK 内对应 Translator 负责，App 不重复对接。</p>
 */
public interface TranslationHost {

    /**
     * 返回由 App 持有的翻译凭据解密器。
     *
     * <p>SDK 会逐条把 {@code engines[].keys[]} 中的密文交给它。实现方必须复用 App
     * 已有的 native/受保护解密流程；不能把 App 的原始 AES Key 返回或保存到 SDK。</p>
     */
    CredentialDecryptor getCredentialDecryptor();

    /**
     * 校验当前运行包名/签名是否与 App 受保护身份一致。
     *
     * <p>该能力用于替代“把正确签名字符串暴露给 SDK”。native 保护层不可用或检测到
     * 二次打包时返回 {@code false}。</p>
     */
    boolean isAppIdentityValid();

    /**
     * 返回用户当前实时会员状态；SDK 不缓存或持久化该状态。
     */
    boolean isVip();

    /**
     * 标识当前构建是否按“可直连 Google 服务”的渠道处理。
     * 保留 Voice 原有国内/海外构建分流规则；未覆盖时默认 {@code true}。
     */
    default boolean isGoogleBuild() { return true; }

    /** 宿主可额外否决 Google 免费直连；每次请求读取，必须快速返回缓存探测结果。
     * 默认沿用构建标记；即使返回 true，SDK 仍要求自己的异步探测确认可达。
     * 返回 false 时 SDK 直接跳过该通道和探测；宿主未知时应返回渠道能力值，交给 SDK 探测。
     */
    default boolean isGoogleReachable() { return isGoogleBuild(); }

    /** 路由元数据，不含 URL、凭据或翻译内容。reason: cooldown/gate/vip/not_configured/unreachable。 */
    default void onEngineSkipped(int engineId, String reason) { }

    /** 本次请求切换引擎，不改变用户保存的选择。 */
    default void onFallback(int fromEngineId, int toEngineId) { }

    /** 可选元数据事件钩子；事件不包含凭据、原文、译文或 Provider 响应。 */
    default void onEvent(String eventId) { }

    /** Per self-hosted HTTP attempt, on an OkHttp thread. Keep this callback fast.
     * Outcomes: http_success, http_error, timeout, cancelled, network_error.
     * http_success does not assert business/translation success. HTTP status is 0 when unavailable.
     * No credentials, request/response text or URL are included.
     */
    default void onRequestFinished(int engineId, String outcome, long durationMs, int httpStatus) {
        onEvent("self_hosted_http_" + outcome);
    }

    /** Transport phases for translation/preconnect/probe. No URL, text or credentials. Keep fast. */
    default void onNetworkRequestFinished(TranslationNetworkTiming timing) { }

    /** One public subscription, measured to main-thread delivery. source: network/merged/cache.
     * queueMs is SDK scheduling delay; callbackWaitMs is main-thread wait. Metadata only.
     */
    default void onTranslationFinished(long requestId, long chainId, int engineId, String outcome, String source,
            long queueMs, long callbackWaitMs, long totalMs) { }

    /** Per Provider attempt, measured around the SDK request stream.
     * Outcomes: response, http_error, timeout, cancelled, network_error, error, and
     * preconnect_* variants for connection warm-up and probe_* for Google reachability checks.
     * This callback contains no URL, credential, source text, translation or response body.
     * HTTP status is 0 when the transport did not expose one. Delivered asynchronously on a
     * dedicated metadata worker with a 256-event waiting queue. Events may be dropped under
     * overload; translation and cancellation never wait for this observer. Implementations
     * must still return quickly to avoid delaying other metadata events.
     */
    default void onProviderAttemptFinished(
            int engineId, String outcome, long durationMs, int httpStatus) {
        // Opt-in only: existing onEvent implementations must not receive new per-request volume.
    }
}
