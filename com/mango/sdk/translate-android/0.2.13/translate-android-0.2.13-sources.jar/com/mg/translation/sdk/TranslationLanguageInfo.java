package com.mg.translation.sdk;

/** 某个具体 Translator 的不可变语言快照，不对语言标识或 Provider code 做转换。 */
public final class TranslationLanguageInfo {
    private final String languageId;
    private final String selectionId;
    private final String displayName;
    private final String providerCode;
    private final String variantDisplayName;

    TranslationLanguageInfo(String languageId, String selectionId, String displayName,
                            String providerCode, String variantDisplayName) {
        this.languageId = languageId;
        this.selectionId = selectionId;
        this.displayName = displayName;
        this.providerCode = providerCode;
        this.variantDisplayName = variantDisplayName;
    }

    /** Voice LanguageVO.key：软件统一保存和查询使用的语言标识。 */
    public String getLanguageId() { return languageId; }

    /** Voice UI 原选择值；没有区域变体时与 languageId 相同。 */
    public String getSelectionId() { return selectionId; }

    public String getDisplayName() { return displayName; }

    /** 当前 Translator 自己的上游语言 code，只读且不得跨引擎复用。 */
    public String getProviderCode() { return providerCode; }

    public String getVariantDisplayName() { return variantDisplayName; }
}
