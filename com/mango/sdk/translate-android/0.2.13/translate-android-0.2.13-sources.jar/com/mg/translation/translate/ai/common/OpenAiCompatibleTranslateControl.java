package com.mg.translation.translate.ai.common;

import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.http.ai.OpenAiChatMessage;
import com.mg.translation.http.ai.OpenAiChatRequest;
import com.mg.translation.http.ai.OpenAiChatResponse;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * Brand-neutral execution for engines using an OpenAI-compatible chat endpoint.
 * Provider classes own identity, languages and prompt placement; no Provider extends another.
 */
public abstract class OpenAiCompatibleTranslateControl extends BaseTranslateControl {
    public enum PromptPlacement { SYSTEM, USER_PREFIX }

    private final Context context;
    private final TranslatorId engineId;
    private final String displayName;
    private final String fallbackModel;
    private final PromptPlacement promptPlacement;
    private final List<LanguageVO> supportedLanguages;

    protected OpenAiCompatibleTranslateControl(Context context, TranslatorId engineId,
                                               String displayName, String fallbackModel,
                                               PromptPlacement promptPlacement,
                                               List<LanguageVO> supportedLanguages) {
        if (context == null || engineId == null || displayName == null
                || promptPlacement == null || supportedLanguages == null) {
            throw new IllegalArgumentException("AI translation engine configuration is required");
        }
        this.context = context;
        this.engineId = engineId;
        this.displayName = displayName;
        this.fallbackModel = fallbackModel;
        this.promptPlacement = promptPlacement;
        this.supportedLanguages = supportedLanguages;
    }

    @Override
    public final void translate(TranslationTask task, TranslateListener listener) {
        if (listener == null || task == null) return;
        if (TranslationSdk.isVipOnly(getTranslateType()) && !TranslateUtils.isVip(context)) {
            listener.onFail(TranslationErrorCode.VIP_REQUIRED,
                    context.getString(R.string.translation_error_vip_required));
            return;
        }
        if (task instanceof BatchTranslationTask) {
            translateBatch((BatchTranslationTask) task, listener);
        } else {
            translateSingle(task, listener);
        }
    }

    private void translateSingle(TranslationTask task, TranslateListener listener) {
        if (TextUtils.isEmpty(task.getContent())) {
            listener.onSuccess(task, getTranslateType(), false);
            return;
        }
        BaseReq request = createBaseReq(task.getContent(), task.getSourceLanguageId(),
                task.getTargetLanguageId());
        if (request == null) {
            dealTranslateError(context, task, listener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().openAiChatTranslate(
                context, engineId.legacyCode, request), response -> {
            String content = firstContent(response);
            if (TextUtils.isEmpty(content)) {
                dealTranslateError(context, task, listener);
                return;
            }
            task.setTranslatedText(content);
            listener.onSuccess(task, getTranslateType(), false);
        }, () -> dealTranslateError(context, task, listener));
    }

    private synchronized void translateBatch(BatchTranslationTask task,
                                              TranslateListener listener) {
        List<String> sourceTexts = task.getSourceTexts();
        BaseReq request = createBatchRequest(copy(sourceTexts),
                task.getTargetLanguageId());
        if (request == null) {
            dealTranslateError(context, task, listener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().openAiChatTranslate(
                context, engineId.legacyCode, request), response -> {
            String content = firstContent(response);
            if (TextUtils.isEmpty(content)) {
                dealTranslateError(context, task, listener);
                return;
            }
            try {
                JSONArray translations = new JSONArray(content.trim());
                if (translations.length() != sourceTexts.size()) {
                    dealTranslateError(context, task, listener);
                    return;
                }
                for (int index = 0; index < translations.length(); index++) {
                    task.setTranslation(index, translations.getString(index));
                }
                listener.onSuccess(task, getTranslateType(), true);
            } catch (Exception invalidResponse) {
                dealTranslateError(context, task, listener);
            }
        }, () -> dealTranslateError(context, task, listener));
    }

    @Override
    public final BaseReq createBaseReq(String content, String source, String target) {
        String targetCode = targetCode(target);
        if (targetCode == null) return null;
        String instruction = singleInstruction(targetCode);
        List<OpenAiChatMessage> messages = new ArrayList<>();
        if (promptPlacement == PromptPlacement.SYSTEM) {
            messages.add(new OpenAiChatMessage("system", instruction));
            messages.add(new OpenAiChatMessage("user", content));
        } else {
            messages.add(new OpenAiChatMessage("user", instruction + "\n\n" + content));
        }
        return request(messages);
    }

    private BaseReq createBatchRequest(List<String> sourceTexts, String target) {
        String targetCode = targetCode(target);
        if (targetCode == null) return null;
        String instruction = batchInstruction(targetCode);
        String payload = GsonUtil.toJson(sourceTexts);
        List<OpenAiChatMessage> messages = new ArrayList<>();
        if (promptPlacement == PromptPlacement.SYSTEM) {
            messages.add(new OpenAiChatMessage("system", instruction));
            messages.add(new OpenAiChatMessage("user", payload));
        } else {
            messages.add(new OpenAiChatMessage("user", instruction + "\n\n" + payload));
        }
        return request(messages);
    }

    private OpenAiChatRequest request(List<OpenAiChatMessage> messages) {
        OpenAiChatRequest request = new OpenAiChatRequest(messages);
        if (!TextUtils.isEmpty(fallbackModel)) request.setModel(fallbackModel);
        return request;
    }

    private String targetCode(String targetLanguageId) {
        LanguageVO language = getSelectLanguageVO(targetLanguageId, false);
        return language == null ? null : language.getValue();
    }

    protected String singleInstruction(String targetCode) {
        return "Translate the user input to language code " + targetCode
                + ". Preserve meaning, formatting, punctuation, line breaks and terminology. "
                + "Return only the translation.";
    }

    protected String batchInstruction(String targetCode) {
        return "Translate every item in the JSON array to language code " + targetCode
                + ". Preserve array order and length. Return only a valid JSON array.";
    }

    private String firstContent(OpenAiChatResponse response) {
        if (response == null || response.getCode() != 0 || response.getChoices() == null
                || response.getChoices().isEmpty() || response.getChoices().get(0) == null
                || response.getChoices().get(0).getMessage() == null) {
            return null;
        }
        return response.getChoices().get(0).getMessage().getContent();
    }

    @Override
    public final List<LanguageVO> getSupportLanguage() { return supportedLanguages; }

    @Override
    public final String getTranslateTypeName() { return displayName; }

    @Override
    public final int getTranslateType() { return engineId.legacyCode; }
}
