package com.mg.translation.translate.baidu;

/** Internal segment used only while reconciling Baidu batch responses. */
final class BaiduTranslationSegment {
    private String sourceText;
    private String translatedText;

    BaiduTranslationSegment() {
    }

    BaiduTranslationSegment(String sourceText) {
        this.sourceText = sourceText;
    }

    String getSourceText() {
        return sourceText;
    }

    void setSourceText(String sourceText) {
        this.sourceText = sourceText;
    }

    String getTranslatedText() {
        return translatedText;
    }

    void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

}
