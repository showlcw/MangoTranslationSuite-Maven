package com.mg.translation.translate.base;

import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.internal.model.TranslationTask;

import java.util.List;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/6 18:35
 */
public interface TranslateControl {

    void translate(TranslationTask task, TranslateListener translateListener);

    /** Provider request construction hook used by concrete engines. */
    default BaseReq createBaseReq(String content, String source, String to) {
        return null;
    }

    /**
     * 获取支持的语音
     *
     * @return
     */
    default List<LanguageVO> getSupportLanguage() {
        return java.util.Collections.emptyList();
    }

    int getIndexByLanguage(String language, boolean isSetDefault);

    void close();

    LanguageVO getSelectLanguageVO(String country, boolean isSetDefault);

    String getTranslateTypeName();

    int getTranslateType();

    /**
     * 是否支持自动模式
     *
     * @return true 支持  false 不支持
     */
    boolean isSupportAuto();
}
