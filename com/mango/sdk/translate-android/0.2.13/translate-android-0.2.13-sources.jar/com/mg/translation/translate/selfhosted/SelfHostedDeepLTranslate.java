package com.mg.translation.translate.selfhosted;

import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;
import com.mg.translation.http.translate.common.dto.MeTranslateReq;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.runtime.TranslationTelemetry;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;
import com.mg.translation.utils.TranslationPreferenceKeys;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Self-hosted DeepL web translation. Language IDs, labels and Provider codes are owned here. */
public class SelfHostedDeepLTranslate extends BaseTranslateControl {
    private final Context context;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    public SelfHostedDeepLTranslate(Context context) { this.context = context; }

    @Override
    public void translate(TranslationTask task, TranslateListener listener) {
        if (listener == null || task == null) return;
        if (!TranslateUtils.getSelfHostedDeepLApiState(context)) {
            dealTranslateError(context, task, listener);
            return;
        }
        TranslationTelemetry.event("self_hosted_deepl_translate_request");
        if (task instanceof BatchTranslationTask) {
            translateBatch((BatchTranslationTask) task, listener);
        } else {
            translateSingle(task, listener);
        }
    }

    private void translateBatch(BatchTranslationTask task, TranslateListener listener) {
        List<String> sourceTexts = task.getSourceTexts();
        List<String> texts = copy(sourceTexts);
        executeRequest(TranslateRepository.getInstance().selfHostedDeepLTranslate(
                createGatewayRequest(texts, task.getSourceLanguageId(), task.getTargetLanguageId())), result -> {
            String[] translated = successTexts(result, sourceTexts.size());
            if (translated == null) {
                handleFailure(task, listener);
                return;
            }
            for (int i = 0; i < translated.length; i++) task.setTranslation(i, translated[i]);
            listener.onSuccess(task, getTranslateType(), true);
        }, () -> handleFailure(task, listener));
    }

    private void translateSingle(TranslationTask task, TranslateListener listener) {
        if (TextUtils.isEmpty(task.getContent())) {
            listener.onSuccess(task, getTranslateType(), false);
            return;
        }
        List<String> texts = new ArrayList<>();
        Collections.addAll(texts, task.getContent().split("\n"));
        executeRequest(TranslateRepository.getInstance().selfHostedDeepLTranslate(
                createGatewayRequest(texts, task.getSourceLanguageId(), task.getTargetLanguageId())), result -> {
            String[] translated = successTexts(result, texts.size());
            if (translated == null) {
                handleFailure(task, listener);
                return;
            }
            task.setTranslatedText(TextUtils.join("\n", translated));
            listener.onSuccess(task, getTranslateType(), false);
        }, () -> handleFailure(task, listener));
    }

    private String[] successTexts(MeTranslateHttpResult result, int expectedSize) {
        if (result == null || !result.isSuccess() || result.getTexts() == null
                || result.getTexts().length != expectedSize) return null;
        return result.getTexts();
    }

    private void handleFailure(TranslationTask task, TranslateListener listener) {
        SdkPreferences.getInstance(context).put(
                TranslationPreferenceKeys.SELF_HOSTED_DEEPL_TRANSLATE_STATE,
                System.currentTimeMillis());
        dealTranslateError(context, task, listener);
    }

    private MeTranslateReq createGatewayRequest(List<String> texts, String sourceId,
                                                String targetId) {
        MeTranslateReq request = new MeTranslateReq();
        LanguageVO target = getSelectLanguageVO(targetId, false);
        if (target != null) request.setTl(target.getValue());
        if (sourceId == null || LanguageConstant.AUTO.equals(sourceId)) {
            request.setFl("auto");
        } else {
            LanguageVO source = getSelectLanguageVO(sourceId, false);
            request.setFl(source == null ? "auto" : source.getValue());
        }
        request.setQ(texts.toArray(new String[0]));
        return request;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String target) {
        return createGatewayRequest(Collections.singletonList(content), source, target);
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguages();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }

    private void initLanguages() {
        mDestLanguageList = new ArrayList<>();
        add(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-Hans");
        add(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh-Hant");
        add(LanguageConstant.ENGLISH, R.string.language_English, "en-US");
        add(LanguageConstant.ARABIC, R.string.language_Arabic, "ar");
        add(LanguageConstant.BULGARIAN, R.string.language_Bulgaria, "bg");
        add(LanguageConstant.CZECH, R.string.language_Czech, "cs");
        add(LanguageConstant.DANISH, R.string.language_Danish, "da");
        add(LanguageConstant.GERMAN, R.string.language_German, "de");
        add(LanguageConstant.GREEK, R.string.language_Greek, "el");
        add(LanguageConstant.SPANISH, R.string.language_Spanish, "es");
        add(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et");
        add(LanguageConstant.FINNISH, R.string.language_Finnish, "fi");
        add(LanguageConstant.FRENCH, R.string.language_French, "fr");
        add(LanguageConstant.HEBREW, R.string.language_Hebrew, "he");
        add(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu");
        add(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id");
        add(LanguageConstant.ITALIAN, R.string.language_Italian, "it");
        add(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja");
        add(LanguageConstant.KOREAN, R.string.language_Korean, "ko");
        add(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt");
        add(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv");
        add(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "nb");
        add(LanguageConstant.DUTCH, R.string.language_Dutch, "nl");
        add(LanguageConstant.POLISH, R.string.language_Polish, "pl");
        add(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese, "pt-BR");
        add(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt-PT");
        add(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro");
        add(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru");
        add(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk");
        add(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl");
        add(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv");
        add(LanguageConstant.THAI, R.string.language_Thai, "th");
        add(LanguageConstant.TURKISH, R.string.language_Turkish, "tr");
        add(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk");
        add(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi");
    }

    private void add(String id, int label, String providerCode) {
        mDestLanguageList.add(new LanguageVO(id, label, providerCode));
    }

    @Override public String getTranslateTypeName() {
        return context.getString(R.string.brand_deepl_translate);
    }
    @Override public int getTranslateType() { return TranslatorId.SELF_HOSTED_DEEPL.legacyCode; }
}
