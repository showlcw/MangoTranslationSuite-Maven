package com.mg.translation.http.translate.common.dto;


/**
 * Created by Shurrik on 2017/11/22.
 */

public class MeTranslateHttpResult {

    private int code;

    private String[] texts;
    private String errorMessage;
    private String msg;
    private String failureOrigin;
    private Integer providerCode;
    private String failureClass;


    public int getCode() {
        return code;
    }

    public String getErrorMessage() {
        return errorMessage != null ? errorMessage : msg;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String[] getTexts() {
        return texts;
    }

    public void setTexts(String[] texts) {
        this.texts = texts;
    }

    public String getFailureOrigin() { return failureOrigin; }
    public Integer getProviderCode() { return providerCode; }
    public String getFailureClass() { return failureClass; }

    public boolean isSuccess() {
        return code == 200;
    }

}
