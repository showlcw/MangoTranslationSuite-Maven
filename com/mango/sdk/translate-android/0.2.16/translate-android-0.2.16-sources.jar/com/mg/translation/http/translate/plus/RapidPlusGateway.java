package com.mg.translation.http.translate.plus;


import android.content.Context;

import com.mg.translation.http.ApiServiceCenter;
import com.mg.translation.http.translate.plus.dto.PlusBatchTranslateResult;
import com.mg.translation.http.translate.plus.dto.PlusTranslateResult;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.runtime.TranslationRuntime;

import io.reactivex.Single;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/** Owns the RapidAPI Translate Plus wire protocol and failure cooldown. */
public final class RapidPlusGateway {
    private static final String RAPID_API_HOST = "translate-plus.p.rapidapi.com";
    private static final RapidPlusGateway INSTANCE = new RapidPlusGateway();

    private RapidPlusGateway() { }

    public static RapidPlusGateway getInstance() {
        return INSTANCE;
    }

    public Single<PlusBatchTranslateResult> translateBatch(Context context, BaseReq request) {
        return ApiServiceCenter.getInstance().getPlusTranslateService()
                .plusBatchTranslate(RAPID_API_HOST, TranslationRuntime.get().plusRapidKey(),
                        "application/json", jsonBody(request))
                .doOnError(com.mg.translation.internal.runtime.ProviderFailurePolicy.observeAttempt(
                        com.mg.translation.engine.TranslatorId.RAPID_PLUS.legacyCode));
    }

    public Single<PlusTranslateResult> translate(Context context, BaseReq request) {
        return ApiServiceCenter.getInstance().getPlusTranslateService()
                .plusTranslate(RAPID_API_HOST, TranslationRuntime.get().plusRapidKey(),
                        "application/json", jsonBody(request))
                .doOnError(com.mg.translation.internal.runtime.ProviderFailurePolicy.observeAttempt(
                        com.mg.translation.engine.TranslatorId.RAPID_PLUS.legacyCode));
    }

    private RequestBody jsonBody(BaseReq request) {
        return RequestBody.create(MediaType.parse("application/json"), GsonUtil.toJson(request));
    }

}
