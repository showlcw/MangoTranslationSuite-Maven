package com.mg.translation.http.translate.websiteplus;


import android.content.Context;

import com.mg.translation.http.ApiServiceCenter;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateResult;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusTranslateResult;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.runtime.TranslationRuntime;

import io.reactivex.Single;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/** Owns the WebsitePlus wire request, credential access and failure cooldown. */
public final class WebsitePlusGateway {
    private static final WebsitePlusGateway INSTANCE = new WebsitePlusGateway();

    private WebsitePlusGateway() { }

    public static WebsitePlusGateway getInstance() {
        return INSTANCE;
    }

    public Single<WebsitePlusBatchTranslateResult> translateBatch(
            Context context, BaseReq request) {
        RequestBody body = jsonBody(request);
        return ApiServiceCenter.getInstance().getWebSitePlusTranslateService()
                .websitePlusBatchTranslate(TranslationRuntime.get().websitePlusKey(),
                        "application/json", body)
                .doOnError(com.mg.translation.internal.runtime.ProviderFailurePolicy.observeAttempt(
                        com.mg.translation.engine.TranslatorId.RAPID_WEBSITE_PLUS.legacyCode));
    }

    public Single<WebsitePlusTranslateResult> translate(Context context, BaseReq request) {
        RequestBody body = jsonBody(request);
        return ApiServiceCenter.getInstance().getWebSitePlusTranslateService()
                .websitePlusTranslate(TranslationRuntime.get().websitePlusKey(),
                        "application/json", body)
                .doOnError(com.mg.translation.internal.runtime.ProviderFailurePolicy.observeAttempt(
                        com.mg.translation.engine.TranslatorId.RAPID_WEBSITE_PLUS.legacyCode));
    }

    private RequestBody jsonBody(BaseReq request) {
        return RequestBody.create(MediaType.parse("application/json"), GsonUtil.toJson(request));
    }

}
