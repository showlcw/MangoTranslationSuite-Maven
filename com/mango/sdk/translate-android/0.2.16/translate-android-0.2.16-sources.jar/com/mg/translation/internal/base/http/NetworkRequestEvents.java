package com.mg.translation.internal.base.http;

import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.sdk.TranslationHost;
import com.mg.translation.sdk.TranslationNetworkTiming;
import okhttp3.*;
import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Shared by probes, preconnect and all SDK transports, so the same socket has the same ID. */
class NetworkRequestEvents extends okhttp3.EventListener {
    private static final Map<Connection, Long> CONNECTIONS = new WeakHashMap<>();
    private static final AtomicLong NEXT_CONNECTION = new AtomicLong();
    private final TranslationHost host;
    private final String purpose;
    private final long chainId = RequestContext.trace();
    protected int engineId;
    private long start, dnsStart, connectStart, tlsStart, sent, bodyStart;
    private long dns = -1, connect = -1, tls = -1, wait = -1, body = -1, acquired = -1, connectionId;
    private boolean reused, reported;
    private int attempts, status;

    NetworkRequestEvents(int engineId, String purpose) {
        this(engineId, purpose, currentHost());
    }
    NetworkRequestEvents(int engineId, String purpose, TranslationHost host) {
        this.engineId = engineId; this.purpose = purpose;
        this.host = host;
    }
    private static TranslationHost currentHost() {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        return runtime == null ? null : runtime.host();
    }
    static NetworkRequestEvents translation() {
        Integer engine = RequestContext.engine();
        return new NetworkRequestEvents(engine == null ? -1 : engine, "translation");
    }
    @Override public void callStart(Call call) { start = System.nanoTime(); }
    @Override public void dnsStart(Call call, String domain) { dnsStart = System.nanoTime(); }
    @Override public void dnsEnd(Call call, String domain, List<InetAddress> addresses) {
        dns = add(dns, dnsStart); dnsStart = 0;
    }
    @Override public void connectStart(Call call, InetSocketAddress address, Proxy proxy) {
        attempts++; connectStart = System.nanoTime();
    }
    @Override public void secureConnectStart(Call call) { tlsStart = System.nanoTime(); }
    @Override public void secureConnectEnd(Call call, Handshake handshake) {
        tls = add(tls, tlsStart); tlsStart = 0;
    }
    @Override public void connectEnd(Call call, InetSocketAddress address, Proxy proxy, Protocol protocol) {
        connect = add(connect, connectStart); connectStart = 0;
    }
    @Override public void connectFailed(Call call, InetSocketAddress address, Proxy proxy, Protocol protocol, IOException error) {
        connect = add(connect, connectStart); connectStart = 0;
        if (tlsStart != 0) { tls = add(tls, tlsStart); tlsStart = 0; }
    }
    @Override public void connectionAcquired(Call call, Connection connection) {
        acquired = elapsed(start);
        synchronized (CONNECTIONS) {
            Long existing = CONNECTIONS.get(connection);
            reused = existing != null;
            if (existing == null) { existing = NEXT_CONNECTION.incrementAndGet(); CONNECTIONS.put(connection, existing); }
            connectionId = existing;
        }
    }
    @Override public void requestHeadersEnd(Call call, Request request) { sent = System.nanoTime(); }
    @Override public void requestBodyEnd(Call call, long byteCount) { sent = System.nanoTime(); }
    @Override public void responseHeadersStart(Call call) { if (sent != 0) wait = elapsed(sent); }
    @Override public void responseHeadersEnd(Call call, Response response) { status = response.code(); }
    @Override public void responseBodyStart(Call call) { bodyStart = System.nanoTime(); }
    @Override public void responseBodyEnd(Call call, long byteCount) { body = add(body, bodyStart); bodyStart = 0; }
    @Override public void callEnd(Call call) { report(status >= 400 ? "http_error" : "http_success"); }
    @Override public void callFailed(Call call, IOException error) { report(SelfHostedRequestEvents.classify(error, call.isCanceled())); }
    private synchronized void report(String outcome) {
        if (reported) return;
        reported = true;
        if (dnsStart != 0) dns = add(dns, dnsStart);
        if (connectStart != 0) connect = add(connect, connectStart);
        if (tlsStart != 0) tls = add(tls, tlsStart);
        if (bodyStart != 0) body = add(body, bodyStart);
        if (host != null) {
            try { host.onNetworkRequestFinished(new TranslationNetworkTiming(chainId, engineId, purpose, outcome, status,
                    elapsed(start), acquired, dns, connect, tls, wait, body, connectionId, reused, attempts)); }
            catch (RuntimeException ignored) { }
        }
    }
    private static long elapsed(long start) { return (System.nanoTime() - start) / 1_000_000L; }
    private static long add(long accumulated, long start) { return start == 0 ? accumulated : Math.max(0, accumulated) + elapsed(start); }
}
