package com.mg.translation.internal.base.http;

/** Scoped only around Retrofit subscription/newCall; never carries text or credentials. */
public final class RequestContext {
    private static final String PROCESS_TRACE_PREFIX =
            java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    private static final ThreadLocal<Integer> ENGINE = new ThreadLocal<>();
    private static final ThreadLocal<Long> DEADLINE = new ThreadLocal<>();
    private static final ThreadLocal<Long> TRACE = new ThreadLocal<>();
    private static final ThreadLocal<Boolean> EMERGENCY = new ThreadLocal<>();
    private RequestContext() { }
    public static Integer engine() { return ENGINE.get(); }
    public static void set(Integer engine) { if (engine == null) ENGINE.remove(); else ENGINE.set(engine); }
    public static long deadline() { Long value = DEADLINE.get(); return value == null ? Long.MAX_VALUE : value; }
    public static long trace() { Long value = TRACE.get(); return value == null ? 0 : value; }
    public static String correlationId() {
        long value = trace();
        return value == 0L ? "" : PROCESS_TRACE_PREFIX + "-" + Long.toUnsignedString(value, 36);
    }
    public static boolean emergency() { return Boolean.TRUE.equals(EMERGENCY.get()); }
    public static void withEmergency(boolean emergency, Runnable action) {
        Boolean previous = EMERGENCY.get();
        if (emergency) EMERGENCY.set(true); else EMERGENCY.remove();
        try { action.run(); }
        finally { if (previous == null) EMERGENCY.remove(); else EMERGENCY.set(previous); }
    }
    public static void withTrace(long trace, Runnable action) {
        Long previous = TRACE.get(); TRACE.set(trace);
        try { action.run(); }
        finally { if (previous == null) TRACE.remove(); else TRACE.set(previous); }
    }
    public static void withDeadline(long deadline, Runnable action) {
        Long previous = DEADLINE.get();
        DEADLINE.set(deadline);
        try { action.run(); }
        finally { if (previous == null) DEADLINE.remove(); else DEADLINE.set(previous); }
    }
}
