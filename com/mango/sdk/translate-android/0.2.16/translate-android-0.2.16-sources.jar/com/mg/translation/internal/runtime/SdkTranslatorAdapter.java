package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.Translator;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.Collections;

public final class SdkTranslatorAdapter implements Translator {
    private final TranslateControl delegate;
    private final long deadlineNanos;
    private final boolean emergencyMode;
    private final boolean requiresRuntime = TranslationRuntime.isInitialized();
    private final FallbackScope fallbacks = new FallbackScope();
    private final java.util.concurrent.atomic.AtomicBoolean closed = new java.util.concurrent.atomic.AtomicBoolean();

    public SdkTranslatorAdapter(TranslateControl delegate) {
        this(delegate, Long.MAX_VALUE);
    }

    public SdkTranslatorAdapter(TranslateControl delegate, long deadlineNanos) {
        this(delegate, deadlineNanos, false);
    }

    public SdkTranslatorAdapter(TranslateControl delegate, long deadlineNanos,
                                boolean emergencyMode) {
        if (delegate == null) throw new IllegalArgumentException("delegate is required");
        this.delegate = delegate;
        this.deadlineNanos = deadlineNanos;
        this.emergencyMode = emergencyMode;
    }

    @Override
    public int getEngineId() {
        return delegate.getTranslateType();
    }

    @Override
    public void translate(TranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (!emergencyMode && rejectRestrictedAccess(callback)) return;
        TranslationTask task = new TranslationTask(request.getText(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        if (!emergencyMode) applyMembershipPolicy(task);
        if (emergencyMode) task.markEmergencyRequest();
        execute(task, callback);
    }

    @Override
    public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (!emergencyMode && rejectRestrictedAccess(callback)) return;
        BatchTranslationTask task = new BatchTranslationTask(request.getTexts(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        if (!emergencyMode) applyMembershipPolicy(task);
        if (emergencyMode) task.markEmergencyRequest();
        execute(task, callback);
    }

    private void execute(TranslationTask task, TranslationCallback callback) {
        if (!task.isRuntimeCurrent()) {
            callback.onError(TranslationErrorMapper.fromInternalCode(
                    com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, getEngineId()));
            return;
        }
        task.setDeadlineNanos(deadlineNanos);
        task.setTraceId(com.mg.translation.internal.base.http.RequestContext.trace());
        TranslationRuntime.withSnapshot(task.getRuntimeSnapshot(), () ->
                com.mg.translation.internal.base.http.RequestContext.withDeadline(deadlineNanos,
                () -> executeInternal(task, callback)));
    }

    private void executeInternal(TranslationTask task, TranslationCallback callback) {
        if (closed.get()) return;
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null && requiresRuntime) {
            callback(callback, task).onFail(com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, "");
            return;
        }
        // Rescue intentionally bypasses cooldown and membership; its independent queue bounds load.
        String reason = runtime == null || emergencyMode ? null
                : com.mg.translation.utils.TranslateUtils.engineSkipReason(
                        runtime.context(), getEngineId(), task.isFreeOnlyForRequest());
        if ("cooldown".equals(reason) || "unreachable".equals(reason) || "gate".equals(reason)
                || "not_configured".equals(reason)) {
            ProviderAttemptTelemetry.skipped(getEngineId(), reason);
            task.setAttemptedEngineIds(new java.util.ArrayList<>(Collections.singletonList(getEngineId())));
            TranslateControl fallback = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                    runtime.context(), task, task instanceof BatchTranslationTask);
            if (fallback != null) {
                ProviderAttemptTelemetry.fallback(getEngineId(), fallback.getTranslateType());
                fallbacks.execute(fallback, task, callback(callback, task));
            } else {
                callback(callback, task).onFail(com.mg.translation.sdk.TranslationErrorCode.ALL_ENGINES_FAILED, "");
            }
            return;
        }
        // The task keeps the overall deadline so a failed attempt can still fall back.
        // The provider call itself gets a shorter engine-specific deadline.
        long attemptDeadline = attemptDeadline(task);
        com.mg.translation.internal.base.http.RequestContext.withDeadline(attemptDeadline,
                () -> delegate.translate(task, callback(callback, task)));
    }

    private long attemptDeadline(TranslationTask task) {
        TranslatorId id = TranslatorId.fromLegacyCode(getEngineId());
        if (id == null || deadlineNanos == Long.MAX_VALUE) return deadlineNanos;
        long attemptMs = id.requestTimeoutMs();
        if (attemptMs <= 0L) return deadlineNanos;
        long now = System.nanoTime();
        long candidate = now + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(attemptMs);
        if (candidate < now) candidate = Long.MAX_VALUE;
        return Math.min(deadlineNanos, candidate);
    }

    private TranslateListener callback(TranslationCallback callback, TranslationTask request) {
        java.util.concurrent.atomic.AtomicBoolean terminal = new java.util.concurrent.atomic.AtomicBoolean();
        return new TranslateListener() {
            @Override
            public void onSuccess(TranslationTask result, int actualEngineId, boolean isList) {
                if (closed.get() || terminal.get()) return;
                TranslationResult mapped = TranslationResultValidation.map(request, result, actualEngineId, isList);
                if (!terminal.compareAndSet(false, true)) return;
                ProviderFailurePolicy.recordSuccess(actualEngineId);
                try {
                    callback.onSuccess(mapped);
                } catch (RuntimeException hostFailure) {
                    // Translation already completed; never turn host callback failures into fallback.
                }
            }

            @Override
            public void onFail(int code, String message) {
                if (closed.get() || !terminal.compareAndSet(false, true)) return;
                com.mg.translation.sdk.TranslationError mapped =
                        TranslationErrorMapper.fromInternalCode(code, delegate.getTranslateType());
                try {
                    callback.onError(mapped);
                } catch (RuntimeException hostFailure) {
                    // A host observer failure must not cause another Provider attempt.
                }
            }
        };
    }

    private void applyMembershipPolicy(TranslationTask task) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null || !runtime.host().isVip()) task.requireFreeEngines();
    }

    private boolean rejectRestrictedAccess(TranslationCallback callback) {
        int engineId = delegate.getTranslateType();
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (!(delegate instanceof NonVipFallbackTranslateControl)
                && com.mg.translation.sdk.TranslationSdk.isVipOnly(engineId)
                && (runtime == null || !runtime.host().isVip())) {
            callback.onError(TranslationErrorMapper.vipRequired(engineId));
            return true;
        }
        return false;
    }

    @Override
    public void close() {
        closed.set(true);
        delegate.close();
        fallbacks.close();
    }
}
