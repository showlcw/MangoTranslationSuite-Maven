package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import java.util.Collections;
import java.util.List;

/** Structural validation only; identical source/target text is not automatically an error. */
final class TranslationResultValidation {
    private TranslationResultValidation() { }
    static TranslationResult map(com.mg.translation.internal.model.TranslationTask request,
                                 com.mg.translation.internal.model.TranslationTask result,
                                 int engineId, boolean batch) {
        if (result == null) throw new IllegalArgumentException("Missing Provider translation result");
        TranslationResult mapped = result instanceof com.mg.translation.internal.model.BatchTranslationTask
                ? new TranslationResult(((com.mg.translation.internal.model.BatchTranslationTask) result).getTranslations(), engineId, true)
                : new TranslationResult(Collections.singletonList(result.getTranslatedText()), engineId, false);
        if (batch != mapped.isBatch() || !matches(request, mapped))
            throw new IllegalArgumentException("Invalid Provider translation result");
        return mapped;
    }
    static boolean matches(com.mg.translation.internal.model.TranslationTask task, TranslationResult result) {
        if (task instanceof com.mg.translation.internal.model.BatchTranslationTask) {
            com.mg.translation.internal.model.BatchTranslationTask batch =
                    (com.mg.translation.internal.model.BatchTranslationTask) task;
            return valid(batch.getSourceTexts(), result, true);
        }
        return task != null && valid(Collections.singletonList(task.getContent()), result, false);
    }
    static boolean matches(Object request, TranslationResult result) {
        if (result == null) return false;
        boolean batch = request instanceof BatchTranslationRequest;
        List<String> source = batch ? ((BatchTranslationRequest) request).getTexts()
                : Collections.singletonList(((TranslationRequest) request).getText());
        return valid(source, result, batch);
    }
    private static boolean valid(List<String> source, TranslationResult result, boolean batch) {
        if (result == null || result.isBatch() != batch) return false;
        List<String> translated = result.getTranslations();
        if (source.size() != translated.size()) return false;
        for (int i = 0; i < source.size(); i++) {
            String value = translated.get(i);
            if (value == null) return false;
            if (source.get(i) != null && !source.get(i).trim().isEmpty()
                    && value.trim().isEmpty()) return false;
        }
        return true;
    }
}
