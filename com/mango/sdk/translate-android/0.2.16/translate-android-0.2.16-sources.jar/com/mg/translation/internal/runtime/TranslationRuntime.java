package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mg.translation.sdk.TranslationHost;
import com.mg.translation.engine.TranslatorId;

/** Internal process runtime; contains only App-level capabilities and one config snapshot. */
public final class TranslationRuntime {
    private static volatile TranslationRuntime instance;
    private static final ThreadLocal<TranslationRuntime> REQUEST_RUNTIME = new ThreadLocal<>();

    /** Credential/config reads stay on the request's snapshot; currentOrNull remains the live generation. */
    public static TranslationRuntime snapshot() {
        TranslationRuntime bound = REQUEST_RUNTIME.get();
        return bound == null ? instance : bound;
    }

    public static void withSnapshot(TranslationRuntime runtime, Runnable action) {
        callWithSnapshot(runtime, () -> { action.run(); return null; });
    }

    public static <T> T callWithSnapshot(TranslationRuntime runtime, java.util.function.Supplier<T> action) {
        TranslationRuntime previous = REQUEST_RUNTIME.get();
        if (runtime == null) REQUEST_RUNTIME.remove(); else REQUEST_RUNTIME.set(runtime);
        try { return action.get(); }
        finally { if (previous == null) REQUEST_RUNTIME.remove(); else REQUEST_RUNTIME.set(previous); }
    }

    private final Context context;
    private final TranslationHost host;
    private final TranslationConfigStore configStore;
    private final GoogleReachability googleReachability;

    private TranslationRuntime(Context context, TranslationHost host,
                               TranslationConfigStore configStore) {
        this.context = context.getApplicationContext();
        this.host = host;
        this.configStore = configStore;
        this.googleReachability = new GoogleReachability(this.context);
    }

    public static synchronized void initialize(Context context, TranslationHost host,
                                  TranslationConfigStore configStore) {
        if (instance != null) instance.googleReachability.close();
        instance = new TranslationRuntime(context, host, configStore);
    }

    public static synchronized void clear() {
        if (instance != null) instance.googleReachability.close();
        instance = null;
    }

    public static boolean isInitialized() {
        return instance != null;
    }

    public static TranslationRuntime currentOrNull() {
        return instance;
    }

    public static TranslationRuntime get() {
        TranslationRuntime value = snapshot();
        if (value == null) throw new IllegalStateException("TranslationSdk is not initialized");
        return value;
    }

    public Context context() { return context; }
    public TranslationHost host() { return host; }
    public GoogleReachability googleReachability() { return googleReachability; }
    public TranslationConfigStore configStore() { return configStore; }
    public String deepRapidKey() { return configStore.getDeepRapidApiKey(); }
    public String googleVipKey() { return configStore.getGoogleVipApiKey(); }
    public String microsoftKey() { return configStore.getMicrosoftApiKey(); }
    public String freeMicrosoftKey() { return configStore.getFreeMicrosoftApiKey(); }
    public String aiRapidKey() { return configStore.getAiRapidApiKey(); }
    public String plusRapidKey() { return configStore.getPlusRapidApiKey(); }
    public String baiduAppId() { return configStore.getBdAppId(); }
    public String baiduSecret() { return configStore.getBdSecret(); }
    public String youdaoAppId() { return configStore.getYouDaoAppId(); }
    public String youdaoSecret() { return configStore.getYouDaoSecret(); }
    public String websitePlusKey() { return configStore.getWebSitePlusKey(); }
    public String multiRapidKey() { return configStore.getMultiRapidApiKey(); }
    public String irctcapiRapidKey() { return configStore.getIrctcapiRapidApiKey(); }
    public boolean hasEnabledEngines() { return configStore.hasEnabledEngines(); }
    public String deepSeekKey() { return configStore.getDeepSeekApiKey(); }
    public String qwenDomains() { return configStore.getQwenMtDomains(); }
    public ProviderCredential providerCredential(int legacyCode, String defaultBaseUrl) {
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null) throw new IllegalArgumentException("unknown SDK legacy code: " + legacyCode);
        return configStore.nextProviderCredential(id, defaultBaseUrl);
    }
    public String peekProviderBaseUrl(int legacyCode, String defaultBaseUrl) {
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null) throw new IllegalArgumentException("unknown SDK legacy code: " + legacyCode);
        return configStore.peekProviderBaseUrl(id, defaultBaseUrl);
    }
    public Integer dailyLimit(int legacyCode) { return configStore.dailyLimit(legacyCode); }
    public int firstTranslateType() { return configStore.getFirstTranslateType(); }
    public java.util.List<String> recentLanguages(boolean source) {
        return configStore.getRecentlyHistoryList(source);
    }
    public void saveRecentLanguage(String languageKey, boolean source) {
        configStore.saveRecentlyHistoryList(languageKey, source);
    }
    public String string(int resourceId) { return context.getString(resourceId); }
    public String string(int resourceId, Object... arguments) {
        return context.getString(resourceId, arguments);
    }
}
