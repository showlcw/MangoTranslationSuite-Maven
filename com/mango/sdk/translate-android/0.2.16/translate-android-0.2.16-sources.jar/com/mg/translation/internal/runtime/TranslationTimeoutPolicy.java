package com.mg.translation.internal.runtime;

/** Process-local client policy, independent of platform settings. */
public final class TranslationTimeoutPolicy {
    private static volatile Settings settings = new Settings(5_000, 8_000, 40_000);
    private TranslationTimeoutPolicy() { }
    public static Settings get() { return settings; }
    public static synchronized void configure(int callMs, int requestMs) {
        if (callMs < 1000 || callMs > 60_000 || requestMs < Math.max(callMs, 10_000)
                || requestMs > 120_000) throw new IllegalArgumentException("Invalid client timeout budget");
        settings = new Settings(callMs, callMs, requestMs);
    }
    public static synchronized void configureGoogle(int callMs) {
        if (callMs < 1000 || callMs > 30000 || callMs > settings.requestBudgetMs)
            throw new IllegalArgumentException("Invalid Google timeout budget");
        settings = new Settings(settings.selfHostedCallMs, callMs, settings.requestBudgetMs);
    }
    public static final class Settings {
        public final int selfHostedCallMs;
        public final int googleCallMs;
        public final int requestBudgetMs;
        private Settings(int callMs, int googleMs, int requestMs) {
            selfHostedCallMs = callMs; googleCallMs = googleMs; requestBudgetMs = requestMs;
        }
    }
}
