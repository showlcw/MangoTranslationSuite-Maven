package com.mg.translation.sdk;

/** Client memory/CPU bounds; individual Providers may impose smaller limits. UTF-16 code units. */
public final class TranslationRequestLimits {
    public static final int MAX_TEXT_CHARS = 32 * 1024;
    public static final int MAX_BATCH_ITEMS = 256;
    public static final int MAX_BATCH_CHARS = 128 * 1024;
    private TranslationRequestLimits() { }
    static void validateText(String text) {
        if (text != null && text.length() > MAX_TEXT_CHARS)
            throw new IllegalArgumentException("translation text exceeds 32768 characters; split the request");
    }
}
