package com.mg.translation.translate.base;

import com.mg.translation.sdk.TranslationErrorCode;


import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.runtime.ProviderAttemptTelemetry;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import io.reactivex.Single;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/6 18:35
 */
public abstract class BaseTranslateControl implements TranslateControl {
    private static final ThreadLocal<Throwable> FAILURE = new ThreadLocal<>();
    private final com.mg.translation.internal.runtime.FallbackScope fallbacks =
            new com.mg.translation.internal.runtime.FallbackScope();
    private final CompositeDisposable requests = new CompositeDisposable();
    private final AtomicBoolean closed = new AtomicBoolean(false);

    /**
     * 统一执行一次 Provider 请求：后台处理结果/回退，单次完成并纳入 close() 取消范围。
     */
    protected final <T> void executeRequest(Single<T> request, Consumer<T> onSuccess,
                                            Runnable onFailure) {
        if (request == null || onSuccess == null || onFailure == null || closed.get()) return;
        AtomicBoolean terminal = new AtomicBoolean(false);
        AtomicReference<Disposable> requestRef = new AtomicReference<>();
        long startedNanos = System.nanoTime();
        long requestNetwork = com.mg.translation.internal.runtime.NetworkFailureScope.network();
        long requestDeadline = com.mg.translation.internal.base.http.RequestContext.deadline();
        long requestTrace = com.mg.translation.internal.base.http.RequestContext.trace();
        com.mg.translation.internal.runtime.TranslationRuntime requestRuntime =
                com.mg.translation.internal.runtime.TranslationRuntime.snapshot();
        Single<T> scoped = Single.create(emitter -> {
            if (requestRuntime != com.mg.translation.internal.runtime.TranslationRuntime.currentOrNull()) {
                emitter.tryOnError(new IllegalStateException("Translation runtime changed")); return;
            }
            Integer previous = com.mg.translation.internal.base.http.RequestContext.engine();
            com.mg.translation.internal.base.http.RequestContext.set(getTranslateType());
            try { com.mg.translation.internal.runtime.TranslationRuntime.withSnapshot(requestRuntime, () ->
                    com.mg.translation.internal.base.http.RequestContext.withDeadline(requestDeadline,
                    () -> com.mg.translation.internal.base.http.RequestContext.withTrace(requestTrace,
                    () -> request.subscribe(new io.reactivex.SingleObserver<T>() {
                @Override public void onSubscribe(Disposable disposable) { emitter.setDisposable(disposable); }
                @Override public void onSuccess(T value) { emitter.onSuccess(value); }
                @Override public void onError(Throwable error) { emitter.tryOnError(error); }
            })))); }
            finally { com.mg.translation.internal.base.http.RequestContext.set(previous); }
        });
        Disposable disposable = scoped
                .subscribeOn(Schedulers.io())
                .doOnDispose(() -> {
                    if (terminal.compareAndSet(false, true)) {
                        com.mg.translation.internal.runtime.TranslationRuntime.withSnapshot(requestRuntime,
                                () -> ProviderAttemptTelemetry.report(getTranslateType(), "cancelled", startedNanos, 0));
                    }
                })
                .doFinally(() -> {
                    Disposable completed = requestRef.get();
                    if (completed != null) requests.delete(completed);
                })
                .subscribe(value -> com.mg.translation.internal.runtime.TranslationRuntime.withSnapshot(requestRuntime, () -> {
                    if (!terminal.compareAndSet(false, true)) return;
                    if (requestRuntime != com.mg.translation.internal.runtime.TranslationRuntime.currentOrNull()) {
                        runFailureAtDeadline(requestDeadline, null, onFailure); return;
                    }
                    if (closed.get()) {
                        ProviderAttemptTelemetry.report(
                                getTranslateType(), "cancelled", startedNanos, 0);
                        return;
                    }
                    long durationMs = ProviderAttemptTelemetry.elapsedMs(startedNanos);
                    try {
                        try {
                            // A synchronous fallback response must not inherit the previous attempt's failure.
                            Throwable previousFailure = FAILURE.get();
                            FAILURE.remove();
                            try { onSuccess.accept(value); }
                            finally { if (previousFailure != null) FAILURE.set(previousFailure); }
                        } catch (Exception responseFailure) {
                            com.mg.translation.internal.runtime.ProviderFailurePolicy.recordAttemptFailure(
                                    getTranslateType(), responseFailure);
                            runFailureAtDeadline(requestDeadline, responseFailure, onFailure);
                        }
                    } finally {
                        ProviderAttemptTelemetry.reportDuration(
                                getTranslateType(), "response", durationMs, 0);
                    }
                }), error -> com.mg.translation.internal.runtime.TranslationRuntime.withSnapshot(requestRuntime, () ->
                        withFailureNetwork(error, requestNetwork, () -> {
                    if (terminal.compareAndSet(false, true)) {
                        if (requestRuntime != com.mg.translation.internal.runtime.TranslationRuntime.currentOrNull()) {
                            runFailureAtDeadline(requestDeadline, error, onFailure); return;
                        }
                        if (closed.get()) {
                            ProviderAttemptTelemetry.report(
                                    getTranslateType(), "cancelled", startedNanos, 0);
                            return;
                        }
                        long durationMs = ProviderAttemptTelemetry.elapsedMs(startedNanos);
                        com.mg.translation.internal.runtime.ProviderFailurePolicy.recordAttemptFailure(getTranslateType(), error);
                        ProviderAttemptTelemetry.reportDuration(getTranslateType(),
                                ProviderAttemptTelemetry.outcome(error, false), durationMs,
                                ProviderAttemptTelemetry.httpStatus(error));
                        runFailureAtDeadline(requestDeadline, error, onFailure);
                    }
                })));
        requestRef.set(disposable);
        requests.add(disposable);
        // 同步 Single 可能在 add 前已经结束，需补一次清理。
        if (disposable.isDisposed()) requests.delete(disposable);
    }

    private static void withFailureNetwork(Throwable error, long network, Runnable action) {
        if (com.mg.translation.internal.runtime.ProviderFailurePolicy.isNetworkFailure(error))
            com.mg.translation.internal.runtime.NetworkFailureScope.run(network, action);
        else action.run();
    }

    private static void runFailureAtDeadline(long deadline, Throwable failure, Runnable action) {
        Throwable previous = FAILURE.get();
        FAILURE.set(failure);
        try { com.mg.translation.internal.base.http.RequestContext.withDeadline(deadline, action); }
        finally { if (previous == null) FAILURE.remove(); else FAILURE.set(previous); }
    }

    /**
     * 是否支持自动模式
     *
     * @return true 支持  false 不支持
     */
    @Override
    public boolean isSupportAuto() {
        return true;
    }

    @Override
    public int getIndexByLanguage(String country, boolean isSetDefault) {
        int index = -1;

        if (getSupportLanguage() == null || getSupportLanguage().isEmpty()) {//
            if (isSetDefault) {
                index = 0;
            }
            return index;
        }

        LanguageVO languageVO = new LanguageVO(country, 0, "");
        index = getSupportLanguage().indexOf(languageVO);
        if (isSetDefault && index == -1) {
            index = 0;
        }
        return index;
    }

    public void dealTranslateError(Context context, TranslationTask task, TranslateListener translateListener) {
        if (closed.get()) return;
        //如果是null的话 直接返回错误
        if (task == null) {
            translateListener.onFail(TranslationErrorCode.INVALID_REQUEST,
                    context.getString(R.string.translation_error_invalid_request));
            return;
        }
        if (!task.isRuntimeCurrent()) {
            translateListener.onFail(TranslationErrorCode.SDK_NOT_INITIALIZED, "Translation runtime changed");
            return;
        }
        Throwable failure = FAILURE.get();
        boolean attemptTimedOut = failure != null
                && ("timeout".equals(ProviderAttemptTelemetry.outcome(failure, false))
                || ProviderAttemptTelemetry.httpStatus(failure) == 408
                || ProviderAttemptTelemetry.httpStatus(failure) == 504);
        task.markAttemptFailure(getTranslateType(), attemptTimedOut);
        if (task.isEmergencyRequest()) {
            translateListener.onFail(attemptTimedOut ? TranslationErrorCode.REQUEST_TIMEOUT
                    : TranslationErrorCode.PROVIDER_UNAVAILABLE,
                    context.getString(attemptTimedOut ? R.string.translation_error_timeout
                    : R.string.translation_error_provider_unavailable));
            return;
        }
        //判断网络
        if (!TranslateUtils.isNetworkConnected(context)) {//如果网络连接不正常
            translateListener.onFail(TranslationErrorCode.NETWORK_UNAVAILABLE,
                    context.getString(R.string.translation_error_network_unavailable));
            return;
        }
        boolean isList = (task instanceof BatchTranslationTask);
        // Record this engine so the current request cannot loop back to it during fallback.
        List<Integer> attemptedEngineIds = new ArrayList<>(task.getAttemptedEngineIds());
        if (!attemptedEngineIds.contains(getTranslateType())) {
            attemptedEngineIds.add(getTranslateType());
        }
        task.setAttemptedEngineIds(attemptedEngineIds);
        TranslateControl translateControl = findFallback(context, task, isList);
        if (translateControl != null) {
            ProviderAttemptTelemetry.fallback(getTranslateType(), translateControl.getTranslateType());
            fallbacks.execute(translateControl, task, translateListener);
            return;
        }
        if (task.allAttemptedFailuresTimedOut()) {
            translateListener.onFail(TranslationErrorCode.REQUEST_TIMEOUT,
                    context.getString(R.string.translation_error_timeout));
            return;
        }
        if (task.remainingBudgetMs() <= 0L) {
            translateListener.onFail(TranslationErrorCode.REQUEST_TIMEOUT,
                    context.getString(R.string.translation_error_timeout));
            return;
        }
        translateListener.onFail(TranslationErrorCode.ALL_ENGINES_FAILED,
                context.getString(R.string.translation_error_all_engines_failed));
    }


    protected TranslateControl findFallback(Context context, TranslationTask task, boolean batch) {
        return TranslateUtils.getCanTranslateType(context, task, batch);
    }

    /**
     * 出现错误的时候处理逻辑
     */
    public void errorDealUserBaidu(Context context, TranslationTask task,
                                   TranslateListener translateListener) {
        // Legacy entry point must obey the same eligibility, budget and attempted-engine checks.
        dealTranslateError(context, task, translateListener);
    }

    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) {
            requests.dispose();
            fallbacks.close();
        }
    }

    @Override
    public LanguageVO getSelectLanguageVO(String country, boolean isSetDefault) {

        if (getSupportLanguage() == null || getSupportLanguage().isEmpty()) {//
            return null;
        }
        int translateIndex =
                getIndexByLanguage(country, isSetDefault);
        if (translateIndex == -1) {
            return null;
        }
        return getSupportLanguage().get(translateIndex);
    }


}
