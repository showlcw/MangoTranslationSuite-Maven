package com.mg.translation.translate.microsoft;

import com.mg.translation.engine.TranslatorId;


import android.content.Context;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.microsoft.dto.MicrosoftTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.http.translate.microsoft.dto.MicrosoftTranslateItemResult;

import java.util.ArrayList;
import java.util.List;


/**
 * @author LiChunWei
 * @description: google  翻译
 * @date :2021/5/7 10:15
 */
public class MicrosoftVipTranslate extends BaseTranslateControl {

    private final Context mContext;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    public MicrosoftVipTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, translateListener);
    }

    /**
     * 翻译
     */
    public synchronized void translateListApi(BatchTranslationTask batchTask,
                                              TranslateListener translateListener) {

        List<String> sourceTexts = batchTask.getSourceTexts();
        JsonArray jsonArray = new JsonArray();
        JsonObject jsonObject = null;
        for (String sourceText : sourceTexts) {
            jsonObject = new JsonObject();
            jsonObject.addProperty("text", sourceText);
            jsonArray.add(jsonObject);
        }
        executeRequest(TranslateRepository.getInstance().microsoftTranslateVip(mContext,
                createBaseReq(batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId()),
                jsonArray.toString()), microsoftTranslateResult -> {
            if (microsoftTranslateResult == null || microsoftTranslateResult.getCode() != 200) {
                errorDealUserBaidu(mContext, batchTask, translateListener);
                return;
            }
            List<MicrosoftTranslateItemResult> list = microsoftTranslateResult.getResult();
            if (list == null || list.size() == 0) {
                errorDealUserBaidu(mContext, batchTask, translateListener);
                return;
            }
            int size = list.size();
            if (size == sourceTexts.size()) {
                MicrosoftTranslateItemResult microsoftTranslateItemResult = null;
                for (int i = 0; i < size; i++) {
                    microsoftTranslateItemResult = list.get(i);
                    if (microsoftTranslateItemResult == null || microsoftTranslateItemResult.getTranslations() == null || microsoftTranslateItemResult.getTranslations().size() == 0) {
                        continue;
                    }
                    String dest = microsoftTranslateItemResult.getTranslations().get(0).getText();
                    batchTask.setTranslation(i, dest);
                }
                translateListener.onSuccess(batchTask, getTranslateType(), true);
            } else {
                errorDealUserBaidu(mContext, batchTask, translateListener);
            }
        }, () -> dealTranslateError(mContext, batchTask, translateListener));
    }

    public MicrosoftTranslateReq createBaseReq(String source, String to) {
        MicrosoftTranslateReq microsoftTranslate = new MicrosoftTranslateReq();
        LanguageVO tolanguageVO = getSelectLanguageVO(to, false);
        String toValue = "";
        if (tolanguageVO != null) {
            toValue = tolanguageVO.getValue();
        }
        LanguageVO sourceLanguageVO = getSelectLanguageVO(source, false);
        String sourceValue = "auto";
        if (sourceLanguageVO != null) {
            sourceValue = sourceLanguageVO.getValue();
        }
        microsoftTranslate.setFrom(sourceValue);
        microsoftTranslate.setTo(toValue);
        return microsoftTranslate;
    }

    public void translateContent(TranslationTask task, TranslateListener translateListener) {
        JsonArray jsonArray = new JsonArray();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("text", task.getContent());
        jsonArray.add(jsonObject);

        executeRequest(TranslateRepository.getInstance().microsoftTranslateVip(mContext,
                createBaseReq(task.getSourceLanguageId(), task.getTargetLanguageId()),
                jsonArray.toString()), microsoftTranslateResult -> {
            if (microsoftTranslateResult == null || microsoftTranslateResult.getCode() != 200) {
                errorDealUserBaidu(mContext, task, translateListener);
                return;
            }
            List<MicrosoftTranslateItemResult> list = microsoftTranslateResult.getResult();
            if (list == null || list.size() == 0) {
                errorDealUserBaidu(mContext, task, translateListener);
                return;
            }
            int size = list.size();
            MicrosoftTranslateItemResult microsoftTranslateItemResult = null;
            StringBuilder stringBuffer = new StringBuilder();
            for (int i = 0; i < size; i++) {
                microsoftTranslateItemResult = list.get(i);
                if (microsoftTranslateItemResult == null || microsoftTranslateItemResult.getTranslations() == null || microsoftTranslateItemResult.getTranslations().size() == 0) {
                    continue;
                }
                String dest = microsoftTranslateItemResult.getTranslations().get(0).getText();
                stringBuffer.append(dest).append("\n");
            }
            task.setTranslatedText(stringBuffer.toString().trim());
            translateListener.onSuccess(task, getTranslateType(), false);
        }, () -> dealTranslateError(mContext, task, translateListener));
    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguage();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }


    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese,
                "zh-Hans"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai,
                "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_PORTUGAL,
                R.string.language_Portuguese_Portugal, "pt-PT",
                LanguageConstant.PORTUGUESE_PORTUGAL, R.string.country_Portugal));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek,
                "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgaria,
                "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian,
                "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish,
                "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish,
                "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian,
                "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian,
                "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish,
                "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN,
                R.string.language_Hungarian,
                "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian,
                "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya,
                "or"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish,
                "ga"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic,
                "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani,
                "az"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian,
                "fa"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese,
                "as"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic,
                "is"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian,
                "bs"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar,
                "tt"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino,
                "fil"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer,
                "km"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian,
                "ka"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian,
                "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz,
                "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan,
                "ca"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada,
                "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian,
                "hr"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao,
                "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian,
                "lv"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian,
                "lt"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian,
                "mk"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali,
                "bn"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto,
                "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese,
                "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese,
                "my"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori,
                "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi,
                "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali,
                "ne"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian,
                "sr-Cyrl"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan,
                "sm"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili,
                "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak,
                "sk"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen,
                "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian,
                "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN,
                R.string.language_Indonesian,
                "id"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-Hant"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KASHMIRI, R.string.language_Kashmiri,
                "ks"));

        // Current Microsoft Translator language catalog additions. Keep the SDK's canonical
        // language identifiers; only the provider-specific code belongs in the third argument.
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASHKIR, R.string.language_Bashkir, "ba"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BGOJPUR, R.string.language_Bhojpur, "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIBETAN, R.string.language_Tibetan, "bo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BODO, R.string.language_Bodo, "brx"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri, "doi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOWER_SORBIAN, R.string.language_Lower_Sorbian, "dsb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi, "dv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FIJIAN, R.string.language_Fijian, "fj"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FAROESE, R.string.language_Faroese, "fo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH_CANADA, R.string.language_French_Canadian, "fr-CA"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani, "gom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa, "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HIGHLAND_SORBIAN, R.string.language_Highland_Sorbian, "hsb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo, "ig"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUKTUT, R.string.language_Inuktut, "iu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUKTUT_LATIN, R.string.language_Inuktut_Latin, "iu-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish, "ku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala, "ln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda, "lug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili, "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "ml"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MANIPURI_BENGALI, R.string.language_Manipuri_Bengali, "mni"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong, "mww"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "nb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi, "nso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa, "nya"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DARI, R.string.language_Dari, "prs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUNDI, R.string.language_Rundi, "run"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda, "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona, "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali, "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho, "st"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya, "ti"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KLINGON, R.string.language_Klingon, "tlh-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSWANA, R.string.language_Tswana, "tn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TONGAN, R.string.language_Tongan, "to"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAHITIAN, R.string.language_Tahitian, "ty"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur, "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa, "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba, "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YUCATEC_MAYA, R.string.language_Yucatec_Maya, "yua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CANTONESE, R.string.language_Cantonese, "yue"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu, "zu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH_MEXICO, R.string.language_Spanish_Mexico, "es-MX"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHHATTISGARHI, R.string.language_Chhattisgarhi, "hne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUINNAQTUN, R.string.language_Inuinnaqtun, "ikt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH_NORTHERN, R.string.language_Kurdish_Northern, "kmr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITERARY_CHINESE, R.string.language_Literary_Chinese, "lzh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN_CYRILLIC, R.string.language_Mongolian_Cyrillic, "mn-Cyrl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN_TRADITIONAL, R.string.language_Mongolian_Traditional, "mn-Mong"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.QUERETARO_OTOMI, R.string.language_Queretaro_Otomi, "otq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN_LATIN, R.string.language_Serbian_Latin, "sr-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KLINGON_PIQAD, R.string.language_Klingon_Piqad, "tlh-Piqd"));
    }

    @Override
    public void close() {
        super.close();
    }


    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_microsoft);
    }

    @Override
    public boolean isSupportAuto() {
        return false;
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.MICROSOFT_VIP.legacyCode;
    }
}
