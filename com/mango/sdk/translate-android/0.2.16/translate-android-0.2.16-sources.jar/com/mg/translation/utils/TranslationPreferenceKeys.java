package com.mg.translation.utils;

/** Internal persistence keys for active provider cooldowns and request gates. */
public final class TranslationPreferenceKeys {
    public static final String SELF_HOSTED_YOUDAO_TRANSLATE_STATE = "SELF_HOSTED_YOUDAO_TRANSLATE_STATE";
    public static final String SELF_HOSTED_DEEPL_TRANSLATE_STATE = "SELF_HOSTED_DEEPL_TRANSLATE_STATE";
    public static final String GOOGLE_FREE_TRANSLATE_STATE = "GOOGLE_FREE_TRANSLATE_STATE_NEW";
    public static final String SELF_HOSTED_GOOGLE_TRANSLATE_STATE = "SELF_HOSTED_GOOGLE_TRANSLATE_STATE";
    public static final String GOOGLE_FREE_CLIENT_STATE = "GOOGLE_FREE_CLIENT_STATE_NEW";
    public static final String GOOGLE_TRANSLATE_LAST_USER_TIME = "GOOGLE_TRANSLATE_LAST_USER_TIME";
    public static final String GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME = "GOOGLE_CLIENT_TRANSLATE_LAST_USER_TIME";
    public static final String MEMORY_TRANSLATE_STATE = "MEMORY_TRANSLATE_STATE";
    public static final String MICROSOFT_TRANSLATE_STATE = "MICROSOFT_TRANSLATE_STATE";
    public static final String MICROSOFT_VIP_TRANSLATE_STATE = "MICROSOFT_VIP_TRANSLATE_STATE";
    public static final String AI_TRANSLATE_STATE = "AI_TRANSLATE_STATE";
    public static final String PLUS_TRANSLATE_STATE = "PLUS_TRANSLATE_STATE";
    public static final String WEBSITE_PLUS_TRANSLATE_STATE = "WEBSITE_PLUS_TRANSLATE_STATE";
    public static final String MULTI_TRANSLATE_STATE = "MULTI_TRANSLATE_STATE";
    public static final String IRCTCAPI_TRANSLATE_STATE = "IRCTCAPI_TRANSLATE_STATE";
    public static final String DEEP_TRANSLATE_STATE = "DEEP_TRANSLATE_STATE";
    public static final String BD_TRANSLATE_STATE = "BD_TRANSLATE_STATE";
    public static final String YOUDAO_TRANSLATE_STATE = "YOUDAO_TRANSLATE_STATE";
    public static final String DEEPSEEK_TRANSLATE_STATE = "DEEPSEEK_TRANSLATE_STATE";
    public static final String HUNYUAN_TRANSLATE_STATE = "HUNYUAN_TRANSLATE_STATE";
    public static final String CHATGPT_TRANSLATE_STATE = "CHATGPT_TRANSLATE_STATE";
    public static final String GEMMA_TRANSLATE_STATE = "GEMMA_TRANSLATE_STATE";
    public static final String GEMINI_TRANSLATE_STATE = "GEMINI_TRANSLATE_STATE";
    public static final String ZHIPU_TRANSLATE_STATE = "ZHIPU_TRANSLATE_STATE";
    public static final String QWEN_TRANSLATE_STATE = "QWEN_TRANSLATE_STATE";

    public static String aiEngineState(int legacyCode) {
        switch (legacyCode) {
            case 43: return DEEPSEEK_TRANSLATE_STATE;
            case 46: return ZHIPU_TRANSLATE_STATE;
            case 49: return HUNYUAN_TRANSLATE_STATE;
            case 50: return CHATGPT_TRANSLATE_STATE;
            case 51: return GEMMA_TRANSLATE_STATE;
            case 52: return GEMINI_TRANSLATE_STATE;
            default: return "AI_ENGINE_TRANSLATE_STATE_" + legacyCode;
        }
    }

    private TranslationPreferenceKeys() { }
}
