package com.mg.translation.internal.base.http;

/** Local admission failure: no provider request was sent and no cooldown is warranted. */
public final class InsufficientTranslationBudgetException extends java.io.InterruptedIOException {
    public InsufficientTranslationBudgetException() { super("deadline reached"); }
}
