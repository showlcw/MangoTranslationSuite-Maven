package com.mg.translation.internal.base.http;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Interceptor;
import okhttp3.Response;

/** Sends a bounded server budget only on the self-hosted transport. */
final class SelfHostedBudgetInterceptor implements Interceptor {
    static final long RETURN_RESERVE_MS = 500L;
    static final long MIN_SERVER_BUDGET_MS = 1_500L;
    @Override public Response intercept(Chain chain) throws IOException {
        Budget captured = chain.request().tag(Budget.class);
        if (captured != null) {
            if (captured.deadline - System.nanoTime() < TimeUnit.MILLISECONDS.toNanos(
                    MIN_SERVER_BUDGET_MS + RETURN_RESERVE_MS)) throw new InsufficientTranslationBudgetException();
            return chain.proceed(chain.request());
        }
        long now = System.nanoTime();
        long remaining = chain.call().timeout().timeoutNanos();
        if (remaining <= 0) remaining = TimeUnit.SECONDS.toNanos(30);
        if (chain.call().timeout().hasDeadline()) {
            remaining = Math.min(remaining, chain.call().timeout().deadlineNanoTime() - now);
        }
        long deadline = now + Math.max(0, remaining);
        return chain.proceed(chain.request().newBuilder().tag(Budget.class,
                new Budget(deadline, RequestContext.correlationId())).build());
    }

    static final class Budget {
        final long deadline;
        final String chainId;
        Budget(long deadline) { this(deadline, ""); }
        Budget(long deadline, String chainId) { this.deadline = deadline; this.chainId = chainId; }
    }

    static final class Network implements Interceptor {
        @Override public Response intercept(Chain chain) throws IOException {
            Budget budget = chain.request().tag(Budget.class);
            if (budget == null) throw new IOException("missing self-hosted request budget");
            long remaining = TimeUnit.NANOSECONDS.toMillis(budget.deadline - System.nanoTime());
            if (remaining < MIN_SERVER_BUDGET_MS + RETURN_RESERVE_MS)
                throw new InsufficientTranslationBudgetException();
            long serverMs = Math.max(MIN_SERVER_BUDGET_MS,
                    Math.min(30000, remaining - RETURN_RESERVE_MS));
            okhttp3.Request.Builder request = chain.request().newBuilder()
                    .header("X-Translation-Timeout-Ms", Long.toString(serverMs));
            if (!budget.chainId.isEmpty()) request.header("X-Translation-Chain-Id", budget.chainId);
            return chain.proceed(request.build());
        }
    }
}
