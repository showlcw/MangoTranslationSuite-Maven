package com.mg.translation.internal.runtime;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;

import androidx.annotation.DrawableRes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** SDK-owned localized brand names, descriptions and display order for active engines. */
public final class TranslationEnginePresentationCatalog {
    public static final class Entry {
        public final TranslatorId id;
        public final int nameRes;
        public final int descriptionRes;
        public final int iconRes;
        public final boolean slow;

        Entry(TranslatorId id, int nameRes, int descriptionRes,
              @DrawableRes int iconRes, boolean slow) {
            this.id = id;
            this.nameRes = nameRes;
            this.descriptionRes = descriptionRes;
            this.iconRes = iconRes;
            this.slow = slow;
        }
    }

    private static final List<Entry> ENTRIES = Collections.unmodifiableList(Arrays.asList(
            new Entry(TranslatorId.GOOGLE_CLIENT, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_google, false),
            new Entry(TranslatorId.SELF_HOSTED_GOOGLE,
                    R.string.brand_google_translate, R.string.translate_desc_google,
                    R.drawable.sdk_engine_google, false),
            new Entry(TranslatorId.GOOGLE, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_google, false),
            new Entry(TranslatorId.GOOGLE_V, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_google, false),
            new Entry(TranslatorId.BAIDU, R.string.brand_baidu_translate,
                    R.string.translate_desc_baidu, R.drawable.sdk_engine_baidu, false),
            new Entry(TranslatorId.BD, R.string.brand_baidu_translate,
                    R.string.translate_desc_baidu, R.drawable.sdk_engine_baidu, false),
            new Entry(TranslatorId.MICROSOFT, R.string.brand_microsoft_translator,
                    R.string.translate_desc_microsoft, R.drawable.sdk_engine_microsoft, false),
            new Entry(TranslatorId.MICROSOFT_VIP, R.string.brand_microsoft_translator,
                    R.string.translate_desc_microsoft, R.drawable.sdk_engine_microsoft, false),
            new Entry(TranslatorId.MYMEMORY, R.string.brand_mymemory,
                    R.string.translate_desc_mymemory, R.drawable.sdk_engine_mymemory, false),
            new Entry(TranslatorId.YOUDAO, R.string.brand_youdao_translate,
                    R.string.translate_desc_youdao, R.drawable.sdk_engine_youdao, false),
            new Entry(TranslatorId.SELF_HOSTED_YOUDAO, R.string.brand_youdao_translate,
                    R.string.translate_desc_youdao, R.drawable.sdk_engine_youdao, false),
            new Entry(TranslatorId.SELF_HOSTED_DEEPL, R.string.brand_deepl_translate,
                    R.string.brand_deepl_translate, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.DEEPSEEK, R.string.brand_deepseek,
                    R.string.translate_desc_deepseek, R.drawable.sdk_engine_deepseek, true),
            new Entry(TranslatorId.HY_MT2, R.string.brand_hy_mt2,
                    R.string.translate_desc_hy_mt2, R.drawable.sdk_engine_hunyuan, true),
            new Entry(TranslatorId.GPT_4O_MINI, R.string.brand_gpt_4o_mini,
                    R.string.translate_desc_gpt_4o_mini, R.drawable.sdk_engine_openai, true),
            new Entry(TranslatorId.GEMMA, R.string.brand_gemma,
                    R.string.translate_desc_gemma, R.drawable.sdk_engine_gemma, true),
            new Entry(TranslatorId.GEMINI, R.string.brand_gemini,
                    R.string.translate_desc_gemini, R.drawable.sdk_engine_gemini, true),
            new Entry(TranslatorId.ZHIPU_FLASH, R.string.brand_glm,
                    R.string.translate_desc_zhipu, R.drawable.sdk_engine_glm, true),
            new Entry(TranslatorId.QWEN, R.string.brand_qwen_mt,
                    R.string.translate_desc_qwen, R.drawable.sdk_engine_qwen, true),
            new Entry(TranslatorId.RAPID_AI, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.RAPID_DEEP, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.RAPID_PLUS, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.RAPID_WEBSITE_PLUS, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.RAPID_MULTI, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false),
            new Entry(TranslatorId.RAPID_IRCTCAPI, R.string.brand_google_translate,
                    R.string.translate_desc_google, R.drawable.sdk_engine_translation, false)
    ));

    private TranslationEnginePresentationCatalog() { }

    public static List<Entry> entries() { return ENTRIES; }

    public static Entry find(int legacyCode) {
        for (Entry entry : ENTRIES) {
            if (entry.id.legacyCode == legacyCode) return entry;
        }
        return null;
    }
}
