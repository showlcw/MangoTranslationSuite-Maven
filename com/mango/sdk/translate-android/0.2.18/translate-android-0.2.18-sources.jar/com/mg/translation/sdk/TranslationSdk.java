package com.mg.translation.sdk;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;

import com.mg.translation.engine.EngineCategory;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.runtime.TranslationEnginePresentationCatalog;
import com.mg.translation.internal.runtime.TranslationLanguageCatalogCache;
import com.mg.translation.internal.runtime.SdkTranslatorAdapter;
import com.mg.translation.internal.runtime.TranslationConfigStore;
import com.mg.translation.internal.runtime.TranslationConfigCache;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.internal.runtime.TranslationPreconnector;
import com.mg.translation.internal.runtime.NonVipFallbackTranslateControl;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * SDK 配置、整数引擎选择和只读目录入口。App 负责持久化选择的 Legacy Code；SDK 不保存第二份。
 */
public final class TranslationSdk {
    public static final String VERSION = "0.2.18";

    /** Configure future client requests; no server setting or in-flight call is changed. */
    public static void configureTimeouts(int selfHostedCallTimeoutMs, int requestBudgetMs) {
        com.mg.translation.internal.runtime.TranslationTimeoutPolicy.configure(selfHostedCallTimeoutMs, requestBudgetMs);
    }

    /** Override only future self-hosted Google attempts; the total request budget is unchanged. */
    public static void configureSelfHostedGoogleTimeout(int timeoutMs) {
        com.mg.translation.internal.runtime.TranslationTimeoutPolicy.configureGoogle(timeoutMs);
    }

    public static int getSelfHostedGoogleTimeoutMs() {
        return com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().googleCallMs;
    }

    /** Only metadata is logged; legacy content-bearing logs remain disabled. */
    public static void setDebugLogging(boolean enabled) {
        com.mg.translation.internal.runtime.ProviderAttemptTelemetry.setDebugLogging(enabled);
    }

    public static int getSelfHostedCallTimeoutMs() {
        return com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().selfHostedCallMs;
    }

    public static int getRequestBudgetMs() {
        return com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().requestBudgetMs;
    }

    private static volatile int selectedEngineId = EngineSelectionResult.NO_ENGINE;
    private static volatile boolean initializedFromCache;

    private TranslationSdk() { }

    public static void initialize(Context context, String configJson, TranslationHost host) {
        if (context == null || host == null) {
            throw new IllegalArgumentException("context and host are required");
        }
        if (!host.isAppIdentityValid()) {
            throw new SecurityException("App identity validation failed");
        }
        boolean fromCache = configJson == null || configJson.trim().isEmpty();
        String effectiveJson = fromCache ? TranslationConfigCache.load(context) : configJson;
        if (effectiveJson == null || effectiveJson.trim().isEmpty()) {
            throw new IllegalArgumentException("translation config JSON or cache is required");
        }
        TranslationConfigStore nextStore = TranslationConfigStore.fromJson(
                effectiveJson, host.getCredentialDecryptor());
        initializeInternal(context, nextStore, host, effectiveJson, fromCache);
    }

    private static synchronized void initializeInternal(Context context,
                                                        TranslationConfigStore next,
                                                        TranslationHost host,
                                                        String encryptedConfigJson,
                                                        boolean fromCache) {
        if (context == null || next == null || host == null) {
            throw new IllegalArgumentException("context, config store and host are required");
        }
        TranslationRuntime.initialize(context, host, next);
        initializedFromCache = fromCache;
        if (!fromCache) TranslationConfigCache.save(context, encryptedConfigJson);
        // 配置刷新只更新可用性，不得覆盖 App 恢复或用户主动选择的真实 ID。
    }

    public static boolean isUsingCachedConfig() { return initializedFromCache; }

    public static synchronized void clearCachedConfig(Context context) {
        if (context != null) TranslationConfigCache.clear(context);
        selectedEngineId = EngineSelectionResult.NO_ENGINE;
        initializedFromCache = false;
        TranslationRuntime.clear();
        TranslationLanguageCatalogCache.clear();
    }

    public static boolean isInitialized() { return TranslationRuntime.isInitialized(); }

    /** 中台已为当前 App 返回该引擎且至少一组解密凭据有效；不代表一定显示在用户列表中。 */
    public static boolean isEngineEnabled(int legacyCode) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        return runtime != null && runtime.configStore().isEngineEnabled(legacyCode);
    }

    public static boolean isVipOnly(int legacyCode) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        return runtime != null && runtime.configStore().isVipOnly(legacyCode);
    }

    /** 返回 SDK 人工可选白名单与当前 App 后台配置的交集。 */
    public static synchronized List<TranslationEngineInfo> getSelectableEngines() {
        requireInitialized();
        List<TranslationEngineInfo> result = new ArrayList<>();
        java.util.Set<Integer> added = new java.util.HashSet<>();
        // Preserve the established user-facing order for engines with localized metadata.
        for (TranslationEnginePresentationCatalog.Entry metadata : TranslationEnginePresentationCatalog.entries()) {
            TranslationEngineInfo info = buildSelectableEngine(metadata.id);
            if (info != null) {
                result.add(info);
                added.add(info.getId());
            }
        }
        // Backend-marked engines without local presentation metadata are appended in config order.
        for (Integer legacyCode : TranslationRuntime.get().configStore().configuredEngineIds()) {
            if (added.contains(legacyCode)) continue;
            TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
            TranslationEngineInfo info = id == null ? null : buildSelectableEngine(id);
            if (info != null) result.add(info);
        }
        return Collections.unmodifiableList(result);
    }

    /** 只查询用户可选目录；隐藏的降级引擎不会由此方法返回。 */
    public static synchronized TranslationEngineInfo findEngine(int legacyCode) {
        requireInitialized();
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        return id == null ? null : buildSelectableEngine(id);
    }

    public static synchronized boolean isEngineSelectable(int legacyCode) {
        return findEngine(legacyCode) != null;
    }

    /**
     * 把 App 传入的已保存 ID 应用到当前进程。SDK 不读取或写入任何 ID 持久化存储。
     * 没有历史值时仅在内存中使用首个健康、免费且可选的引擎；已保存 ID 不可用时明确拒绝并
     * 保持当前选择，不静默换 ID。
     */
    public static synchronized EngineSelectionResult restoreSelectedEngine(int savedLegacyCode) {
        requireInitialized();
        int previous = selectedEngineId;
        if (savedLegacyCode == EngineSelectionResult.NO_ENGINE) {
            int defaultEngine = findDefaultEngineId();
            if (defaultEngine == EngineSelectionResult.NO_ENGINE) {
                return new EngineSelectionResult(savedLegacyCode, previous, previous,
                        EngineSelectionOutcome.REJECTED, EngineSelectionReason.NO_AVAILABLE_ENGINE);
            }
            selectedEngineId = defaultEngine;
            return new EngineSelectionResult(savedLegacyCode, previous, selectedEngineId,
                    previous == selectedEngineId
                            ? EngineSelectionOutcome.UNCHANGED : EngineSelectionOutcome.APPLIED,
                    EngineSelectionReason.NONE);
        }
        // Preserve an existing paid selection after membership expires. Execution policy below
        // routes it to free engines without overwriting the user's saved brand choice.
        EngineSelectionReason reason = validateSelection(savedLegacyCode, false);
        if (reason == EngineSelectionReason.NONE) {
            selectedEngineId = savedLegacyCode;
            return new EngineSelectionResult(savedLegacyCode, previous, selectedEngineId,
                    previous == selectedEngineId
                            ? EngineSelectionOutcome.UNCHANGED : EngineSelectionOutcome.APPLIED,
                    EngineSelectionReason.NONE);
        }
        return new EngineSelectionResult(savedLegacyCode, previous, previous,
                EngineSelectionOutcome.REJECTED, reason);
    }

    /** 用户主动切换；失败时保持当前选择不变，也不会静默改成另一个 ID。 */
    public static synchronized EngineSelectionResult selectEngine(int legacyCode) {
        requireInitialized();
        int previous = selectedEngineId;
        EngineSelectionReason reason = validateSelection(legacyCode, true);
        if (reason != EngineSelectionReason.NONE) {
            return new EngineSelectionResult(legacyCode, previous, previous,
                    EngineSelectionOutcome.REJECTED, reason);
        }
        selectedEngineId = legacyCode;
        return new EngineSelectionResult(legacyCode, previous, selectedEngineId,
                previous == selectedEngineId
                        ? EngineSelectionOutcome.UNCHANGED : EngineSelectionOutcome.APPLIED,
                EngineSelectionReason.NONE);
    }

    /** VIP 或后台配置变化后只重新校验；失败也保持用户选择 ID。 */
    public static synchronized EngineSelectionResult refreshSelection() {
        requireInitialized();
        int current = selectedEngineId;
        EngineSelectionReason reason = validateSelection(current, false);
        return new EngineSelectionResult(current, current, current,
                reason == EngineSelectionReason.NONE
                        ? EngineSelectionOutcome.UNCHANGED : EngineSelectionOutcome.REJECTED,
                reason);
    }

    /** 返回进程内真实整数 ID；App 应保存成功选择结果中的 selectedId。 */
    public static int getSelectedEngineId() { return selectedEngineId; }

    /** 按当前选择创建只暴露 SDK 领域模型的 Translator。 */
    public static synchronized Translator createTranslator() {
        requireInitialized();
        // Each request still gets its own cancellable Provider control. Creating and closing
        // an extra control here only to validate the selection does not prepare a connection.
        if (validateSelection(selectedEngineId, false) != EngineSelectionReason.NONE) return null;
        return managedTranslator(selectedEngineId);
    }

    /**
     * Creates a Translator whose primary engine is fixed for this object only.
     * This does not read, change or persist the App's user-selected engine ID. Backend-hidden
     * engines are allowed because selectable controls presentation, not execution/fallback use.
     */
    public static synchronized Translator createTranslator(int legacyCode) {
        requireInitialized();
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null || id.isRetired() || !isEngineEnabled(legacyCode)) return null;
        return managedTranslator(legacyCode);
    }

    /** In-memory exact-result reuse for non-AI engines; 0 disables, default 15000 ms. */
    public static void configureResultCache(long ttlMs) {
        com.mg.translation.internal.runtime.ManagedTranslator.configureResultCache(ttlMs);
    }

    private static Translator managedTranslator(int engineId) {
        TranslatorId id = TranslatorId.fromLegacyCode(engineId);
        return new com.mg.translation.internal.runtime.ManagedTranslator(engineId,
                id.category != com.mg.translation.engine.EngineCategory.AI,
                deadline -> createAttemptTranslator(engineId, deadline),
                (fallbackId, deadline) -> createEmergencyAttemptTranslator(fallbackId, deadline));
    }

    private static Translator createAttemptTranslator(int engineId, long deadline) {
        if (!isInitialized() || !isEngineEnabled(engineId)) return null;
        TranslateControl control = TranslateFactory.createTranslate(
                TranslationRuntime.get().context(), engineId);
        control = applyVipExecutionPolicy(control, engineId);
        return control == null ? null : new SdkTranslatorAdapter(control, deadline);
    }

    private static Translator createEmergencyAttemptTranslator(int engineId, long deadline) {
        if (!isInitialized() || !isEngineEnabled(engineId)) return null;
        TranslateControl control = TranslateFactory.createTranslate(
                TranslationRuntime.get().context(), engineId);
        return control == null ? null : new SdkTranslatorAdapter(control, deadline, true);
    }

    /** Best-effort warm-up for the first two eligible engines, starting with the selection. */
    public static synchronized boolean preconnect() {
        requireInitialized();
        return TranslationPreconnector.preconnect(TranslatorId.fromLegacyCode(selectedEngineId));
    }

    /**
     * Best-effort asynchronous DNS/TCP/TLS warm-up using the SDK-owned connection pool.
     * No credential or text is sent and no translation quota/fallback/cooldown is consumed.
     */
    public static synchronized boolean preconnect(int legacyCode) {
        requireInitialized();
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null || id.isRetired() || !isEngineEnabled(legacyCode)) return false;
        return TranslationPreconnector.preconnect(id);
    }

    private static TranslateControl applyVipExecutionPolicy(
            TranslateControl control, int requestedEngineId) {
        if (control == null) return null;
        TranslationRuntime runtime = TranslationRuntime.get();
        return runtime.configStore().isVipOnly(requestedEngineId)
                ? new NonVipFallbackTranslateControl(runtime.context(), control) : control;
    }

    /** 返回具体 Translator 的语言快照；隐藏降级引擎也可按已启用 ID 查询。 */
    public static synchronized List<TranslationLanguageInfo> getSupportedLanguages(int legacyCode) {
        requireInitialized();
        if (!isEngineEnabled(legacyCode)) return Collections.emptyList();
        Context context = TranslationRuntime.get().context();
        String localeTag = context.getResources().getConfiguration()
                .getLocales().get(0).toLanguageTag();
        List<TranslationLanguageInfo> cached = TranslationLanguageCatalogCache.get(
                legacyCode, localeTag);
        if (cached != null) return cached;
        TranslateControl control = createEnabledTranslator(legacyCode);
        if (control == null) return Collections.emptyList();
        try {
            List<LanguageVO> languages = control.getSupportLanguage();
            if (languages == null || languages.isEmpty()) return Collections.emptyList();
            List<TranslationLanguageInfo> result = new ArrayList<>(languages.size());
            for (LanguageVO language : languages) {
                if (language == null || TextUtils.isEmpty(language.getKey())) continue;
                String selectionId = TextUtils.isEmpty(language.getLanguageKey())
                        ? language.getKey() : language.getLanguageKey();
                result.add(new TranslationLanguageInfo(
                        language.getKey(), selectionId,
                        resolveString(context, language.getCountry(), language.getKey()),
                        language.getValue(),
                        resolveString(context, language.getLanguageCountry(), null)));
            }
            List<TranslationLanguageInfo> immutable = Collections.unmodifiableList(result);
            TranslationLanguageCatalogCache.put(legacyCode, localeTag, immutable);
            return immutable;
        } finally {
            control.close();
        }
    }

    public static TranslationLanguageInfo findLanguage(int legacyCode, String languageId) {
        if (languageId == null) return null;
        for (TranslationLanguageInfo language : getSupportedLanguages(legacyCode)) {
            if (languageId.equals(language.getLanguageId())
                    || languageId.equals(language.getSelectionId())) return language;
        }
        return null;
    }

    public static boolean supportsLanguage(int legacyCode, String languageId) {
        return findLanguage(legacyCode, languageId) != null;
    }

    public static TranslationLanguageInfo getDefaultLanguage(int legacyCode) {
        List<TranslationLanguageInfo> languages = getSupportedLanguages(legacyCode);
        return languages.isEmpty() ? null : languages.get(0);
    }

    public static synchronized boolean supportsAutoSource(int legacyCode) {
        requireInitialized();
        TranslateControl control = createEnabledTranslator(legacyCode);
        if (control == null) return false;
        try {
            return control.isSupportAuto();
        } finally {
            control.close();
        }
    }

    private static TranslationEngineInfo buildSelectableEngine(TranslatorId id) {
        TranslationConfigStore value = TranslationRuntime.get().configStore();
        if (id.isRetired()
                || !value.isEngineEnabled(id.legacyCode)
                || !value.isSelectable(id.legacyCode)
                || (id.requiresEndpointCredential()
                && !value.hasEndpointCredential(id.legacyCode))) {
            return null;
        }
        TranslateControl control = TranslateFactory.createTranslate(
                TranslationRuntime.get().context(), id.legacyCode);
        if (control == null) return null;
        try {
            TranslationEnginePresentationCatalog.Entry metadata = TranslationEnginePresentationCatalog.find(id.legacyCode);
            boolean vipOnly = value.isVipOnly(id.legacyCode);
            boolean locked = vipOnly && !TranslationRuntime.get().host().isVip();
            if (metadata == null) return null;
            String name = TranslationRuntime.get().string(metadata.nameRes);
            String description = TranslationRuntime.get().string(metadata.descriptionRes);
            return new TranslationEngineInfo(id.legacyCode, name, description, metadata.iconRes,
                    id.category, vipOnly, locked,
                    id.category == EngineCategory.AI,
                    metadata != null ? metadata.slow : id.category == EngineCategory.AI,
                    control.isSupportAuto());
        } finally {
            control.close();
        }
    }

    private static TranslateControl createEnabledTranslator(int legacyCode) {
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null || id.isRetired() || !isEngineEnabled(legacyCode)) return null;
        return TranslateFactory.createTranslate(TranslationRuntime.get().context(), legacyCode);
    }

    private static EngineSelectionReason validateSelection(int legacyCode, boolean enforceVip) {
        TranslatorId id = TranslatorId.fromLegacyCode(legacyCode);
        if (id == null) return EngineSelectionReason.INVALID_ID;
        if (id.isRetired()) return EngineSelectionReason.RETIRED_ENGINE;
        TranslationConfigStore value = TranslationRuntime.get().configStore();
        if (!value.isEngineEnabled(legacyCode)) {
            return EngineSelectionReason.NOT_CONFIGURED;
        }
        if (!value.isSelectable(legacyCode)) return EngineSelectionReason.NOT_SELECTABLE;
        if (id.requiresEndpointCredential() && !value.hasEndpointCredential(legacyCode)) {
            return EngineSelectionReason.NOT_CONFIGURED;
        }
        if (enforceVip && value.isVipOnly(legacyCode)
                && !TranslationRuntime.get().host().isVip()) {
            return EngineSelectionReason.VIP_REQUIRED;
        }
        return EngineSelectionReason.NONE;
    }

    private static int findDefaultEngineId() {
        for (int id : com.mg.translation.utils.TranslateUtils.fallbackOrder()) {
            if (validateSelection(id, true) != EngineSelectionReason.NONE || isVipOnly(id)) continue;
            // Default selection is a pure in-memory choice. Provider cooldowns and
            // reachability are checked when the request actually starts, off the UI thread.
            TranslatorId engine = TranslatorId.fromLegacyCode(id);
            if ((engine == TranslatorId.GOOGLE || engine == TranslatorId.GOOGLE_CLIENT)
                    && (!TranslationRuntime.get().host().isGoogleReachable()
                    || !TranslationRuntime.get().googleReachability().isKnownReachable(id))) continue;
            return id;
        }
        return EngineSelectionResult.NO_ENGINE;
    }

    private static String resolveString(Context context, int resourceId, String fallback) {
        if (resourceId == 0) return fallback;
        try {
            return context.getString(resourceId);
        } catch (Resources.NotFoundException error) {
            return fallback;
        }
    }

    private static void requireInitialized() {
        if (!isInitialized()) throw new IllegalStateException("TranslationSdk is not initialized");
    }
}
