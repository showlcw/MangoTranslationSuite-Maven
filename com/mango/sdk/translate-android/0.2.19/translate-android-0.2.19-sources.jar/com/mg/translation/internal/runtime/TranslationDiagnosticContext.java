package com.mg.translation.internal.runtime;

/** A bounded, content-free host label captured when a public request is submitted. */
public final class TranslationDiagnosticContext {
    private static final ThreadLocal<State> CURRENT = new ThreadLocal<>();
    private static final State NONE = new State("unspecified", 0L);

    private TranslationDiagnosticContext() { }

    public static void run(String scenario, long hostRequestId, Runnable action) {
        if (action == null) throw new IllegalArgumentException("action is required");
        if (!ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            action.run();
            return;
        }
        State previous = CURRENT.get();
        CURRENT.set(new State(normalize(scenario), Math.max(0L, hostRequestId)));
        try { action.run(); }
        finally {
            if (previous == null) CURRENT.remove();
            else CURRENT.set(previous);
        }
    }

    public static State snapshot() {
        State state = CURRENT.get();
        return state == null ? NONE : state;
    }

    private static String normalize(String value) {
        if (value == null) return "unspecified";
        switch (value) {
            case "text_input":
            case "screen_quick":
            case "subtitle":
            case "auto":
            case "popup":
            case "image":
                return value;
            default:
                return "other";
        }
    }

    public static final class State {
        public final String scenario;
        public final long hostRequestId;

        private State(String scenario, long hostRequestId) {
            this.scenario = scenario;
            this.hostRequestId = hostRequestId;
        }
    }
}
