package com.mg.translation.http.ai;

/** One role/content message in an OpenAI-compatible chat request or response. */
public class OpenAiChatMessage {
    private String role;
    private String content;

    public OpenAiChatMessage() { }

    public OpenAiChatMessage(String role, String content) {
        this.role = role;
        this.content = content;
    }

    public String getRole() { return role; }
    public void setRole(String value) { role = value; }
    public String getContent() { return content; }
    public void setContent(String value) { content = value; }
}
