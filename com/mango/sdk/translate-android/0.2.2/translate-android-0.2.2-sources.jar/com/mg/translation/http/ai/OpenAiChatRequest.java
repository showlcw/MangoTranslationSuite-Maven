package com.mg.translation.http.ai;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;

/** Provider-neutral request body for an OpenAI-compatible chat completion endpoint. */
public class OpenAiChatRequest extends BaseReq {
    private List<OpenAiChatMessage> messages;
    private String model;
    private boolean stream;
    private float temperature = 0.3f;

    public OpenAiChatRequest(List<OpenAiChatMessage> messages) { this.messages = messages; }
    public List<OpenAiChatMessage> getMessages() { return messages; }
    public void setMessages(List<OpenAiChatMessage> value) { messages = value; }
    public String getModel() { return model; }
    public void setModel(String value) { model = value; }
    public boolean isStream() { return stream; }
    public void setStream(boolean value) { stream = value; }
    public float getTemperature() { return temperature; }
    public void setTemperature(float value) { temperature = value; }
}
