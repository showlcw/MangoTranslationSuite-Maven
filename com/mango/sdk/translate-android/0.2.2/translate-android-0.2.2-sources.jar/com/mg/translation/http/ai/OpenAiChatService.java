package com.mg.translation.http.ai;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

/** Transport contract shared only by Providers exposing OpenAI-compatible chat completions. */
public interface OpenAiChatService {
    @POST("chat/completions")
    Single<OpenAiChatResponse> translate(@Header("Authorization") String authorization,
                                         @Header("Content-type") String contentType,
                                         @Header("Accept") String accept,
                                         @Body RequestBody requestBody);
}
