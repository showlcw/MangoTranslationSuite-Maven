package com.mg.translation.http.translate;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;

import static com.mg.translation.utils.TranslationPreferenceKeys.AI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEPSEEK_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.QWEN_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.DEEP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_CLIENT_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.GOOGLE_FREE_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.IRCTCAPI_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MEMORY_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MICROSOFT_VIP_TRANSLATE_STATE;
import static com.mg.translation.utils.TranslationPreferenceKeys.MULTI_TRANSLATE_STATE;

import android.content.Context;
import android.text.TextUtils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.HttpUtil;
import com.mg.translation.internal.base.LogManager;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.runtime.ProviderCredential;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.http.ApiServiceCenter;
import com.mg.translation.http.translate.microsoft.dto.MicrosoftTranslateReq;
import com.mg.translation.http.ai.OpenAiChatResponse;
import com.mg.translation.http.ai.OpenAiChatService;
import com.mg.translation.http.translate.common.dto.MeTranslateReq;
import com.mg.translation.internal.base.http.RetrofitServiceManager;
import com.mg.translation.http.translate.baidu.dto.BaiduTranslateHttpResult;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;
import com.mg.translation.http.translate.youdao.dto.YoudaoTranslateHttpResult;
import com.mg.translation.http.translate.qwen.QwenTranslateService;
import com.mg.translation.http.translate.selfhosted.SelfHostedTranslateService;
import com.mg.translation.http.translate.deep.dto.DeepTranslateResult;
import com.mg.translation.http.translate.google.dto.GoogleTranslateResult;
import com.mg.translation.http.translate.ai.dto.RapidAiBatchTranslateResult;
import com.mg.translation.http.translate.ai.dto.RapidAiTranslateResult;
import com.mg.translation.http.translate.irctcapi.dto.IrctcapiTranslateResult;
import com.mg.translation.http.translate.memory.dto.MemoryTranslateResult;
import com.mg.translation.http.translate.microsoft.dto.MicrosoftTranslateResult;
import com.mg.translation.http.translate.plus.dto.PlusBatchTranslateResult;
import com.mg.translation.http.translate.plus.dto.PlusTranslateResult;
import com.mg.translation.http.translate.plus.RapidPlusGateway;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateResult;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusTranslateResult;
import com.mg.translation.http.translate.websiteplus.WebsitePlusGateway;
import com.mg.translation.http.translate.baidu.dto.TransResultBean;
import com.mg.translation.utils.TranslateUtils;

import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import io.reactivex.Single;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.HttpException;

/**
 * @author Catherine Liu
 * 2021/11/18 18:48
 * 壁纸数据请求动作
 **/
public final class TranslateRepository {
    private static final String QWEN_DATA_INSPECTION_DISABLED =
            "{\"input\":\"disable\",\"output\":\"disable\"}";
    private static TranslateRepository mInstance = null;
    public static final String BAIDU_URL = "https://fanyi-api.baidu.com/";
    public static final String GOOGLE_TRANSLATE_URL = "https://translate.googleapis.com/";
    public static final String GOOGLE_TRANSLATE_VIP_URL = "https://translation.googleapis.com/";
    public static final String GOOGLE_TRANSLATE_CLIENT_URL = "https://clients5.google.com/";
    public static final String DEEP_TRANSLATE_URL = "https://deep-translate1.p.rapidapi.com/";
    public static final String PLUS_TRANSLATE_URL = "https://translate-plus.p.rapidapi.com/";
    public static final String WEBSITE_PLUS_TRANSLATE_URL = "https://api.translateplus.io/";

    public static final String AI_TRANSLATE_URL = "https://ai-translate.p.rapidapi.com/";
    public static final String MICROSOFT_TRANSLATE_URL = "https://api.cognitive.microsofttranslator.com/";
    public static final String YOUDAO_TRANSLATE_URL = "https://openapi.youdao.com/";




    public static final String MEMORY_TRANSLATE_URL = "https://api.mymemory.translated.net/";

    public static final String MULTI_TRANSLATE_URL = "https://rapid-translate-multi-traduction.p.rapidapi.com/";

    public static final String IRCTCAPI_TRANSLATE_URL = "https://google-translator9.p.rapidapi.com/";


    public static final String ME_TRANSLATE_URL = "https://translate.mgthly.com/";
    public static final String DEEPSEEK_TRANSLATE_URL = "https://api.deepseek.com/";

    private TranslateRepository() {
    }

    public static TranslateRepository getInstance() {
        if (mInstance == null) {
            mInstance = new TranslateRepository();
        }
        return mInstance;
    }

    /**
     * 百度翻译
     */
    public Single<BaiduTranslateHttpResult<List<TransResultBean>>> baiduTranslate(BaseReq baiduTranslateReq) {
        return ApiServiceCenter.getInstance().getBaiduTranslateService()
                .baiduTranslate(HttpUtil.convertReq2Params(baiduTranslateReq));
    }

    /** BD 作为独立 Provider，由 SDK 使用 BD 自己的配置直接请求。 */
    public Single<MeTranslateHttpResult> bdTranslate(MeTranslateReq request) {
        return selfHostedTranslate(request, TranslatorId.BD.legacyCode, false);
    }

    /** SELF_HOSTED_GOOGLE 作为独立 Provider，由 SDK 使用该引擎自己的配置直接请求。 */
    public Single<MeTranslateHttpResult> selfHostedGoogleTranslate(MeTranslateReq request) {
        return selfHostedTranslate(request,
                TranslatorId.SELF_HOSTED_GOOGLE.legacyCode, true);
    }

    private Single<MeTranslateHttpResult> selfHostedTranslate(
            MeTranslateReq request, int engineId, boolean google) {
        ProviderCredential credential = TranslationRuntime.get()
                .providerCredential(engineId, null);
        if (TextUtils.isEmpty(credential.getBaseUrl()) || TextUtils.isEmpty(credential.getApiKey())) {
            MeTranslateHttpResult error = new MeTranslateHttpResult();
            error.setCode(TranslationErrorCode.UNKNOWN);
            error.setErrorMessage("Provider endpoint or credential is not configured");
            return Single.just(error);
        }
        SelfHostedTranslateService service = RetrofitServiceManager.getInstance()
                .createTranslate(credential.getBaseUrl(), SelfHostedTranslateService.class);
        Single<MeTranslateHttpResult> call = google
                ? service.googleTranslate(credential.getApiKey(), createJsonRequestBody(request))
                : service.baiduTranslate(credential.getApiKey(), createJsonRequestBody(request));
        return call;
    }


    /**
     * 自己的翻译
     */
    private RequestBody createJsonRequestBody(BaseReq request) {
        MediaType mediaType = MediaType.parse("application/json");
        return RequestBody.create(mediaType, GsonUtil.toJson(request));
    }

    /**
     * 自己的翻译
     */
    public Single<MeTranslateHttpResult> ydTranslate(BaseReq meTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, GsonUtil.toJson(meTranslateReq));
        return ApiServiceCenter.getInstance().getMeTranslateService().youdaoTranslate(body);
    }

    /** 有道官方翻译。 */
    public Single<YoudaoTranslateHttpResult> youdaoTranslate(BaseReq ydTranslateReq, String[] qStringArray) {
        Map<String, String> map = HttpUtil.convertReq2Params(ydTranslateReq);

        FormBody.Builder builder = new FormBody.Builder();
        for (Map.Entry<String, String> en : map.entrySet()) {
            String key = en.getKey();
            String value = en.getValue();
            builder.add(key, value);
        }
        for (String str : qStringArray) {
            builder.add("q", str);
        }
        return ApiServiceCenter.getInstance().getYoudaoTranslateService()
                .youdaoTranslate(builder.build());
    }

    /**
     * Google翻译
     */
    public Single<String> googleTranslate(Context context, BaseReq googleTranslateReq) {
        return ApiServiceCenter.getInstance().getGoogleTranslateService()
                .googleTranslate(HttpUtil.convertReq2Params(googleTranslateReq))
                .doOnError(error -> markProviderFailure(context, GOOGLE_FREE_TRANSLATE_STATE));
    }

    /**
     * Google翻译
     */
    public Single<String> googleClientTranslate(Context context, BaseReq googleTranslateReq) {
        return ApiServiceCenter.getInstance().getGoogleClientTranslateService()
                .googleClientTranslate(HttpUtil.convertReq2Params(googleTranslateReq))
                .doOnError(error -> markProviderFailure(context, GOOGLE_FREE_CLIENT_STATE));
    }

    /** Google Cloud Translation v2. */
    public Single<GoogleTranslateResult> googleTranslateVip(Context context,
                                                             BaseReq googleTranslateReq,
                                                             String key) {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, GsonUtil.toJson(googleTranslateReq));
        Map<String, String> map = new HashMap<>();
        map.put("key", key);
        return ApiServiceCenter.getInstance().getGoogleVipTranslateService().googleTranslateVip(
                        context.getPackageName(), TranslateUtils.getAppSignatureSha1(context), map, body)
                .onErrorReturn(error -> {
                    GoogleTranslateResult result = new GoogleTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else if (error instanceof HttpException) {
                        LogManager.e("Provider HTTP request failed");
                        result.setCode(TranslationErrorCode.PROVIDER_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                    }
                    return result;
                });
    }


    /**
     * deep翻译
     */
    public Single<DeepTranslateResult> deepTranslate(Context context, BaseReq deepTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, GsonUtil.toJson(deepTranslateReq));
        return ApiServiceCenter.getInstance().getDeepTranslateService().deepTranslate(
                "deep-translate1.p.rapidapi.com",
                TranslateUtils.getDeepRapidApiKey(context), "application/json",
                body)
                .onErrorReturn(error -> {
                    DeepTranslateResult result = new DeepTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, DEEP_TRANSLATE_STATE);
                    }
                    return result;
                });
    }


    /**
     * deep翻译  列表
     */
    public Single<DeepTranslateResult> deepJsonTranslate(Context context, BaseReq deepTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, GsonUtil.toJson(deepTranslateReq));
        return ApiServiceCenter.getInstance().getDeepTranslateService().deepJsonTranslate(
                "deep-translate1.p.rapidapi.com",
                TranslateUtils.getDeepRapidApiKey(context), "application/json",
                body)
                .onErrorReturn(error -> {
                    DeepTranslateResult result = new DeepTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, DEEP_TRANSLATE_STATE);
                    }
                    return result;
                });
    }


    /**
     * plus翻译  批量
     */
    public Single<PlusBatchTranslateResult> plusBatchTranslate(Context context, BaseReq plusBatchTranslateReq) {
        return RapidPlusGateway.getInstance().translateBatch(context, plusBatchTranslateReq);
    }

    /**
     * plus翻译
     */
    public Single<PlusTranslateResult> plusTranslate(Context context, BaseReq plusTranslateReq) {
        return RapidPlusGateway.getInstance().translate(context, plusTranslateReq);
    }

    /** TranslatePlus direct batch endpoint. */
    public Single<WebsitePlusBatchTranslateResult> webSitePlusBatchTranslate(
            Context context, BaseReq plusBatchTranslateReq) {
        return WebsitePlusGateway.getInstance().translateBatch(context, plusBatchTranslateReq);
    }

    /** TranslatePlus direct single endpoint. */
    public Single<WebsitePlusTranslateResult> webSitePlusTranslate(
            Context context, BaseReq plusTranslateReq) {
        return WebsitePlusGateway.getInstance().translate(context, plusTranslateReq);
    }

    /**
     * Ai翻译
     */
    public Single<RapidAiBatchTranslateResult> aiJsonTranslate(Context context, BaseReq transloTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        String content = GsonUtil.toJson(transloTranslateReq);
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getAiTranslateService().aiJsonTranslate(
                "ai-translate.p.rapidapi.com",
                TranslateUtils.getAiRapidApiKey(context),
                body)
                .onErrorReturn(error -> {
                    RapidAiBatchTranslateResult result = new RapidAiBatchTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, AI_TRANSLATE_STATE);
                    }
                    return result;
                });
    }


    /**
     * multi翻译
     */
    public Single<List<List<String>>> multiJsonTranslate(Context context, BaseReq transloTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        String content = GsonUtil.toJson(transloTranslateReq);
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getMultiTranslateService().multiJsonTranslate(
                "rapid-translate-multi-traduction.p.rapidapi.com",
                TranslateUtils.getMultiRapidApiKey(context),
                body)
                .doOnError(error -> markProviderFailure(context, MULTI_TRANSLATE_STATE))
                .onErrorReturnItem(Collections.emptyList());
    }


    /**
     * multi翻译
     */
    public Single<List<List<String>>> multiTranslate(Context context, BaseReq transloTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        String content = GsonUtil.toJson(transloTranslateReq);
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getMultiTranslateService().multiTranslate(
                "rapid-translate-multi-traduction.p.rapidapi.com",
                TranslateUtils.getMultiRapidApiKey(context),
                body)
                .doOnError(error -> markProviderFailure(context, MULTI_TRANSLATE_STATE))
                .onErrorReturnItem(Collections.emptyList());
    }


    /**
     * memory翻译
     */
    public Single<MemoryTranslateResult> memoryTranslate(Context context, BaseReq googleTranslateReq) {
        return ApiServiceCenter.getInstance().getMemoryTranslateService()
                .memoryTranslate(HttpUtil.convertReq2Params(googleTranslateReq))
                .onErrorReturn(error -> {
                    MemoryTranslateResult result = new MemoryTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setResponseStatus(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setResponseStatus(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, MEMORY_TRANSLATE_STATE);
                    }
                    return result;
                });
    }



    /**
     * heBingBing翻译
     */
    public Single<RapidAiTranslateResult> aiTranslate(Context context, BaseReq transloTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        String content = GsonUtil.toJson(transloTranslateReq);
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getAiTranslateService().aiTranslate(
                "ai-translate.p.rapidapi.com",
                TranslateUtils.getAiRapidApiKey(context),
                body)
                .onErrorReturn(error -> {
                    RapidAiTranslateResult result = new RapidAiTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, AI_TRANSLATE_STATE);
                    }
                    return result;
                });
    }



    public Single<MicrosoftTranslateResult> microsoftTranslateVip(
            Context context, MicrosoftTranslateReq microsoftTranslateReq, String content) {
        String key = TranslateUtils.getMicrosoftApiKey(context);
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getMicrosoftTranslateService().microsoftTranslate(
                        "global", key, "application/json",
                        HttpUtil.convertReq2Params(microsoftTranslateReq), body)
                .map(list -> {
                    MicrosoftTranslateResult result = new MicrosoftTranslateResult();
                    result.setCode(200);
                    result.setResult(list);
                    return result;
                })
                .onErrorReturn(error -> {
                    MicrosoftTranslateResult result = new MicrosoftTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, MICROSOFT_VIP_TRANSLATE_STATE);
                    }
                    return result;
                });
    }

    /** Microsoft free translation. */
    public Single<MicrosoftTranslateResult> microsoftTranslate(Context context, MicrosoftTranslateReq microsoftTranslateReq, String content) {
        String key = TranslateUtils.getFreeMicrosoftApiKey(context);
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getMicrosoftTranslateService().microsoftTranslate(
                "eastasia", key, "application/json", HttpUtil.convertReq2Params(microsoftTranslateReq), body)
                .map(list -> {
                    MicrosoftTranslateResult result = new MicrosoftTranslateResult();
                    result.setCode(200);
                    result.setResult(list);
                    return result;
                })
                .onErrorReturn(error -> {
                    MicrosoftTranslateResult result = new MicrosoftTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, MICROSOFT_TRANSLATE_STATE);
                    }
                    return result;
                });
    }

    /**
     * irctcapi翻译
     */
    public Single<IrctcapiTranslateResult> irctcapiTranslateText(Context context, BaseReq devTranslateReq) {
        MediaType mediaType = MediaType.parse("application/json");
        String content = GsonUtil.toJson(devTranslateReq);
        RequestBody body = RequestBody.create(mediaType, content);
        return ApiServiceCenter.getInstance().getIrctcapiTranslateService().irctcapiTranslate(
                "google-translator9.p.rapidapi.com",
                TranslateUtils.getIrctcapiRapidApiKey(context), body)
                .onErrorReturn(error -> {
                    IrctcapiTranslateResult result = new IrctcapiTranslateResult();
                    if (!TranslateUtils.isNetworkConnected(context)) {
                        result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
                    } else {
                        result.setCode(TranslationErrorCode.UNKNOWN);
                        markProviderFailure(context, IRCTCAPI_TRANSLATE_STATE);
                    }
                    return result;
                });
    }

    /** Server-configured OpenAI-compatible AI translation engine. */
    public Single<OpenAiChatResponse> openAiChatTranslate(
            Context context, int engineId, BaseReq request) {
        ProviderCredential credential = TranslationRuntime.get().providerCredential(
                engineId, defaultOpenAiCompatibleBaseUrl(engineId));
        if (TextUtils.isEmpty(credential.getApiKey())
                || TextUtils.isEmpty(credential.getBaseUrl())) {
            OpenAiChatResponse error = new OpenAiChatResponse();
            error.setCode(TranslationErrorCode.UNKNOWN);
            return Single.just(error);
        }
        JsonObject payload = JsonParser.parseString(
                GsonUtil.toJson(request)).getAsJsonObject();
        if (!TextUtils.isEmpty(credential.getModel())) {
            payload.addProperty("model", credential.getModel());
        }
        addReasoningControl(payload, credential);
        addOpenRouterProviderRouting(payload, credential);
        MediaType mediaType = MediaType.parse("application/json; charset=UTF-8");
        String content = payload.toString();
        RequestBody body = RequestBody.create(mediaType, content);
        OpenAiChatService service = RetrofitServiceManager.getInstance()
                .createLlmTranslate(credential.getBaseUrl(), OpenAiChatService.class);
        return service.translate("Bearer " + credential.getApiKey(),
                        "application/json", "application/json", body)
                .doOnError(error -> markProviderFailure(
                        context, com.mg.translation.utils.TranslationPreferenceKeys
                                .aiEngineState(engineId)));
    }

    private String defaultOpenAiCompatibleBaseUrl(int engineId) {
        if (engineId == TranslatorId.DEEPSEEK.legacyCode) return DEEPSEEK_TRANSLATE_URL;
        return null;
    }

    /**
     * Translation defaults to non-reasoning. DeepSeek and OpenRouter expose different
     * wire parameters, so the Provider-specific field is added only at the HTTP boundary.
     */
    private void addReasoningControl(JsonObject payload, ProviderCredential credential) {
        if (credential.isReasoningEnabled()) return;
        String protocol = credential.getProtocol();
        if (TextUtils.isEmpty(protocol)) {
            String baseUrl = credential.getBaseUrl().toLowerCase(java.util.Locale.ROOT);
            protocol = baseUrl.contains("openrouter.ai/") ? "openrouter"
                    : baseUrl.contains("api.deepseek.com/") ? "deepseek" : "openai";
        }
        JsonObject control = new JsonObject();
        if ("openrouter".equalsIgnoreCase(protocol)) {
            control.addProperty("effort", "none");
            payload.add("reasoning", control);
        } else if ("deepseek".equalsIgnoreCase(protocol)) {
            control.addProperty("type", "disabled");
            payload.add("thinking", control);
        }
    }

    private void addOpenRouterProviderRouting(JsonObject payload,
                                              ProviderCredential credential) {
        JsonObject routing = credential.getProviderRouting();
        if (routing != null && "openrouter".equalsIgnoreCase(credential.getProtocol())) {
            payload.add("provider", routing);
        }
    }

    /** Backward-compatible Zhipu entry; transport is selected by the active server profile. */
    public Single<OpenAiChatResponse> zhipuTranslateText(Context context, BaseReq zhipuTranslateReq) {
        return openAiChatTranslate(
                context, TranslatorId.ZHIPU_FLASH.legacyCode, zhipuTranslateReq);
    }

    /** Qwen Provider 直连 DashScope；端点和 Key 均取自对应整数引擎配置。 */
    public Single<OpenAiChatResponse> qwenTranslateText(
            Context context, int engineId, BaseReq qwenTranslateReq) {
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json; charset=UTF-8"),
                GsonUtil.toJson(qwenTranslateReq));
        ProviderCredential config = TranslationRuntime.get().providerCredential(engineId, null);
        if (TextUtils.isEmpty(config.getApiKey()) || TextUtils.isEmpty(config.getBaseUrl())) {
            OpenAiChatResponse error = new OpenAiChatResponse();
            error.setCode(TranslationErrorCode.UNKNOWN);
            return Single.just(error);
        }
        if (qwenTranslateReq instanceof com.mg.translation.http.translate.qwen.dto.QwenMtTranslateReq) {
            com.mg.translation.http.translate.qwen.dto.QwenMtTranslateReq request =
                    (com.mg.translation.http.translate.qwen.dto.QwenMtTranslateReq) qwenTranslateReq;
            request.setModel(config.getModel());
            if (!TextUtils.isEmpty(config.getDomains())
                    && request.getTranslationOptions() != null) {
                request.getTranslationOptions().setDomains(config.getDomains());
            }
            body = RequestBody.create(
                    MediaType.parse("application/json; charset=UTF-8"),
                    GsonUtil.toJson(request));
        }
        QwenTranslateService service = RetrofitServiceManager.getInstance()
                .createLlmTranslate(config.getBaseUrl(), QwenTranslateService.class);
        // Alibaba Cloud Model Studio regional MaaS compatible endpoints reject the DashScope-only
        // X-DashScope-DataInspection header with HTTP 400. Keep the server switch for native
        // DashScope endpoints, but omit the header entirely for *.maas.aliyuncs.com.
        boolean regionalMaas = config.getBaseUrl().toLowerCase(java.util.Locale.ROOT)
                .contains(".maas.aliyuncs.com/");
        return service.translate("Bearer " + config.getApiKey(), "application/json", "application/json",
                        config.isDataInspectionEnabled() && !regionalMaas
                                ? QWEN_DATA_INSPECTION_DISABLED : null,
                        body)
                .doOnError(error -> markProviderFailure(context, QWEN_TRANSLATE_STATE));
    }

    private void markProviderFailure(Context context, String stateKey) {
        if (TranslateUtils.isNetworkConnected(context)) {
            SdkPreferences.getInstance(context).put(stateKey, System.currentTimeMillis());
        }
    }

}
