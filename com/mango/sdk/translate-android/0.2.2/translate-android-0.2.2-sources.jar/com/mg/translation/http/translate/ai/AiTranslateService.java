package com.mg.translation.http.translate.ai;

import com.mg.translation.http.translate.ai.dto.RapidAiBatchTranslateResult;
import com.mg.translation.http.translate.ai.dto.RapidAiTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface AiTranslateService {

    /**
     * hebingbing  translate
     *
     * @return
     */
    @POST("translate")
    Single<RapidAiBatchTranslateResult> aiJsonTranslate(@Header("x-rapidapi-host") String host, @Header("x-rapidapi-key") String key, @Body RequestBody requestBody);


    /**
     * hebingbing  translate
     *
     * @return
     */
    @POST("translate")
    Single<RapidAiTranslateResult> aiTranslate(@Header("x-rapidapi-host") String host, @Header("x-rapidapi-key") String key, @Body RequestBody requestBody);

}
