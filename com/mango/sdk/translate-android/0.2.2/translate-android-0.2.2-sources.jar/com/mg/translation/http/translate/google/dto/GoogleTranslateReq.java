package com.mg.translation.http.translate.google.dto;

import com.mg.translation.internal.base.http.req.BaseReq;


public class GoogleTranslateReq extends BaseReq {

    private String client = "gtx";
    private String sl = "auto";
    private String hl;
    private String tl;
    private String q;
    private String dt = "t";

//            "client=gtx&sl=" + src +
//            "&hl=" + googleFrom +
//            "&tl=" + target +
//            "&q=" + URLEncoder.encode(content, "utf-8") +
//            "&dt=t";


    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getSl() {
        return sl;
    }

    public void setSl(String sl) {
        this.sl = sl;
    }

    public String getHl() {
        return hl;
    }

    public void setHl(String hl) {
        this.hl = hl;
    }

    public String getTl() {
        return tl;
    }

    public void setTl(String tl) {
        this.tl = tl;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }
}
