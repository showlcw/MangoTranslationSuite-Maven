package com.mg.translation.http.translate.google.dto;

import java.util.List;

public class GoogleTranslateResult {


    private GoogleTranslateArray data;
    private int code;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isSuccess() {
        return code == 0;
    }

    public GoogleTranslateArray getData() {
        return data;
    }

    public void setData(GoogleTranslateArray data) {
        this.data = data;
    }

    public static final class GoogleTranslateBlock {
        private String translatedText;

        public String getTranslatedText() {
            return translatedText;
        }

        public void setTranslatedText(String translatedText) {
            this.translatedText = translatedText;
        }
    }


    public static final class GoogleTranslateArray {
        private List<GoogleTranslateBlock> translations;

        public List<GoogleTranslateBlock> getTranslations() {
            return translations;
        }

        public void setTranslations(List<GoogleTranslateBlock> translations) {
            this.translations = translations;
        }
    }
}
