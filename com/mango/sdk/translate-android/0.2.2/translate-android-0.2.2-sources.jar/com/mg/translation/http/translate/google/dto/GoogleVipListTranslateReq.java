package com.mg.translation.http.translate.google.dto;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.List;


public class GoogleVipListTranslateReq extends BaseReq {

    private String target ;
    private String source;
    private List<String> q;
//    private String key;

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

//    public String getKey() {
//        return key;
//    }
//
//    public void setKey(String key) {
//        this.key = key;
//    }

    public List<String> getQ() {
        return q;
    }

    public void setQ(List<String> q) {
        this.q = q;
    }
}
