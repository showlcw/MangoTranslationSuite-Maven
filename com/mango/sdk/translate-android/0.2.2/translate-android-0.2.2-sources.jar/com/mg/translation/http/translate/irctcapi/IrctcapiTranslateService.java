package com.mg.translation.http.translate.irctcapi;

import com.mg.translation.http.translate.irctcapi.dto.IrctcapiTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface IrctcapiTranslateService {

    /**
     * 翻译json列表
     * @return
     */
    @POST("v2")
    Single<IrctcapiTranslateResult> irctcapiTranslate(@Header("x-rapidapi-host") String host, @Header("x-rapidapi-key") String key, @Body RequestBody requestBody);


}
