package com.mg.translation.http.translate.irctcapi.dto;

import java.util.List;

public class IrctcapiTranslateResult {
    private DataText  data;

    private int code;

    public DataText getData() {
        return data;
    }

    public void setData(DataText data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static final class DataText {
        private List<DataTranslation>  translations;

        public List<DataTranslation> getTranslations() {
            return translations;
        }

        public void setTranslations(List<DataTranslation> translations) {
            this.translations = translations;
        }
    }


    public static final class DataTranslation {

        private String translatedText;

        public String getTranslatedText() {
            return translatedText;
        }

        public void setTranslatedText(String translatedText) {
            this.translatedText = translatedText;
        }
    }
}
