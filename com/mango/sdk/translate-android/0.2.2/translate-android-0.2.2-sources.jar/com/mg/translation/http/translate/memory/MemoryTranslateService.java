package com.mg.translation.http.translate.memory;

import com.mg.translation.http.translate.memory.dto.MemoryTranslateResult;

import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

public interface MemoryTranslateService {

    /**
     * memory  translate
     *
     * @return
     */
    @GET("get")
    Single<MemoryTranslateResult> memoryTranslate(@QueryMap Map<String, String> map);
}
