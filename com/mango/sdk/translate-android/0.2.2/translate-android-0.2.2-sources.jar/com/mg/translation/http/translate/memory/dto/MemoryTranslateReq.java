package com.mg.translation.http.translate.memory.dto;

import com.mg.translation.internal.base.http.req.BaseReq;

import java.util.Random;


public class MemoryTranslateReq extends BaseReq {


//    "langpair=" + src + "|" + target +
//            "&q=" + URLEncoder.encode(content, "utf-8") +
//            "&de=" + getRandomEmail();


    private String langpair ;
    private String de;
    private String q ;

    public MemoryTranslateReq() {
        setDe(getRandomEmail());
    }

    public String getRandomEmail() {
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        int nextInt = random.nextInt(10) + 5;
        while (sb.length() < nextInt) {
            sb.append("abcdefghijklmnopqrstuvwxyz1234567890".charAt((int) (random.nextFloat() * ((float) "abcdefghijklmnopqrstuvwxyz1234567890".length()))));
        }
        return sb.toString() + "@gmail.com";
    }


    public String getLangpair() {
        return langpair;
    }

    public void setLangpair(String langpair) {
        this.langpair = langpair;
    }

    public String getDe() {
        return de;
    }

    public void setDe(String de) {
        this.de = de;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }
}
