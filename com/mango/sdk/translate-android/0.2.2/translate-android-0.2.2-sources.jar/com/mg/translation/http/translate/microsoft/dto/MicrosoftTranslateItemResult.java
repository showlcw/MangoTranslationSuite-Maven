package com.mg.translation.http.translate.microsoft.dto;

import java.util.List;

public class MicrosoftTranslateItemResult {

    private List<MicrosoftTranslateText> translations;

    public List<MicrosoftTranslateText> getTranslations() {
        return translations;
    }

    public void setTranslations(List<MicrosoftTranslateText> translations) {
        this.translations = translations;
    }

    public static final class MicrosoftTranslateText {

        private String text;
        private String to;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getTo() {
            return to;
        }

        public void setTo(String to) {
            this.to = to;
        }
    }


}
