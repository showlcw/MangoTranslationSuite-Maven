package com.mg.translation.http.translate.microsoft.dto;

import java.util.List;

public class MicrosoftTranslateResult {

    private int code;

    private List<MicrosoftTranslateItemResult> result;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<MicrosoftTranslateItemResult> getResult() {
        return result;
    }

    public void setResult(List<MicrosoftTranslateItemResult> result) {
        this.result = result;
    }
}
