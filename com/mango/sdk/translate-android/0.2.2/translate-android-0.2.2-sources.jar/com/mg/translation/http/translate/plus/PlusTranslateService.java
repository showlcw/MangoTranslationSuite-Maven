package com.mg.translation.http.translate.plus;

import com.mg.translation.http.translate.plus.dto.PlusBatchTranslateResult;
import com.mg.translation.http.translate.plus.dto.PlusTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface PlusTranslateService {

    /**
     * PLUS  translate  单条文本
     *
     * @return
     */
    @POST("v2/translate")
    Single<PlusTranslateResult> plusTranslate(@Header("X-RapidAPI-Host") String host, @Header("X-RapidAPI-Key") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);

    /**
     * PLUS  translate  批量文本
     *
     * @return
     */
    @POST("v2/translate/batch")
    Single<PlusBatchTranslateResult> plusBatchTranslate(@Header("X-RapidAPI-Host") String host, @Header("X-RapidAPI-Key") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);

}
