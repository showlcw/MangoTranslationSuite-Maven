package com.mg.translation.http.translate.plus.dto;

import com.mg.translation.internal.base.http.req.BaseReq;


public class PlusTranslateReq extends BaseReq {

    private String text;
    private String source = "auto";
    private String target;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
}
