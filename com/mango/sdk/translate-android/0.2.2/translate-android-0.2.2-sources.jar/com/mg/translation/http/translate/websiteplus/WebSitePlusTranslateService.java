package com.mg.translation.http.translate.websiteplus;

import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateResult;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusTranslateResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface WebSitePlusTranslateService {

    /**
     * WebsitePlus 单条文本
     *
     * @return
     */
    @POST("v2/translate")
    Single<WebsitePlusTranslateResult> websitePlusTranslate(@Header("X-API-KEY") String key,  @Header("Content-type") String contentType, @Body RequestBody requestBody);

    /**
     * WebsitePlus 批量文本
     *
     * @return
     */
    @POST("v2/translate/batch")
    Single<WebsitePlusBatchTranslateResult> websitePlusBatchTranslate(@Header("X-API-KEY") String key, @Header("Content-type") String contentType, @Body RequestBody requestBody);

}
