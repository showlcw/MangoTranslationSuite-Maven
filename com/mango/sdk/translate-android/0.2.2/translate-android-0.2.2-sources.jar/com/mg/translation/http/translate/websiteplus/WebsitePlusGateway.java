package com.mg.translation.http.translate.websiteplus;

import static com.mg.translation.utils.TranslationPreferenceKeys.WEBSITE_PLUS_TRANSLATE_STATE;

import android.content.Context;

import com.mg.translation.http.ApiServiceCenter;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateResult;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusTranslateResult;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.sdk.TranslationErrorCode;

import io.reactivex.Single;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/** Owns the WebsitePlus wire request, credential access and failure cooldown. */
public final class WebsitePlusGateway {
    private static final WebsitePlusGateway INSTANCE = new WebsitePlusGateway();

    private WebsitePlusGateway() { }

    public static WebsitePlusGateway getInstance() {
        return INSTANCE;
    }

    public Single<WebsitePlusBatchTranslateResult> translateBatch(
            Context context, BaseReq request) {
        RequestBody body = jsonBody(request);
        return ApiServiceCenter.getInstance().getWebSitePlusTranslateService()
                .websitePlusBatchTranslate(TranslationRuntime.get().websitePlusKey(),
                        "application/json", body)
                .onErrorReturn(error -> batchError(context));
    }

    public Single<WebsitePlusTranslateResult> translate(Context context, BaseReq request) {
        RequestBody body = jsonBody(request);
        return ApiServiceCenter.getInstance().getWebSitePlusTranslateService()
                .websitePlusTranslate(TranslationRuntime.get().websitePlusKey(),
                        "application/json", body)
                .onErrorReturn(error -> singleError(context));
    }

    private RequestBody jsonBody(BaseReq request) {
        return RequestBody.create(MediaType.parse("application/json"), GsonUtil.toJson(request));
    }

    private WebsitePlusBatchTranslateResult batchError(Context context) {
        WebsitePlusBatchTranslateResult result = new WebsitePlusBatchTranslateResult();
        if (!NetworkUtils.isConnectedAvailableNetwork(context)) {
            result.setLocalErrorCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
        } else {
            result.setLocalErrorCode(TranslationErrorCode.UNKNOWN);
            markFailure(context);
        }
        return result;
    }

    private WebsitePlusTranslateResult singleError(Context context) {
        WebsitePlusTranslateResult result = new WebsitePlusTranslateResult();
        if (!NetworkUtils.isConnectedAvailableNetwork(context)) {
            result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
        } else {
            result.setCode(TranslationErrorCode.UNKNOWN);
            markFailure(context);
        }
        return result;
    }

    private void markFailure(Context context) {
        SdkPreferences.getInstance(context).put(
                WEBSITE_PLUS_TRANSLATE_STATE, System.currentTimeMillis());
    }
}
