package com.mg.translation.http.translate.youdao;

import com.mg.translation.http.translate.youdao.dto.YoudaoTranslateHttpResult;

import io.reactivex.Single;
import okhttp3.FormBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface YoudaoService {

    @POST("v2/api/")
    Single<YoudaoTranslateHttpResult> youdaoTranslate(@Body FormBody requestBody);

}
