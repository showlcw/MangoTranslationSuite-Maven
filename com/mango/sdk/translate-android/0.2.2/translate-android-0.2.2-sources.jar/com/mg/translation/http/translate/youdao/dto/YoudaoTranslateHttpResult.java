package com.mg.translation.http.translate.youdao.dto;

import java.util.List;

/**
 * Created by Shurrik on 2017/11/22.
 */

public class YoudaoTranslateHttpResult {

    private int errorCode;
    private String requestId;
    private List<TranslateResult> translateResults;


    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<TranslateResult> getTranslatedTexts() {
        return translateResults;
    }

    public void setTranslatedTexts(List<TranslateResult> translateResults) {
        this.translateResults = translateResults;
    }

    public static final class TranslateResult {
        //"query": "屏募翻译",
//        "translation": "Screen Recruitment Pagsasalin",
//        "type": "zh-CHS2tl"
        private String query;
        private String translation;
        private String type;

        public String getQuery() {
            return query;
        }

        public void setQuery(String query) {
            this.query = query;
        }

        public String getTranslation() {
            return translation;
        }

        public void setTranslation(String translation) {
            this.translation = translation;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

}
