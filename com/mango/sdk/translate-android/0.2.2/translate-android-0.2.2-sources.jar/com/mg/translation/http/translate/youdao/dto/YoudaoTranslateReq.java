package com.mg.translation.http.translate.youdao.dto;

import com.mg.translation.internal.base.http.req.BaseReq;

public class YoudaoTranslateReq extends BaseReq {

    private String from = "auto";
    private String to;
    private String appKey;
    private String salt;
    private String sign;//appKey+img+salt+curtime+应用密钥的MD5值
    private String signType = "v3";
    private String curtime;//当前UTC时间戳（秒）

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getCurtime() {
        return curtime;
    }

    public void setCurtime(String curtime) {
        this.curtime = curtime;
    }
}
