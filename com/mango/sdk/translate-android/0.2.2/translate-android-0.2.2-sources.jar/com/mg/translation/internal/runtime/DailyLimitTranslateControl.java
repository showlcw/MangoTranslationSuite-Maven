package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

/** Enforces an optional per-install daily request-attempt cap before Provider I/O. */
public final class DailyLimitTranslateControl implements TranslateControl {
    private static final long MILLIS_PER_DAY = 24L * 60L * 60L * 1000L;
    private final Context context;
    private final TranslateControl delegate;
    private final int engineId;
    private final int dailyLimit;

    public DailyLimitTranslateControl(Context context, TranslateControl delegate,
                                      int engineId, int dailyLimit) {
        this.context = context.getApplicationContext();
        this.delegate = delegate;
        this.engineId = engineId;
        this.dailyLimit = dailyLimit;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener listener) {
        if (task == null || listener == null) return;
        if ((task instanceof BatchTranslationTask
                && ((BatchTranslationTask) task).getSourceTexts().isEmpty())
                || (!(task instanceof BatchTranslationTask)
                && (task.getContent() == null || task.getContent().isEmpty()))) {
            delegate.translate(task, listener);
            return;
        }
        long epochDay = localEpochDay(System.currentTimeMillis(), TimeZone.getDefault());
        if (SdkPreferences.getInstance(context)
                .tryAcquireDailyRequest(engineId, dailyLimit, epochDay)) {
            delegate.translate(task, listener);
            return;
        }
        List<Integer> attempted = new ArrayList<>(task.getAttemptedEngineIds());
        if (!attempted.contains(engineId)) attempted.add(engineId);
        task.setAttemptedEngineIds(attempted);
        TranslateControl fallback = TranslateUtils.getCanTranslateType(
                context, task, task instanceof BatchTranslationTask);
        if (fallback != null) {
            fallback.translate(task, listener);
            return;
        }
        listener.onFail(TranslationErrorCode.QUOTA_EXHAUSTED,
                context.getString(R.string.translation_error_quota_exhausted));
    }

    /** Calculates the device-local date without allocating or normalizing a Calendar. */
    static long localEpochDay(long currentTimeMillis, TimeZone timeZone) {
        long localMillis = currentTimeMillis + timeZone.getOffset(currentTimeMillis);
        return Math.floorDiv(localMillis, MILLIS_PER_DAY);
    }

    @Override public BaseReq createBaseReq(String content, String source, String to) {
        return delegate.createBaseReq(content, source, to);
    }
    @Override public List<LanguageVO> getSupportLanguage() { return delegate.getSupportLanguage(); }
    @Override public int getIndexByLanguage(String language, boolean useDefault) {
        return delegate.getIndexByLanguage(language, useDefault);
    }
    @Override public LanguageVO getSelectLanguageVO(String country, boolean useDefault) {
        return delegate.getSelectLanguageVO(country, useDefault);
    }
    @Override public String getTranslateTypeName() { return delegate.getTranslateTypeName(); }
    @Override public int getTranslateType() { return delegate.getTranslateType(); }
    @Override public boolean isSupportAuto() { return delegate.isSupportAuto(); }
    @Override public void close() { delegate.close(); }
}
