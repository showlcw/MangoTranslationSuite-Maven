package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.TranslationLanguageInfo;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Small LRU for immutable, localized public language catalogs. */
public final class TranslationLanguageCatalogCache {
    private static final int MAX_ENTRIES = 64;
    private static final Map<String, List<TranslationLanguageInfo>> ENTRIES =
            new LinkedHashMap<String, List<TranslationLanguageInfo>>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(
                        Map.Entry<String, List<TranslationLanguageInfo>> eldest) {
                    return size() > MAX_ENTRIES;
                }
            };

    private TranslationLanguageCatalogCache() { }

    public static synchronized List<TranslationLanguageInfo> get(
            int engineId, String localeTag) {
        return ENTRIES.get(key(engineId, localeTag));
    }

    public static synchronized void put(int engineId, String localeTag,
                                        List<TranslationLanguageInfo> languages) {
        ENTRIES.put(key(engineId, localeTag), languages);
    }

    public static synchronized void clear() {
        ENTRIES.clear();
    }

    private static String key(int engineId, String localeTag) {
        return engineId + ":" + (localeTag == null ? "" : localeTag);
    }
}
