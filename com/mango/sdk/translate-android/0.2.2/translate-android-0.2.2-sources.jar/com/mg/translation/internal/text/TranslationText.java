package com.mg.translation.internal.text;

import com.mg.translation.language.LanguageConstant;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Brand-neutral text shaping helpers used by Translator implementations. */
public final class TranslationText {
    private static final Pattern SPECIAL_CHARACTER_PATTERN = Pattern.compile(
            "[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’↠。，↡→、？]");

    private TranslationText() { }

    public static boolean containsSpecialCharacter(String text) {
        return SPECIAL_CHARACTER_PATTERN.matcher(text).find();
    }

    public static String join(List<String> texts, String separator) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < texts.size(); i++) {
            if (i > 0) {
                result.append(separator);
            }
            result.append(texts.get(i));
        }
        return result.toString();
    }

    public static List<String> copy(List<String> texts) {
        return new ArrayList<>(texts);
    }

    public static String[] toArray(List<String> texts) {
        return texts.toArray(new String[0]);
    }

    public static boolean isCjk(String languageId) {
        return languageId != null && (languageId.equals(LanguageConstant.CHINESE)
                || languageId.equals(LanguageConstant.KOREAN)
                || languageId.equals(LanguageConstant.TRADITIONAL_CHINESE)
                || languageId.equals(LanguageConstant.JAPANESE));
    }

    public static boolean isRightToLeft(String languageId) {
        return languageId != null && (languageId.equals(LanguageConstant.ARABIC)
                || languageId.equals(LanguageConstant.PERSIAN)
                || languageId.equals(LanguageConstant.HEBREW)
                || languageId.equals(LanguageConstant.PASHTO)
                || languageId.equals(LanguageConstant.UYGHUR));
    }

    public static boolean usesCompactSpacing(String languageId) {
        return languageId != null && (languageId.equals(LanguageConstant.CHINESE)
                || languageId.equals(LanguageConstant.TRADITIONAL_CHINESE)
                || languageId.equals(LanguageConstant.KOREAN)
                || languageId.equals(LanguageConstant.JAPANESE)
                || languageId.equals(LanguageConstant.THAI));
    }

    public static boolean providerCodeUsesCompactSpacing(String providerCode) {
        return providerCode != null && (providerCode.equals("zh-CHS")
                || providerCode.equals("zh")
                || providerCode.equals("ko")
                || providerCode.equals("zh-CHT")
                || providerCode.equals("ja")
                || providerCode.equals("th"));
    }

    public static String summarize(String value) {
        if (value == null) {
            return null;
        }
        int length = value.length();
        return length <= 20
                ? value
                : value.substring(0, 10) + length + value.substring(length - 10);
    }
}
