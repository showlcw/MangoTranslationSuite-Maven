package com.mg.translation.language;

import androidx.annotation.NonNull;

import java.util.Objects;

/**
 * Created by lion on 2016/10/28.
 * 语言简写配置，目前的几种语言使用的是google翻译的标准
 */
public class LanguageVO implements Cloneable {

    private String value;
    private int country;
    private String key;
    private int ocrFlag = -1;
    private String topTitle;

    private String sourceLanguageIdName;

    private int languageCountry;//国家
    private String languageKey;//语言

    public LanguageVO(String topTitle) {
        this.topTitle = topTitle;
    }

    public LanguageVO(String key, int country, String value) {
        this.value = value;
        this.country = country;
        this.key = key;
    }

    public LanguageVO(String key, int country, String value, String languageKey, int languageCountry) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.languageKey = languageKey;
        this.languageCountry = languageCountry;
    }
    public LanguageVO(String key, int country, String value, int ocrFlag) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.ocrFlag = ocrFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LanguageVO)) return false;
        LanguageVO that = (LanguageVO) o;
        return key != null && Objects.equals(key, that.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }

    public int getLanguageCountry() {
        return languageCountry;
    }

    public String getLanguageKey() {
        return languageKey;
    }

    public void setLanguageKey(String languageKey) {
        this.languageKey = languageKey;
    }

    public String getSourceLanguageIdName() {
        return sourceLanguageIdName;
    }

    public void setSourceLanguageIdName(String sourceLanguageIdName) {
        this.sourceLanguageIdName = sourceLanguageIdName;
    }

    public String getTopTitle() {
        return topTitle;
    }

    public int getOcrFlag() {
        return ocrFlag;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getCountry() {
        return country;
    }

    public String getKey() {
        return key;
    }

    @NonNull
    @Override
    public LanguageVO clone() throws CloneNotSupportedException {
        return (LanguageVO) super.clone();
    }
}
