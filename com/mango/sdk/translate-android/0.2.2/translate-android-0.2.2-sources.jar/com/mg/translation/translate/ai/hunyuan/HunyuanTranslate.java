package com.mg.translation.translate.ai.hunyuan;

import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.ai.common.OpenAiCompatibleTranslateControl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Independent Hunyuan translation engine, including its owned language IDs and Provider codes. */
public final class HunyuanTranslate extends OpenAiCompatibleTranslateControl {
    public HunyuanTranslate(Context context) {
        super(context, TranslatorId.HY_MT2, "Hunyuan", null,
                PromptPlacement.USER_PREFIX, createLanguages());
    }

    private static List<LanguageVO> createLanguages() {
        List<LanguageVO> languages = new ArrayList<>();
        languages.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        languages.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali,
                "bn"));
        languages.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese,
                "zh-CN"));
        languages.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-TW"));
        languages.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        languages.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        languages.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        languages.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino,
                "fil"));
        languages.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        languages.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        languages.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));
        languages.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));
        languages.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        languages.add(new LanguageVO(LanguageConstant.INDONESIAN,
                R.string.language_Indonesian,
                "id"));
        languages.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        languages.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));
        languages.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh,
                "kk"));
        languages.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer,
                "km"));
        languages.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        languages.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));
        languages.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi,
                "mr"));
        languages.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian,
                "mn"));
        languages.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese,
                "my"));
        languages.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian,
                "fa"));
        languages.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        languages.add(new LanguageVO(LanguageConstant.PORTUGUESE,
                R.string.language_Portuguese, "pt"));
        languages.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        languages.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        languages.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es"));
        languages.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog,
                "tl"));
        languages.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));
        languages.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        languages.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai,
                "th"));
        languages.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));
        languages.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        languages.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));
        languages.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur,
                "ug"));
        languages.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        return Collections.unmodifiableList(languages);
    }
}
