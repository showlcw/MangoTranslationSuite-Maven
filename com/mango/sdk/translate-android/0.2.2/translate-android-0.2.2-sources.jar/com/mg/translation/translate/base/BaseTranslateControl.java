package com.mg.translation.translate.base;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.TranslationErrorCode;


import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/6 18:35
 */
public abstract class BaseTranslateControl implements TranslateControl {
    private final CompositeDisposable requests = new CompositeDisposable();
    private final AtomicBoolean closed = new AtomicBoolean(false);

    /**
     * 统一执行一次 Provider 请求：IO订阅、主线程回调、单次完成并纳入 close() 取消范围。
     */
    protected final <T> void executeRequest(Single<T> request, Consumer<T> onSuccess,
                                            Runnable onFailure) {
        if (request == null || onSuccess == null || onFailure == null || closed.get()) return;
        AtomicBoolean terminal = new AtomicBoolean(false);
        AtomicReference<Disposable> requestRef = new AtomicReference<>();
        Disposable disposable = request
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doFinally(() -> {
                    Disposable completed = requestRef.get();
                    if (completed != null) requests.delete(completed);
                })
                .subscribe(value -> {
                    if (!terminal.compareAndSet(false, true) || closed.get()) return;
                    try {
                        onSuccess.accept(value);
                    } catch (Exception ignored) {
                        onFailure.run();
                    }
                }, error -> {
                    if (terminal.compareAndSet(false, true) && !closed.get()) {
                        onFailure.run();
                    }
                });
        requestRef.set(disposable);
        requests.add(disposable);
        // 同步 Single 可能在 add 前已经结束，需补一次清理。
        if (disposable.isDisposed()) requests.delete(disposable);
    }

    /**
     * 用于仓库层已将网络异常转换为业务结果的请求。
     */
    protected final <T> void executeRequest(Single<T> request, Consumer<T> onSuccess) {
        executeRequest(request, onSuccess, () -> { });
    }

    /**
     * 是否支持自动模式
     *
     * @return true 支持  false 不支持
     */
    @Override
    public boolean isSupportAuto() {
        return true;
    }

    @Override
    public int getIndexByLanguage(String country, boolean isSetDefault) {
        int index = -1;

        if (getSupportLanguage() == null || getSupportLanguage().isEmpty()) {//
            if (isSetDefault) {
                index = 0;
            }
            return index;
        }

        LanguageVO languageVO = new LanguageVO(country, 0, "");
        index = getSupportLanguage().indexOf(languageVO);
        if (isSetDefault && index == -1) {
            index = 0;
        }
        return index;
    }

    public void dealTranslateError(Context context, TranslationTask task, TranslateListener translateListener) {
        //如果是null的话 直接返回错误
        if (task == null) {
            translateListener.onFail(TranslationErrorCode.INVALID_REQUEST,
                    context.getString(R.string.translation_error_invalid_request));
            return;
        }
        //判断网络
        if (!TranslateUtils.isNetworkConnected(context)) {//如果网络连接不正常
            translateListener.onFail(TranslationErrorCode.NETWORK_UNAVAILABLE,
                    context.getString(R.string.translation_error_network_unavailable));
            return;
        }
        boolean isList = (task instanceof BatchTranslationTask);
        // Record this engine so the current request cannot loop back to it during fallback.
        List<Integer> attemptedEngineIds = new ArrayList<>(task.getAttemptedEngineIds());
        if (!attemptedEngineIds.contains(getTranslateType())) {
            attemptedEngineIds.add(getTranslateType());
        }
        task.setAttemptedEngineIds(attemptedEngineIds);
        TranslateControl translateControl = TranslateUtils.getCanTranslateType(context, task, isList);
        if (translateControl != null) {
            translateControl.translate(task, translateListener);
            return;
        }
        if (task.remainingBudgetMs() < 3_000L) {
            translateListener.onFail(TranslationErrorCode.REQUEST_TIMEOUT,
                    context.getString(R.string.translation_error_timeout));
            return;
        }
        translateListener.onFail(TranslationErrorCode.ALL_ENGINES_FAILED,
                context.getString(R.string.translation_error_all_engines_failed));
    }

    /**
     * 出现错误的时候处理逻辑
     */
    public void errorDealUserBaidu(Context context, TranslationTask task,
                                   TranslateListener translateListener) {
        if (!TranslateUtils.isNetworkConnected(context)) {//没有网络
            translateListener.onFail(TranslationErrorCode.NETWORK_UNAVAILABLE,
                    context.getString(R.string.translation_error_network_unavailable));
            return;
        }
        //使用百度 VIP
        TranslateControl translateControl = TranslateUtils.getTranslateByType(TranslatorId.BAIDU.legacyCode, task.getSourceLanguageId(), task.getTargetLanguageId(), context);
        if (translateControl != null) {
            translateControl.translate(task, translateListener);
            return;
        }
        translateListener.onFail(TranslationErrorCode.ALL_ENGINES_FAILED,
                context.getString(R.string.translation_error_all_engines_failed));
    }

    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) requests.dispose();
    }

    @Override
    public LanguageVO getSelectLanguageVO(String country, boolean isSetDefault) {

        if (getSupportLanguage() == null || getSupportLanguage().isEmpty()) {//
            return null;
        }
        int translateIndex =
                getIndexByLanguage(country, isSetDefault);
        if (translateIndex == -1) {
            return null;
        }
        return getSupportLanguage().get(translateIndex);
    }


}
