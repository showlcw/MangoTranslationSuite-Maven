package com.mg.translation.translate.google;

/** Internal segment used only while reconciling Google batch responses. */
final class GoogleTranslationSegment {
    private String sourceText;
    private String translatedText;

    GoogleTranslationSegment() {
    }

    GoogleTranslationSegment(String sourceText) {
        this.sourceText = sourceText;
    }

    String getSourceText() {
        return sourceText;
    }

    void setSourceText(String sourceText) {
        this.sourceText = sourceText;
    }

    String getTranslatedText() {
        return translatedText;
    }

    void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

}
