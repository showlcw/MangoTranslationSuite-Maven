package com.mg.translation.translate.google;

import com.mg.translation.engine.TranslatorId;



import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.google.dto.GoogleVipListTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.http.translate.google.dto.GoogleTranslateResult;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;
import java.util.List;


/**
 * @author LiChunWei
 * @description: google  翻译
 * @date :2021/5/7 10:15
 */
public class GoogleVTranslate extends BaseTranslateControl {


    private final Context mContext;
    private List<LanguageVO> mDestLanguageList;

    public GoogleVTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        String apiKey = TranslateUtils.getGoogleVipApiKey(mContext);
        if (TextUtils.isEmpty(apiKey)) {//不可以使用
            errorDealUserBaidu(mContext, task, translateListener);
            return;
        }

        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, apiKey, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, apiKey, translateListener);
    }

    /**
     * 翻译
     */
    public synchronized void translateListApi(BatchTranslationTask batchTask, String apiKey,
                                              TranslateListener translateListener) {
        List<String> sourceTexts = batchTask.getSourceTexts();
        executeRequest(TranslateRepository.getInstance().googleTranslateVip(mContext, createBaseReqList(sourceTexts, batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId()), apiKey), googleTranslateResult -> {

            if (googleTranslateResult == null || !googleTranslateResult.isSuccess()) {
                errorDealUserBaidu(mContext, batchTask, translateListener);
                return;
            }
            GoogleTranslateResult.GoogleTranslateArray googleTranslateArray = googleTranslateResult.getData();
            if (googleTranslateArray == null || googleTranslateArray.getTranslations() == null) {
                errorDealUserBaidu(mContext, batchTask, translateListener);
                return;
            }
            List<GoogleTranslateResult.GoogleTranslateBlock> resultList = googleTranslateArray.getTranslations();
            int size = resultList.size();
            if (size == sourceTexts.size()) {
                for (int i = 0; i < size; i++) {
                    batchTask.setTranslation(i, resultList.get(i).getTranslatedText());
                }
            } else {
                errorDealUserBaidu(mContext, batchTask, translateListener);
                return;
            }
            translateListener.onSuccess(batchTask, getTranslateType(), true);
        });
    }

    public void translateContent(TranslationTask task, String apiKey, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }
        executeRequest(TranslateRepository.getInstance().googleTranslateVip(mContext, createBaseReq(task.getContent(), task.getSourceLanguageId(), task.getTargetLanguageId()), apiKey), googleTranslateResult -> {
            if (googleTranslateResult == null || !googleTranslateResult.isSuccess()) {
                errorDealUserBaidu(mContext, task, translateListener);
                return;
            }
            GoogleTranslateResult.GoogleTranslateArray googleTranslateArray = googleTranslateResult.getData();
            if (googleTranslateArray == null || googleTranslateArray.getTranslations() == null) {
                errorDealUserBaidu(mContext, task, translateListener);
                return;
            }
            List<GoogleTranslateResult.GoogleTranslateBlock> resultList = googleTranslateArray.getTranslations();
            StringBuilder sb = new StringBuilder();
            for (GoogleTranslateResult.GoogleTranslateBlock translateBlock : resultList) {
                sb.append(translateBlock.getTranslatedText()).append("\n");
            }
            task.setTranslatedText(sb.toString().trim());
            translateListener.onSuccess(task, getTranslateType(), false);
        });
    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }


    @Override
    public void close() {
        super.close();
    }


    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        // Authenticated Google Cloud v2 /languages catalog, verified 2026-09-01.
        // Alias-only codes zh, iw and jw are omitted in favor of zh-CN, he and jv.
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ABKHAZIAN, R.string.language_Abkhazian, "ab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACEHNESE, R.string.language_Acehnese, "ace"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACHOLI, R.string.language_Acholi, "ach"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan, "ak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALUR, R.string.language_Alur, "alz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic, "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese, "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AWADHI, R.string.language_Awadhi, "awa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AYMARA, R.string.language_Aymara, "ay"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASHKIR, R.string.language_Bashkir, "ba"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BALINESE, R.string.language_Balinese, "ban"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_TOBA, R.string.language_Batak_Toba, "bbc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BEMBA, R.string.language_Bemba, "bem"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BETAWI, R.string.language_Betawi, "bew"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian, "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri, "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BIKOL, R.string.language_Bikol, "bik"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara, "bm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali, "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BRETON, R.string.language_Breton, "br"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_SIMALUNGUN, R.string.language_Batak_Simalungun, "bts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_KARO, R.string.language_Batak_Karo, "btx"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURYAT, R.string.language_Buryat, "bua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan, "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHIGA, R.string.language_Chiga, "cgg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARI, R.string.language_Mari, "chm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SORANI, R.string.language_Sorani, "ckb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAKHA_CHIN, R.string.language_Hakha_Chin, "cnh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican, "co"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CRIMEAN_TATAR, R.string.language_Crimean_Tatar, "crh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEYCHELLOIS_CREOLE, R.string.language_Seychellois_Creole, "crs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech, "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHUVASH, R.string.language_Chuvash, "cv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish, "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DINKA, R.string.language_Dinka, "din"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri, "doi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOMBE, R.string.language_Dombe, "dov"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi, "dv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DZONGKHA, R.string.language_Dzongkha, "dz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EWE, R.string.language_Ewe, "ee"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek, "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto, "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian, "fa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FULANI, R.string.language_Fulani, "ff"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish, "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FIJIAN, R.string.language_Fijian, "fj"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH_CANADA, R.string.language_French_Canadian, "fr-CA"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian, "fy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish, "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GA, R.string.language_Ga, "gaa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic, "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani, "gn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani, "gom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati, "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa, "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian, "haw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew, "he"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi, "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HILIGAYNON, R.string.language_Hiligaynon, "hil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong, "hmn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian, "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNSRIK, R.string.language_Hunsrik, "hrx"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian, "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian, "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo, "ig"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ILOCANO, R.string.language_Ilocano, "ilo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese, "jv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian, "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer, "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada, "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KRIO, R.string.language_Krio, "kri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANURI, R.string.language_Kanuri, "ktu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish, "ku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz, "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin, "la"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda, "lg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIMBURGISH, R.string.language_Limburgish, "li"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIGURIAN, R.string.language_Ligurian, "lij"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOMBARD, R.string.language_Lombard, "lmo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala, "ln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao, "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATGALIAN, R.string.language_Latgalian, "ltg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUO, R.string.language_Luo, "luo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MIZO, R.string.language_Mizo, "lus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili, "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAKASAR, R.string.language_Makasar, "mak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori, "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MINANGKABAU, R.string.language_Minangkabau, "min"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "ml"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian, "mn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MEITEILON, R.string.language_Meiteilon, "mni-Mtei"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay, "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY_JAWI, R.string.language_Malay_Jawi, "ms-Arab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese, "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese, "my"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali, "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEWARI, R.string.language_Newari, "new"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "no"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTH_NDEBELE, R.string.language_South_Ndebele, "nr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi, "nso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NUER, R.string.language_Nuer, "nus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa, "ny"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OCCITAN, R.string.language_Occitan, "oc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo, "om"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya, "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi, "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI_ARABIC, R.string.language_Punjabi_Arabic, "pa-Arab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PANGASINAN, R.string.language_Pangasinan, "pag"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAMPANGA, R.string.language_Pampanga, "pam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAPIAMENTO, R.string.language_Papiamento, "pap"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish, "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto, "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_PORTUGAL, R.string.language_Portuguese_Portugal, "pt-PT"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.QUECHUA, R.string.language_Quechua, "qu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KIRUNDI, R.string.language_Kirundi, "rn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANI, R.string.language_Romani, "rom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda, "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit, "sa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SICILIAN, R.string.language_Sicilian, "scn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANGO, R.string.language_Sango, "sg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHAN, R.string.language_Shan, "shn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan, "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona, "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali, "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian, "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian, "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWATI, R.string.language_Swati, "ss"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho, "st"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese, "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili, "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SILESIAN, R.string.language_Silesian, "szl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil, "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu, "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TETUM, R.string.language_Tetum, "tet"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik, "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya, "ti"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen, "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino, "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSWANA, R.string.language_Tswana, "tn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish, "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga, "ts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar, "tt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur, "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu, "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa, "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish, "yi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba, "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YUCATEC_MAYA, R.string.language_Yucatec_Maya, "yua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CANTONESE, R.string.language_Cantonese, "yue"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu, "zu"));
    }
    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_google);
    }

    @Override
    public BaseReq createBaseReq(String content, String sourceCountry, String toCountry) {
        GoogleVipListTranslateReq googleTranslateReq = new GoogleVipListTranslateReq();
        LanguageVO toLanguageVO = getSelectLanguageVO(toCountry, false);
        LanguageVO sourceLanguageVO = getSelectLanguageVO(sourceCountry, false);

        if (sourceLanguageVO != null) {
            googleTranslateReq.setSource(sourceLanguageVO.getValue());
        } else {
            googleTranslateReq.setSource("auto");
        }
        if (toLanguageVO != null) {
            googleTranslateReq.setTarget(toLanguageVO.getValue());
        }
        String[] strings = content.split("\n");
        int size = strings.length;
        List<String> stringList = new ArrayList<>(Arrays.asList(strings).subList(0, size));
        googleTranslateReq.setQ(stringList);
        return googleTranslateReq;
    }


    public BaseReq createBaseReqList(List<String> sourceTexts, String sourceCountry, String toCountry) {
        GoogleVipListTranslateReq googleTranslateReq = new GoogleVipListTranslateReq();
        LanguageVO toLanguageVO = getSelectLanguageVO(toCountry, false);
        LanguageVO sourceLanguageVO = getSelectLanguageVO(sourceCountry, false);

        if (sourceLanguageVO != null) {
            googleTranslateReq.setSource(sourceLanguageVO.getValue());
        } else {
            googleTranslateReq.setSource("auto");
        }
        if (toLanguageVO != null) {
            googleTranslateReq.setTarget(toLanguageVO.getValue());
        }
        googleTranslateReq.setQ(new ArrayList<>(sourceTexts));
        return googleTranslateReq;
    }

    @Override
    public boolean isSupportAuto() {
        return false;
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.GOOGLE_V.legacyCode;
    }
}
