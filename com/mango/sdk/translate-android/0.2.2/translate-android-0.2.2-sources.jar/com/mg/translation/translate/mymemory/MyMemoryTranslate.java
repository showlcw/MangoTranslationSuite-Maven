package com.mg.translation.translate.mymemory;

import com.mg.translation.engine.TranslatorId;



import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.memory.dto.MemoryTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.http.translate.memory.dto.MemoryTranslateResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author LiChunWei
 * @description: google  翻译
 * @date :2021/5/7 10:15
 */
public class MyMemoryTranslate extends BaseTranslateControl {
    private final Context mContext;
    private List<LanguageVO> mDestLanguageList;

    public MyMemoryTranslate(Context context) {
        mContext = context;
    }

    /**
     * 翻译
     */
    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            dealTranslateError(mContext, batchTask, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, translateListener);
    }

    public void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }

        executeRequest(TranslateRepository.getInstance().memoryTranslate(mContext,
                createBaseReq(task.getContent(), task.getSourceLanguageId(),
                        task.getTargetLanguageId())), memoryTranslateResult -> {
                    if (memoryTranslateResult == null || !memoryTranslateResult.isSuccess()) {
                        dealTranslateError(mContext, task, translateListener);
                        return;
                    }

                    MemoryTranslateResult.ResponseData responseData = memoryTranslateResult.getResponseData();
                    String result = responseData.getTranslatedText();
                    if (TextUtils.isEmpty(result)) {//翻译出错 切其他的方式
                        dealTranslateError(mContext, task, translateListener);
                        return;
                    }
                    task.setTranslatedText(memoryTranslateResult.getResponseData().getTranslatedText());
                    translateListener.onSuccess(task, getTranslateType(), false);
                });
    }


    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }

    @Override
    public void close() {
        super.close();
    }


    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();


        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACEH, R.string.language_Aceh,
                "ace"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans,
                "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan,
                "ak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian,
                "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian,
                "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese,
                "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani,
                "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara
                , "bm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASHKIR, R.string.language_Bashkir
                , "ba"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian
                , "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali
                , "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri
                , "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian
                , "bs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian,
                "bg"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan,
                "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano,
                "ceb"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE,
                R.string.language_Chinese,
                "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian,
                "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish,
                "da"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto,
                "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian,
                "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EWE, R.string.language_Ewe,
                "ee"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FAROESE, R.string.language_Faroese,
                "fo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRIULI, R.string.language_Friuli,
                "fur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish,
                "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician,
                "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA , R.string.language_Luganda,
                "lg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN , R.string.language_Georgian,
                "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek,
                "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani,
                "gn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa,
                "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN,
                R.string.language_Hungarian,
                "hu"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic,
                "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian,
                "id"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH,
                R.string.language_Irish,
                "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KABYLE, R.string.language_Kabyle
                , "kab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANURI, R.string.language_Kanuri
                , "knc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh
                , "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer
                , "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda
                , "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONGO, R.string.language_Kongo
                , "kg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish,
                "ckb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz,
                "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao,
                "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin,
                "la"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian,
                "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIMBURGISH, R.string.language_Limburgish,
                "li"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala,
                "ln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian,
                "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish,
                "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili,
                "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy,
                "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam,
                "ml"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese,
                "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori,
                "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi,
                "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MIZO, R.string.language_Mizo,
                "lus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian,
                "mn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali,
                "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian,
                "nb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NYANJA,
                R.string.language_Nyanja,
                "ny"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OCCITAN,
                R.string.language_Occitan,
                "oc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA,
                R.string.language_Oriya,
                "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO,
                R.string.language_Oromo,
                "gaz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAPIAMENTO,
                R.string.language_Papiamento,
                "pap"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO,
                R.string.language_Pashto,
                "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI,
                R.string.language_Punjabi, "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian,
                "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan,
                "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANGO, R.string.language_Sango,
                "sg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit,
                "sa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SARDINIAN, R.string.language_Sardinian,
                "sc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SCOTS, R.string.language_Scots,
                "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHAN, R.string.language_Shan,
                "shn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SILESIAN, R.string.language_Silesian,
                "szl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi,
                "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala,
                "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali,
                "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian,
                "sr-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak,
                "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian,
                "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es-ES"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese,
                "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili,
                "sw"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish,
                "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog,
                "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik,
                "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar,
                "tt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya,
                "ti"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga,
                "ts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen,
                "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TWI, R.string.language_Twi,
                "tw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur,
                "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek,
                "uzn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WOLOF,
                R.string.language_Wolof,
                "wo"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA,
                R.string.language_Xhosa,
                "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH,
                R.string.language_Welsh,
                "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH,
                R.string.language_Yiddish,
                "ydd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA,
                R.string.language_Yoruba,
                "yo"));
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_mymemory);
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        MemoryTranslateReq memoryTranslateReq = new MemoryTranslateReq();
        LanguageVO tolanguageVO = getSelectLanguageVO(to, false);
        String toValue = "";
        if (tolanguageVO != null) {
            toValue = tolanguageVO.getValue();
        }

        LanguageVO sourceLanguageVO = getSelectLanguageVO(source, false);
        String sourceValue = "";
        if (sourceLanguageVO != null) {
            sourceValue = sourceLanguageVO.getValue();
        }
        memoryTranslateReq.setLangpair(sourceValue + "|" + toValue);
        memoryTranslateReq.setQ(content);
        return memoryTranslateReq;
    }

    @Override
    public boolean isSupportAuto() {
        return false;
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.MYMEMORY.legacyCode;
    }
}
