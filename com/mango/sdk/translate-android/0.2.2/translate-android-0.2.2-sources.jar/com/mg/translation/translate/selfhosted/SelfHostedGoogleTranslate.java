package com.mg.translation.translate.selfhosted;

import com.mg.translation.engine.TranslatorId;

import static com.mg.translation.utils.TranslationPreferenceKeys.SELF_HOSTED_GOOGLE_TRANSLATE_STATE;
import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.common.dto.MeTranslateReq;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.runtime.TranslationTelemetry;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 通过自建网关调用 Google 翻译。保持 GoogleTranslate 的控制器调用方式，
 * 使用独立翻译类型并复用原 Google 的语言代码表。
 */
public class SelfHostedGoogleTranslate extends BaseTranslateControl {

    private final Context mContext;
    private List<LanguageVO> mDestLanguageList;

    public SelfHostedGoogleTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        if (!TranslateUtils.getSelfHostedGoogleApiState(mContext)) {
            dealTranslateError(mContext, task, translateListener);
            return;
        }

        TranslationTelemetry.event("self_hosted_google_translate_request");
        if (task instanceof BatchTranslationTask) {
            translateListApi((BatchTranslationTask) task, translateListener);
        } else {
            translateApi(task, translateListener);
        }
    }

    public void translateListApi(BatchTranslationTask translateVO, TranslateListener listener) {
        List<String> sourceTexts = translateVO.getSourceTexts();
        List<String> texts = copy(sourceTexts);
        executeRequest(TranslateRepository.getInstance().selfHostedGoogleTranslate(
                createGatewayRequest(texts, translateVO.getTargetLanguageId())), result -> {
            String[] translated = successTexts(result, sourceTexts.size());
            if (translated == null) {
                if (result != null && result.isSuccess()) {
                    TranslationTelemetry.event(
                            "self_hosted_google_result_count_mismatch");
                }
                handleFailure(translateVO, listener);
                return;
            }
            for (int i = 0; i < sourceTexts.size(); i++) {
                translateVO.setTranslation(i, translated[i]);
            }
            listener.onSuccess(translateVO, getTranslateType(), true);
        }, () -> handleFailure(translateVO, listener));
    }

    public void translateApi(TranslationTask translateVO, TranslateListener listener) {
        if (TextUtils.isEmpty(translateVO.getContent())) {
            listener.onSuccess(translateVO, getTranslateType(), false);
            return;
        }

        List<String> texts = new ArrayList<>();
        Collections.addAll(texts, translateVO.getContent().split("\n"));
        executeRequest(TranslateRepository.getInstance().selfHostedGoogleTranslate(
                createGatewayRequest(texts, translateVO.getTargetLanguageId())), result -> {
            String[] translated = successTexts(result, texts.size());
            if (translated == null) {
                handleFailure(translateVO, listener);
                return;
            }
            translateVO.setTranslatedText(TextUtils.join("\n", translated));
            listener.onSuccess(translateVO, getTranslateType(), false);
        }, () -> handleFailure(translateVO, listener));
    }

    private String[] successTexts(MeTranslateHttpResult result, int expectedSize) {
        if (result == null || !result.isSuccess() || result.getTexts() == null
                || result.getTexts().length != expectedSize) {
            return null;
        }
        return result.getTexts();
    }

    private void handleFailure(TranslationTask translateVO, TranslateListener listener) {
        SdkPreferences.getInstance(mContext).put(
                SELF_HOSTED_GOOGLE_TRANSLATE_STATE, System.currentTimeMillis());
        dealTranslateError(mContext, translateVO, listener);
    }

    private MeTranslateReq createGatewayRequest(List<String> content, String toCountry) {
        MeTranslateReq request = new MeTranslateReq();
        LanguageVO target = getSelectLanguageVO(toCountry, false);
        if (target != null) {
            request.setTl(target.getValue());
        }
        request.setFl(null);
        request.setQ(content.toArray(new String[0]));
        return request;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        List<String> texts = new ArrayList<>();
        texts.add(content);
        return createGatewayRequest(texts, to);
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        if (mDestLanguageList == null) {
            initLanguage();
        }
        return Collections.unmodifiableList(mDestLanguageList);
    }

    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();

        // Live GOOGLE/GOOGLE_CLIENT target-language catalog, verified 2026-09-01.
        // Variants without a distinct shared LanguageConstant remain intentionally unexposed:
        // ber-Latn, bm-Nkoo, crh-Latn, fa-AF, ndc-ZW, sat-Latn.
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFAR, R.string.language_Afar, "aa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ABKHAZ, R.string.language_Abkhaz, "ab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACEHNESE, R.string.language_Acehnese, "ace"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ACHOLI, R.string.language_Acholi, "ach"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan, "ak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALUR, R.string.language_Alur, "alz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic, "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese, "as"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AVAR, R.string.language_Avar, "av"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AWADHI, R.string.language_Awadhi, "awa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AYMARA, R.string.language_Aymara, "ay"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASHKIR, R.string.language_Bashkir, "ba"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BALUCHI, R.string.language_Baluchi, "bal"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BALINESE, R.string.language_Balinese, "ban"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_TOBA, R.string.language_Batak_Toba, "bbc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAOULE, R.string.language_Baoule, "bci"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BEMBA, R.string.language_Bemba, "bem"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BERBER, R.string.language_Berber, "ber"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BETAWI, R.string.language_Betawi, "bew"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian, "bg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri, "bho"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BIKOL, R.string.language_Bikol, "bik"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara, "bm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali, "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIBETAN, R.string.language_Tibetan, "bo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BRETON, R.string.language_Breton, "br"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_SIMALUNGUN, R.string.language_Batak_Simalungun, "bts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BATAK_KARO, R.string.language_Batak_Karo, "btx"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURYAT, R.string.language_Buryat, "bua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan, "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHECHEN, R.string.language_Chechen, "ce"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KIGA, R.string.language_Kiga, "cgg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHAMORRO, R.string.language_Chamorro, "ch"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHUUKESE, R.string.language_Chuukese, "chk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MEADOW_MARI, R.string.language_Meadow_Mari, "chm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SORANI, R.string.language_Sorani, "ckb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAKHA_CHIN, R.string.language_Hakha_Chin, "cnh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican, "co"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CRIMEAN_TATAR, R.string.language_Crimean_Tatar, "crh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEYCHELLOIS_CREOLE, R.string.language_Seychellois_Creole, "crs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech, "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHUVASH, R.string.language_Chuvash, "cv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish, "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DINKA, R.string.language_Dinka, "din"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri, "doi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DOMBE, R.string.language_Dombe, "dov"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi, "dv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DYULA, R.string.language_Dyula, "dyu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DZONGKHA, R.string.language_Dzongkha, "dz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EWE, R.string.language_Ewe, "ee"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek, "el"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto, "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian, "fa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FULA, R.string.language_Fula, "ff"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish, "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FIJIAN, R.string.language_Fijian, "fj"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FAROESE, R.string.language_Faroese, "fo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FON, R.string.language_Fon, "fon"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH_CANADA, R.string.language_French_Canadian, "fr-CA"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRIULIAN, R.string.language_Friulian, "fur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian, "fy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish, "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GA, R.string.language_Ga, "gaa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic, "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani, "gn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani, "gom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati, "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MANX, R.string.language_Manx, "gv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa, "ha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian, "haw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi, "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HILIGAYNON, R.string.language_Hiligaynon, "hil"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong, "hmn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian, "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNSRIK, R.string.language_Hunsrik, "hrx"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian, "ht"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian, "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IBAN, R.string.language_Iban, "iba"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo, "ig"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ILOCANO, R.string.language_Ilocano, "ilo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "is"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUKTUT, R.string.language_Inuktut, "iu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INUKTUT_LATIN, R.string.language_Inuktut_Latin, "iu-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew, "iw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAMAICAN_PATOIS, R.string.language_Jamaican_Patois, "jam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese, "jw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian, "ka"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JINGPO, R.string.language_Jingpo, "kac"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KEKCHI, R.string.language_Kekchi, "kek"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KONGO, R.string.language_Kongo, "kg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHASI, R.string.language_Khasi, "kha"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREENLANDIC, R.string.language_Greenlandic, "kl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer, "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada, "kn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANURI, R.string.language_Kanuri, "kr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KRIO, R.string.language_Krio, "kri"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KITUBA, R.string.language_Kituba, "ktu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish, "ku"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOMI, R.string.language_Komi, "kv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz, "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin, "la"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda, "lg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIMBURGISH, R.string.language_Limburgish, "li"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LIGURIAN, R.string.language_Ligurian, "lij"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LOMBARD, R.string.language_Lombard, "lmo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala, "ln"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao, "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATGALIAN, R.string.language_Latgalian, "ltg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUBA_KASAI, R.string.language_Luba_Kasai, "lua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUO, R.string.language_Luo, "luo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MIZO, R.string.language_Mizo, "lus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MADURESE, R.string.language_Madurese, "mad"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili, "mai"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAKASSAR, R.string.language_Makassar, "mak"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAM, R.string.language_Mam, "mam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAURITIAN_CREOLE, R.string.language_Mauritian_Creole, "mfe"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARSHALLESE, R.string.language_Marshallese, "mh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori, "mi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MINANGKABAU, R.string.language_Minangkabau, "min"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "ml"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian, "mn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MEITEILON, R.string.language_Meiteilon, "mni-Mtei"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay, "ms"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY_JAWI, R.string.language_Malay_Jawi, "ms-Arab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese, "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARWARI, R.string.language_Marwari, "mwr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese, "my"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali, "ne"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEWARI, R.string.language_Newari, "new"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.EASTERN_HUASTECA_NAHUATL, R.string.language_Eastern_Huasteca_Nahuatl, "nhe"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "no"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_NDEBELE, R.string.language_Southern_Ndebele, "nr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi, "nso"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NUER, R.string.language_Nuer, "nus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa, "ny"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OCCITAN, R.string.language_Occitan, "oc"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo, "om"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya, "or"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.OSSETIAN, R.string.language_Ossetian, "os"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi, "pa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI_ARABIC, R.string.language_Punjabi_Arabic, "pa-Arab"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PANGASINAN, R.string.language_Pangasinan, "pag"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAMPANGA, R.string.language_Pampanga, "pam"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PAPIAMENTO, R.string.language_Papiamento, "pap"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish, "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto, "ps"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_PORTUGAL, R.string.language_Portuguese_Portugal, "pt-PT"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.QUECHUA, R.string.language_Quechua, "qu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUNDI, R.string.language_Rundi, "rn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANI, R.string.language_Romani, "rom"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda, "rw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit, "sa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAKHA, R.string.language_Sakha, "sah"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANTALI, R.string.language_Santali, "sat"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SICILIAN, R.string.language_Sicilian, "scn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORTHERN_SAMI, R.string.language_Northern_Sami, "se"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANGO, R.string.language_Sango, "sg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHAN, R.string.language_Shan, "shn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "si"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan, "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona, "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali, "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian, "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian, "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWATI, R.string.language_Swati, "ss"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho, "st"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese, "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUSU, R.string.language_Susu, "sus"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili, "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SILESIAN, R.string.language_Silesian, "szl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil, "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TULU, R.string.language_Tulu, "tcy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu, "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TETUM, R.string.language_Tetum, "tet"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik, "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya, "ti"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TIV, R.string.language_Tiv, "tiv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen, "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino, "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSWANA, R.string.language_Tswana, "tn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TONGAN, R.string.language_Tongan, "to"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TOK_PISIN, R.string.language_Tok_Pisin, "tpi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish, "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOKBOROK, R.string.language_Kokborok, "trp"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga, "ts"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar, "tt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TUMBUKA, R.string.language_Tumbuka, "tum"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAHITIAN, R.string.language_Tahitian, "ty"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TUVAN, R.string.language_Tuvan, "tyv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UDMURT, R.string.language_Udmurt, "udm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur, "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu, "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VENDA, R.string.language_Venda, "ve"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VENETIAN, R.string.language_Venetian, "vec"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WARAY, R.string.language_Waray, "war"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WOLOF, R.string.language_Wolof, "wo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa, "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish, "yi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba, "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YUCATEC_MAYA, R.string.language_Yucatec_Maya, "yua"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CANTONESE, R.string.language_Cantonese, "yue"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZAPOTEC, R.string.language_Zapotec, "zap"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu, "zu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMAZIGHT_LATIN, R.string.language_Tamazight_Latin, "ber-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BAMBARA_NKO, R.string.language_Bambara_Nko, "bm-Nkoo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CRIMEAN_TATAR_LATIN, R.string.language_Crimean_Tatar_Latin, "crh-Latn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DARI, R.string.language_Dari, "fa-AF"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NDAU, R.string.language_Ndau, "ndc-ZW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SANTALI_LATIN, R.string.language_Santali_Latin, "sat-Latn"));
    }

    @Override
    public void close() {
        super.close();
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_self_hosted_google);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.SELF_HOSTED_GOOGLE.legacyCode;
    }
}
