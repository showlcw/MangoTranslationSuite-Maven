package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.Translator;
import com.mg.translation.sdk.TranslationCall;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationHost;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.LongFunction;
import java.util.function.BiFunction;

/** Owns isolated chains, bounded scheduling, exact in-flight coalescing and bounded memory results. */
public final class ManagedTranslator implements Translator {
    private static final ScheduledThreadPoolExecutor TIMER = deadlineTimer();
    private static ScheduledThreadPoolExecutor deadlineTimer() {
        ScheduledThreadPoolExecutor timer = new ScheduledThreadPoolExecutor(1, r -> {
            Thread thread = new Thread(r, "mango-deadline"); thread.setDaemon(true); return thread;
        });
        timer.setRemoveOnCancelPolicy(true);
        return timer;
    }
    private static volatile long cacheTtlMs = 15_000L;
    private static final java.util.concurrent.atomic.AtomicLong NEXT_REQUEST = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.AtomicLong NEXT_CHAIN = new java.util.concurrent.atomic.AtomicLong();
    private static final int MAX_CACHE_CHARS = 128 * 1024;
    private static final long EMERGENCY_BUDGET_MS = 8_000L;
    private static final long SELF_HOSTED_COMPLETION_GRACE_MS = 2_000L;
    private static final ScheduledThreadPoolExecutor EMERGENCY_EXECUTOR =
            new ScheduledThreadPoolExecutor(2, r -> {
                Thread thread = new Thread(r, "mango-emergency"); thread.setDaemon(true); return thread;
            });
    // A permit covers both asynchronous rescue attempts, not just their launch runnable.
    private static final TranslationDispatchQueue EMERGENCY_DISPATCH =
            new TranslationDispatchQueue(8, 64, EMERGENCY_EXECUTOR);
    private final int engineId;
    private final boolean cacheAllowed;
    private final LongFunction<Translator> factory;
    private final BiFunction<Integer, Long, Translator> emergencyFactory;
    private final TranslationDispatchQueue dispatch;
    private final long testBudgetMs;
    private final java.util.function.Consumer<Runnable> delivery;
    private final Map<List<Object>, Operation> active = new HashMap<>();
    private final Set<Subscription> subscriptions = new HashSet<>();
    private final LinkedHashMap<List<Object>, Cached> cache = new LinkedHashMap<>(16, .75f, true);
    private int cacheChars;
    private boolean closed;
    private Object cacheRuntime;
    private boolean cacheVip;

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), null);
    }

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), emergencyFactory);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery) {
        this(engineId, cacheAllowed, factory, dispatch, testBudgetMs, delivery, null);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this.engineId = engineId; this.cacheAllowed = cacheAllowed; this.factory = factory;
        this.dispatch = dispatch; this.testBudgetMs = testBudgetMs; this.delivery = delivery;
        this.emergencyFactory = emergencyFactory;
    }

    public static void configureResultCache(long ttlMs) {
        if (ttlMs < 0 || ttlMs > 60_000) throw new IllegalArgumentException("Cache TTL must be 0..60000 ms");
        cacheTtlMs = ttlMs;
    }

    @Override public int getEngineId() { return engineId; }
    @Override public void translate(TranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public TranslationCall translateCancellable(TranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }
    @Override public TranslationCall translateCancellable(BatchTranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }

    private synchronized TranslationCall submit(Object request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        TranslationDiagnosticContext.markSubmitted();
        Subscription subscriber = new Subscription(callback);
        if (closed) { subscriber.cancelled.set(true); return subscriber; }
        subscriptions.add(subscriber);
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        boolean vip = runtime != null && runtime.host().isVip();
        if (cacheRuntime != runtime || cacheVip != vip || cacheTtlMs == 0) {
            cache.clear(); cacheChars = 0; cacheRuntime = runtime; cacheVip = vip;
        }
        if (request == null) {
            deliver(subscriber, null, TranslationErrorMapper.invalidRequest(engineId)); return subscriber;
        }
        List<Object> key = key(request, runtime, vip);
        Cached cached = cache.get(key);
        if (cached != null && cacheAllowed && cacheTtlMs > 0
                && System.nanoTime() - cached.created < TimeUnit.MILLISECONDS.toNanos(cacheTtlMs)) {
            subscriber.source = "cache";
            deliver(subscriber, cached.result, null); return subscriber;
        }
        Operation operation = active.get(key);
        if (operation != null) subscriber.source = "merged";
        if (operation == null) {
            operation = new Operation(key, request, runtime, vip);
            active.put(key, operation);
        }
        subscriber.operation = operation;
        operation.listeners.add(subscriber);
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            int items = request instanceof BatchTranslationRequest
                    ? ((BatchTranslationRequest) request).getTexts().size() : 1;
            int chars = request instanceof BatchTranslationRequest
                    ? ((BatchTranslationRequest) request).getTexts().stream().mapToInt(String::length).sum()
                    : ((TranslationRequest) request).getText().length();
            ProviderAttemptTelemetry.debugLog("submit host=" + subscriber.diagnostic.hostRequestId
                    + " request=" + subscriber.id + " chain=" + operation.chainId
                    + " scene=" + subscriber.diagnostic.scenario + " engine=" + engineId
                    + " source=" + subscriber.source + " items=" + items + " chars=" + chars);
        }
        // Each subscriber has its own delivery gate. A merged caller shares the original chain deadline.
        if (operation.ticket == null) {
            Operation scheduled = operation;
            operation.timeout = TIMER.schedule(() -> deadlineReached(scheduled),
                    Math.max(0L, operation.deadline - System.nanoTime()), TimeUnit.NANOSECONDS);
            operation.ticket = dispatch.submit(() -> start(scheduled));
            if ((operation.done || operation.emergencyStarted) && operation.ticket != null) operation.ticket.finish();
            if (operation.ticket == null) complete(operation, null,
                    TranslationErrorMapper.fromInternalCode(TranslationErrorCode.RATE_LIMITED, engineId));
        }
        return subscriber;
    }

    private List<Object> key(Object request, TranslationRuntime runtime, boolean vip) {
        boolean batch = request instanceof BatchTranslationRequest;
        TranslationTimeoutPolicy.Settings settings = TranslationTimeoutPolicy.get();
        if (batch) {
            BatchTranslationRequest r = (BatchTranslationRequest) request;
            return Arrays.asList(runtime, vip, engineId, true, r.getSourceLanguageId(), r.getTargetLanguageId(),
                    r.getTexts(), settings);
        }
        TranslationRequest r = (TranslationRequest) request;
        return Arrays.asList(runtime, vip, engineId, false, r.getSourceLanguageId(), r.getTargetLanguageId(),
                Collections.singletonList(r.getText()), settings);
    }

    private void start(Operation operation) {
        try {
            synchronized (this) {
                if (operation.done || operation.emergencyStarted) return;
                operation.started = System.nanoTime();
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                    ProviderAttemptTelemetry.debugLog("chain_start chain=" + operation.chainId
                            + " engine=" + engineId + " queueMs="
                            + TimeUnit.NANOSECONDS.toMillis(operation.started - operation.created));
                }
                if (operation.runtime != TranslationRuntime.currentOrNull()) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.SDK_NOT_INITIALIZED, engineId)); return;
                }
                if (operation.runtime != null && operation.vip != operation.runtime.host().isVip()) {
                    complete(operation, null, TranslationErrorMapper.vipRequired(engineId)); return;
                }
                operation.translator = TranslationRuntime.callWithSnapshot(operation.runtime,
                        () -> factory.apply(operation.deadline));
                if (operation.translator == null) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.ENGINE_NOT_CONFIGURED, engineId)); return;
                }
            }
                TranslationCallback callback = new TranslationCallback() {
                    @Override public void onSuccess(TranslationResult result) {
                        completeOrdinary(operation, result, null);
                    }
                    @Override public void onError(TranslationError error) {
                        completeOrdinary(operation, null, error);
                    }
                };
                TranslationRuntime.withSnapshot(operation.runtime, () ->
                com.mg.translation.internal.base.http.RequestContext.withTrace(operation.chainId, () -> {
                    if (operation.request instanceof BatchTranslationRequest)
                        operation.translator.translate((BatchTranslationRequest) operation.request, callback);
                    else operation.translator.translate((TranslationRequest) operation.request, callback);
                }));
        } catch (RuntimeException error) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(TranslationErrorCode.UNKNOWN, engineId));
        }
    }

    private synchronized void completeOrdinary(Operation operation, TranslationResult result, TranslationError error) {
        if (operation.done || operation.emergencyStarted) return;
        if (error == null && !TranslationResultValidation.matches(operation.request, result)) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(
                    TranslationErrorCode.INVALID_PROVIDER_RESPONSE, engineId));
            return;
        }
        if (error != null && error.getCode() == TranslationErrorCode.REQUEST_TIMEOUT) {
            deadlineReached(operation);
        } else {
            complete(operation, result, error);
        }
    }

    /** Moves a deadline-expired request to the independent final rescue chain. */
    private void deadlineReached(Operation operation) {
        synchronized (this) {
            if (operation.done || operation.emergencyStarted) return;
            operation.emergencyStarted = true;
            if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                ProviderAttemptTelemetry.debugLog("deadline_rescue chain=" + operation.chainId
                        + " engine=" + engineId + " started=" + (operation.started != 0));
            }
            operation.emergencyDeadline = System.nanoTime()
                    + TimeUnit.MILLISECONDS.toNanos(EMERGENCY_BUDGET_MS);
            if (operation.translator != null) operation.translator.close();
            if (operation.ticket != null) operation.ticket.finish();
            operation.emergencyTimeout = TIMER.schedule(
                    () -> complete(operation, null,
                            TranslationErrorMapper.fromInternalCode(
                                    TranslationErrorCode.REQUEST_TIMEOUT, engineId)),
                    EMERGENCY_BUDGET_MS, TimeUnit.MILLISECONDS);
            operation.emergencyTicket = EMERGENCY_DISPATCH.submit(() -> runEmergency(operation));
            if (operation.emergencyTicket == null) {
                complete(operation, null, TranslationErrorMapper.fromInternalCode(
                        TranslationErrorCode.RATE_LIMITED, engineId));
            } else if (operation.done) operation.emergencyTicket.finish();
        }
    }

    private void runEmergency(Operation operation) {
        runEmergencyAttempt(operation, 0);
    }

    private synchronized void runEmergencyAttempt(Operation operation, int index) {
        if (operation.done) return;
        if (operation.runtime != TranslationRuntime.currentOrNull()) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(
                    TranslationErrorCode.SDK_NOT_INITIALIZED, engineId));
            return;
        }
        if (index >= 2 || System.nanoTime() >= operation.emergencyDeadline) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(
                    TranslationErrorCode.REQUEST_TIMEOUT, engineId));
            return;
        }
        int id = index == 0 ? com.mg.translation.engine.TranslatorId.BAIDU.legacyCode
                : com.mg.translation.engine.TranslatorId.QWEN.legacyCode;
        int generation = ++operation.emergencyGeneration;
        long attemptDeadline = index == 0
                ? Math.min(operation.emergencyDeadline, System.nanoTime() + TimeUnit.SECONDS.toNanos(3))
                : operation.emergencyDeadline;
        try {
            Translator rescue = emergencyFactory == null ? null : TranslationRuntime.callWithSnapshot(operation.runtime,
                    () -> emergencyFactory.apply(id, attemptDeadline));
            if (rescue == null) {
                runEmergencyAttempt(operation, index + 1);
                return;
            }
            int previousEngine = index == 0 ? engineId
                    : com.mg.translation.engine.TranslatorId.BAIDU.legacyCode;
            ProviderAttemptTelemetry.fallback(previousEngine, id, operation.chainId);
            operation.emergencyTranslator = rescue;
            operation.attemptTimeout = TIMER.schedule(
                    () -> finishEmergencyAttempt(operation, generation, index, null),
                    Math.max(0L, attemptDeadline - System.nanoTime()), TimeUnit.NANOSECONDS);
            TranslationCallback callback = new TranslationCallback() {
                public void onSuccess(TranslationResult result) {
                    finishEmergencyAttempt(operation, generation, index, result);
                }
                public void onError(TranslationError error) {
                    finishEmergencyAttempt(operation, generation, index, null);
                }
            };
            TranslationRuntime.withSnapshot(operation.runtime, () ->
            com.mg.translation.internal.base.http.RequestContext.withTrace(operation.chainId,
                    () -> {
                if (operation.request instanceof BatchTranslationRequest)
                    rescue.translate((BatchTranslationRequest) operation.request, callback);
                else rescue.translate((TranslationRequest) operation.request, callback);
            }));
        } catch (RuntimeException error) {
            finishEmergencyAttempt(operation, generation, index, null);
        }
    }

    private synchronized void finishEmergencyAttempt(Operation operation, int generation,
                                                      int index, TranslationResult result) {
        if (operation.done || generation != operation.emergencyGeneration) return;
        ++operation.emergencyGeneration;
        if (operation.attemptTimeout != null) operation.attemptTimeout.cancel(false);
        Translator previous = operation.emergencyTranslator;
        operation.emergencyTranslator = null;
        if (previous != null) previous.close();
        if (TranslationResultValidation.matches(operation.request, result)) {
            complete(operation, result, null);
        } else {
            EMERGENCY_EXECUTOR.execute(() -> runEmergencyAttempt(operation, index + 1));
        }
    }

    private synchronized void complete(Operation operation, TranslationResult result, TranslationError error) {
        if (operation.done) return;
        operation.done = true;
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            ProviderAttemptTelemetry.debugLog("chain_complete chain=" + operation.chainId
                    + " engine=" + engineId + " actual="
                    + (result == null ? 0 : result.getActualEngineId())
                    + " outcome=" + (error == null ? "success" : "error")
                    + " error=" + (error == null ? 0 : error.getCode())
                    + " rescue=" + operation.emergencyStarted + " durationMs="
                    + TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - operation.created));
        }
        active.remove(operation.key, operation);
        if (operation.timeout != null) operation.timeout.cancel(false);
        if (operation.emergencyTimeout != null) operation.emergencyTimeout.cancel(false);
        if (operation.attemptTimeout != null) operation.attemptTimeout.cancel(false);
        if (operation.translator != null) operation.translator.close();
        if (operation.emergencyTranslator != null) operation.emergencyTranslator.close();
        if (operation.ticket != null) operation.ticket.finish();
        if (operation.emergencyTicket != null) operation.emergencyTicket.finish();
        // Never pin a fallback result to the selected engine, or cache a result across runtime/membership changes.
        if (!operation.emergencyStarted && result != null && result.getActualEngineId() == engineId && cacheAllowed && cacheTtlMs > 0
                && operation.runtime == TranslationRuntime.currentOrNull()
                && (operation.runtime == null || operation.vip == operation.runtime.host().isVip())) {
            putCache(operation.key, result);
        }
        for (Subscription subscriber : operation.listeners) deliver(subscriber, result, error);
        operation.listeners.clear();
    }

    private void putCache(List<Object> key, TranslationResult result) {
        int chars = 0;
        for (Object item : (List<?>) key.get(6)) chars += ((String) item).length();
        for (String item : result.getTranslations()) chars += item.length();
        if (chars > MAX_CACHE_CHARS) return;
        Cached previous = cache.remove(key);
        if (previous != null) cacheChars -= previous.chars;
        cache.put(key, new Cached(result, chars)); cacheChars += chars;
        Iterator<Cached> iterator = cache.values().iterator();
        while ((cache.size() > 64 || cacheChars > MAX_CACHE_CHARS) && iterator.hasNext()) {
            cacheChars -= iterator.next().chars; iterator.remove();
        }
    }

    private void deliver(Subscription subscriber, TranslationResult result, TranslationError error) {
        long ready = System.nanoTime();
        delivery.accept(() -> {
            synchronized (ManagedTranslator.this) {
                subscriptions.remove(subscriber);
                if (closed || subscriber.cancelled.get() || !subscriber.delivered.compareAndSet(false, true)) return;
            }
            TranslationError deliveredError = error;
            if (subscriber.runtime != TranslationRuntime.currentOrNull())
                deliveredError = TranslationErrorMapper.fromInternalCode(TranslationErrorCode.SDK_NOT_INITIALIZED, engineId);
            else if ((subscriber.operation == null || !subscriber.operation.emergencyStarted)
                    && subscriber.runtime != null && subscriber.vip != subscriber.runtime.host().isVip())
                deliveredError = TranslationErrorMapper.vipRequired(engineId);
            // A completed result must not become a timeout merely because UI delivery was delayed.
            long now = System.nanoTime();
            Operation op = subscriber.operation;
            long queue = op == null ? 0 : Math.max(0L,
                    (op.started == 0 ? ready : op.started) - subscriber.created);
            if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                ProviderAttemptTelemetry.debugLog("done host=" + subscriber.diagnostic.hostRequestId
                        + " request=" + subscriber.id + " chain=" + (op == null ? 0 : op.chainId)
                        + " scene=" + subscriber.diagnostic.scenario + " engine=" + engineId
                        + " actual=" + (result == null ? 0 : result.getActualEngineId())
                        + " source=" + subscriber.source
                        + " outcome=" + (deliveredError == null ? "success" : "error")
                        + " error=" + (deliveredError == null ? 0 : deliveredError.getCode())
                        + " queueMs=" + TimeUnit.NANOSECONDS.toMillis(queue)
                        + " callbackWaitMs=" + TimeUnit.NANOSECONDS.toMillis(now - ready)
                        + " totalMs=" + TimeUnit.NANOSECONDS.toMillis(now - subscriber.created));
            }
            if (subscriber.host != null) {
                try { subscriber.host.onTranslationFinished(subscriber.id, op == null ? 0 : op.chainId, engineId,
                        deliveredError == null ? "success" : "error", subscriber.source,
                        TimeUnit.NANOSECONDS.toMillis(queue), TimeUnit.NANOSECONDS.toMillis(now - ready),
                        TimeUnit.NANOSECONDS.toMillis(now - subscriber.created)); }
                catch (RuntimeException ignored) { }
            }
            try { if (deliveredError == null) subscriber.callback.onSuccess(result); else subscriber.callback.onError(deliveredError); }
            catch (RuntimeException ignored) { /* Host observers never trigger retries. */ }
        });
    }

    @Override public synchronized void clearResultCache() { cache.clear(); cacheChars = 0; }
    @Override public synchronized void close() {
        closed = true;
        for (Subscription subscriber : new ArrayList<>(subscriptions)) subscriber.cancel();
        clearResultCache();
    }

    private final class Subscription implements TranslationCall {
        final long id = NEXT_REQUEST.incrementAndGet();
        final long created = System.nanoTime();
        final long deadline = created + TimeUnit.MILLISECONDS.toNanos(budgetMs());
        final TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        final TranslationHost host = runtime == null ? null : runtime.host();
        final TranslationDiagnosticContext.State diagnostic = TranslationDiagnosticContext.snapshot();
        final boolean vip = host != null && host.isVip();
        String source = "network";
        final TranslationCallback callback;
        final AtomicBoolean cancelled = new AtomicBoolean();
        final AtomicBoolean delivered = new AtomicBoolean();
        Operation operation;
        Subscription(TranslationCallback callback) { this.callback = callback; }
        @Override public boolean isCancelled() { return cancelled.get(); }
        @Override public void cancel() {
            synchronized (ManagedTranslator.this) {
                if (!cancelled.compareAndSet(false, true)) return;
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                    ProviderAttemptTelemetry.debugLog("cancel host=" + diagnostic.hostRequestId
                            + " request=" + id + " chain="
                            + (operation == null ? 0 : operation.chainId)
                            + " scene=" + diagnostic.scenario + " engine=" + engineId);
                }
                subscriptions.remove(this);
                if (operation != null && !operation.done) {
                    operation.listeners.remove(this);
                    if (operation.listeners.isEmpty()) complete(operation, null,
                            TranslationErrorMapper.fromInternalCode(TranslationErrorCode.CANCELLED, engineId));
                }
            }
        }
    }

    private final class Operation {
        final long chainId = NEXT_CHAIN.incrementAndGet();
        final long created = System.nanoTime();
        final List<Object> key;
        final Object request;
        final TranslationRuntime runtime;
        final boolean vip;
        final long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(operationBudgetMs());
        final List<Subscription> listeners = new ArrayList<>();
        Translator translator;
        TranslationDispatchQueue.Ticket ticket;
        TranslationDispatchQueue.Ticket emergencyTicket;
        ScheduledFuture<?> timeout;
        ScheduledFuture<?> emergencyTimeout;
        boolean emergencyStarted;
        long emergencyDeadline;
        int emergencyGeneration;
        ScheduledFuture<?> attemptTimeout;
        Translator emergencyTranslator;
        boolean done;
        long started;
        Operation(List<Object> key, Object request, TranslationRuntime runtime, boolean vip) {
            this.key = key; this.request = request; this.runtime = runtime; this.vip = vip;
        }
    }
    private static final class Cached {
        final TranslationResult result;
        final int chars;
        final long created = System.nanoTime();
        Cached(TranslationResult result, int chars) { this.result = result; this.chars = chars; }
    }

    private long budgetMs() { return testBudgetMs > 0 ? testBudgetMs : TranslationTimeoutPolicy.get().requestBudgetMs; }
    private long operationBudgetMs() {
        long configured = budgetMs();
        if (testBudgetMs > 0) return configured;
        com.mg.translation.engine.TranslatorId id =
                com.mg.translation.engine.TranslatorId.fromLegacyCode(engineId);
        boolean selfHosted = id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_GOOGLE
                || id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_YOUDAO
                || id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_DEEPL
                || id == com.mg.translation.engine.TranslatorId.BD;
        return configured + (selfHosted ? SELF_HOSTED_COMPLETION_GRACE_MS : 0L);
    }
}
