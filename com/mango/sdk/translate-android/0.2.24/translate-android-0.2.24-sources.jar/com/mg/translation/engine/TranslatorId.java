package com.mg.translation.engine;

import static com.mg.translation.engine.EngineCategory.*;

/**
 * 翻译引擎唯一标识枚举
 * <p>
 * legacyCode 是跨 App、平台和历史版本持久化的整数引擎 ID。
 * 每个引擎声明所属类别、当前状态和默认冷却时间。
 */
public enum TranslatorId {

    // ==================== AI 引擎 ====================
    /** 已下线：qwen-mt-turbo 不再提供，47 仅保留防止历史 ID 被复用。 */
    @Deprecated
    QWEN_TURBO(47, "QwenTurbo", AI, 5 * 60 * 1000L),
    QWEN(45, "Qwen", AI, 5 * 60 * 1000L),
    DEEPSEEK(43, "DeepSeek", AI, 5 * 60 * 1000L),
    HY_MT2(49, "Hunyuan", AI, 5 * 60 * 1000L),
    GPT_4O_MINI(50, "ChatGPT", AI, 5 * 60 * 1000L),
    GEMMA(51, "Gemma", AI, 5 * 60 * 1000L),
    GEMINI(52, "Gemini", AI, 5 * 60 * 1000L),
    /** 墓碑:旧智谱引擎已下线，legacyCode 44 永久保留且不得复用；Factory 不创建、不调度。 */
    @Deprecated
    ZHIPU(44, "Zhipu", AI, 5 * 60 * 1000L),
    ZHIPU_FLASH(46, "ZhipuFlash", AI, 5 * 60 * 1000L),

    // ==================== 免费 API ====================
    GOOGLE(2, "Google", FREE_API, 90 * 60 * 1000L),
    GOOGLE_CLIENT(8, "GoogleClient", FREE_API, 90 * 60 * 1000L),
    GOOGLE_V(9, "GoogleV", VIP, 90 * 60 * 1000L),
    BAIDU(16, "Baidu", FREE_API, 5 * 60 * 1000L),
    BD(1, "BaiduDirect", FREE_API, 10 * 60 * 1000L),
    MICROSOFT(15, "Microsoft", FREE_API, 60 * 60 * 1000L),
    MYMEMORY(4, "MyMemory", FREE_API, 5 * 60 * 1000L),
    /** 产品已全局删除，22 仅保留防止历史 ID 被复用。 */
    @Deprecated
    YOUDAO_ME(22, "YoudaoMe", FREE_API, 5 * 60 * 1000L),
    SELF_HOSTED_GOOGLE(48, "SelfHostedGoogle", FREE_API, 10 * 60 * 1000L),
    SELF_HOSTED_YOUDAO(53, "SelfHostedYoudao", FREE_API, 5 * 60 * 1000L),
    SELF_HOSTED_DEEPL(54, "SelfHostedDeepL", FREE_API, 10 * 60 * 1000L),

    // ==================== RapidAPI ====================
    RAPID_AI(18, "RapidAI", RAPID_API, 5 * 60 * 1000L),
    /** 产品明确不对接且生产 Key 返回 403，27 不再注册。 */
    @Deprecated
    RAPID_AIBIT(27, "RapidAiBit", RAPID_API, 5 * 60 * 1000L),
    RAPID_DEEP(14, "RapidDeep", RAPID_API, 5 * 60 * 1000L),
    /** 产品决定不再使用，11 仅保留防止历史 ID 被复用。 */
    @Deprecated
    RAPID_NLP(11, "RapidNLP", RAPID_API, 5 * 60 * 1000L),
    RAPID_PLUS(19, "RapidPlus", RAPID_API, 5 * 60 * 1000L),
    /** 墓碑:接口失效已于 2026-07 下线,legacyCode 保留防复用;Factory 不创建、不调度 */
    @Deprecated
    RAPID_MOHAMMED(28, "RapidMohammed", RAPID_API, 5 * 60 * 1000L),
    /** 墓碑:接口失效已于 2026-07 下线,legacyCode 保留防复用;Factory 不创建、不调度 */
    @Deprecated
    RAPID_JUSTMOBI(29, "RapidJustMobi", RAPID_API, 5 * 60 * 1000L),
    /** 产品决定不再使用，30 仅保留防止历史 ID 被复用。 */
    @Deprecated
    RAPID_UNDERGROUND(30, "RapidUnderground", RAPID_API, 5 * 60 * 1000L),
    RAPID_WEBSITE_PLUS(32, "RapidWebsitePlus", RAPID_API, 5 * 60 * 1000L),
    RAPID_MULTI(34, "RapidMulti", RAPID_API, 5 * 60 * 1000L),
    RAPID_IRCTCAPI(36, "RapidIrctcapi", RAPID_API, 5 * 60 * 1000L),
    /** 产品决定不再使用，37 仅保留防止历史 ID 被复用。 */
    @Deprecated
    RAPID_MIXER_BOX(37, "RapidMixerBox", RAPID_API, 5 * 60 * 1000L),
    YOUDAO(23, "Youdao", RAPID_API, 5 * 60 * 1000L),

    // ==================== VIP ====================
    MICROSOFT_VIP(31, "MicrosoftVip", VIP, 60 * 60 * 1000L),

    // ==================== 特殊 ====================
    /** 产品已全局删除，21 仅保留防止历史 ID 被复用。 */
    @Deprecated
    TIPS(21, "VipTips", FREE_API, 0L);

    /** 跨版本持久化的整数引擎 ID。 */
    public final int legacyCode;

    /**
     * 引擎名称（用于日志和调试）
     */
    public final String displayName;

    /**
     * 引擎类别
     */
    public final EngineCategory category;

    /**
     * 错误后默认冷却时间（毫秒）
     */
    public final long defaultCooldownMs;

    TranslatorId(int legacyCode, String displayName, EngineCategory category, long defaultCooldownMs) {
        this.legacyCode = legacyCode;
        this.displayName = displayName;
        this.category = category;
        this.defaultCooldownMs = defaultCooldownMs;
    }

    /**
     * 通过 legacyCode 查找 TranslatorId（兼容现有代码）
     *
     * @return 对应的 TranslatorId，找不到返回 null
     */
    public static TranslatorId fromLegacyCode(int code) {
        for (TranslatorId id : values()) {
            if (id.legacyCode == code) {
                return id;
            }
        }
        return null;
    }

    public boolean isRetired() {
        switch (this) {
            case QWEN_TURBO:
            case ZHIPU:
            case YOUDAO_ME:
            case TIPS:
            case RAPID_AIBIT:
            case RAPID_NLP:
            case RAPID_MOHAMMED:
            case RAPID_JUSTMOBI:
            case RAPID_UNDERGROUND:
            case RAPID_MIXER_BOX:
                return true;
            default:
                return false;
        }
    }

    public boolean requiresEndpointCredential() {
        return this == QWEN || this == HY_MT2
                || this == GPT_4O_MINI || this == GEMMA || this == GEMINI
                || this == ZHIPU_FLASH
                || this == BD || this == SELF_HOSTED_GOOGLE || this == SELF_HOSTED_YOUDAO
                || this == SELF_HOSTED_DEEPL;
    }

    public boolean isOpenAiCompatibleTranslation() {
        return this == DEEPSEEK || this == HY_MT2 || this == GPT_4O_MINI
                || this == GEMMA || this == GEMINI || this == ZHIPU_FLASH;
    }

    public boolean supportsBatch() {
        return this != MYMEMORY;
    }

    /** Maximum time reserved before starting this engine as an automatic fallback. */
    public long requestTimeoutMs() {
        if (this == SELF_HOSTED_GOOGLE)
            return com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().googleCallMs;
        if (this == BD || this == SELF_HOSTED_GOOGLE || this == SELF_HOSTED_YOUDAO
                || this == SELF_HOSTED_DEEPL)
            return com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().selfHostedCallMs;
        return category == AI ? 10_000L : 3_000L;
    }

}
