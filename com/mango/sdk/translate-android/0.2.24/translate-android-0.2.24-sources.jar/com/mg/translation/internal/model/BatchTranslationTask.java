package com.mg.translation.internal.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.mg.translation.sdk.TranslationResult;

/** SDK-internal mutable state for an ordered batch translation. */
public final class BatchTranslationTask extends TranslationTask {
    private List<String> sourceTexts;
    private List<String> translations;
    private List<Integer> untranslatedSourceIds = Collections.emptyList();
    private volatile boolean unalignedResponseSeen;
    private volatile boolean otherFailureSeen;
    private volatile TranslationResult bestUnalignedResult;

    public BatchTranslationTask() {
    }

    public BatchTranslationTask(List<String> sourceTexts, String sourceLanguageId,
                                String targetLanguageId) {
        super(sourceLanguageId, targetLanguageId);
        setSourceTexts(sourceTexts);
    }

    public List<String> getSourceTexts() {
        return sourceTexts == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(sourceTexts);
    }

    public void setSourceTexts(List<String> sourceTexts) {
        this.sourceTexts = sourceTexts == null ? new ArrayList<>() : new ArrayList<>(sourceTexts);
        this.translations = new ArrayList<>(Collections.nCopies(this.sourceTexts.size(), null));
    }

    public List<String> getTranslations() {
        return translations == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(translations);
    }

    public String getTranslation(int index) {
        return translations.get(index);
    }

    public void setTranslation(int index, String translation) {
        translations.set(index, translation);
    }

    public void setUntranslatedSourceIds(List<Integer> ids) {
        untranslatedSourceIds = ids == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(ids));
    }

    public List<Integer> getUntranslatedSourceIds() { return untranslatedSourceIds; }

    /** Reset mutable Provider state before trying another engine on this request. */
    public void clearAttemptResults() {
        translations = new ArrayList<>(Collections.nCopies(getSourceTexts().size(), null));
        untranslatedSourceIds = Collections.emptyList();
    }

    public void markUnalignedResponse() {
        unalignedResponseSeen = true;
        TranslationTask root = historyOwner();
        if (root != this && root instanceof BatchTranslationTask) {
            ((BatchTranslationTask) root).unalignedResponseSeen = true;
        }
    }
    public boolean hasUnalignedResponse() { return unalignedResponseSeen; }
    public boolean hasLocalUnalignedResponse() { return unalignedResponseSeen; }
    public void markOtherFailure() {
        otherFailureSeen = true;
        TranslationTask owner = historyOwner();
        if (owner != this && owner instanceof BatchTranslationTask)
            ((BatchTranslationTask) owner).otherFailureSeen = true;
    }
    public boolean hasOtherFailure() { return otherFailureSeen; }

    /** Keep the most useful proven rows if all later Provider attempts fail. */
    public void rememberUnaligned(TranslationResult result) {
        if (result == null || !result.isUnaligned()) return;
        markUnalignedResponse();
        TranslationTask owner = historyOwner();
        BatchTranslationTask root = owner instanceof BatchTranslationTask
                ? (BatchTranslationTask) owner : this;
        synchronized (root) {
            if (root.bestUnalignedResult == null
                    || result.getUntranslatedSourceIds().size()
                            < root.bestUnalignedResult.getUntranslatedSourceIds().size()) {
                root.bestUnalignedResult = result;
            }
        }
    }

    public TranslationResult bestUnalignedResult() {
        TranslationTask owner = historyOwner();
        return owner instanceof BatchTranslationTask
                ? ((BatchTranslationTask) owner).bestUnalignedResult : bestUnalignedResult;
    }

    @Override
    public String getTranslatedText() {
        if (translations == null || translations.isEmpty()) {
            return null;
        }
        StringBuilder stringBuffer = new StringBuilder();
        for (String translation : translations) {
            if (translation != null) {
                stringBuffer.append(translation);
            }
            stringBuffer.append("\n");
        }
        return stringBuffer.toString().trim();
    }
}
