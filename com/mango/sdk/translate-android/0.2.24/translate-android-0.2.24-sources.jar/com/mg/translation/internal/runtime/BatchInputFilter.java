package com.mg.translation.internal.runtime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Common batch preprocessing before any Provider or fallback receives the request. */
public final class BatchInputFilter {
    private BatchInputFilter() { }

    static Plan plan(List<String> sources) {
        List<String> original = new ArrayList<>(sources);
        List<String> sent = new ArrayList<>();
        List<Integer> sentIds = new ArrayList<>();
        List<Integer> skippedIds = new ArrayList<>();
        for (int id = 0; id < original.size(); id++) {
            if (original.get(id) == null) throw new IllegalArgumentException("batch text is required");
            if (!isBlank(original.get(id))) {
                sent.add(original.get(id));
                sentIds.add(id);
            } else {
                skippedIds.add(id);
            }
        }
        return new Plan(original, sent, sentIds, skippedIds);
    }

    public static boolean isBlank(String text) {
        if (text == null) return false;
        for (int offset = 0; offset < text.length(); ) {
            int point = text.codePointAt(offset);
            if (!isUnicodeWhiteSpace(point)) return false;
            offset += Character.charCount(point);
        }
        return true;
    }

    private static boolean isUnicodeWhiteSpace(int point) {
        return point >= 0x0009 && point <= 0x000D
                || point == 0x0020 || point == 0x0085 || point == 0x00A0
                || point == 0x1680 || point >= 0x2000 && point <= 0x200A
                || point == 0x2028 || point == 0x2029 || point == 0x202F
                || point == 0x205F || point == 0x3000;
    }

    static final class Plan {
        final List<String> original;
        final List<String> sent;
        final List<Integer> sentIds;
        final List<Integer> skippedIds;

        Plan(List<String> original, List<String> sent,
             List<Integer> sentIds, List<Integer> skippedIds) {
            this.original = Collections.unmodifiableList(original);
            this.sent = Collections.unmodifiableList(sent);
            this.sentIds = Collections.unmodifiableList(sentIds);
            this.skippedIds = Collections.unmodifiableList(skippedIds);
        }

        List<String> restore(List<String> translated) {
            if (translated == null || translated.size() != sent.size()) {
                throw new IllegalArgumentException("Filtered batch result length mismatch");
            }
            List<String> restored = new ArrayList<>(original);
            for (int index = 0; index < sentIds.size(); index++) {
                restored.set(sentIds.get(index), translated.get(index));
            }
            return restored;
        }

        List<Integer> restoreMissingIds(List<Integer> missingSentIds) {
            List<Integer> restored = new ArrayList<>();
            for (Integer sentId : missingSentIds) {
                if (sentId == null || sentId < 0 || sentId >= sentIds.size()) {
                    throw new IllegalArgumentException("Invalid filtered batch source ID");
                }
                restored.add(sentIds.get(sentId));
            }
            return restored;
        }
    }
}
