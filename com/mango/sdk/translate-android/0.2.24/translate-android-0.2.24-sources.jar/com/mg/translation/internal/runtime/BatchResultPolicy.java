package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.sdk.TranslationResult;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reconciles only rows whose original position is known; never shifts a short response. */
final class BatchResultPolicy {
    private BatchResultPolicy() { }

    static int allowedMissing(int sentCount) {
        return sentCount <= 10 ? 0 : sentCount / 10;
    }

    static TranslationResult fromTask(BatchTranslationTask task, int engineId) {
        return reconcile(task.getSourceTexts(), task.getTranslations(),
                task.getUntranslatedSourceIds(), engineId);
    }

    static TranslationResult reconcile(List<String> sources, List<String> translations,
                                       List<Integer> reportedMissing, int engineId) {
        if (sources == null || translations == null || sources.size() != translations.size()
                || sources.isEmpty() || reportedMissing == null) {
            throw new IllegalArgumentException("Unalignable batch response length");
        }
        Set<Integer> missingSet = new HashSet<>();
        for (Integer id : reportedMissing) {
            if (id == null || id < 0 || id >= sources.size() || !missingSet.add(id)) {
                throw new IllegalArgumentException("Invalid missing batch ID");
            }
        }
        List<String> values = new ArrayList<>(translations.size());
        List<Integer> missing = new ArrayList<>();
        int sent = 0;
        int valid = 0;
        for (int id = 0; id < sources.size(); id++) {
            String source = sources.get(id);
            if (source == null) throw new IllegalArgumentException("Missing source text");
            boolean sourceBlank = BatchInputFilter.isBlank(source);
            if (!sourceBlank) sent++;
            String value = translations.get(id);
            if (missingSet.contains(id) || value == null || BatchInputFilter.isBlank(value)) {
                values.add("");
                if (!sourceBlank) missing.add(id);
            } else {
                values.add(value);
                if (!sourceBlank) valid++;
            }
        }
        TranslationResult.Status status = missing.isEmpty() ? TranslationResult.Status.COMPLETE
                : valid > 0 && missing.size() <= allowedMissing(sent)
                ? TranslationResult.Status.PARTIAL : TranslationResult.Status.UNALIGNED;
        return new TranslationResult(values, engineId, true, missing, status);
    }

    static TranslationResult empty(List<String> sources, int engineId) {
        List<String> empty = new ArrayList<>(sources.size());
        for (int i = 0; i < sources.size(); i++) empty.add("");
        return reconcile(sources, empty, new ArrayList<>(), engineId);
    }
}
