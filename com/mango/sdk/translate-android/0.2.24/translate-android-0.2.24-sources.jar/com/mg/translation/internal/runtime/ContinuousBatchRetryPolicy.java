package com.mg.translation.internal.runtime;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

/** Briefly avoids a short-batch Provider that repeatedly returns unaligned rows. */
final class ContinuousBatchRetryPolicy {
    static final int SHORT_BATCH_MAX = 10;
    private static final long FAILURE_WINDOW_NS = TimeUnit.MINUTES.toNanos(1);
    private static final long AVOID_NS = TimeUnit.SECONDS.toNanos(45);
    private static final ContinuousBatchRetryPolicy PROCESS =
            new ContinuousBatchRetryPolicy(System::nanoTime);

    static ContinuousBatchRetryPolicy process() { return PROCESS; }

    private final LongSupplier clock;
    private final Map<Integer, State> states = new HashMap<>();
    private Object runtimeKey;

    ContinuousBatchRetryPolicy(LongSupplier clock) {
        if (clock == null) throw new IllegalArgumentException("clock is required");
        this.clock = clock;
    }

    synchronized void recordUnaligned(Object runtime, int engineId) {
        if (runtime == null || engineId <= 0) return;
        resetFor(runtime);
        long now = clock.getAsLong();
        State state = states.computeIfAbsent(engineId, ignored -> new State());
        if (state.avoidUntil > now) return;
        if (state.avoidUntil != 0 || now - state.lastFailure > FAILURE_WINDOW_NS) {
            state.failures = 0;
            state.avoidUntil = 0;
        }
        state.lastFailure = now;
        if (++state.failures >= 2) {
            state.failures = 0;
            state.avoidUntil = now + AVOID_NS;
        }
    }

    synchronized void recordComplete(Object runtime, int engineId) {
        if (runtime == null || engineId <= 0) return;
        resetFor(runtime);
        states.remove(engineId);
    }

    synchronized boolean shouldAvoid(Object runtime, int engineId) {
        if (runtime == null || engineId <= 0) return false;
        resetFor(runtime);
        State state = states.get(engineId);
        if (state == null || state.avoidUntil == 0) return false;
        long now = clock.getAsLong();
        if (now < state.avoidUntil) return true;
        states.remove(engineId);
        return false;
    }

    synchronized void clear() {
        states.clear();
        runtimeKey = null;
    }

    private void resetFor(Object runtime) {
        if (runtimeKey == runtime) return;
        states.clear();
        runtimeKey = runtime;
    }

    private static final class State {
        int failures;
        long lastFailure;
        long avoidUntil;
    }
}
