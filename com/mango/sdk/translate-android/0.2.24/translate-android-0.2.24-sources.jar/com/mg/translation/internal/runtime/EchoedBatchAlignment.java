package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Matches shortened Provider responses only when the Provider echoes a unique source item. */
public final class EchoedBatchAlignment {
    private EchoedBatchAlignment() { }

    public static int apply(BatchTranslationTask task, List<String> echoedSources,
                            List<String> translatedTexts) {
        if (task == null || echoedSources == null || translatedTexts == null
                || echoedSources.size() != translatedTexts.size()) {
            throw new IllegalArgumentException("Echoed batch response is invalid");
        }
        List<String> sources = echoedSources;
        List<String> translations = translatedTexts;
        for (int i = 0; i < echoedSources.size(); i++) {
            String source = echoedSources.get(i);
            String translation = translatedTexts.get(i);
            if (source != null && translation != null
                    && source.indexOf('\n') >= 0 && translation.indexOf('\n') >= 0) {
                sources = new ArrayList<>();
                translations = new ArrayList<>();
                for (int row = 0; row < echoedSources.size(); row++) {
                    String original = echoedSources.get(row);
                    String translated = translatedTexts.get(row);
                    if (original != null && translated != null
                            && original.indexOf('\n') >= 0 && translated.indexOf('\n') >= 0
                            && limitedLineCount(original, task.getSourceTexts().size()) > 1
                            && limitedLineCount(original, task.getSourceTexts().size())
                                    == limitedLineCount(translated, task.getSourceTexts().size())) {
                        String[] sourceLines = original.replace("\r\n", "\n").split("\n", -1);
                        String[] translatedLines = translated.replace("\r\n", "\n").split("\n", -1);
                        if (sourceLines.length == translatedLines.length) {
                            for (int line = 0; line < sourceLines.length; line++) {
                                sources.add(sourceLines[line]);
                                translations.add(translatedLines[line]);
                            }
                            continue;
                        }
                    }
                    sources.add(original);
                    translations.add(translated);
                }
                break;
            }
        }
        task.clearAttemptResults();
        Map<String, Integer> uniqueSourceIds = new HashMap<>();
        Set<String> duplicateSources = new HashSet<>();
        List<String> originals = task.getSourceTexts();
        for (int id = 0; id < originals.size(); id++) {
            String key = key(originals.get(id));
            if (key == null) continue;
            if (uniqueSourceIds.putIfAbsent(key, id) != null) duplicateSources.add(key);
        }
        Set<String> repeatedReplies = new HashSet<>();
        Set<String> seenReplies = new HashSet<>();
        for (String source : sources) {
            String key = key(source);
            if (key != null && !seenReplies.add(key)) repeatedReplies.add(key);
        }
        int mapped = 0;
        for (int index = 0; index < sources.size(); index++) {
            String key = key(sources.get(index));
            if (key == null || duplicateSources.contains(key) || repeatedReplies.contains(key))
                continue;
            Integer id = uniqueSourceIds.get(key);
            String translation = translations.get(index);
            if (id != null && translation != null && !BatchInputFilter.isBlank(translation)) {
                task.setTranslation(id, translation.trim());
                mapped++;
            }
        }
        return mapped;
    }

    private static String key(String value) {
        if (value == null || BatchInputFilter.isBlank(value)) return null;
        return value.trim();
    }

    private static int limitedLineCount(String value, int maximum) {
        int count = 1;
        for (int i = 0; i < value.length(); i++) {
            if (value.charAt(i) == '\n' && ++count > maximum) return -1;
        }
        return count;
    }
}
