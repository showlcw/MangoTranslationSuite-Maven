package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationCall;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.sdk.Translator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/** Bounded, runtime-scoped engine reuse; each caller receives an isolated cancellable lease. */
public final class SharedTranslatorPool {
    private static final int MAX_CACHED_ENGINES = 8;
    private static final long IDLE_MS = TimeUnit.MINUTES.toMillis(5);
    private static final SharedTranslatorPool PROCESS = new SharedTranslatorPool(
            MAX_CACHED_ENGINES, IDLE_MS,
            action -> io.reactivex.android.schedulers.AndroidSchedulers.mainThread()
                    .scheduleDirect(action));

    private final int maxCachedEngines;
    private final long idleMs;
    private final Consumer<Runnable> delivery;
    private final ScheduledThreadPoolExecutor timer = new ScheduledThreadPoolExecutor(1, action -> {
        Thread thread = new Thread(action, "mango-translator-idle");
        thread.setDaemon(true);
        return thread;
    });
    private final LinkedHashMap<Integer, Entry> cached = new LinkedHashMap<>(16, .75f, true);
    private final Map<Integer, Entry> overflow = new HashMap<>();
    private Object runtimeKey;

    public static SharedTranslatorPool process() { return PROCESS; }

    SharedTranslatorPool(int maxCachedEngines, long idleMs, Consumer<Runnable> delivery) {
        if (maxCachedEngines < 1 || idleMs < 1 || delivery == null)
            throw new IllegalArgumentException("Invalid translator pool bounds");
        this.maxCachedEngines = maxCachedEngines;
        this.idleMs = idleMs;
        this.delivery = delivery;
        timer.setRemoveOnCancelPolicy(true);
    }

    public Translator acquire(Object currentRuntime, int engineId, Supplier<Translator> factory) {
        if (currentRuntime == null || factory == null)
            throw new IllegalArgumentException("Runtime and translator factory are required");
        List<Retired> retire = new ArrayList<>();
        Lease lease;
        try {
            synchronized (this) {
                if (runtimeKey != currentRuntime) {
                    for (Entry old : cached.values()) retire.add(detach(old));
                    for (Entry old : overflow.values()) retire.add(detach(old));
                    cached.clear();
                    overflow.clear();
                    runtimeKey = currentRuntime;
                }
                Entry entry = cached.get(engineId);
                if (entry == null) entry = overflow.get(engineId);
                if (entry == null) {
                    if (cached.size() >= maxCachedEngines) {
                        Iterator<Entry> iterator = cached.values().iterator();
                        while (iterator.hasNext()) {
                            Entry candidate = iterator.next();
                            if (candidate.handles.isEmpty()) {
                                iterator.remove();
                                retire.add(detach(candidate));
                                break;
                            }
                        }
                    }
                    boolean pooled = cached.size() < maxCachedEngines;
                    Translator core = factory.get();
                    if (core == null || core.getEngineId() != engineId) {
                        if (core != null) core.close();
                        throw new IllegalArgumentException("Engine factory returned the wrong Translator");
                    }
                    entry = new Entry(engineId, core, pooled);
                    if (pooled) cached.put(engineId, entry);
                    else overflow.put(engineId, entry);
                }
                if (entry.eviction != null) entry.eviction.cancel(false);
                entry.eviction = null;
                lease = new Lease(entry);
                entry.handles.add(lease);
            }
        } finally {
            for (Retired old : retire) closeRetired(old);
        }
        return lease;
    }

    /** Configuration replacement retires old engines and fails their pending calls. */
    public void invalidate() {
        List<Retired> retire = new ArrayList<>();
        synchronized (this) {
            for (Entry entry : cached.values()) retire.add(detach(entry));
            for (Entry entry : overflow.values()) retire.add(detach(entry));
            cached.clear();
            overflow.clear();
            runtimeKey = null;
        }
        for (Retired old : retire) closeRetired(old);
    }

    private Retired detach(Entry entry) {
        entry.invalidated = true;
        if (entry.eviction != null) entry.eviction.cancel(false);
        entry.eviction = null;
        return new Retired(entry.core, new ArrayList<>(entry.handles));
    }

    private void closeRetired(Retired retired) {
        try {
            for (Lease handle : retired.handles) {
                try { handle.invalidate(); }
                catch (RuntimeException ignored) { /* Retire the remaining handles too. */ }
            }
        } finally {
            try { retired.core.close(); }
            catch (RuntimeException ignored) { /* New runtime remains usable. */ }
        }
    }

    private void release(Lease lease) {
        Retired retired = null;
        synchronized (this) {
            Entry entry = lease.entry;
            if (!entry.handles.remove(lease)) return;
            if (!entry.handles.isEmpty() || entry.invalidated) return;
            if (!entry.pooled) {
                overflow.remove(entry.engineId, entry);
                retired = detach(entry);
            } else {
                entry.eviction = timer.schedule(() -> evictIfIdle(entry), idleMs,
                        TimeUnit.MILLISECONDS);
            }
        }
        if (retired != null) closeRetired(retired);
    }

    private void evictIfIdle(Entry entry) {
        Retired retired = null;
        synchronized (this) {
            if (!entry.invalidated && entry.handles.isEmpty()
                    && cached.get(entry.engineId) == entry) {
                cached.remove(entry.engineId);
                retired = detach(entry);
            }
        }
        if (retired != null) closeRetired(retired);
    }

    private static final class Entry {
        final int engineId;
        final Translator core;
        final boolean pooled;
        final Set<Lease> handles = Collections.newSetFromMap(new WeakHashMap<Lease, Boolean>());
        volatile boolean invalidated;
        ScheduledFuture<?> eviction;
        Entry(int engineId, Translator core, boolean pooled) {
            this.engineId = engineId;
            this.core = core;
            this.pooled = pooled;
        }
    }

    private static final class Retired {
        final Translator core;
        final List<Lease> handles;
        Retired(Translator core, List<Lease> handles) {
            this.core = core;
            this.handles = handles;
        }
    }

    private final class Lease implements Translator {
        private final Entry entry;
        private final AtomicBoolean closed = new AtomicBoolean();
        private final Set<LeaseCall> calls = ConcurrentHashMap.newKeySet();
        Lease(Entry entry) { this.entry = entry; }

        @Override public int getEngineId() { return entry.engineId; }
        @Override public void translate(TranslationRequest request, TranslationCallback callback) {
            translateCancellable(request, callback);
        }
        @Override public void translate(BatchTranslationRequest request, TranslationCallback callback) {
            translateCancellable(request, callback);
        }
        @Override public TranslationCall translateCancellable(
                TranslationRequest request, TranslationCallback callback) {
            return submit(callback, wrapped -> entry.core.translateCancellable(request, wrapped));
        }
        @Override public TranslationCall translateCancellable(
                BatchTranslationRequest request, TranslationCallback callback) {
            return submit(callback, wrapped -> entry.core.translateCancellable(request, wrapped));
        }

        private TranslationCall submit(TranslationCallback callback,
                                       Function<TranslationCallback, TranslationCall> action) {
            if (callback == null) throw new IllegalArgumentException("callback is required");
            LeaseCall call = new LeaseCall(callback);
            if (closed.get()) { call.cancel(); return call; }
            if (entry.invalidated) { call.failInvalidated(); return call; }
            calls.add(call);
            if (closed.get()) { call.cancel(); return call; }
            if (entry.invalidated) { call.failInvalidated(); return call; }
            try {
                call.attach(action.apply(new TranslationCallback() {
                    @Override public void onSuccess(TranslationResult result) {
                        call.succeed(result);
                    }
                    @Override public void onError(TranslationError error) {
                        call.fail(error);
                    }
                }));
            } catch (RuntimeException failure) {
                call.cancel();
                throw failure;
            }
            return call;
        }

        @Override public void clearResultCache() {
            if (!closed.get() && !entry.invalidated) entry.core.clearResultCache();
        }
        @Override public void close() {
            if (!closed.compareAndSet(false, true)) return;
            for (LeaseCall call : new ArrayList<>(calls)) call.cancel();
            release(this);
        }

        void invalidate() {
            for (LeaseCall call : new ArrayList<>(calls)) call.failInvalidated();
        }

        private final class LeaseCall implements TranslationCall {
            private final TranslationCallback callback;
            private final AtomicBoolean terminal = new AtomicBoolean();
            private volatile TranslationCall upstream;
            private volatile boolean cancelled;
            LeaseCall(TranslationCallback callback) { this.callback = callback; }

            void attach(TranslationCall call) {
                if (call == null) throw new IllegalArgumentException("Missing shared translation call");
                upstream = call;
                if (cancelled) call.cancel();
            }
            @Override public void cancel() {
                cancelled = true;
                if (terminal.compareAndSet(false, true)) calls.remove(this);
                TranslationCall call = upstream;
                if (call != null) {
                    try { call.cancel(); }
                    catch (RuntimeException ignored) { /* Cancellation remains best effort. */ }
                }
            }
            @Override public boolean isCancelled() { return cancelled; }

            void succeed(TranslationResult result) {
                if (!finish()) return;
                if (entry.invalidated) { cancelled = true; deliverInvalidated(); }
                else if (!closed.get()) callback.onSuccess(result);
            }
            void fail(TranslationError error) {
                if (!finish()) return;
                if (entry.invalidated) { cancelled = true; deliverInvalidated(); }
                else if (!closed.get()) callback.onError(error);
            }
            void failInvalidated() {
                if (!finish()) return;
                cancelled = true;
                TranslationCall call = upstream;
                if (call != null) {
                    try { call.cancel(); }
                    catch (RuntimeException ignored) { /* Still notify the caller below. */ }
                }
                deliverInvalidated();
            }
            private boolean finish() {
                if (!terminal.compareAndSet(false, true)) return false;
                calls.remove(this);
                return true;
            }
            private void deliverInvalidated() {
                Runnable notify = () -> {
                    if (!closed.get()) {
                        try { callback.onError(TranslationErrorMapper.fromInternalCode(
                                TranslationErrorCode.SDK_NOT_INITIALIZED, entry.engineId)); }
                        catch (RuntimeException ignored) { /* Host observers cannot block retirement. */ }
                    }
                };
                try { delivery.accept(notify); }
                catch (RuntimeException schedulerFailure) { notify.run(); }
            }
        }
    }
}
