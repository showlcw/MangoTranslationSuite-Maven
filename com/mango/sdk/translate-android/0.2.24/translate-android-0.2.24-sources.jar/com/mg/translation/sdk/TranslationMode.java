package com.mg.translation.sdk;

/** Per-request execution policy. Continuous captures never call AI or VIP engines. */
public enum TranslationMode {
    STANDARD,
    CONTINUOUS
}
