package com.mg.translation.sdk;

/** Immutable single-text translation request. */
public final class TranslationRequest {
    private final String text;
    private final String sourceLanguageId;
    private final String targetLanguageId;
    private final TranslationMode mode;

    public TranslationRequest(String text, String sourceLanguageId, String targetLanguageId) {
        this(text, sourceLanguageId, targetLanguageId, TranslationMode.STANDARD);
    }

    public TranslationRequest(String text, String sourceLanguageId, String targetLanguageId,
                              TranslationMode mode) {
        TranslationRequestLimits.validateText(text);
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("text is required");
        }
        if (sourceLanguageId == null || sourceLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("sourceLanguageId is required");
        }
        if (targetLanguageId == null || targetLanguageId.trim().isEmpty()) {
            throw new IllegalArgumentException("targetLanguageId is required");
        }
        if (mode == null) throw new IllegalArgumentException("mode is required");
        this.text = text;
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
        this.mode = mode;
    }

    public String getText() { return text; }
    public String getSourceLanguageId() { return sourceLanguageId; }
    public String getTargetLanguageId() { return targetLanguageId; }
    public TranslationMode getMode() { return mode; }
}
