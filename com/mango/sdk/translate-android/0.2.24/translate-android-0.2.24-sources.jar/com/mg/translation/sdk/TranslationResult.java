package com.mg.translation.sdk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable translation result for both single and batch requests. */
public final class TranslationResult {
    /** UNALIGNED contains only provably matched rows; other positions are empty. */
    public enum Status { COMPLETE, PARTIAL, UNALIGNED }

    private final List<String> translations;
    private final int actualEngineId;
    private final boolean batch;
    private final List<Integer> untranslatedSourceIds;
    private final Status status;

    public TranslationResult(List<String> translations, int actualEngineId, boolean batch) {
        this(translations, actualEngineId, batch, Collections.emptyList());
    }

    public TranslationResult(List<String> translations, int actualEngineId, boolean batch,
                             List<Integer> untranslatedSourceIds) {
        this(translations, actualEngineId, batch, untranslatedSourceIds,
                untranslatedSourceIds == null || untranslatedSourceIds.isEmpty()
                        ? Status.COMPLETE : Status.PARTIAL);
    }

    public TranslationResult(List<String> translations, int actualEngineId, boolean batch,
                             List<Integer> untranslatedSourceIds, Status status) {
        if (translations == null || translations.isEmpty()) {
            throw new IllegalArgumentException("translations are required");
        }
        if (!batch && translations.size() != 1) {
            throw new IllegalArgumentException("single translation result must contain one item");
        }
        for (String translation : translations) {
            if (translation == null) {
                throw new IllegalArgumentException("translation item is required");
            }
        }
        if (untranslatedSourceIds == null || (!batch && !untranslatedSourceIds.isEmpty())) {
            throw new IllegalArgumentException("partial IDs require a batch result");
        }
        if (status == null || (status == Status.COMPLETE && !untranslatedSourceIds.isEmpty())
                || (status != Status.COMPLETE && untranslatedSourceIds.isEmpty())) {
            throw new IllegalArgumentException("batch result status does not match missing IDs");
        }
        java.util.Set<Integer> distinct = new java.util.HashSet<>();
        for (Integer id : untranslatedSourceIds) {
            if (id == null || id < 0 || id >= translations.size() || !distinct.add(id)) {
                throw new IllegalArgumentException("invalid partial source ID");
            }
        }
        this.translations = Collections.unmodifiableList(new ArrayList<>(translations));
        this.actualEngineId = actualEngineId;
        this.batch = batch;
        this.untranslatedSourceIds = Collections.unmodifiableList(
                new ArrayList<>(untranslatedSourceIds));
        this.status = status;
    }

    public String getTranslatedText() {
        return translations.isEmpty() ? null : translations.get(0);
    }

    public List<String> getTranslations() { return translations; }
    public int getActualEngineId() { return actualEngineId; }
    public boolean isBatch() { return batch; }
    public boolean isPartial() { return status == Status.PARTIAL; }
    public boolean isUnaligned() { return status == Status.UNALIGNED; }
    public Status getStatus() { return status; }
    /** Original batch positions whose translation is exactly the empty string. */
    public List<Integer> getUntranslatedSourceIds() { return untranslatedSourceIds; }
}
