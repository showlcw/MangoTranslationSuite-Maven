package com.mg.translation.sdk;

public interface Translator extends AutoCloseable {
    int getEngineId();
    void translate(TranslationRequest request, TranslationCallback callback);
    void translate(BatchTranslationRequest request, TranslationCallback callback);

    /** SDK-created translators support cancellation without closing other requests. */
    default TranslationCall translateCancellable(TranslationRequest request, TranslationCallback callback) {
        throw new UnsupportedOperationException("Cancellable requests require an SDK-created Translator");
    }

    default TranslationCall translateCancellable(BatchTranslationRequest request, TranslationCallback callback) {
        throw new UnsupportedOperationException("Cancellable requests require an SDK-created Translator");
    }

    /** Clears the SDK-owned result cache for this engine in the current runtime. */
    default void clearResultCache() { }

    /** Releases this caller's handle and cancels only its outstanding subscriptions. */
    @Override
    void close();
}
