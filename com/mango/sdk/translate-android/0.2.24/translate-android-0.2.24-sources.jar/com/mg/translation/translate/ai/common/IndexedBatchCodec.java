package com.mg.translation.translate.ai.common;

import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.runtime.BatchInputFilter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Ordered AI batch wire format. IDs make a short response safe to align with OCR rows. */
final class IndexedBatchCodec {
    private IndexedBatchCodec() { }

    static Plan plan(List<String> sources) {
        List<String> original = new ArrayList<>(sources);
        List<Item> items = new ArrayList<>();
        boolean[] requested = new boolean[original.size()];
        for (int id = 0; id < original.size(); id++) {
            String source = original.get(id);
            if (source == null) throw new IllegalArgumentException("batch text is required");
            if (!BatchInputFilter.isBlank(source)) {
                requested[id] = true;
                items.add(new Item(id, source));
            }
        }
        return new Plan(original, items, requested);
    }

    static Result parse(Plan plan, String content) {
        int actual = -1;
        try {
            JSONArray array = new JSONArray(content.trim());
            actual = array.length();
            List<String> values = plan.originalValues();
            boolean[] seen = new boolean[plan.original.size()];
            boolean[] translated = new boolean[plan.original.size()];
            boolean[] ambiguous = new boolean[plan.original.size()];
            for (int index = 0; index < array.length(); index++) {
                JSONObject entry = array.optJSONObject(index);
                if (entry == null) continue;
                Object rawId = entry.opt("id");
                if (!(rawId instanceof Integer) && !(rawId instanceof Long)) {
                    continue;
                }
                long numericId = ((Number) rawId).longValue();
                if (numericId < 0 || numericId >= seen.length) {
                    continue;
                }
                int id = (int) numericId;
                if (!plan.requested[id]) continue;
                if (seen[id]) {
                    ambiguous[id] = true;
                    translated[id] = false;
                    values.set(id, "");
                    continue;
                }
                seen[id] = true;
                Object value = entry.opt("text");
                if (!ambiguous[id] && value instanceof String
                        && !BatchInputFilter.isBlank((String) value)) {
                    values.set(id, (String) value);
                    translated[id] = true;
                }
            }
            List<Integer> missing = new ArrayList<>();
            for (Item item : plan.items) {
                if (!translated[item.id]) {
                    values.set(item.id, "");
                    missing.add(item.id);
                }
            }
            return Result.valid(values, missing, actual);
        } catch (JSONException invalid) {
            return Result.invalid("indexed_json_invalid", actual);
        }
    }

    static final class Plan {
        final List<String> original;
        final List<Item> items;
        final boolean[] requested;

        Plan(List<String> original, List<Item> items, boolean[] requested) {
            this.original = original;
            this.items = items;
            this.requested = requested;
        }

        int sentCount() { return items.size(); }
        int skippedCount() { return original.size() - items.size(); }
        String payload() {
            List<Map<String, Object>> wire = new ArrayList<>(items.size());
            for (Item item : items) {
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("id", item.id);
                entry.put("text", item.text);
                wire.add(entry);
            }
            return GsonUtil.toJson(wire);
        }

        List<String> originalValues() {
            List<String> result = new ArrayList<>(original.size());
            for (String value : original) result.add(value == null ? "" : value);
            return result;
        }
    }

    private static final class Item {
        final int id;
        final String text;

        Item(int id, String text) { this.id = id; this.text = text; }
    }

    static final class Result {
        final List<String> values;
        final List<Integer> missingIds;
        final String failure;
        final int actualCount;

        private Result(List<String> values, List<Integer> missingIds,
                       String failure, int actualCount) {
            this.values = values;
            this.missingIds = missingIds;
            this.failure = failure;
            this.actualCount = actualCount;
        }

        static Result valid(List<String> values, List<Integer> missing, int actual) {
            return new Result(values, Collections.unmodifiableList(missing), null, actual);
        }

        static Result invalid(String reason, int actual) {
            return new Result(null, Collections.emptyList(), reason, actual);
        }
    }
}
