package com.mg.translation.translate.ai.common;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

/** Brand-neutral JSON envelope validation; positional short arrays never shift source rows. */
public final class AiBatchJson {
    private AiBatchJson() { }

    public static Object parse(String content) throws JSONException {
        JSONTokener tokener = new JSONTokener(unwrap(content));
        Object root = tokener.nextValue();
        if (!(root instanceof JSONArray) && !(root instanceof JSONObject))
            throw new JSONException("Expected JSON array or object");
        if (tokener.nextClean() != 0) throw new JSONException("Extra data after JSON");
        return root;
    }

    public static String unwrap(String content) throws JSONException {
        if (content == null) throw new JSONException("Missing JSON");
        String json = content.trim();
        if (json.startsWith("```")) {
            int lineEnd = json.indexOf('\n');
            if (lineEnd < 0 || !json.endsWith("```"))
                throw new JSONException("Incomplete JSON fence");
            String language = json.substring(3, lineEnd).trim();
            if (!language.isEmpty() && !"json".equalsIgnoreCase(language))
                throw new JSONException("Unexpected JSON fence language");
            json = json.substring(lineEnd + 1, json.length() - 3).trim();
        }
        if (!json.startsWith("[") && !json.startsWith("{"))
            throw new JSONException("Expected JSON array or object");
        return json;
    }

    /** Missing indexed/string values stay empty; the SDK applies its common missing-row limit. */
    public static List<String> translations(String content, int expected, boolean allowKeyed) {
        if (expected <= 0) return null;
        try {
            Object root = parse(content);
            List<String> values = new ArrayList<>(expected);
            if (root instanceof JSONArray) {
                JSONArray array = (JSONArray) root;
                if (array.length() != expected) return null;
                for (int id = 0; id < expected; id++) values.add(text(array.opt(id)));
            } else if (allowKeyed) {
                JSONObject object = (JSONObject) root;
                boolean mapped = false;
                for (int id = 0; id < expected; id++) {
                    Object value = object.opt(String.valueOf(id));
                    mapped |= value instanceof String;
                    values.add(text(value));
                }
                if (!mapped) return null;
            } else return null;
            return values;
        } catch (JSONException invalid) {
            return null;
        }
    }

    private static String text(Object value) {
        return value instanceof String ? (String) value : "";
    }
}
