package com.mg.translation.translate.ai.common;

import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.http.ai.OpenAiChatMessage;
import com.mg.translation.http.ai.OpenAiChatRequest;
import com.mg.translation.http.ai.OpenAiChatResponse;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.runtime.ProviderAttemptTelemetry;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * Brand-neutral execution for engines using an OpenAI-compatible chat endpoint.
 * Provider classes own identity, languages and prompt placement; no Provider extends another.
 */
public abstract class OpenAiCompatibleTranslateControl extends BaseTranslateControl {
    public enum PromptPlacement { SYSTEM, USER_PREFIX }

    private final Context context;
    private final TranslatorId engineId;
    private final String displayName;
    private final String fallbackModel;
    private final PromptPlacement promptPlacement;
    private final List<LanguageVO> supportedLanguages;

    protected OpenAiCompatibleTranslateControl(Context context, TranslatorId engineId,
                                               String displayName, String fallbackModel,
                                               PromptPlacement promptPlacement,
                                               List<LanguageVO> supportedLanguages) {
        if (context == null || engineId == null || displayName == null
                || promptPlacement == null || supportedLanguages == null) {
            throw new IllegalArgumentException("AI translation engine configuration is required");
        }
        this.context = context;
        this.engineId = engineId;
        this.displayName = displayName;
        this.fallbackModel = fallbackModel;
        this.promptPlacement = promptPlacement;
        this.supportedLanguages = supportedLanguages;
    }

    @Override
    public final void translate(TranslationTask task, TranslateListener listener) {
        if (listener == null || task == null) return;
        if (TranslationSdk.isVipOnly(getTranslateType()) && !TranslateUtils.isVip(context)) {
            listener.onFail(TranslationErrorCode.VIP_REQUIRED,
                    context.getString(R.string.translation_error_vip_required));
            return;
        }
        if (task instanceof BatchTranslationTask) {
            translateBatch((BatchTranslationTask) task, listener);
        } else {
            translateSingle(task, listener);
        }
    }

    private void translateSingle(TranslationTask task, TranslateListener listener) {
        if (TextUtils.isEmpty(task.getContent())) {
            listener.onSuccess(task, getTranslateType(), false);
            return;
        }
        BaseReq request = createBaseReq(task.getContent(), task.getSourceLanguageId(),
                task.getTargetLanguageId());
        if (request == null) {
            dealTranslateError(context, task, listener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().openAiChatTranslate(
                context, engineId.legacyCode, request), response -> {
            String content = firstContent(response);
            if (TextUtils.isEmpty(content)) {
                dealTranslateError(context, task, listener);
                return;
            }
            task.setTranslatedText(content);
            listener.onSuccess(task, getTranslateType(), false);
        }, () -> dealTranslateError(context, task, listener));
    }

    private synchronized void translateBatch(BatchTranslationTask task,
                                              TranslateListener listener) {
        if (useIndexedBatch()) {
            translateIndexedBatch(task, listener);
            return;
        }
        List<String> sourceTexts = task.getSourceTexts();
        BaseReq request = createBatchRequest(copy(sourceTexts),
                task.getTargetLanguageId());
        if (request == null) {
            logBatchInvalid(task, "request_unavailable", sourceTexts.size(), -1, 0, null);
            dealTranslateError(context, task, listener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().openAiChatTranslate(
                context, engineId.legacyCode, request), response -> {
            String responseFailure = batchContentFailure(response);
            if (responseFailure != null) {
                if (response != null && response.getCode() == 0)
                    task.markUnalignedResponse();
                logBatchInvalid(task, responseFailure, sourceTexts.size(), -1, 0, response);
                dealTranslateError(context, task, listener);
                return;
            }
            String content = firstContent(response);
            int actualCount = -1;
            try {
                Object root = AiBatchJson.parse(content);
                if (!(root instanceof JSONArray)) throw new IllegalArgumentException("Expected array");
                JSONArray translations = (JSONArray) root;
                actualCount = translations.length();
                if (actualCount != sourceTexts.size()) {
                    task.markUnalignedResponse();
                    logBatchInvalid(task, "count_mismatch", sourceTexts.size(),
                            actualCount, content.length(), response);
                    dealTranslateError(context, task, listener);
                    return;
                }
                for (int index = 0; index < translations.length(); index++) {
                    Object value = translations.opt(index);
                    task.setTranslation(index, value instanceof String ? (String) value : "");
                }
                listener.onSuccess(task, getTranslateType(), true);
            } catch (Exception invalidResponse) {
                task.markUnalignedResponse();
                logBatchInvalid(task, actualCount < 0 ? "json_array_invalid" : "item_invalid",
                        sourceTexts.size(), actualCount, content.length(), response);
                dealTranslateError(context, task, listener);
            }
        }, () -> {
            logBatchInvalid(task, "request_error", sourceTexts.size(), -1, 0, null);
            dealTranslateError(context, task, listener);
        });
    }

    private void translateIndexedBatch(BatchTranslationTask task, TranslateListener listener) {
        IndexedBatchCodec.Plan plan = IndexedBatchCodec.plan(task.getSourceTexts());
        if (plan.original.isEmpty()) {
            dealTranslateError(context, task, listener);
            return;
        }
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled() && plan.skippedCount() > 0) {
            ProviderAttemptTelemetry.debugLog("ai_batch_filter chain=" + task.getTraceId()
                    + " engine=" + engineId.legacyCode + " original=" + plan.original.size()
                    + " sent=" + plan.sentCount() + " skipped=" + plan.skippedCount());
        }
        if (plan.sentCount() == 0) {
            List<String> unchanged = plan.originalValues();
            for (int index = 0; index < unchanged.size(); index++) {
                task.setTranslation(index, unchanged.get(index));
            }
            listener.onSuccess(task, getTranslateType(), true);
            return;
        }
        BaseReq request = createIndexedBatchRequest(plan, task.getTargetLanguageId());
        if (request == null) {
            logBatchInvalid(task, "request_unavailable", plan.sentCount(), -1, 0, null);
            dealTranslateError(context, task, listener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().openAiChatTranslate(
                context, engineId.legacyCode, request), response -> {
            String responseFailure = batchContentFailure(response);
            if (responseFailure != null) {
                if (response != null && response.getCode() == 0)
                    task.markUnalignedResponse();
                logBatchInvalid(task, responseFailure, plan.sentCount(), -1, 0, response);
                dealTranslateError(context, task, listener);
                return;
            }
            String content = firstContent(response);
            IndexedBatchCodec.Result result = IndexedBatchCodec.parse(plan, content);
            if (result.failure != null) {
                task.markUnalignedResponse();
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                    ProviderAttemptTelemetry.debugLog("ai_batch_shape chain=" + task.getTraceId()
                            + " engine=" + engineId.legacyCode
                            + " shape=" + IndexedBatchCodec.responseShape(content));
                }
                logBatchInvalid(task, result.failure, plan.sentCount(),
                        result.actualCount, content.length(), response);
                dealTranslateError(context, task, listener);
                return;
            }
            for (int index = 0; index < result.values.size(); index++) {
                task.setTranslation(index, result.values.get(index));
            }
            task.setUntranslatedSourceIds(result.missingIds);
            if (!result.missingIds.isEmpty() && ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                ProviderAttemptTelemetry.debugLog("ai_batch_partial chain=" + task.getTraceId()
                        + " engine=" + engineId.legacyCode + " original=" + plan.original.size()
                        + " sent=" + plan.sentCount() + " received=" + result.actualCount
                        + " missingIds=" + result.missingIds);
            }
            listener.onSuccess(task, getTranslateType(), true);
        }, () -> {
            logBatchInvalid(task, "request_error", plan.sentCount(), -1, 0, null);
            dealTranslateError(context, task, listener);
        });
    }

    static String batchContentFailure(OpenAiChatResponse response) {
        if (response == null) return "response_null";
        if (response.getCode() != 0) return "provider_code_nonzero";
        if (response.getChoices() == null || response.getChoices().isEmpty()
                || response.getChoices().get(0) == null) return "choices_missing";
        if (response.getChoices().get(0).getMessage() == null) return "message_missing";
        if (TextUtils.isEmpty(response.getChoices().get(0).getMessage().getContent())) {
            return "content_empty";
        }
        return null;
    }

    private void logBatchInvalid(BatchTranslationTask task, String reason,
                                 int expected, int actual, int contentChars,
                                 OpenAiChatResponse response) {
        if (!ProviderAttemptTelemetry.isDebugLoggingEnabled()) return;
        String finish = "missing";
        if (response != null && response.getChoices() != null
                && !response.getChoices().isEmpty() && response.getChoices().get(0) != null) {
            String value = response.getChoices().get(0).getFinishReason();
            finish = "stop".equals(value) ? "stop" : "length".equals(value) ? "length"
                    : value == null ? "missing" : "other";
        }
        ProviderAttemptTelemetry.debugLog("ai_batch_invalid chain=" + task.getTraceId()
                + " engine=" + engineId.legacyCode + " reason=" + reason
                + " expected=" + expected + " actual=" + actual
                + " contentChars=" + contentChars + " finish=" + finish);
    }

    @Override
    public final BaseReq createBaseReq(String content, String source, String target) {
        String targetCode = targetCode(target);
        if (targetCode == null) return null;
        String instruction = singleInstruction(targetCode);
        List<OpenAiChatMessage> messages = new ArrayList<>();
        if (promptPlacement == PromptPlacement.SYSTEM) {
            messages.add(new OpenAiChatMessage("system", instruction));
            messages.add(new OpenAiChatMessage("user", content));
        } else {
            messages.add(new OpenAiChatMessage("user", instruction + "\n\n" + content));
        }
        return request(messages);
    }

    private BaseReq createBatchRequest(List<String> sourceTexts, String target) {
        String targetCode = targetCode(target);
        if (targetCode == null) return null;
        return batchRequest(batchInstruction(targetCode), GsonUtil.toJson(sourceTexts));
    }

    private BaseReq createIndexedBatchRequest(IndexedBatchCodec.Plan plan, String target) {
        String targetCode = targetCode(target);
        if (targetCode == null) return null;
        String instruction = "Translate the text field of every JSON object to language code "
                + targetCode + ". Return only a JSON array of objects with the same integer id "
                + "and translated text field. Do not skip, merge, renumber or reorder ids. "
                + "There are exactly " + plan.sentCount() + " input objects.";
        return batchRequest(instruction, plan.payload());
    }

    private BaseReq batchRequest(String instruction, String payload) {
        List<OpenAiChatMessage> messages = new ArrayList<>();
        if (promptPlacement == PromptPlacement.SYSTEM) {
            messages.add(new OpenAiChatMessage("system", instruction));
            messages.add(new OpenAiChatMessage("user", payload));
        } else {
            messages.add(new OpenAiChatMessage("user", instruction + "\n\n" + payload));
        }
        return request(messages);
    }

    private OpenAiChatRequest request(List<OpenAiChatMessage> messages) {
        OpenAiChatRequest request = new OpenAiChatRequest(messages);
        if (!TextUtils.isEmpty(fallbackModel)) request.setModel(fallbackModel);
        return request;
    }

    private String targetCode(String targetLanguageId) {
        LanguageVO language = getSelectLanguageVO(targetLanguageId, false);
        return language == null ? null : language.getValue();
    }

    protected String singleInstruction(String targetCode) {
        return "Translate the user input to language code " + targetCode
                + ". Preserve meaning, formatting, punctuation, line breaks and terminology. "
                + "Return only the translation.";
    }

    protected String batchInstruction(String targetCode) {
        return "Translate every item in the JSON array to language code " + targetCode
                + ". Preserve array order and length. Return only a valid JSON array.";
    }

    protected boolean useIndexedBatch() { return false; }

    private String firstContent(OpenAiChatResponse response) {
        if (response == null || response.getCode() != 0 || response.getChoices() == null
                || response.getChoices().isEmpty() || response.getChoices().get(0) == null
                || response.getChoices().get(0).getMessage() == null) {
            return null;
        }
        return response.getChoices().get(0).getMessage().getContent();
    }

    @Override
    public final List<LanguageVO> getSupportLanguage() { return supportedLanguages; }

    @Override
    public final String getTranslateTypeName() { return displayName; }

    @Override
    public final int getTranslateType() { return engineId.legacyCode; }
}
