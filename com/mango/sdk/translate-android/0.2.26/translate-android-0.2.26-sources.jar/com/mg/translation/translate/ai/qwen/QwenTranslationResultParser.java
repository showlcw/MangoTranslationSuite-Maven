package com.mg.translation.translate.ai.qwen;

import com.mg.translation.translate.ai.common.AiBatchJson;
import java.util.List;

/** SubFlowAI 同口径的 Qwen-MT 索引 JSON/旧数组响应解析。 */
final class QwenTranslationResultParser {
    private QwenTranslationResultParser() { }

    static List<String> parse(String content, int expectedCount) {
        if (content == null || expectedCount <= 0) return null;
        try {
            // Keep Qwen's localized JSON syntax support, but validate the whole envelope.
            return AiBatchJson.translations(normalizeStructure(AiBatchJson.unwrap(content)),
                    expectedCount, true);
        } catch (org.json.JSONException invalid) {
            return null;
        }
    }

    private static String normalizeStructure(String value) {
        StringBuilder normalized = new StringBuilder(value.length());
        char expectedQuote = 0;
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (expectedQuote != 0) {
                if (current == '\\' && i + 1 < value.length()) {
                    normalized.append(current).append(value.charAt(++i));
                } else if (current == expectedQuote) {
                    normalized.append('"');
                    expectedQuote = 0;
                } else {
                    normalized.append(current);
                }
                continue;
            }
            char quoteEnd = quoteEnd(current);
            if (quoteEnd != 0) {
                normalized.append('"');
                expectedQuote = quoteEnd;
            } else if (current == '،' || current == '，' || current == '、') {
                normalized.append(',');
            } else if (current == '：') {
                normalized.append(':');
            } else {
                normalized.append(current);
            }
        }
        return removeTrailingSeparators(normalized.toString());
    }

    private static String removeTrailingSeparators(String value) {
        StringBuilder result = new StringBuilder(value.length());
        boolean inString = false;
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (current == '"' && (i == 0 || value.charAt(i - 1) != '\\')) inString = !inString;
            if (!inString && current == ',') {
                int next = i + 1;
                while (next < value.length() && Character.isWhitespace(value.charAt(next))) next++;
                if (next < value.length() && (value.charAt(next) == '}' || value.charAt(next) == ']')) {
                    continue;
                }
            }
            result.append(current);
        }
        return result.toString();
    }

    private static char quoteEnd(char start) {
        switch (start) {
            case '"':
            case '\'': return start;
            case '“': return '”';
            case '‘': return '’';
            case '«': return '»';
            default: return 0;
        }
    }
}
