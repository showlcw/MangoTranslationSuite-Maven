package com.mg.translation.internal.runtime;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;

import okhttp3.ResponseBody;
import retrofit2.HttpException;

/** Keeps a self-hosted request rejection distinct from an engine health failure. */
public final class SelfHostedRequestRejectionException extends HttpException {
    private static final int MAX_ERROR_BYTES = 4096;

    private SelfHostedRequestRejectionException(HttpException original) {
        super(original.response());
        initCause(original);
    }

    /** Called only by the self-hosted repository, before any cooldown observer. */
    public static Throwable decode(Throwable failure) {
        if (failure instanceof SelfHostedRequestRejectionException
                || !(failure instanceof HttpException)) return failure;
        HttpException http = (HttpException) failure;
        if (http.code() != 400 || http.response() == null) return failure;
        ResponseBody body = http.response().errorBody();
        if (body == null) return failure;
        try {
            // Inspect a bounded copy; preserve the original error body for other consumers.
            okio.BufferedSource source = body.source();
            source.request(MAX_ERROR_BYTES + 1L);
            if (source.buffer().size() > MAX_ERROR_BYTES) return failure;
            JsonElement parsed = JsonParser.parseString(source.buffer().clone().readUtf8());
            if (!parsed.isJsonObject()) return failure;
            JsonObject error = parsed.getAsJsonObject();
            String code = string(error, "code");
            String origin = string(error, "failureOrigin");
            String kind = string(error, "failureClass");
            if (isRejection(code, origin, kind)) {
                return new SelfHostedRequestRejectionException(http);
            }
        } catch (Exception unreadableError) {
            // Unknown or malformed errors retain the existing health-failure policy.
        }
        return failure;
    }

    /** Nodes may return a numeric error envelope over HTTP 200 instead of HTTP 400. */
    public static Throwable decodeEnvelope(MeTranslateHttpResult result) {
        if (result != null && result.getCode() == 400
                && isRejection("", result.getFailureOrigin(), result.getFailureClass())) {
            return new EnvelopeRejection();
        }
        return null;
    }

    static boolean isRequestRejection(Throwable failure) {
        return failure instanceof SelfHostedRequestRejectionException
                || failure instanceof EnvelopeRejection;
    }

    private static boolean isRejection(String code, String origin, String kind) {
        return "UPSTREAM_REQUEST_REJECTED".equals(code) || "INVALID_REQUEST".equals(code)
                || ("PROVIDER".equals(origin) && "LANGUAGE_UNSUPPORTED".equals(kind))
                || ("NODE_VALIDATION".equals(origin) && "INVALID_REQUEST".equals(kind));
    }

    private static final class EnvelopeRejection extends IllegalArgumentException {
        EnvelopeRejection() { super("Self-hosted translation input rejected"); }
    }

    private static String string(JsonObject object, String key) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()
                ? value.getAsString() : "";
    }
}
