package com.mg.translation.translate.selfhosted;

import com.mg.translation.engine.TranslatorId;

import static com.mg.translation.utils.TranslationPreferenceKeys.SELF_HOSTED_YOUDAO_TRANSLATE_STATE;
import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.common.dto.MeTranslateReq;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.text.LineTranslationPlan;
import com.mg.translation.internal.runtime.TranslationTelemetry;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.List;

/** Self-hosted Youdao. Language IDs, labels and Provider codes are owned here. */
public class SelfHostedYoudaoTranslate extends BaseTranslateControl {

    private final Context mContext;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    public SelfHostedYoudaoTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }
        String source = task.getSourceLanguageId();
        if (getSelectLanguageVO(task.getTargetLanguageId(), false) == null
                || source != null && !LanguageConstant.AUTO.equals(source)
                && getSelectLanguageVO(source, false) == null) {
            translateListener.onFail(TranslationErrorCode.UNSUPPORTED_LANGUAGE,
                    mContext.getString(R.string.translation_error_unsupported_language));
            return;
        }
        if (!TranslateUtils.getSelfHostedYoudaoApiState(mContext)) {
            dealTranslateError(mContext, task, translateListener);
            return;
        }

        TranslationTelemetry.event("self_hosted_youdao_translate_request");
        if (task instanceof BatchTranslationTask) {
            translateListApi((BatchTranslationTask) task, translateListener);
        } else {
            translateApi(task, translateListener);
        }
    }

    public void translateListApi(BatchTranslationTask translateVO, TranslateListener listener) {
        List<String> sourceTexts = translateVO.getSourceTexts();
        List<String> texts = copy(sourceTexts);
        executeRequest(TranslateRepository.getInstance().selfHostedYoudaoTranslate(
                createGatewayRequest(texts, translateVO.getSourceLanguageId(), translateVO.getTargetLanguageId())), result -> {
            String[] translated = successTexts(result, sourceTexts.size());
            if (translated == null) {
                if (result != null && result.isSuccess()) {
                    translateVO.markUnalignedResponse();
                    TranslationTelemetry.event(
                            "self_hosted_youdao_result_count_mismatch");
                }
                handleFailure(translateVO, listener, isLanguageUnsupported(result));
                return;
            }
            for (int i = 0; i < sourceTexts.size(); i++) {
                translateVO.setTranslation(i, translated[i]);
            }
            listener.onSuccess(translateVO, getTranslateType(), true);
        }, () -> handleFailure(translateVO, listener, false));
    }

    public void translateApi(TranslationTask translateVO, TranslateListener listener) {
        if (TextUtils.isEmpty(translateVO.getContent())) {
            listener.onSuccess(translateVO, getTranslateType(), false);
            return;
        }

        LineTranslationPlan plan = new LineTranslationPlan(translateVO.getContent());
        if (plan.getTexts().isEmpty()) {
            translateVO.setTranslatedText(translateVO.getContent());
            listener.onSuccess(translateVO, getTranslateType(), false);
            return;
        }
        executeRequest(sendGatewayRequest(
                createGatewayRequest(plan.getTexts(), translateVO.getSourceLanguageId(), translateVO.getTargetLanguageId())), result -> {
            String translated = plan.restore(successTexts(result, plan.getTexts().size()));
            if (translated == null) {
                handleFailure(translateVO, listener, isLanguageUnsupported(result));
                return;
            }
            translateVO.setTranslatedText(translated);
            listener.onSuccess(translateVO, getTranslateType(), false);
        }, () -> handleFailure(translateVO, listener, false));
    }

    protected io.reactivex.Single<MeTranslateHttpResult> sendGatewayRequest(MeTranslateReq request) {
        return TranslateRepository.getInstance().selfHostedYoudaoTranslate(request);
    }

    private String[] successTexts(MeTranslateHttpResult result, int expectedSize) {
        if (result == null || !result.isSuccess() || result.getTexts() == null
                || result.getTexts().length != expectedSize) {
            return null;
        }
        return result.getTexts();
    }

    private void handleFailure(TranslationTask translateVO, TranslateListener listener,
                               boolean providerLanguageRejected) {
        if (!providerLanguageRejected && shouldRecordCooldownForCurrentFailure()) {
            SdkPreferences.getInstance(mContext).put(
                    SELF_HOSTED_YOUDAO_TRANSLATE_STATE, System.currentTimeMillis());
        }
        dealTranslateError(mContext, translateVO, listener);
    }

    private static boolean isLanguageUnsupported(MeTranslateHttpResult result) {
        return result != null && "PROVIDER".equals(result.getFailureOrigin())
                && "LANGUAGE_UNSUPPORTED".equals(result.getFailureClass());
    }

    private MeTranslateReq createGatewayRequest(List<String> content, String sourceCountry, String toCountry) {
        MeTranslateReq request = new MeTranslateReq();
        LanguageVO target = getSelectLanguageVO(toCountry, false);
        if (target == null) {
            throw new IllegalArgumentException("Unsupported Youdao target language");
        }
        request.setTl(target.getValue());
        if (sourceCountry == null || LanguageConstant.AUTO.equals(sourceCountry)) {
            request.setFl("auto");
        } else {
            LanguageVO source = getSelectLanguageVO(sourceCountry, false);
            if (source == null) {
                throw new IllegalArgumentException("Unsupported Youdao source language");
            }
            request.setFl(source.getValue());
        }
        request.setQ(content.toArray(new String[0]));
        return request;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String to) {
        List<String> texts = new ArrayList<>();
        texts.add(content);
        return createGatewayRequest(texts, source, to);
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguage();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }

    private void initLanguage() {
        // Youdao web textTranslate languages verified in production, plus zh-CHT.
        // Portuguese was removed after the text endpoint repeatedly returned code 40 for en -> pt.
        // The website's much larger imageTranslate list is not this endpoint's capability.
        mDestLanguageList = new ArrayList<>();
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-CHS"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh-CHT"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
    }

    @Override
    public String getTranslateTypeName() { return mContext.getString(R.string.brand_youdao_translate); }
    @Override
    public int getTranslateType() { return TranslatorId.SELF_HOSTED_YOUDAO.legacyCode; }
}
