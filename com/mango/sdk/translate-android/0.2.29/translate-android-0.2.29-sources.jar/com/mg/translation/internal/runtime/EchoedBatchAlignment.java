package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Matches shortened Provider responses only when the Provider echoes a unique source item. */
public final class EchoedBatchAlignment {
    private EchoedBatchAlignment() { }

    public static int apply(BatchTranslationTask task, List<String> echoedSources,
                            List<String> translatedTexts) {
        if (task == null || echoedSources == null || translatedTexts == null
                || echoedSources.size() != translatedTexts.size()) {
            throw new IllegalArgumentException("Echoed batch response is invalid");
        }
        task.clearAttemptResults();
        // Segment count alone does not prove item boundaries. Exact per-position echoes
        // do, including repeated inputs and a single item containing multiple lines.
        if (echoedSources.size() == task.getSourceTexts().size()) {
            boolean ordered = true;
            for (int id = 0; id < echoedSources.size(); id++) {
                String echo = key(echoedSources.get(id));
                if (echo == null || !echo.equals(key(task.getSourceTexts().get(id)))) {
                    ordered = false; break;
                }
            }
            if (ordered) {
                int mapped = 0;
                for (int id = 0; id < translatedTexts.size(); id++) {
                    String value = translatedTexts.get(id);
                    if (value != null && !BatchInputFilter.isBlank(value)) {
                        task.setTranslation(id, value.trim()); mapped++;
                    }
                }
                return mapped;
            }
        }
        List<String> sources = echoedSources;
        List<String> translations = translatedTexts;
        int maximumLines = 0;
        for (String original : task.getSourceTexts()) {
            maximumLines += original.replace("\r\n", "\n").split("\n", -1).length;
        }
        for (int i = 0; i < echoedSources.size(); i++) {
            String source = echoedSources.get(i);
            String translation = translatedTexts.get(i);
            if (source != null && translation != null
                    && source.indexOf('\n') >= 0 && translation.indexOf('\n') >= 0
                    && !matchesWholeSource(task.getSourceTexts(), source)) {
                sources = new ArrayList<>();
                translations = new ArrayList<>();
                for (int row = 0; row < echoedSources.size(); row++) {
                    String original = echoedSources.get(row);
                    String translated = translatedTexts.get(row);
                    if (original != null && translated != null
                            && original.indexOf('\n') >= 0 && translated.indexOf('\n') >= 0
                            && !matchesWholeSource(task.getSourceTexts(), original)
                            && limitedLineCount(original, maximumLines) > 1
                            && limitedLineCount(original, maximumLines)
                                    == limitedLineCount(translated, maximumLines)) {
                        String[] sourceLines = original.replace("\r\n", "\n").split("\n", -1);
                        String[] translatedLines = translated.replace("\r\n", "\n").split("\n", -1);
                        if (sourceLines.length == translatedLines.length) {
                            for (int line = 0; line < sourceLines.length; line++) {
                                sources.add(sourceLines[line]);
                                translations.add(translatedLines[line]);
                            }
                            continue;
                        }
                    }
                    sources.add(original);
                    translations.add(translated);
                }
                break;
            }
        }
        task.clearAttemptResults();
        Map<String, Integer> uniqueSourceIds = new HashMap<>();
        Set<String> duplicateSources = new HashSet<>();
        List<String> originals = task.getSourceTexts();
        for (int id = 0; id < originals.size(); id++) {
            String key = key(originals.get(id));
            if (key == null) continue;
            if (uniqueSourceIds.putIfAbsent(key, id) != null) duplicateSources.add(key);
        }
        Set<String> repeatedReplies = new HashSet<>();
        Set<String> seenReplies = new HashSet<>();
        for (String source : sources) {
            String key = key(source);
            if (key != null && !seenReplies.add(key)) repeatedReplies.add(key);
        }
        Map<String, Integer> inputLineCounts = new HashMap<>();
        for (String original : originals) {
            for (String line : original.replace("\r\n", "\n").split("\n", -1)) {
                String value = key(line);
                if (value != null) inputLineCounts.merge(value, 1, Integer::sum);
            }
        }
        int mapped = 0;
        for (int index = 0; index < sources.size(); index++) {
            String key = key(sources.get(index));
            if (key == null || duplicateSources.contains(key) || repeatedReplies.contains(key))
                continue;
            Integer id = uniqueSourceIds.get(key);
            String translation = translations.get(index);
            if (id != null && originals.get(id).indexOf('\n') < 0
                    && inputLineCounts.getOrDefault(key, 0) != 1) continue;
            if (id != null && translation != null && !BatchInputFilter.isBlank(translation)) {
                task.setTranslation(id, translation.trim());
                mapped++;
            }
        }
        // A Provider may split one original item at its explicit newline boundaries.
        // Reassemble only when every nonblank line is globally unique and has one reply.
        for (int id = 0; id < originals.size(); id++) {
            if (task.getTranslation(id) != null || duplicateSources.contains(key(originals.get(id)))) continue;
            String[] lines = originals.get(id).replace("\r\n", "\n").split("\n", -1);
            if (lines.length < 2) continue;
            List<String> parts = new ArrayList<>();
            boolean complete = true;
            for (String line : lines) {
                String value = key(line);
                if (value == null) { parts.add(""); continue; }
                if (inputLineCounts.get(value) != 1 || repeatedReplies.contains(value)) {
                    complete = false; break;
                }
                String translated = null;
                for (int index = 0; index < sources.size(); index++) {
                    if (value.equals(key(sources.get(index)))) { translated = translations.get(index); break; }
                }
                if (translated == null || BatchInputFilter.isBlank(translated)) { complete = false; break; }
                parts.add(translated.trim());
            }
            if (complete) {
                StringBuilder joined = new StringBuilder();
                for (int line = 0; line < parts.size(); line++) {
                    if (line > 0) joined.append('\n');
                    joined.append(parts.get(line));
                }
                task.setTranslation(id, joined.toString()); mapped++;
            }
        }
        return mapped + applySentenceRuns(task, echoedSources, translatedTexts, duplicateSources);
    }

    /**
     * A Provider such as Google splits one item into sentence rows ("Hello. " + "How are you?\n").
     * Reassemble a still-missing unique item only from one contiguous run of at least two raw rows
     * whose echoes concatenate exactly to it; ambiguous starts and overlapping runs are rejected.
     * Must stay identical to Harmony SegmentProtocol.sentenceRuns.
     */
    private static int applySentenceRuns(BatchTranslationTask task, List<String> echoes,
                                         List<String> translations, Set<String> duplicateSources) {
        List<String> originals = task.getSourceTexts();
        Map<Integer, int[]> runs = new HashMap<>();
        for (int id = 0; id < originals.size(); id++) {
            String target = key(normalize(originals.get(id)));
            if (task.getTranslation(id) != null || target == null
                    || duplicateSources.contains(key(originals.get(id)))) continue;
            int[] found = null;
            boolean ambiguous = false;
            for (int start = 0; start < echoes.size() && !ambiguous; start++) {
                StringBuilder joined = new StringBuilder();
                for (int end = start; end < echoes.size(); end++) {
                    if (echoes.get(end) == null || translations.get(end) == null) break;
                    joined.append(normalize(echoes.get(end)));
                    String value = joined.toString().trim();
                    if (end > start && value.equals(target)) {
                        if (found != null) ambiguous = true;
                        found = new int[] {start, end + 1};
                        break;
                    }
                    if (!target.startsWith(value)) break;
                }
            }
            if (found != null && !ambiguous) runs.put(id, found);
        }
        Set<Integer> overlapping = new HashSet<>();
        for (Map.Entry<Integer, int[]> left : runs.entrySet()) {
            for (Map.Entry<Integer, int[]> right : runs.entrySet()) {
                if (!left.getKey().equals(right.getKey()) && left.getValue()[0] < right.getValue()[1]
                        && right.getValue()[0] < left.getValue()[1]) overlapping.add(left.getKey());
            }
        }
        int mapped = 0;
        for (Map.Entry<Integer, int[]> run : runs.entrySet()) {
            if (overlapping.contains(run.getKey())) continue;
            StringBuilder translated = new StringBuilder();
            for (int row = run.getValue()[0]; row < run.getValue()[1]; row++) {
                translated.append(normalize(translations.get(row)));
            }
            String value = translated.toString().trim();
            if (BatchInputFilter.isBlank(value)) continue;
            task.setTranslation(run.getKey(), value);
            mapped++;
        }
        return mapped;
    }

    private static String normalize(String value) {
        return value.replace("\r\n", "\n");
    }

    private static String key(String value) {
        if (value == null || BatchInputFilter.isBlank(value)) return null;
        return value.trim();
    }

    private static boolean matchesWholeSource(List<String> sources, String echo) {
        String value = key(echo);
        for (String source : sources) if (value != null && value.equals(key(source))) return true;
        return false;
    }

    private static int limitedLineCount(String value, int maximum) {
        int count = 1;
        for (int i = 0; i < value.length(); i++) {
            if (value.charAt(i) == '\n' && ++count > maximum) return -1;
        }
        return count;
    }
}
