package com.mg.translation.http.ai;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/** Provider-neutral subset of an OpenAI-compatible chat completion response. */
public class OpenAiChatResponse {
    private List<Choice> choices;
    private int code;
    private String id;

    public List<Choice> getChoices() { return choices; }
    public void setChoices(List<Choice> value) { choices = value; }
    public int getCode() { return code; }
    public void setCode(int value) { code = value; }
    public String getId() { return id; }
    public void setId(String value) { id = value; }

    /** finish_reason "length": the output hit the token limit and is incomplete. */
    public boolean isTruncated() {
        return choices != null && !choices.isEmpty() && choices.get(0) != null
                && "length".equals(choices.get(0).getFinishReason());
    }

    public static class Choice {
        private int index;
        private OpenAiChatMessage message;
        @SerializedName("finish_reason")
        private String finishReason;

        public int getIndex() { return index; }
        public void setIndex(int value) { index = value; }
        public OpenAiChatMessage getMessage() { return message; }
        public void setMessage(OpenAiChatMessage value) { message = value; }
        public String getFinishReason() { return finishReason; }
        public void setFinishReason(String value) { finishReason = value; }
    }
}
