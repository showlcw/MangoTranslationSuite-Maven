package com.mg.translation.http.translate.google;

import java.util.Map;

import io.reactivex.Single;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

public interface GoogleClientTranslateService {

    /**
     * Google free translate (client). Routing parameters stay in the query string; the text
     * is sent in the form body so long inputs never exceed URL limits (HTTP 411/414).
     */
    @FormUrlEncoded
    @POST("translate_a/single")
    Single<String> googleClientTranslate(@QueryMap Map<String, String> query,
                                         @Field("q") String text);

}
