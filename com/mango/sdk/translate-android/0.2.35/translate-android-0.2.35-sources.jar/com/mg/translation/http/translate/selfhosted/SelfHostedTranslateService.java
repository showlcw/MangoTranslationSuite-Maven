package com.mg.translation.http.translate.selfhosted;

import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;

import io.reactivex.Single;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

/** 自建翻译服务的第三方 Provider 协议，由 SDK 直接调用。 */
public interface SelfHostedTranslateService {
    @POST("api/youdao/translate")
    Single<MeTranslateHttpResult> youdaoTranslate(@Header("X-API-Key") String apiKey,
                                                 @Header("X-Translation-Chain-Id") String chainId,
                                                 @Body RequestBody request);
    @POST("api/google/translate")
    Single<MeTranslateHttpResult> googleTranslate(@Header("X-API-Key") String apiKey,
                                                  @Header("X-Translation-Chain-Id") String chainId,
                                                  @Body RequestBody request);

    @POST("api/baidu/translate")
    Single<MeTranslateHttpResult> baiduTranslate(@Header("X-API-Key") String apiKey,
                                                 @Header("X-Translation-Chain-Id") String chainId,
                                                 @Body RequestBody request);

    @POST("api/yandex/translate")
    Single<MeTranslateHttpResult> yandexTranslate(@Header("X-API-Key") String apiKey,
                                                 @Header("X-Translation-Chain-Id") String chainId,
                                                 @Body RequestBody request);

    @POST("api/deepl/translate")
    Single<MeTranslateHttpResult> deepLTranslate(@Header("X-API-Key") String apiKey,
                                                 @Header("X-Translation-Chain-Id") String chainId,
                                                 @Body RequestBody request);
}
