package com.mg.translation.internal.model;

import com.mg.translation.internal.text.LanguageIdentifier;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/** SDK-internal mutable state for one translation and its fallback attempts. */
public class TranslationTask {
    public static final long TOTAL_REQUEST_BUDGET_MS = 40_000L;
    private final long requestBudgetMs = com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().requestBudgetMs;

    private final long startedNanos = System.nanoTime();
    private long deadlineNanos = Long.MAX_VALUE;
    private long traceId;
    public void setTraceId(long trace) { traceId = trace; }
    public long getTraceId() { return traceId; }

    public void setDeadlineNanos(long deadline) { deadlineNanos = deadline; }
    public long getDeadlineNanos() { return deadlineNanos; }
    private String content;
    private String sourceLanguageId;
    private String targetLanguageId;
    private List<Integer> attemptedEngineIds;
    private String translatedText;
    private boolean freeOnlyForRequest;
    private boolean nonAiOnlyForRequest;
    private boolean emergencyRequest;
    private final java.util.Set<Integer> timeoutEngineIds = new java.util.HashSet<>();
    private volatile int lastDispatchedEngineId;
    private volatile boolean echoFallbackUsed;
    private boolean nonTimeoutFailure;
    private com.mg.translation.internal.runtime.TranslationRuntime runtime =
            com.mg.translation.internal.runtime.TranslationRuntime.snapshot();
    private TranslationTask historyOwner;

    public boolean isRuntimeCurrent() {
        return runtime == com.mg.translation.internal.runtime.TranslationRuntime.currentOrNull();
    }
    public com.mg.translation.internal.runtime.TranslationRuntime getRuntimeSnapshot() { return runtime; }
    protected TranslationTask historyOwner() { return historyOwner == null ? this : historyOwner; }

    /** Copy inputs and share only routing history; each attempt owns its output. */
    public TranslationTask copyForAttempt() {
        TranslationTask copy = this instanceof BatchTranslationTask
                ? new BatchTranslationTask(((BatchTranslationTask) this).getSourceTexts(), sourceLanguageId, targetLanguageId)
                : new TranslationTask(content, sourceLanguageId, targetLanguageId);
        copy.deadlineNanos = Math.min(deadlineNanos,
                startedNanos + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(requestBudgetMs));
        copy.traceId = traceId;
        copy.runtime = runtime;
        copy.freeOnlyForRequest = freeOnlyForRequest;
        copy.nonAiOnlyForRequest = nonAiOnlyForRequest;
        copy.emergencyRequest = emergencyRequest;
        copy.historyOwner = historyOwner == null ? this : historyOwner;
        return copy;
    }

    public TranslationTask() {
    }

    public TranslationTask(String content, String sourceLanguageId, String targetLanguageId) {
        this.content = content;
        this.sourceLanguageId = LanguageIdentifier.normalize(sourceLanguageId);
        this.targetLanguageId = LanguageIdentifier.normalize(targetLanguageId);
    }

    public TranslationTask(String sourceLanguageId, String targetLanguageId) {
        this.sourceLanguageId = LanguageIdentifier.normalize(sourceLanguageId);
        this.targetLanguageId = LanguageIdentifier.normalize(targetLanguageId);
    }


    public String getTranslatedText() {
        return translatedText;
    }

    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceLanguageId() {
        return sourceLanguageId;
    }

    public void setSourceLanguageId(String sourceLanguageId) {
        this.sourceLanguageId = LanguageIdentifier.normalize(sourceLanguageId);
    }

    public String getTargetLanguageId() {
        return targetLanguageId;
    }

    public void setTargetLanguageId(String targetLanguageId) {
        this.targetLanguageId = LanguageIdentifier.normalize(targetLanguageId);
    }

    public List<Integer> getAttemptedEngineIds() {
        if (historyOwner != null) return historyOwner.getAttemptedEngineIds();
        return attemptedEngineIds == null ? Collections.emptyList()
                : Collections.unmodifiableList(attemptedEngineIds);
    }

    public void setAttemptedEngineIds(List<Integer> attemptedEngineIds) {
        if (historyOwner != null) { historyOwner.setAttemptedEngineIds(attemptedEngineIds); return; }
        this.attemptedEngineIds = attemptedEngineIds == null ? new ArrayList<>()
                : new ArrayList<>(attemptedEngineIds);
    }

    public boolean isFreeOnlyForRequest() { return freeOnlyForRequest; }
    public void requireFreeEngines() { freeOnlyForRequest = true; }
    public boolean isNonAiOnlyForRequest() { return nonAiOnlyForRequest; }
    public void requireContinuousEngines() {
        freeOnlyForRequest = true;
        nonAiOnlyForRequest = true;
    }
    public boolean isEmergencyRequest() { return emergencyRequest; }
    public void markEmergencyRequest() { emergencyRequest = true; }
    public void markAttemptedEngine(int engineId) {
        if (historyOwner != null) { historyOwner.markAttemptedEngine(engineId); return; }
        if (attemptedEngineIds == null) attemptedEngineIds = new ArrayList<>();
        if (!attemptedEngineIds.contains(engineId)) attemptedEngineIds.add(engineId);
    }
    /**
     * After an echo, exactly one more engine is tried; once that engine is dispatched no further
     * fallback is selected for this request, whatever that engine returns.
     */
    public void markEchoFallbackUsed() {
        if (historyOwner != null) { historyOwner.markEchoFallbackUsed(); return; }
        echoFallbackUsed = true;
    }
    public boolean isEchoFallbackUsed() {
        return historyOwner != null ? historyOwner.isEchoFallbackUsed() : echoFallbackUsed;
    }
    /** The engine a Provider attempt was last dispatched to, for error attribution. */
    public void markDispatched(int engineId) {
        if (historyOwner != null) { historyOwner.markDispatched(engineId); return; }
        lastDispatchedEngineId = engineId;
    }
    public int getLastDispatchedEngineId(int fallbackEngineId) {
        if (historyOwner != null) return historyOwner.getLastDispatchedEngineId(fallbackEngineId);
        int engineId = lastDispatchedEngineId;
        return engineId > 0 ? engineId : fallbackEngineId;
    }
    public void markAttemptFailure(int engineId, boolean timeout) {
        if (historyOwner != null) { historyOwner.markAttemptFailure(engineId, timeout); return; }
        markAttemptedEngine(engineId);
        if (timeout) timeoutEngineIds.add(engineId); else nonTimeoutFailure = true;
    }
    public boolean allAttemptedFailuresTimedOut() {
        if (historyOwner != null) return historyOwner.allAttemptedFailuresTimedOut();
        return !timeoutEngineIds.isEmpty() && !nonTimeoutFailure;
    }

    public long remainingBudgetMs() {
        long elapsedNanos = Math.max(0L, System.nanoTime() - startedNanos);
        long elapsedMs = elapsedNanos / 1_000_000L;
        return Math.max(0L, Math.min(requestBudgetMs - elapsedMs,
                java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(deadlineNanos - System.nanoTime())));
    }

    public boolean hasBudgetFor(long requestTimeoutMs) {
        return requestTimeoutMs > 0L && remainingBudgetMs() >= requestTimeoutMs;
    }

}
