package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Detects a Provider that returned its input unchanged. An item is non-trivial when it has at
 * least three Unicode letters; texts are compared after collapsing whitespace and case folding.
 * A source equal to the target is routed as auto-detect, so every request is checked.
 * A batch is an echo only when every non-trivial item came back unchanged and there is at least
 * one: echoed names among translated rows are legitimate.
 */
final class EchoGuard {
    private EchoGuard() { }

    static boolean isEcho(TranslationTask task, TranslationResult result) {
        if (task == null || result == null || result.isUnaligned()) return false;
        List<String> inputs = task instanceof BatchTranslationTask
                ? ((BatchTranslationTask) task).getSourceTexts()
                : Collections.singletonList(task.getContent());
        return isEcho(inputs, result.getTranslations());
    }

    static boolean isEcho(Object request, TranslationResult result) {
        if (result == null || result.isUnaligned()) return false;
        if (request instanceof BatchTranslationRequest)
            return isEcho(((BatchTranslationRequest) request).getTexts(), result.getTranslations());
        return request instanceof TranslationRequest && isEcho(
                Collections.singletonList(((TranslationRequest) request).getText()), result.getTranslations());
    }

    static boolean isEcho(List<String> inputs, List<String> outputs) {
        if (inputs == null || outputs == null || inputs.size() != outputs.size()) return false;
        int nonTrivial = 0;
        for (int i = 0; i < inputs.size(); i++) {
            String input = inputs.get(i);
            if (!isNonTrivial(input)) continue;
            nonTrivial++;
            String output = outputs.get(i);
            if (output == null || !normalize(input).equals(normalize(output))) return false;
        }
        return nonTrivial > 0;
    }

    static boolean isNonTrivial(String text) {
        if (text == null) return false;
        int letters = 0;
        for (int offset = 0; offset < text.length(); ) {
            int point = text.codePointAt(offset);
            if (Character.isLetter(point) && ++letters >= 3) return true;
            offset += Character.charCount(point);
        }
        return false;
    }

    static String normalize(String text) {
        StringBuilder collapsed = new StringBuilder(text.length());
        boolean space = false;
        for (int offset = 0; offset < text.length(); ) {
            int point = text.codePointAt(offset);
            offset += Character.charCount(point);
            if (Character.isWhitespace(point) || Character.isSpaceChar(point)) {
                space = collapsed.length() > 0;
                continue;
            }
            if (space) collapsed.append(' ');
            space = false;
            collapsed.appendCodePoint(point);
        }
        return collapsed.toString().toUpperCase(Locale.ROOT).toLowerCase(Locale.ROOT);
    }
}
