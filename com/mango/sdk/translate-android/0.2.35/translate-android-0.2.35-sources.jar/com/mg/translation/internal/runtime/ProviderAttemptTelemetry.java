package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.TranslationHost;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;

import retrofit2.HttpException;

/** Metadata-only timing for every Provider attempt. */
public final class ProviderAttemptTelemetry {
    private static volatile boolean debugLogging;
    // Best-effort metadata only. A stalled host cannot block cancellation or grow memory without limit.
    private static final java.util.concurrent.ThreadPoolExecutor OBSERVERS =
            new java.util.concurrent.ThreadPoolExecutor(1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
                    new java.util.concurrent.ArrayBlockingQueue<>(256), runnable -> {
                        Thread thread = new Thread(runnable, "mango-observers");
                        thread.setDaemon(true); return thread;
                    }, new java.util.concurrent.ThreadPoolExecutor.DiscardPolicy());
    /** A body the Provider returned and the SDK accepted. */
    public static final String ACCEPTED_RESPONSE = "response";
    /** A body that was a Provider error, misaligned, or failed validation. */
    public static final String REJECTED_RESPONSE = "rejected_response";
    /** A body that returned the input unchanged. */
    public static final String ECHOED_RESPONSE = "echoed_response";
    /** A body whose handling threw (unparseable or malformed). */
    public static final String INVALID_RESPONSE = "invalid_response";
    // Verdict for the response being handled on this thread; the first verdict wins.
    private static final ThreadLocal<String[]> RESPONSE_VERDICT = new ThreadLocal<>();

    private ProviderAttemptTelemetry() { }

    /** Opens a verdict scope around one Provider response handler; returns the outer scope. */
    public static Object beginResponse() {
        String[] outer = RESPONSE_VERDICT.get();
        RESPONSE_VERDICT.set(new String[1]);
        return outer;
    }

    /** Closes the scope opened by {@link #beginResponse()} and returns its outcome. */
    public static String endResponse(Object outer) {
        String[] verdict = RESPONSE_VERDICT.get();
        if (outer instanceof String[]) RESPONSE_VERDICT.set((String[]) outer);
        else RESPONSE_VERDICT.remove();
        return verdict == null || verdict[0] == null ? ACCEPTED_RESPONSE : verdict[0];
    }

    /** Classifies the response being handled on this thread; ignored outside a response. */
    public static void markResponse(String outcome) {
        String[] verdict = RESPONSE_VERDICT.get();
        if (verdict != null && verdict[0] == null) verdict[0] = outcome;
    }

    public static void setDebugLogging(boolean enabled) { debugLogging = enabled; }

    public static boolean isDebugLoggingEnabled() { return debugLogging; }

    /** Callers must pass only fixed metadata fields, never text, URL or credentials. */
    public static void debugLog(String metadata) { log(metadata); }

    private static void log(String message) {
        if (debugLogging) android.util.Log.i("MangoTranslation", message);
    }

    public static void skipped(int engineId, String reason) {
        skipped(engineId, reason, com.mg.translation.internal.base.http.RequestContext.trace());
    }

    public static void skipped(int engineId, String reason, long chainId) {
        if (debugLogging) log("engine_skipped chain=" + chainId
                + " engine=" + engineId + " reason=" + reason);
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null) return;
        try { runtime.host().onEngineSkipped(engineId, reason); }
        catch (RuntimeException ignored) { }
    }

    public static void fallback(int fromEngineId, int toEngineId) {
        fallback(fromEngineId, toEngineId,
                com.mg.translation.internal.base.http.RequestContext.trace());
    }

    public static void fallback(int fromEngineId, int toEngineId, long chainId) {
        if (debugLogging) log("fallback_to chain=" + chainId
                + " from=" + fromEngineId + " to=" + toEngineId);
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null) return;
        try { runtime.host().onFallback(fromEngineId, toEngineId); }
        catch (RuntimeException ignored) { }
    }

    public static void report(int engineId, String outcome,
                              long startedNanos, int httpStatus) {
        reportDuration(engineId, outcome, elapsedMs(startedNanos), httpStatus);
    }

    public static void report(int engineId, String outcome,
                              long startedNanos, int httpStatus, long chainId) {
        reportDuration(engineId, outcome, elapsedMs(startedNanos), httpStatus, chainId);
    }

    public static long elapsedMs(long startedNanos) {
        return Math.max(0L, System.nanoTime() - startedNanos) / 1_000_000L;
    }

    public static void reportDuration(int engineId, String outcome,
                                      long durationMs, int httpStatus) {
        reportDuration(engineId, outcome, durationMs, httpStatus,
                com.mg.translation.internal.base.http.RequestContext.trace());
    }

    public static void reportDuration(int engineId, String outcome,
                                      long durationMs, int httpStatus, long chainId) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null) return;
        if (debugLogging) log("provider_attempt chain=" + chainId
                + " engine=" + engineId + " outcome=" + outcome
                + " durationMs=" + Math.max(0L, durationMs) + " httpStatus=" + httpStatus);
        TranslationHost host = runtime.host();
        OBSERVERS.execute(() -> { try {
            host.onProviderAttemptFinished(
                    engineId, outcome, Math.max(0L, durationMs), httpStatus);
        } catch (RuntimeException ignored) {
            // Host telemetry must never delay or break translation.
        } });
    }

    public static String outcome(Throwable failure, boolean cancelled) {
        if (cancelled) return "cancelled";
        if (findHttpException(failure) != null) return "http_error";
        Throwable cause = rootCause(failure);
        if (cause instanceof SocketTimeoutException
                || cause instanceof InterruptedIOException) return "timeout";
        if (cause instanceof IOException) return "network_error";
        return "error";
    }

    public static int httpStatus(Throwable failure) {
        HttpException http = findHttpException(failure);
        return http == null ? 0 : http.code();
    }

    private static Throwable rootCause(Throwable failure) {
        Throwable current = failure;
        while (current != null && current.getCause() != null
                && current.getCause() != current) current = current.getCause();
        return current;
    }

    private static HttpException findHttpException(Throwable failure) {
        Throwable current = failure;
        while (current != null) {
            if (current instanceof HttpException) return (HttpException) current;
            if (current.getCause() == current) return null;
            current = current.getCause();
        }
        return null;
    }
}
