package com.mg.translation.internal.runtime;

/**
 * A Provider answered, but its result was rejected by SDK validation (unaligned batch, blank or
 * mismatched rows). The request falls back; the rejection is input-scoped and never cools the
 * engine down.
 */
final class RejectedProviderResultException extends IllegalArgumentException {
    RejectedProviderResultException(String message) { super(message); }
}
