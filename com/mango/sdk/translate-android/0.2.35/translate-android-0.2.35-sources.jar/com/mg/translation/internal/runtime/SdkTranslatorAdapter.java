package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.Translator;
import com.mg.translation.sdk.TranslationMode;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.text.LanguageIdentifier;
import com.mg.translation.language.LanguageConstant;

public final class SdkTranslatorAdapter implements Translator {
    private final TranslateControl delegate;
    private final long deadlineNanos;
    private final boolean emergencyMode;
    private final boolean requiresRuntime = TranslationRuntime.isInitialized();
    private final FallbackScope fallbacks = new FallbackScope();
    private final java.util.concurrent.atomic.AtomicBoolean closed = new java.util.concurrent.atomic.AtomicBoolean();
    private volatile java.util.function.BooleanSupplier pendingEcho;
    private volatile TranslationTask currentTask;

    public SdkTranslatorAdapter(TranslateControl delegate) {
        this(delegate, Long.MAX_VALUE);
    }

    public SdkTranslatorAdapter(TranslateControl delegate, long deadlineNanos) {
        this(delegate, deadlineNanos, false);
    }

    public SdkTranslatorAdapter(TranslateControl delegate, long deadlineNanos,
                                boolean emergencyMode) {
        if (delegate == null) throw new IllegalArgumentException("delegate is required");
        this.delegate = delegate;
        this.deadlineNanos = deadlineNanos;
        this.emergencyMode = emergencyMode;
    }

    @Override
    public int getEngineId() {
        return delegate.getTranslateType();
    }

    @Override
    public void translate(TranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (!emergencyMode && request.getMode() != TranslationMode.CONTINUOUS
                && rejectRestrictedAccess(callback)) return;
        TranslationTask task = new TranslationTask(request.getText(),
                LanguageIdentifier.routingSource(request.getSourceLanguageId(),
                        request.getTargetLanguageId()), request.getTargetLanguageId());
        if (!emergencyMode) applyMembershipPolicy(task);
        if (request.getMode() == TranslationMode.CONTINUOUS) task.requireContinuousEngines();
        if (emergencyMode) task.markEmergencyRequest();
        execute(task, callback);
    }

    @Override
    public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (!emergencyMode && request.getMode() != TranslationMode.CONTINUOUS
                && rejectRestrictedAccess(callback)) return;
        if (closed.get()) return;
        BatchInputFilter.Plan plan = BatchInputFilter.plan(request.getTexts());
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled() && !plan.skippedIds.isEmpty()) {
            ProviderAttemptTelemetry.debugLog("batch_filter chain="
                    + com.mg.translation.internal.base.http.RequestContext.trace()
                    + " engine=" + getEngineId() + " original=" + plan.original.size()
                    + " sent=" + plan.sent.size() + " skippedIds=" + plan.skippedIds
                    + " sentOriginalIds=" + plan.sentIds);
        }
        if (plan.sent.isEmpty()) {
            if (TranslationRuntime.snapshot() != TranslationRuntime.currentOrNull()
                    || (requiresRuntime && TranslationRuntime.currentOrNull() == null)) {
                callback.onError(TranslationErrorMapper.fromInternalCode(
                        com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED,
                        getEngineId()));
            } else {
                callback.onSuccess(new TranslationResult(plan.original,
                        com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE, true));
            }
            return;
        }
        BatchTranslationTask task = new BatchTranslationTask(plan.sent,
                LanguageIdentifier.routingSource(request.getSourceLanguageId(),
                        request.getTargetLanguageId()), request.getTargetLanguageId());
        if (!emergencyMode) applyMembershipPolicy(task);
        if (request.getMode() == TranslationMode.CONTINUOUS) task.requireContinuousEngines();
        if (emergencyMode) task.markEmergencyRequest();
        execute(task, new TranslationCallback() {
            @Override public void onSuccess(TranslationResult filtered) {
                TranslationResult restored;
                try {
                    if (!filtered.isBatch()) throw new IllegalArgumentException("Expected batch result");
                    restored = new TranslationResult(plan.restore(filtered.getTranslations()),
                            filtered.getActualEngineId(), true,
                            plan.restoreMissingIds(filtered.getUntranslatedSourceIds()),
                            filtered.getStatus());
                } catch (IllegalArgumentException invalid) {
                    callback.onError(TranslationErrorMapper.fromInternalCode(
                            com.mg.translation.sdk.TranslationErrorCode.INVALID_PROVIDER_RESPONSE,
                            filtered.getActualEngineId()));
                    return;
                }
                callback.onSuccess(restored);
            }

            @Override public void onError(com.mg.translation.sdk.TranslationError error) {
                callback.onError(error);
            }
        });
    }

    private void execute(TranslationTask task, TranslationCallback callback) {
        if (!task.isRuntimeCurrent()) {
            callback.onError(TranslationErrorMapper.fromInternalCode(
                    com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, getEngineId()));
            return;
        }
        task.setDeadlineNanos(deadlineNanos);
        task.setTraceId(com.mg.translation.internal.base.http.RequestContext.trace());
        currentTask = task;
        TranslationRuntime.withSnapshot(task.getRuntimeSnapshot(), () ->
                com.mg.translation.internal.base.http.RequestContext.withDeadline(deadlineNanos,
                () -> executeInternal(task, callback)));
    }

    private void executeInternal(TranslationTask task, TranslationCallback callback) {
        if (closed.get()) return;
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null && requiresRuntime) {
            callback(callback, task).onFail(com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, "");
            return;
        }
        if (runtime == null && task.isNonAiOnlyForRequest()) {
            callback(callback, task).onFail(com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, "");
            return;
        }
        // Rescue intentionally bypasses cooldown and membership; its independent queue bounds load.
        String reason = task.isNonAiOnlyForRequest()
                && !com.mg.translation.sdk.TranslationSdk.isContinuousEngineAllowed(getEngineId())
                ? "mode" : runtime == null || emergencyMode ? null
                : com.mg.translation.utils.TranslateUtils.engineSkipReason(
                        runtime.context(), getEngineId(), task.isFreeOnlyForRequest());
        // Validate before a Provider can omit an unsupported target or turn an explicit source into auto.
        if (reason == null && !supportsRequestLanguages(task)) reason = "unsupported_language";
        if (reason == null && isShortContinuousBatch(task)
                && ContinuousBatchRetryPolicy.process().shouldAvoid(runtime, getEngineId())) {
            java.util.List<Integer> previous = new java.util.ArrayList<>(task.getAttemptedEngineIds());
            java.util.List<Integer> attempted = new java.util.ArrayList<>(previous);
            if (!attempted.contains(getEngineId())) attempted.add(getEngineId());
            task.setAttemptedEngineIds(attempted);
            TranslateControl fallback;
            try {
                fallback = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                        runtime.context(), task, true);
            } catch (RuntimeException selectionFailure) {
                fallback = null;
            }
            if (fallback != null) {
                ProviderAttemptTelemetry.skipped(getEngineId(), "batch_quality", task.getTraceId());
                ProviderAttemptTelemetry.fallback(getEngineId(), fallback.getTranslateType(),
                        task.getTraceId());
                fallbacks.execute(fallback, task, callback(callback, task));
                return;
            }
            // Without an eligible alternative, preserve the original primary attempt.
            task.setAttemptedEngineIds(previous);
        }
        if ("mode".equals(reason) || "cooldown".equals(reason)
                || "unreachable".equals(reason) || "gate".equals(reason)
                || "not_configured".equals(reason) || "unsupported_language".equals(reason)) {
            ProviderAttemptTelemetry.skipped(getEngineId(), reason, task.getTraceId());
            boolean unsupportedLanguage = "unsupported_language".equals(reason);
            if (emergencyMode || runtime == null) {
                callback(callback, task).onFail(
                        unsupportedLanguage ? com.mg.translation.sdk.TranslationErrorCode.UNSUPPORTED_LANGUAGE
                                : com.mg.translation.sdk.TranslationErrorCode.PROVIDER_UNAVAILABLE, "");
                return;
            }
            task.markAttemptedEngine(getEngineId());
            if (unsupportedLanguage && task.remainingBudgetMs() <= 0L) {
                callback(callback, task).onFail(
                        com.mg.translation.sdk.TranslationErrorCode.REQUEST_TIMEOUT, "");
                return;
            }
            TranslateControl fallback = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                    runtime.context(), task, task instanceof BatchTranslationTask);
            if (fallback != null) {
                ProviderAttemptTelemetry.fallback(getEngineId(), fallback.getTranslateType(),
                        task.getTraceId());
                fallbacks.execute(fallback, task, callback(callback, task));
            } else {
                callback(callback, task).onFail("mode".equals(reason)
                        ? com.mg.translation.sdk.TranslationErrorCode.ENGINE_NOT_CONFIGURED
                        : unsupportedLanguage ? com.mg.translation.sdk.TranslationErrorCode.UNSUPPORTED_LANGUAGE
                        : com.mg.translation.sdk.TranslationErrorCode.ALL_ENGINES_FAILED, "");
            }
            return;
        }
        // The task keeps the overall deadline so a failed attempt can still fall back.
        // The provider call itself gets a shorter engine-specific deadline.
        long attemptDeadline = attemptDeadline(task);
        task.markDispatched(getEngineId());
        com.mg.translation.internal.base.http.RequestContext.withDeadline(attemptDeadline,
                () -> delegate.translate(task, callback(callback, task)));
    }

    private boolean supportsRequestLanguages(TranslationTask task) {
        String target = task.getTargetLanguageId();
        if (target == null || LanguageConstant.AUTO.equals(target)
                || delegate.getIndexByLanguage(target, false) < 0) return false;
        String source = task.getSourceLanguageId();
        return LanguageConstant.AUTO.equals(source) ? delegate.isSupportAuto()
                : source != null && delegate.getIndexByLanguage(source, false) >= 0;
    }

    private long attemptDeadline(TranslationTask task) {
        TranslatorId id = TranslatorId.fromLegacyCode(getEngineId());
        if (id == null || deadlineNanos == Long.MAX_VALUE) return deadlineNanos;
        long attemptMs = id.requestTimeoutMs();
        if (attemptMs <= 0L) return deadlineNanos;
        long now = System.nanoTime();
        long candidate = now + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(attemptMs);
        if (candidate < now) candidate = Long.MAX_VALUE;
        return Math.min(deadlineNanos, candidate);
    }

    private boolean isShortContinuousBatch(TranslationTask task) {
        return !emergencyMode && task instanceof BatchTranslationTask
                && task.isNonAiOnlyForRequest()
                && ((BatchTranslationTask) task).getSourceTexts().size()
                        <= ContinuousBatchRetryPolicy.SHORT_BATCH_MAX;
    }

    /**
     * Delivers the first echoed result of the current request, if any, as its final success.
     * Used when the overall request deadline ends the fallback chain that the echo started.
     */
    public boolean deliverPendingEcho() {
        java.util.function.BooleanSupplier pending = pendingEcho;
        return pending != null && pending.getAsBoolean();
    }

    /** The engine the current request was last dispatched to; this adapter's engine if none. */
    public int lastAttemptedEngineId() {
        TranslationTask task = currentTask;
        return task == null ? getEngineId() : task.getLastDispatchedEngineId(getEngineId());
    }

    private static void reportEcho() {
        if (TranslationRuntime.snapshot() == null) return;
        try {
            TranslationTelemetry.event("echoed_result");
        } catch (RuntimeException ignored) {
            // Host telemetry must never change the translation outcome.
        }
    }

    private TranslateListener callback(TranslationCallback callback, TranslationTask request) {
        java.util.concurrent.atomic.AtomicBoolean terminal = new java.util.concurrent.atomic.AtomicBoolean();
        java.util.concurrent.atomic.AtomicReference<TranslationResult> firstEcho =
                new java.util.concurrent.atomic.AtomicReference<>();
        return new TranslateListener() {
            @Override
            public void onSuccess(TranslationTask result, int actualEngineId, boolean isList) {
                if (closed.get() || terminal.get()) return;
                TranslationResult mapped;
                try {
                    mapped = TranslationResultValidation.map(request, result, actualEngineId, isList);
                } catch (IllegalArgumentException invalid) {
                    if (!(request instanceof BatchTranslationTask)) throw invalid;
                    BatchTranslationTask batch = (BatchTranslationTask) request;
                    batch.markUnalignedResponse();
                    if (isShortContinuousBatch(batch) && batch.isRuntimeCurrent())
                        ContinuousBatchRetryPolicy.process().recordUnaligned(
                                batch.getRuntimeSnapshot(), actualEngineId);
                    if (retryUnaligned(batch, actualEngineId)) return;
                    onFail(com.mg.translation.sdk.TranslationErrorCode.INVALID_PROVIDER_RESPONSE, "");
                    return;
                }
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled() && mapped.isBatch()
                        && mapped.getStatus() != TranslationResult.Status.COMPLETE) {
                    ProviderAttemptTelemetry.debugLog("batch_reconcile chain=" + request.getTraceId()
                            + " engine=" + actualEngineId + " status=" + mapped.getStatus()
                            + " sent=" + mapped.getTranslations().size()
                            + " missingIds=" + mapped.getUntranslatedSourceIds());
                }
                if (mapped.isUnaligned() && request instanceof BatchTranslationTask) {
                    ProviderAttemptTelemetry.markResponse(ProviderAttemptTelemetry.REJECTED_RESPONSE);
                    BatchTranslationTask batch = (BatchTranslationTask) request;
                    if (isShortContinuousBatch(batch) && batch.isRuntimeCurrent())
                        ContinuousBatchRetryPolicy.process().recordUnaligned(
                                batch.getRuntimeSnapshot(), actualEngineId);
                    batch.rememberUnaligned(mapped);
                    if (retryUnaligned(batch, actualEngineId)) return;
                    if (batch.hasOtherFailure()) {
                        onFail(com.mg.translation.sdk.TranslationErrorCode.PROVIDER_UNAVAILABLE, "");
                        return;
                    }
                    if (deliverEcho()) return;
                }
                if (!mapped.isUnaligned() && EchoGuard.isEcho(request, mapped)) {
                    // Soft failure: no cache, no success record, no cooldown. Try the next engine;
                    // if nothing translates, the first echo is still delivered as a success.
                    ProviderAttemptTelemetry.markResponse(ProviderAttemptTelemetry.ECHOED_RESPONSE);
                    reportEcho();
                    if (firstEcho.compareAndSet(null, mapped)) pendingEcho = this::deliverEcho;
                    if (retryEcho(actualEngineId)) return;
                    deliverEcho();
                    return;
                }
                if (!terminal.compareAndSet(false, true)) return;
                if (!mapped.isUnaligned()) ProviderFailurePolicy.recordSuccess(actualEngineId);
                if (mapped.getStatus() == TranslationResult.Status.COMPLETE
                        && isShortContinuousBatch(request) && request.isRuntimeCurrent())
                    ContinuousBatchRetryPolicy.process().recordComplete(
                            request.getRuntimeSnapshot(), actualEngineId);
                try {
                    TranslationResult best = mapped.isUnaligned() && request instanceof BatchTranslationTask
                            ? ((BatchTranslationTask) request).bestUnalignedResult() : null;
                    callback.onSuccess(best == null ? mapped : best);
                } catch (RuntimeException hostFailure) {
                    // Translation already completed; never turn host callback failures into fallback.
                }
            }

            private boolean retryUnaligned(BatchTranslationTask batch, int failedEngineId) {
                batch.markAttemptFailure(failedEngineId, false);
                if (emergencyMode || batch.remainingBudgetMs() <= 0L) return false;
                TranslationRuntime runtime = TranslationRuntime.snapshot();
                if (runtime == null) return false;
                TranslateControl next;
                try {
                    next = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                            runtime.context(), batch, true);
                } catch (RuntimeException selectionFailure) {
                    batch.markOtherFailure();
                    return false;
                }
                if (next == null) return false;
                ProviderAttemptTelemetry.fallback(failedEngineId, next.getTranslateType(),
                        batch.getTraceId());
                try {
                    fallbacks.execute(next, batch, this);
                    return true;
                } catch (RuntimeException failure) {
                    batch.markOtherFailure();
                    return false;
                }
            }

            private boolean retryEcho(int echoedEngineId) {
                request.markAttemptedEngine(echoedEngineId);
                if (emergencyMode || request.remainingBudgetMs() <= 0L) return false;
                TranslationRuntime runtime = TranslationRuntime.snapshot();
                if (runtime == null) return false;
                TranslateControl next;
                try {
                    next = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                            runtime.context(), request, request instanceof BatchTranslationTask);
                } catch (RuntimeException selectionFailure) {
                    return false;
                }
                if (next == null) return false;
                // Capped: this is the only engine tried after an echo. Its echo, failure or
                // missing successor delivers the first echo instead of walking the chain.
                request.markEchoFallbackUsed();
                ProviderAttemptTelemetry.fallback(echoedEngineId, next.getTranslateType(),
                        request.getTraceId());
                try {
                    fallbacks.execute(next, request, this);
                    return true;
                } catch (RuntimeException failure) {
                    return false;
                }
            }

            private boolean deliverEcho() {
                TranslationResult echo = firstEcho.get();
                if (echo == null || closed.get() || !terminal.compareAndSet(false, true)) return false;
                try {
                    callback.onSuccess(echo);
                } catch (RuntimeException hostFailure) {
                    // Translation already completed; never turn host callback failures into fallback.
                }
                return true;
            }

            @Override
            public void onFail(int code, String message) {
                if (closed.get()) return;
                if (code != com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED
                        && code != com.mg.translation.sdk.TranslationErrorCode.CANCELLED
                        && deliverEcho()) return;
                if (!terminal.compareAndSet(false, true)) return;
                // Report the engine that was actually attempted last, not the primary.
                int lastEngineId = request.getLastDispatchedEngineId(delegate.getTranslateType());
                if (request instanceof BatchTranslationTask
                        && ((BatchTranslationTask) request).hasUnalignedResponse()
                        && !((BatchTranslationTask) request).hasOtherFailure()
                        && (code == com.mg.translation.sdk.TranslationErrorCode.ALL_ENGINES_FAILED
                        || code == com.mg.translation.sdk.TranslationErrorCode.INVALID_PROVIDER_RESPONSE
                        || code == com.mg.translation.sdk.TranslationErrorCode.PROVIDER_UNAVAILABLE)) {
                    BatchTranslationTask batch = (BatchTranslationTask) request;
                    TranslationResult unresolved = batch.bestUnalignedResult() != null
                            ? batch.bestUnalignedResult()
                            : BatchResultPolicy.empty(batch.getSourceTexts(), lastEngineId);
                    try { callback.onSuccess(unresolved); }
                    catch (RuntimeException hostFailure) { /* Host observers never trigger retries. */ }
                    return;
                }
                com.mg.translation.sdk.TranslationError mapped =
                        TranslationErrorMapper.fromInternalCode(code, lastEngineId);
                try {
                    callback.onError(mapped);
                } catch (RuntimeException hostFailure) {
                    // A host observer failure must not cause another Provider attempt.
                }
            }
        };
    }

    private void applyMembershipPolicy(TranslationTask task) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null || !runtime.host().isVip()) task.requireFreeEngines();
    }

    private boolean rejectRestrictedAccess(TranslationCallback callback) {
        int engineId = delegate.getTranslateType();
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (!(delegate instanceof NonVipFallbackTranslateControl)
                && com.mg.translation.sdk.TranslationSdk.isVipOnly(engineId)
                && (runtime == null || !runtime.host().isVip())) {
            callback.onError(TranslationErrorMapper.vipRequired(engineId));
            return true;
        }
        return false;
    }

    @Override
    public void close() {
        closed.set(true);
        delegate.close();
        fallbacks.close();
    }
}
