package com.mg.translation.internal.text;

import com.mg.translation.language.LanguageConstant;

/** Removes boundary whitespace from identifiers without changing case or interior characters. */
public final class LanguageIdentifier {
    private LanguageIdentifier() { }

    /** Request sources also accept the auto-detect identifier in any letter case. */
    public static String normalizeSource(String identifier) {
        String normalized = normalize(identifier);
        return "auto".equalsIgnoreCase(normalized) ? LanguageConstant.AUTO : normalized;
    }

    /** An explicit source equal to the target is routed and sent as auto-detect. */
    public static String routingSource(String source, String target) {
        return source != null && !LanguageConstant.AUTO.equals(source) && matches(source, target)
                ? LanguageConstant.AUTO : source;
    }

    public static String normalize(String identifier) {
        if (identifier == null) return null;
        int begin = 0;
        int end = identifier.length();
        while (begin < end) {
            int point = identifier.codePointAt(begin);
            if (!isWhitespace(point)) break;
            begin += Character.charCount(point);
        }
        while (begin < end) {
            int point = identifier.codePointBefore(end);
            if (!isWhitespace(point)) break;
            end -= Character.charCount(point);
        }
        return identifier.substring(begin, end);
    }

    public static boolean matches(String first, String second) {
        return first != null && second != null && normalize(first).equals(normalize(second));
    }

    static boolean isWhitespace(int point) {
        return point >= 0x0009 && point <= 0x000D
                || point == 0x0020 || point == 0x0085 || point == 0x00A0
                || point == 0x1680 || point >= 0x2000 && point <= 0x200A
                || point == 0x2028 || point == 0x2029 || point == 0x202F
                || point == 0x205F || point == 0x3000;
    }
}
