package com.mg.translation.internal.text;

import com.mg.translation.internal.runtime.BatchInputFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Keeps source line positions while omitting locally restorable blank lines from a request. */
public final class LineTranslationPlan {
    private final List<String> lines;
    private final List<String> texts;
    private final List<Integer> positions;

    public LineTranslationPlan(String source) {
        if (source == null) throw new IllegalArgumentException("Source text is required");
        lines = Arrays.asList(source.split("\n", -1));
        List<String> sent = new ArrayList<>();
        positions = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            if (!BatchInputFilter.isBlank(lines.get(i))) {
                sent.add(lines.get(i));
                positions.add(i);
            }
        }
        texts = Collections.unmodifiableList(sent);
    }

    public List<String> getTexts() { return texts; }

    /** A missing translation for any sent line cannot be a complete single-text result. */
    public String restore(String[] translated) {
        if (translated == null || translated.length != texts.size()) return null;
        List<String> output = new ArrayList<>(lines);
        for (int i = 0; i < translated.length; i++) {
            if (translated[i] == null || BatchInputFilter.isBlank(translated[i])) return null;
            output.set(positions.get(i), translated[i]);
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < output.size(); i++) {
            if (i > 0) result.append('\n');
            result.append(output.get(i));
        }
        return result.toString();
    }
}
