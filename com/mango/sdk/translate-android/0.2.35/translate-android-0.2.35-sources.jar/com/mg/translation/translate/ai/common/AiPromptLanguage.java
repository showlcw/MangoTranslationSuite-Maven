package com.mg.translation.translate.ai.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

import com.mg.translation.language.LanguageVO;

import java.util.Locale;

/**
 * Brand-neutral prompt helper: the English name of a language entry owned by a Translator.
 * Each Translator still declares its own language list; this only reads that entry's labels.
 */
public final class AiPromptLanguage {
    private AiPromptLanguage() { }

    /** English label from the SDK's default resources, or null when the entry has none. */
    @SuppressLint("AppBundleLocaleChanges") // A private English Resources view; the App Locale is untouched.
    public static String englishName(Context context, LanguageVO language) {
        if (context == null || language == null || language.getCountry() == 0) return null;
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.setLocale(Locale.ENGLISH);
        Resources english = context.createConfigurationContext(configuration).getResources();
        String name = english.getString(language.getCountry());
        if (language.getLanguageCountry() != 0) {
            name += " (" + english.getString(language.getLanguageCountry()) + ")";
        }
        return name;
    }
}
