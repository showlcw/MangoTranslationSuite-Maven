package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.sdk.TranslationSdk;
import com.mg.translation.utils.TranslateUtils;
import com.mg.translation.utils.TranslationPreferenceKeys;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Free requests have only a few eligible engines. One network hiccup can put all of them into
 * their (at least five minute) cooldown, after which every request — a subtitle frame in
 * continuous mode or a per-frame standard request alike — would fail locally without sending
 * anything. When no engine is eligible, in either mode, this clears the
 * cooldowns that came only from transport failures — at most once per {@link #RESET_INTERVAL_MS}
 * for the whole process — so the current request walks the normal fallback chain again.
 *
 * <p>Termination: a request resets at most once (its flag is shared by every attempt copy), the
 * reset never re-enables an engine this request already dispatched, and every dispatched engine
 * is added to the attempted list. The chain therefore sends each engine at most once.
 */
public final class ContinuousCooldownProbe {
    static final long RESET_INTERVAL_MS = 30_000L;
    private static final long NEVER = Long.MIN_VALUE;
    private static final AtomicLong LAST_RESET_NANOS = new AtomicLong(NEVER);

    private ContinuousCooldownProbe() { }

    /** Engines with a known state key whose cooldowns are all written by ProviderFailurePolicy. */
    static String stateKey(int engineId) {
        TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
        if (engine == null) return null;
        switch (engine) {
            case SELF_HOSTED_GOOGLE: return TranslationPreferenceKeys.SELF_HOSTED_GOOGLE_TRANSLATE_STATE;
            case SELF_HOSTED_YOUDAO: return TranslationPreferenceKeys.SELF_HOSTED_YOUDAO_TRANSLATE_STATE;
            case SELF_HOSTED_DEEPL: return TranslationPreferenceKeys.SELF_HOSTED_DEEPL_TRANSLATE_STATE;
            case SELF_HOSTED_YANDEX: return TranslationPreferenceKeys.SELF_HOSTED_YANDEX_TRANSLATE_STATE;
            case MYMEMORY: return TranslationPreferenceKeys.MEMORY_TRANSLATE_STATE;
            default: return null;
        }
    }

    /**
     * For a request (standard or continuous) with no eligible engine: clears every
     * transport-only cooldown of an engine the request may use, and
     * re-allows engines this request skipped without sending. Returns whether anything was
     * cleared; the caller then selects once more. Rate limit, authentication, quota, rejected
     * envelope and free Google direct cooldowns are never cleared.
     */
    public static boolean resetCooledEngines(Context context, TranslationTask task, boolean batch) {
        if (context == null || task == null || task.isEmergencyRequest() || task.isCooldownProbeUsed()
                || task.remainingBudgetMs() <= 0L) return false;
        long nowMs = System.currentTimeMillis();
        List<Integer> clearable = new ArrayList<>();
        for (int engineId : TranslateUtils.fallbackOrder()) {
            TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
            if (stateKey(engineId) == null || engine == null || (batch && !engine.supportsBatch())
                    || task.wasDispatched(engineId)
                    // Continuous requests keep their free non-AI engine set; standard requests
                    // use the membership check inside engineSkipReason.
                    || (task.isNonAiOnlyForRequest() && !TranslationSdk.isContinuousEngineAllowed(engineId))
                    || !"cooldown".equals(TranslateUtils.engineSkipReason(
                            context, engineId, task.isFreeOnlyForRequest()))
                    || !ProviderFailurePolicy.isProbeAllowed(context, engineId, nowMs)) continue;
            clearable.add(engineId);
        }
        // Nothing this request could use: keep the interval for a later frame that can.
        if (!anyUsable(context, task, clearable)) return false;
        List<Integer> cleared = new ArrayList<>();
        // Failure writes use this same monitor. Recheck after candidate discovery, before
        // reserving the interval or erasing anything: a concurrent 429/auth/body rejection wins.
        synchronized (ProviderFailurePolicy.class) {
            clearable.removeIf(engineId -> task.wasDispatched(engineId)
                    || !ProviderFailurePolicy.isProbeAllowed(context, engineId, System.currentTimeMillis()));
            if (clearable.isEmpty() || !task.isRuntimeCurrent() || task.remainingBudgetMs() <= 0L
                    || task.isCooldownProbeUsed() || !tryReserve(System.nanoTime())) return false;
            task.markCooldownProbeUsed();
            List<Integer> attempted = new ArrayList<>(task.getAttemptedEngineIds());
            for (int engineId : clearable) {
                if (ProviderFailurePolicy.clearForProbe(context, engineId, stateKey(engineId), task)) {
                    // Skipped for cooldown, never sent: it may be tried once now.
                    attempted.remove(Integer.valueOf(engineId));
                    cleared.add(engineId);
                }
            }
            task.setAttemptedEngineIds(attempted);
        }
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            ProviderAttemptTelemetry.debugLog("cooldown_reset chain=" + task.getTraceId()
                    + " engines=" + cleared);
        }
        return !cleared.isEmpty();
    }

    private static boolean anyUsable(Context context, TranslationTask task, List<Integer> engines) {
        String target = task.getTargetLanguageId();
        if (target == null) return false;
        for (int engineId : engines) {
            com.mg.translation.translate.base.TranslateControl control =
                    TranslateUtils.getTranslateByType(engineId, task.getSourceLanguageId(), target, context);
            if (control == null) continue;
            boolean usable = control.getIndexByLanguage(target, false) >= 0;
            control.close();
            if (usable) return true;
        }
        return false;
    }

    static boolean tryReserve(long nowNanos) {
        long interval = TimeUnit.MILLISECONDS.toNanos(RESET_INTERVAL_MS);
        while (true) {
            long last = LAST_RESET_NANOS.get();
            if (last != NEVER && nowNanos - last < interval) return false;
            if (LAST_RESET_NANOS.compareAndSet(last, nowNanos)) return true;
        }
    }

    /** Test hook: forget the last reset. */
    static void resetForTest() { LAST_RESET_NANOS.set(NEVER); }
}
