package com.mg.translation.internal.runtime;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.sdk.CredentialDecryptor;

import java.util.ArrayList;
import java.util.Collections;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicInteger;

public final class TranslationConfigStore {
    private final Map<Integer, EngineValues> engines = new LinkedHashMap<>();
    private static final int MAX_RECENT_LANGUAGES = 20;
    private static final int MAX_CONFIGURED_ENGINES = 64;
    private static final int MAX_CREDENTIALS_PER_ENGINE = 20;
    private static final int MAX_ENCRYPTED_CREDENTIAL_LENGTH = 32 * 1024;
    private static final int MAX_CONFIG_JSON_LENGTH = 2 * 1024 * 1024;
    private final Map<Boolean, Deque<String>> recent = new ConcurrentHashMap<>();

    public static TranslationConfigStore fromJson(String json, CredentialDecryptor decryptor) {
        if (json == null || json.trim().isEmpty()) {
            throw new IllegalArgumentException("translation config JSON is required");
        }
        if (json.length() > MAX_CONFIG_JSON_LENGTH) {
            throw new IllegalArgumentException("translation config JSON is too large");
        }
        AppTranslationConfig config;
        try {
            config = new Gson().fromJson(json, AppTranslationConfig.class);
        } catch (RuntimeException error) {
            throw new IllegalArgumentException("translation config JSON is invalid", error);
        }
        if (config == null) {
            throw new IllegalArgumentException("translation config JSON is invalid");
        }
        return new TranslationConfigStore(config, decryptor);
    }

    private TranslationConfigStore(AppTranslationConfig config, CredentialDecryptor decryptor) {
        if (decryptor == null) throw new IllegalArgumentException("credential decryptor is required");
        if (!config.hasEnginesField()) {
            throw new IllegalArgumentException("translation config engines are required");
        }
        if (config.getEngines().size() > MAX_CONFIGURED_ENGINES) {
            throw new IllegalArgumentException("too many configured translation engines");
        }
        Set<Integer> seenEngineIds = new HashSet<>();
        boolean recognizedEngineSeen = false;
        boolean activeEngineSeen = false;
        boolean usableEngineSeen = false;
        for (ConfiguredEngine engine : config.getEngines()) {
            if (engine == null) throw new IllegalArgumentException("translation engine is required");
            if (!seenEngineIds.add(engine.getId())) {
                throw new IllegalArgumentException(
                        "duplicate translation engine ID: " + engine.getId());
            }
            TranslatorId id = TranslatorId.fromLegacyCode(engine.getId());
            if (id == null) {
                // Forward compatibility: a newer control plane may publish engines that this
                // SDK does not know yet. Ignore them before validating or decrypting their shape.
                continue;
            }
            recognizedEngineSeen = true;
            if (id.isRetired()) {
                continue;
            }
            activeEngineSeen = true;
            if (!engine.hasSelectableFlag()) {
                throw new IllegalArgumentException(
                        "translation engine selectable flag is required: " + engine.getId());
            }
            if (engine.getDailyLimit() != null
                    && (engine.getDailyLimit() < 1 || engine.getDailyLimit() > 1_000_000)) {
                throw new IllegalArgumentException(
                        "translation engine dailyLimit must be between 1 and 1000000: "
                                + engine.getId());
            }
            List<CredentialValue> values = new ArrayList<>();
            List<String> encryptedKeys = engine.getKeys() == null
                    ? Collections.emptyList() : engine.getKeys();
            if (encryptedKeys.size() > MAX_CREDENTIALS_PER_ENGINE) {
                continue;
            }
            for (String encrypted : encryptedKeys) {
                if (encrypted == null || encrypted.trim().isEmpty()) continue;
                if (encrypted.length() > MAX_ENCRYPTED_CREDENTIAL_LENGTH) {
                    continue;
                }
                try {
                    String decrypted = decryptor.decrypt(encrypted);
                    CredentialValue value = CredentialValue.parse(decrypted);
                    if (value != null) values.add(value);
                } catch (RuntimeException invalidCredential) {
                    // Invalid credentials are isolated to their owning engine/key.
                }
            }
            engines.put(engine.getId(), new EngineValues(values, engine.isVip(),
                    engine.isSelectable(), engine.getDailyLimit()));
            if (!hasCredential(engine.getId())) {
                engines.remove(engine.getId());
                continue;
            }
            usableEngineSeen = true;
        }
        if (!config.getEngines().isEmpty() && !recognizedEngineSeen) {
            throw new IllegalArgumentException(
                    "translation config contains no engines supported by this SDK");
        }
        if (activeEngineSeen && !usableEngineSeen) {
            throw new IllegalArgumentException(
                    "translation config has no usable Provider credential for any active engine");
        }
    }

    /** 中台响应中存在且至少一组 Provider 凭据完整，才是 SDK 可用的启用引擎。 */
    public boolean isEngineEnabled(int id) { return engines.containsKey(id) && hasCredential(id); }
    public boolean isVipOnly(int id) { EngineValues value = engines.get(id); return value != null && value.vip; }
    public boolean isSelectable(int id) {
        EngineValues value = engines.get(id);
        return value != null && value.selectable;
    }
    public Integer dailyLimit(int id) {
        EngineValues value = engines.get(id);
        return value == null ? null : value.dailyLimit;
    }
    public List<Integer> configuredEngineIds() { return new ArrayList<>(engines.keySet()); }
    public boolean hasCredential(int id) {
        EngineValues value = engines.get(id);
        if (value == null) return false;
        TranslatorId translatorId = TranslatorId.fromLegacyCode(id);
        if (translatorId == null) return false;
        if (translatorId == TranslatorId.BAIDU) {
            return nonBlank(getBdAppId()) && nonBlank(getBdSecret());
        }
        if (translatorId == TranslatorId.YOUDAO) {
            return nonBlank(getYouDaoAppId()) && nonBlank(getYouDaoSecret());
        }
        if (translatorId.isOpenAiCompatibleTranslation()) {
            return hasOpenAiCompatibleCredential(translatorId, value);
        }
        if (translatorId.requiresEndpointCredential()) {
            return hasEndpointCredential(id);
        }
        for (CredentialValue raw : value.values) {
            try {
                if (nonBlank(jsonString(raw,
                        "apiKey", "rapidApiKey", "key", "token", "value"))) return true;
            } catch (IllegalArgumentException ignored) {
                // Malformed JSON is not a usable credential.
            }
        }
        return false;
    }

    private boolean hasOpenAiCompatibleCredential(TranslatorId id, EngineValues value) {
        for (CredentialValue raw : value.values) {
            if (isUsableOpenAiCompatibleCredential(id, raw)) return true;
        }
        return false;
    }

    private boolean isUsableOpenAiCompatibleCredential(TranslatorId id, CredentialValue raw) {
        try {
            if (raw == null) return false;
            if (!raw.isJson()) return id == TranslatorId.DEEPSEEK && nonBlank(raw.scalar);
            String apiKey = jsonString(raw, "apiKey", "key", "token", "value");
            String baseUrl = jsonField(raw, "baseUrl", "endpoint");
            String model = jsonField(raw, "model");
            String protocol = jsonField(raw, "protocol");
            String reasoningEnabled = jsonField(raw, "reasoningEnabled");
            JsonObject providerRouting = jsonObjectField(raw, "providerRouting");
            return nonBlank(apiKey)
                    && (id == TranslatorId.DEEPSEEK
                    || (nonBlank(baseUrl) && nonBlank(model) && nonBlank(protocol)))
                    && (baseUrl == null || isSecureBaseUrl(baseUrl))
                    && (baseUrl == null || nonBlank(model))
                    && (protocol == null || isSupportedLlmProtocol(protocol))
                    && (providerRouting == null
                    || "openrouter".equalsIgnoreCase(protocol))
                    && (reasoningEnabled == null
                    || "true".equalsIgnoreCase(reasoningEnabled)
                    || "false".equalsIgnoreCase(reasoningEnabled));
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private boolean isSupportedLlmProtocol(String protocol) {
        return "deepseek".equalsIgnoreCase(protocol)
                || "openrouter".equalsIgnoreCase(protocol)
                || "openai".equalsIgnoreCase(protocol);
    }
    public boolean hasEndpointCredential(int id) {
        EngineValues value = engines.get(id);
        if (value == null) return false;
        for (CredentialValue raw : value.values) {
            try {
                String baseUrl = jsonField(raw, "baseUrl", "endpoint");
                String apiKey = jsonString(raw,
                        "apiKey", "rapidApiKey", "key", "token", "value");
                if (isSecureBaseUrl(baseUrl) && apiKey != null
                        && !apiKey.trim().isEmpty()) return true;
            } catch (IllegalArgumentException ignored) {
                // Malformed JSON cannot make an endpoint-backed Provider selectable.
            }
        }
        return false;
    }
    private CredentialValue nextRaw(TranslatorId id) {
        EngineValues values = engines.get(id.legacyCode);
        if (values == null || values.values.isEmpty()) return null;
        for (int attempt = 0; attempt < values.values.size(); attempt++) {
            int index = Math.floorMod(values.cursor.getAndIncrement(), values.values.size());
            CredentialValue candidate = values.values.get(index);
            if (isUsableRotatingCredential(id, candidate)) return candidate;
        }
        return null;
    }
    private String next(TranslatorId id) {
        return jsonString(nextRaw(id), "apiKey", "rapidApiKey", "key", "token", "value");
    }

    private String part(TranslatorId id, int orderedIndex, String... names) {
        EngineValues values = engines.get(id.legacyCode);
        if (values == null || values.values.isEmpty()) return null;
        CredentialValue first = values.values.get(0);
        String parsed = jsonString(first, names);
        if (first.isJson()) return parsed;
        return orderedIndex < values.values.size()
                ? values.values.get(orderedIndex).scalar : null;
    }

    private String jsonString(CredentialValue value, String... names) {
        if (value == null) return null;
        if (!value.isJson()) return value.scalar;
        return jsonField(value, names);
    }

    private String jsonField(CredentialValue value, String... names) {
        if (value == null || !value.isJson()) return null;
        try {
            JsonObject object = value.json;
            for (String name : names) {
                if (object.has(name) && !object.get(name).isJsonNull()) {
                    String result = object.get(name).getAsString();
                    if (!result.trim().isEmpty()) return result;
                }
            }
            return null;
        } catch (RuntimeException error) {
            throw new IllegalArgumentException("Provider JSON credential is invalid", error);
        }
    }

    String getDeepRapidApiKey() { return next(TranslatorId.RAPID_DEEP); }
    String getGoogleVipApiKey() { return next(TranslatorId.GOOGLE_V); }
    String getMicrosoftApiKey() { return next(TranslatorId.MICROSOFT_VIP); }
    String getFreeMicrosoftApiKey() { return next(TranslatorId.MICROSOFT); }
    String getAiRapidApiKey() { return next(TranslatorId.RAPID_AI); }
    String getPlusRapidApiKey() { return next(TranslatorId.RAPID_PLUS); }
    String getBdAppId() { return part(TranslatorId.BAIDU, 0, "appId", "appid"); }
    String getBdSecret() { return part(TranslatorId.BAIDU, 1, "secret", "appSecret"); }
    String getYouDaoAppId() { return part(TranslatorId.YOUDAO, 0, "appId", "appid"); }
    String getYouDaoSecret() { return part(TranslatorId.YOUDAO, 1, "secret", "appSecret"); }
    String getWebSitePlusKey() { return next(TranslatorId.RAPID_WEBSITE_PLUS); }
    List<String> getRecentlyHistoryList(boolean source) {
        Deque<String> values = recent.get(source);
        if (values == null) return new ArrayList<>();
        synchronized (values) {
            return new ArrayList<>(values);
        }
    }
    void saveRecentlyHistoryList(String languageKey, boolean source) {
        if (!nonBlank(languageKey)) return;
        Deque<String> values = recent.computeIfAbsent(source,
                key -> new ConcurrentLinkedDeque<>());
        synchronized (values) {
            values.remove(languageKey);
            values.addFirst(languageKey);
            while (values.size() > MAX_RECENT_LANGUAGES) values.pollLast();
        }
    }
    public int getFirstTranslateType() {
        for (Integer id : engines.keySet()) {
            if (isEngineEnabled(id)) return id;
        }
        return -1;
    }
    String getMultiRapidApiKey() { return next(TranslatorId.RAPID_MULTI); }
    String getIrctcapiRapidApiKey() { return next(TranslatorId.RAPID_IRCTCAPI); }
    boolean hasEnabledEngines() {
        for (Integer id : engines.keySet()) {
            if (isEngineEnabled(id)) return true;
        }
        return false;
    }
    String getDeepSeekApiKey() { return next(TranslatorId.DEEPSEEK); }
    String getQwenMtDomains() {
        return firstJsonField(TranslatorId.QWEN, "domains");
    }

    private String firstJsonField(TranslatorId id, String... names) {
        EngineValues values = engines.get(id.legacyCode);
        if (values == null) return null;
        for (CredentialValue value : values.values) {
            try {
                String result = jsonField(value, names);
                if (nonBlank(result)) return result;
            } catch (IllegalArgumentException ignored) {
                // A later valid credential may still provide this optional field.
            }
        }
        return null;
    }

    ProviderCredential nextProviderCredential(TranslatorId id, String defaultBaseUrl) {
        CredentialValue raw = nextRaw(id);
        if (raw == null) {
            return new ProviderCredential(normalizeBaseUrl(defaultBaseUrl), null,
                    null, null, true, null, false, null);
        }
        String apiKey = jsonString(raw, "apiKey", "rapidApiKey", "key", "token", "value");
        String configuredBaseUrl = jsonField(raw, "baseUrl", "endpoint");
        String dataInspection = jsonField(raw,
                "dataInspection", "dataInspectionEnabled", "enableDataInspection");
        String reasoningEnabled = jsonField(raw, "reasoningEnabled");
        return new ProviderCredential(
                normalizeBaseUrl(configuredBaseUrl == null ? defaultBaseUrl : configuredBaseUrl),
                apiKey,
                jsonField(raw, "model"),
                jsonField(raw, "domains"),
                dataInspection == null || Boolean.parseBoolean(dataInspection),
                normalizeProtocol(jsonField(raw, "protocol")),
                reasoningEnabled != null && Boolean.parseBoolean(reasoningEnabled),
                jsonObjectField(raw, "providerRouting"));
    }

    private String normalizeProtocol(String protocol) {
        return protocol == null ? null : protocol.trim().toLowerCase(java.util.Locale.ROOT);
    }

    private JsonObject jsonObjectField(CredentialValue value, String name) {
        if (value == null || !value.isJson()) return null;
        try {
            JsonObject object = value.json;
            if (!object.has(name) || object.get(name).isJsonNull()) return null;
            if (!object.get(name).isJsonObject()) {
                throw new IllegalArgumentException(name + " must be a JSON object");
            }
            return object.getAsJsonObject(name);
        } catch (IllegalArgumentException failure) {
            throw failure;
        } catch (RuntimeException error) {
            throw new IllegalArgumentException("Provider JSON credential is invalid", error);
        }
    }

    private String normalizeBaseUrl(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        String result = value.trim();
        return result.endsWith("/") ? result : result + "/";
    }

    private boolean isUsableRotatingCredential(TranslatorId id, CredentialValue raw) {
        if (raw == null) return false;
        try {
            if (id.isOpenAiCompatibleTranslation()) {
                return isUsableOpenAiCompatibleCredential(id, raw);
            }
            if (id.requiresEndpointCredential()) {
                return isSecureBaseUrl(jsonField(raw, "baseUrl", "endpoint"))
                        && nonBlank(jsonString(raw,
                        "apiKey", "rapidApiKey", "key", "token", "value"));
            }
            return nonBlank(jsonString(raw,
                    "apiKey", "rapidApiKey", "key", "token", "value"));
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private boolean nonBlank(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private boolean isSecureBaseUrl(String value) {
        if (!nonBlank(value)) return false;
        try {
            URI uri = new URI(value.trim());
            return "https".equalsIgnoreCase(uri.getScheme())
                    && nonBlank(uri.getHost())
                    && uri.getUserInfo() == null
                    && uri.getQuery() == null
                    && uri.getFragment() == null;
        } catch (URISyntaxException error) {
            return false;
        }
    }

    private static final class EngineValues {
        final List<CredentialValue> values;
        final boolean vip;
        final boolean selectable;
        final Integer dailyLimit;
        final AtomicInteger cursor = new AtomicInteger();
        EngineValues(List<CredentialValue> values, boolean vip, boolean selectable,
                     Integer dailyLimit) {
            this.values = Collections.unmodifiableList(new ArrayList<>(values));
            this.vip = vip;
            this.selectable = selectable;
            this.dailyLimit = dailyLimit;
        }
    }

    /** Parsed once during configuration load; JSON plaintext is not retained a second time. */
    private static final class CredentialValue {
        final String scalar;
        final JsonObject json;

        private CredentialValue(String scalar, JsonObject json) {
            this.scalar = scalar;
            this.json = json;
        }

        static CredentialValue parse(String decrypted) {
            if (decrypted == null || decrypted.trim().isEmpty()) return null;
            String trimmed = decrypted.trim();
            if (!trimmed.startsWith("{")) return new CredentialValue(decrypted, null);
            try {
                return new CredentialValue(null,
                        JsonParser.parseString(trimmed).getAsJsonObject());
            } catch (RuntimeException invalidJson) {
                return null;
            }
        }

        boolean isJson() { return json != null; }
    }

    private static final class AppTranslationConfig {
        @SerializedName("engines")
        List<ConfiguredEngine> engines;
        boolean hasEnginesField() { return engines != null; }
        List<ConfiguredEngine> getEngines() {
            return engines == null ? Collections.emptyList() : engines;
        }
    }

    private static final class ConfiguredEngine {
        @SerializedName("id")
        int id;
        @SerializedName("keys")
        List<String> keys;
        @SerializedName("vip")
        boolean vip;
        @SerializedName("selectable")
        Boolean selectable;
        @SerializedName("dailyLimit")
        Integer dailyLimit;

        int getId() { return id; }
        List<String> getKeys() { return keys == null ? Collections.emptyList() : keys; }
        boolean isVip() { return vip; }
        boolean isSelectable() { return Boolean.TRUE.equals(selectable); }
        boolean hasSelectableFlag() { return selectable != null; }
        Integer getDailyLimit() { return dailyLimit; }
    }
}
