package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.SdkPreferences;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;

import retrofit2.HttpException;

/** Google direct failures use an hour-scale cooldown; self-hosted and other providers keep their own policy. */
public final class ProviderFailurePolicy {
    static final long TRANSIENT_NETWORK_COOLDOWN_MS = 300_000L;
    static final long SERVER_COOLDOWN_MS = 300_000L;
    static final long DEFAULT_RATE_LIMIT_COOLDOWN_MS = 300_000L;
    /** Longer than every engine's configured cooldown (the longest is 90 minutes). */
    private static final long MAX_NON_PROBEABLE_MS = 2L * 60L * 60L * 1_000L;

    private ProviderFailurePolicy() { }
    /** Preserve the original throwable and avoid recording a retired request against a new runtime. */
    public static io.reactivex.functions.Consumer<Throwable> observeAttempt(int engineId) {
        TranslationRuntime expected = TranslationRuntime.snapshot();
        return failure -> {
            if (expected == TranslationRuntime.currentOrNull())
                TranslationRuntime.withSnapshot(expected, () -> recordAttemptFailure(engineId, failure));
        };
    }

    public static synchronized void record(Context context, String stateKey,
                              TranslatorId engine, Throwable failure) {
        if (isRequestScopedFailure(engine, failure)) return;
        if (TranslationRuntime.snapshot() != TranslationRuntime.currentOrNull()) return;
        if (isNetworkFailure(failure) && NetworkFailureScope.current() == null) {
            NetworkFailureScope.run(NetworkFailureScope.network(context), () -> record(context, stateKey, engine, failure));
            return;
        }
        if (context == null || stateKey == null || engine == null
                || !NetworkUtils.isConnectedAvailableNetwork(context)) return;
        SdkPreferences preferences = SdkPreferences.getInstance(context);
        long now = System.currentTimeMillis();
        boolean unidentifiedState = isUnidentifiedCooldown(preferences, stateKey,
                engine.defaultCooldownMs, now);
        recordAttemptFailure(engine.legacyCode, failure);
        long failures = isTransientFailure(failure)
                ? Math.min(4L, preferences.getLong(streakKey(engine.legacyCode), 0L) + 1L) : 0L;
        preferences.put(streakKey(engine.legacyCode), failures);
        if (isFreeGoogleDirect(engine)) {
            TranslationRuntime runtime = TranslationRuntime.snapshot();
            if (runtime != null) runtime.googleReachability().recordFailure(engine.legacyCode);
        }
        long cooldownMs = cooldownMs(failure, engine, failures);
        if (cooldownMs <= 0L) return;
        SdkPreferences.getInstance(context).putCooldown(stateKey, now, cooldownMs);
        recordTransportOrigin(preferences, stateKey,
                isProbeableFailure(engine, failure) && !unidentifiedState);
        if (!isProbeableFailure(engine, failure))
            markNonProbeable(preferences, engine.legacyCode, now, cooldownMs);
    }

    /**
     * State cooldown written by a Provider's own failure handler. With a transport failure it
     * follows the same escalation as {@link #record}; a rejected response envelope (no
     * throwable) keeps the engine's configured cooldown and is never probed early.
     */
    public static synchronized void recordStateFailure(Context context, String stateKey,
                                                       TranslatorId engine, Throwable failure) {
        if (context == null || stateKey == null || engine == null) return;
        if (failure != null) {
            record(context, stateKey, engine, failure);
            return;
        }
        if (TranslationRuntime.snapshot() != TranslationRuntime.currentOrNull()) return;
        long now = System.currentTimeMillis();
        SdkPreferences preferences = SdkPreferences.getInstance(context);
        preferences.putCooldown(stateKey, now, engine.defaultCooldownMs);
        recordTransportOrigin(preferences, stateKey, false);
        markNonProbeable(preferences, engine.legacyCode, now, engine.defaultCooldownMs);
    }

    /**
     * A self-hosted node answered with a failed envelope whose business code reports an upstream
     * timeout or server error (408 or 5xx, for example UPSTREAM_ERROR or BUDGET_EXHAUSTED). It is
     * recorded like the equivalent HTTP status; any other envelope code returns null and keeps the
     * engine's configured, non-probeable cooldown.
     */
    public static Throwable envelopeTransportFailure(int envelopeCode) {
        if (envelopeCode != 408 && (envelopeCode < 500 || envelopeCode > 599)) return null;
        return new HttpException(retrofit2.Response.error(envelopeCode,
                okhttp3.ResponseBody.create(null, "")));
    }

    /**
     * Only transport-level trouble (network, 408, 5xx) may be probed before its cooldown ends.
     * Rate limits, authentication, quota and rejected bodies keep their full cooldown, and the
     * free Google direct engines keep their 90 minute block.
     */
    static boolean isProbeableFailure(TranslatorId engine, Throwable failure) {
        if (engine == null || isFreeGoogleDirect(engine) || !isTransientFailure(failure)) return false;
        HttpException http = findHttpException(failure);
        return http == null || http.code() != 429;
    }

    private static String nonProbeableKey(int engineId) {
        return "PROVIDER_NONPROBEABLE_UNTIL_" + engineId;
    }

    private static String transportOriginKey(String cooldownKey) {
        return "PROVIDER_TRANSPORT_ORIGIN_" + cooldownKey;
    }

    /** Old persisted cooldowns have no proven cause and must expire normally. */
    private static boolean isUnidentifiedCooldown(SdkPreferences preferences, String key,
                                                   long fallbackMs, long nowMs) {
        return !preferences.isCooldownReady(key, fallbackMs, nowMs, 300_000L)
                && preferences.getLong(transportOriginKey(key), 0L)
                != preferences.getLong(key, 0L);
    }

    private static void recordTransportOrigin(SdkPreferences preferences, String key,
                                              boolean transport) {
        preferences.putRaw(transportOriginKey(key), transport ? preferences.getLong(key, 0L) : 0L);
    }

    private static void markNonProbeable(SdkPreferences preferences, int engineId,
                                         long nowMs, long durationMs) {
        if (durationMs <= 0L) return;
        long until = nowMs > Long.MAX_VALUE - durationMs ? Long.MAX_VALUE : nowMs + durationMs;
        String key = nonProbeableKey(engineId);
        synchronized (preferences) {
            if (preferences.getLong(key, 0L) < until) preferences.putRaw(key, until);
        }
    }

    /** Whether every cooldown currently recorded for the engine came from probeable failures. */
    public static synchronized boolean isProbeAllowed(Context context, int engineId, long nowMs) {
        if (context == null || ContinuousCooldownProbe.stateKey(engineId) == null) return false;
        SdkPreferences preferences = SdkPreferences.getInstance(context);
        String key = nonProbeableKey(engineId);
        synchronized (preferences) {
            long until = preferences.getLong(key, 0L);
            if (until <= nowMs) {
                TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
                return !isUnidentifiedCooldown(preferences, "PROVIDER_ATTEMPT_COOLDOWN_" + engineId,
                        300_000L, nowMs)
                        && !isUnidentifiedCooldown(preferences, ContinuousCooldownProbe.stateKey(engineId),
                        engine.defaultCooldownMs, nowMs);
            }
            // The wall clock moved back: stay blocked, but never longer than any cooldown lasts.
            if (until - nowMs > MAX_NON_PROBEABLE_MS) preferences.putRaw(key, nowMs + MAX_NON_PROBEABLE_MS);
            return false;
        }
    }

    /**
     * Ends the engine's transport-failure cooldown so it can be tried again. The failure streak
     * is kept: another failure records the next, longer cooldown; a success resets it as usual.
     */
    public static synchronized boolean clearForProbe(Context context, int engineId, String stateKey,
                                                      com.mg.translation.internal.model.TranslationTask task) {
        if (task == null || !task.isRuntimeCurrent() || task.remainingBudgetMs() <= 0L
                || task.wasDispatched(engineId)
                || TranslationRuntime.snapshot() != TranslationRuntime.currentOrNull()
                || !isProbeAllowed(context, engineId, System.currentTimeMillis())) return false;
        SdkPreferences preferences = SdkPreferences.getInstance(context);
        preferences.put("PROVIDER_ATTEMPT_COOLDOWN_" + engineId, 0L);
        if (stateKey != null) preferences.put(stateKey, 0L);
        return true;
    }

    public static synchronized void recordSuccess(int engineId) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null || runtime != TranslationRuntime.currentOrNull()) return;
        SdkPreferences.getInstance(runtime.context()).put(streakKey(engineId), 0L);
        ContinuousCooldownProbe.noteSuccess();
    }

    private static String streakKey(int engineId) { return "NETWORK_FAILURE_STREAK_" + engineId; }

    private static boolean isFreeGoogleDirect(TranslatorId engine) {
        return engine == TranslatorId.GOOGLE || engine == TranslatorId.GOOGLE_CLIENT;
    }

    private static boolean isSelfHosted(TranslatorId engine) {
        return engine == TranslatorId.SELF_HOSTED_GOOGLE
                || engine == TranslatorId.SELF_HOSTED_YOUDAO
                || engine == TranslatorId.SELF_HOSTED_DEEPL
                || engine == TranslatorId.SELF_HOSTED_YANDEX || engine == TranslatorId.BD;
    }

    /** Also covers providers whose repositories do not record a provider-specific cooldown. */
    public static synchronized void recordAttemptFailure(int engineId, Throwable failure) {
        if (isRequestScopedFailure(engineId, failure)) return;
        if (isNetworkFailure(failure) && NetworkFailureScope.current() == null) {
            NetworkFailureScope.run(NetworkFailureScope.network(), () -> recordAttemptFailure(engineId, failure));
            return;
        }
        TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime != TranslationRuntime.currentOrNull()) return;
        if (engine == null || runtime == null) return;
        if (findHttpException(failure) == null
                && !NetworkUtils.isConnectedAvailableNetwork(runtime.context())) return;
        long now = System.currentTimeMillis();
        long cooldownMs = cooldownMs(failure, engine, 1);
        SdkPreferences preferences = SdkPreferences.getInstance(runtime.context());
        String key = "PROVIDER_ATTEMPT_COOLDOWN_" + engineId;
        boolean unidentified = isUnidentifiedCooldown(preferences, key, 300_000L, now);
        preferences.putCooldownAtLeast(key, now, cooldownMs);
        recordTransportOrigin(preferences, key, isProbeableFailure(engine, failure) && !unidentified);
        if (!isProbeableFailure(engine, failure))
            markNonProbeable(preferences, engineId, now, cooldownMs);
    }

    /**
     * A rate-limit, account or quota rejection reported in a successful response body: the
     * engine's normal cooldown. Other body-level rejections are input-scoped and never call this.
     */
    public static synchronized void recordProviderLimit(int engineId) {
        TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (engine == null || runtime == null || runtime != TranslationRuntime.currentOrNull()) return;
        long now = System.currentTimeMillis();
        SdkPreferences preferences = SdkPreferences.getInstance(runtime.context());
        preferences.putCooldownAtLeast("PROVIDER_ATTEMPT_COOLDOWN_" + engineId, now,
                engine.defaultCooldownMs);
        recordTransportOrigin(preferences, "PROVIDER_ATTEMPT_COOLDOWN_" + engineId, false);
        markNonProbeable(preferences, engineId, now, engine.defaultCooldownMs);
    }

    public static boolean isAttemptCoolingDown(Context context, int engineId) {
        return !SdkPreferences.getInstance(context).isCooldownReady(
                "PROVIDER_ATTEMPT_COOLDOWN_" + engineId, 300_000L, System.currentTimeMillis());
    }

    static long cooldownMs(Throwable failure, TranslatorId engine, long consecutiveFailures) {
        if (isRequestScopedFailure(engine, failure)) return 0L;
        // Only the free Google engines keep their hour-scale (90 minute) failure cooldown.
        if (isFreeGoogleDirect(engine)) return engine.defaultCooldownMs;
        HttpException http = findHttpException(failure);
        if (!isSelfHosted(engine) && http != null && http.code() == 429) {
            return engine.defaultCooldownMs;
        }
        return cooldownMs(failure, engine.defaultCooldownMs, consecutiveFailures);
    }

    public static boolean isNetworkFailure(Throwable failure) {
        Throwable cause = rootCause(failure);
        return findHttpException(failure) == null && cause instanceof IOException
                && !(cause instanceof SSLHandshakeException)
                && !(cause instanceof SSLPeerUnverifiedException);
    }

    /** A request with too little time left did not establish provider health. */
    public static boolean isLocalBudgetFailure(Throwable failure) {
        return rootCause(failure) instanceof
                com.mg.translation.internal.base.http.InsufficientTranslationBudgetException;
    }

    /** Input rejection says nothing about the health of other requests on that engine. */
    public static boolean isRequestScopedFailure(Throwable failure) {
        if (isLocalBudgetFailure(failure)) return true;
        Throwable current = failure;
        while (current != null) {
            if (SelfHostedRequestRejectionException.isRequestRejection(current)
                    || current instanceof RejectedProviderResultException) return true;
            if (current.getCause() == current) break;
            current = current.getCause();
        }
        return false;
    }

    /**
     * Also input-scoped for the given engine: HTTP 400/404/413/414/422 from a Provider that is
     * not self-hosted (self-hosted nodes classify their own rejections), and MyMemory 403.
     */
    public static boolean isRequestScopedFailure(int engineId, Throwable failure) {
        return isRequestScopedFailure(TranslatorId.fromLegacyCode(engineId), failure);
    }

    private static boolean isRequestScopedFailure(TranslatorId engine, Throwable failure) {
        if (isRequestScopedFailure(failure)) return true;
        HttpException http = findHttpException(failure);
        if (engine == null || http == null || isSelfHosted(engine)) return false;
        int status = http.code();
        return status == 400 || status == 404 || status == 413 || status == 414 || status == 422
                || engine == TranslatorId.MYMEMORY && status == 403;
    }

    private static boolean isTransientFailure(Throwable failure) {
        HttpException http = findHttpException(failure);
        return isNetworkFailure(failure) || (http != null
                && (http.code() == 408 || http.code() == 429 || http.code() >= 500));
    }

    static long cooldownMs(Throwable failure, long configuredCooldownMs, long consecutiveFailures) {
        if (isRequestScopedFailure(failure)) return 0L;
        if (isTransientFailure(failure)) {
            long backoff = consecutiveFailures <= 1L ? TRANSIENT_NETWORK_COOLDOWN_MS
                    : consecutiveFailures == 2L ? 600_000L
                    : consecutiveFailures == 3L ? 1_800_000L : configuredCooldownMs;
            return Math.min(configuredCooldownMs,
                    Math.max(backoff, cooldownMs(failure, configuredCooldownMs)));
        }
        return cooldownMs(failure, configuredCooldownMs);
    }

    static long cooldownMs(Throwable failure, long configuredCooldownMs) {
        if (isRequestScopedFailure(failure)) return 0L;
        Throwable cause = rootCause(failure);
        HttpException http = findHttpException(failure);
        if (http != null) {
            int status = http.code();
            if (status == 401 || status == 403) return configuredCooldownMs;
            if (status == 429) return retryAfterMs(http, configuredCooldownMs);
            if (status == 408 || status >= 500) {
                return Math.min(configuredCooldownMs, SERVER_COOLDOWN_MS);
            }
            return configuredCooldownMs;
        }
        if (cause instanceof SSLHandshakeException
                || cause instanceof SSLPeerUnverifiedException) {
            return configuredCooldownMs;
        }
        if (cause instanceof SocketTimeoutException
                || cause instanceof InterruptedIOException
                || cause instanceof UnknownHostException
                || cause instanceof ConnectException
                || cause instanceof NoRouteToHostException
                || cause instanceof IOException) {
            return Math.min(configuredCooldownMs, TRANSIENT_NETWORK_COOLDOWN_MS);
        }
        return Math.min(configuredCooldownMs, SERVER_COOLDOWN_MS);
    }

    private static long retryAfterMs(HttpException failure, long maximumMs) {
        String value = failure.response() == null ? null
                : failure.response().headers().get("Retry-After");
        if (value != null) {
            try {
                long seconds = Long.parseLong(value.trim());
                if (seconds > 0L) {
                    long millis = seconds > Long.MAX_VALUE / 1_000L
                            ? Long.MAX_VALUE : seconds * 1_000L;
                    return Math.min(maximumMs, Math.max(DEFAULT_RATE_LIMIT_COOLDOWN_MS, millis));
                }
            } catch (NumberFormatException ignored) {
                // HTTP-date Retry-After values use the bounded default below.
            }
        }
        return Math.min(maximumMs, DEFAULT_RATE_LIMIT_COOLDOWN_MS);
    }

    private static Throwable rootCause(Throwable failure) {
        Throwable current = failure;
        while (current != null && current.getCause() != null
                && current.getCause() != current) current = current.getCause();
        return current;
    }

    private static HttpException findHttpException(Throwable failure) {
        Throwable current = failure;
        while (current != null) {
            if (current instanceof HttpException) return (HttpException) current;
            if (current.getCause() == current) return null;
            current = current.getCause();
        }
        return null;
    }
}
