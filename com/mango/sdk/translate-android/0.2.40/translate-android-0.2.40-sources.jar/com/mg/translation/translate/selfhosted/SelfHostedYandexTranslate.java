package com.mg.translation.translate.selfhosted;

import static com.mg.translation.internal.text.TranslationText.copy;

import android.content.Context;
import android.text.TextUtils;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.http.translate.common.dto.MeTranslateHttpResult;
import com.mg.translation.http.translate.common.dto.MeTranslateReq;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.base.http.RequestContext;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.runtime.TranslationTelemetry;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.internal.runtime.BatchInputFilter;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;
import com.mg.translation.utils.TranslationPreferenceKeys;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

/** Self-hosted Yandex web translation. Owns all 121 languages published by translate.yandex.com v321.0. */
public class SelfHostedYandexTranslate extends BaseTranslateControl {
    private final Context context;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    public SelfHostedYandexTranslate(Context context) { this.context = context; }

    @Override
    public void translate(TranslationTask task, TranslateListener listener) {
        if (listener == null || task == null) return;
        String source = task.getSourceLanguageId();
        if (getSelectLanguageVO(task.getTargetLanguageId(), false) == null
                || source != null && !LanguageConstant.AUTO.equals(source)
                && getSelectLanguageVO(source, false) == null) {
            listener.onFail(TranslationErrorCode.UNSUPPORTED_LANGUAGE,
                    context.getString(R.string.translation_error_unsupported_language));
            return;
        }
        try {
            partitionTexts(new InputPlan(task instanceof BatchTranslationTask
                    ? ((BatchTranslationTask) task).getSourceTexts()
                    : java.util.Arrays.asList((task.getContent() == null ? "" : task.getContent()).split("\n", -1))).sent);
        } catch (IllegalArgumentException invalid) {
            // A line or item over Yandex's 10,000 code point limit is only too long for this
            // engine: other eligible engines take it, and Yandex is not cooled down.
            fallbackForUnacceptedInput(context, task, listener, TranslationErrorCode.INVALID_REQUEST,
                    context.getString(R.string.translation_error_invalid_request));
            return;
        }
        if (!TranslateUtils.getSelfHostedYandexApiState(context)) {
            dealTranslateError(context, task, listener);
            return;
        }
        TranslationTelemetry.event("self_hosted_yandex_translate_request");
        if (task instanceof BatchTranslationTask) {
            translateBatch((BatchTranslationTask) task, listener);
        } else {
            translateSingle(task, listener);
        }
    }

    private void translateBatch(BatchTranslationTask task, TranslateListener listener) {
        List<String> sourceTexts = task.getSourceTexts();
        List<String> texts = copy(sourceTexts);
        executeRequest(translateTexts(texts, task.getSourceLanguageId(), task.getTargetLanguageId()), result -> {
            String[] translated = successTexts(result, sourceTexts.size());
            if (translated == null) {
                if (result != null && result.isSuccess()) task.markUnalignedResponse();
                handleFailure(task, listener, suppressCooldown(result) || result != null && result.isSuccess(), result);
                return;
            }
            for (int i = 0; i < translated.length; i++) task.setTranslation(i, translated[i]);
            listener.onSuccess(task, getTranslateType(), true);
        }, () -> handleFailure(task, listener, false, null));
    }

    private void translateSingle(TranslationTask task, TranslateListener listener) {
        if (TextUtils.isEmpty(task.getContent())) {
            listener.onSuccess(task, getTranslateType(), false);
            return;
        }
        List<String> texts = new ArrayList<>();
        Collections.addAll(texts, task.getContent().split("\n", -1));
        executeRequest(translateTexts(texts, task.getSourceLanguageId(), task.getTargetLanguageId()), result -> {
            String[] translated = successTexts(result, texts.size());
            if (translated == null || hasBlankOutputForNonblankInput(texts, translated)) {
                // Wrong row counts and blank rows in a successful envelope are input-scoped.
                handleFailure(task, listener, suppressCooldown(result)
                        || result != null && result.isSuccess(), result);
                return;
            }
            task.setTranslatedText(TextUtils.join("\n", translated));
            listener.onSuccess(task, getTranslateType(), false);
        }, () -> handleFailure(task, listener, false, null));
    }

    private String[] successTexts(MeTranslateHttpResult result, int expectedSize) {
        if (result == null || !result.isSuccess() || result.getTexts() == null
                || result.getTexts().length != expectedSize) return null;
        for (String text : result.getTexts()) if (text == null) return null;
        return result.getTexts();
    }

    private static boolean hasBlankOutputForNonblankInput(List<String> input, String[] output) {
        for (int i = 0; i < input.size(); i++) {
            if (!BatchInputFilter.isBlank(input.get(i)) && BatchInputFilter.isBlank(output[i])) return true;
        }
        return false;
    }

    /** Node limits are stricter than the public SDK batch limit; keep one attempt deadline. */
    private Single<MeTranslateHttpResult> translateTexts(List<String> texts, String source, String target) {
        final InputPlan inputs = new InputPlan(texts);
        final List<List<String>> parts;
        try { parts = partitionTexts(inputs.sent); }
        catch (IllegalArgumentException invalid) { return Single.error(invalid); }
        final long deadline = RequestContext.deadline();
        final long trace = RequestContext.trace();
        final TranslationRuntime runtime = TranslationRuntime.snapshot();
        return Observable.fromIterable(parts).concatMapSingle(part -> {
            Single<MeTranslateHttpResult> call = Single.create(emitter -> {
                Integer previous = RequestContext.engine();
                RequestContext.set(getTranslateType());
                try {
                    TranslationRuntime.withSnapshot(runtime, () -> RequestContext.withDeadline(deadline,
                            () -> RequestContext.withTrace(trace, () ->
                                    sendGatewayRequest(createGatewayRequest(part, source, target)).subscribe(
                                            new SingleObserver<MeTranslateHttpResult>() {
                                                @Override public void onSubscribe(Disposable disposable) {
                                                    emitter.setDisposable(disposable);
                                                }
                                                @Override public void onSuccess(MeTranslateHttpResult value) {
                                                    emitter.onSuccess(value);
                                                }
                                                @Override public void onError(Throwable error) {
                                                    emitter.tryOnError(error);
                                                }
                                            }))));
                } finally { RequestContext.set(previous); }
            });
            return call.map(reply -> new ChunkReply(reply, part.size()));
        }).takeUntil(reply -> successTexts(reply.result, reply.expected) == null).toList().map(replies -> {
            List<String> output = new ArrayList<>();
            for (ChunkReply reply : replies) {
                String[] translated = successTexts(reply.result, reply.expected);
                if (translated == null) {
                    if (!reply.result.isSuccess()) return reply.result;
                    MeTranslateHttpResult invalid = new MeTranslateHttpResult();
                    invalid.setCode(200); // Preserve the batch misalignment path, without accepting extra rows.
                    return invalid;
                }
                Collections.addAll(output, translated);
            }
            MeTranslateHttpResult result = new MeTranslateHttpResult();
            result.setCode(200);
            result.setTexts(inputs.restore(output));
            return result;
        });
    }

    protected Single<MeTranslateHttpResult> sendGatewayRequest(MeTranslateReq request) {
        return TranslateRepository.getInstance().selfHostedYandexTranslate(request);
    }

    static List<List<String>> partitionTexts(List<String> texts) {
        List<List<String>> parts = new ArrayList<>();
        List<String> part = new ArrayList<>();
        int codepoints = 0;
        for (String text : texts) {
            if (text == null) throw new IllegalArgumentException("Null Yandex input");
            int count = text.codePointCount(0, text.length());
            if (count > 10000) throw new IllegalArgumentException("Yandex text exceeds 10000 codepoints");
            if (!part.isEmpty() && (part.size() == 100 || codepoints + count > 10000)) {
                parts.add(part); part = new ArrayList<>(); codepoints = 0;
            }
            part.add(text); codepoints += count;
        }
        if (!part.isEmpty()) parts.add(part);
        return parts;
    }

    private static final class ChunkReply {
        final MeTranslateHttpResult result;
        final int expected;
        ChunkReply(MeTranslateHttpResult result, int expected) { this.result = result; this.expected = expected; }
    }

    /** Blank lines/items retain their exact text and position without violating @NotBlank upstream. */
    private static final class InputPlan {
        final List<String> original;
        final List<String> sent = new ArrayList<>();
        final List<Integer> sentIds = new ArrayList<>();
        InputPlan(List<String> texts) {
            original = new ArrayList<>(texts);
            for (int i = 0; i < texts.size(); i++) {
                String text = texts.get(i);
                if (text == null) throw new IllegalArgumentException("Null Yandex input");
                if (!BatchInputFilter.isBlank(text)) { sent.add(text); sentIds.add(i); }
            }
        }
        String[] restore(List<String> translated) {
            if (translated.size() != sent.size()) throw new IllegalArgumentException("Unaligned Yandex chunks");
            String[] restored = original.toArray(new String[0]);
            for (int i = 0; i < sentIds.size(); i++) restored[sentIds.get(i)] = translated.get(i);
            return restored;
        }
    }

    private void handleFailure(TranslationTask task, TranslateListener listener,
                               boolean skipCooldown,
                               MeTranslateHttpResult envelope) {
        if (!skipCooldown && shouldRecordCooldownForCurrentFailure()) {
            recordStateFailure(context, TranslationPreferenceKeys.SELF_HOSTED_YANDEX_TRANSLATE_STATE,
                    envelope == null ? 0 : envelope.getCode());
        }
        dealTranslateError(context, task, listener);
    }

    static boolean suppressCooldown(MeTranslateHttpResult result) {
        return result != null && ("BUDGET_EXHAUSTED".equals(result.getFailureClass())
                || "PROVIDER".equals(result.getFailureOrigin())
                && "LANGUAGE_UNSUPPORTED".equals(result.getFailureClass()));
    }

    private MeTranslateReq createGatewayRequest(List<String> texts, String sourceId,
                                                String targetId) {
        MeTranslateReq request = new MeTranslateReq();
        LanguageVO target = getSelectLanguageVO(targetId, false);
        if (target == null) throw new IllegalArgumentException("Unsupported Yandex target language");
        request.setTl(target.getValue());
        if (sourceId == null || LanguageConstant.AUTO.equals(sourceId)) {
            request.setFl("auto");
        } else {
            LanguageVO source = getSelectLanguageVO(sourceId, false);
            if (source == null) throw new IllegalArgumentException("Unsupported Yandex source language");
            request.setFl(source.getValue());
        }
        request.setQ(texts.toArray(new String[0]));
        return request;
    }

    @Override
    public BaseReq createBaseReq(String content, String source, String target) {
        return createGatewayRequest(Collections.singletonList(content), source, target);
    }

    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguages();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }

    private void initLanguages() {
        mDestLanguageList = new ArrayList<>();
        add(LanguageConstant.ABAZA, R.string.provider_language_yandex_abq, "abq");
        add(LanguageConstant.ABKHAZ, R.string.language_Abkhaz, "ab");
        add(LanguageConstant.ADYGHE, R.string.provider_language_yandex_ady, "ady");
        add(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af");
        add(LanguageConstant.ALBANIAN, R.string.language_Albanian, "sq");
        add(LanguageConstant.ALTAI, R.string.provider_language_yandex_alt, "alt");
        add(LanguageConstant.AMHARIC, R.string.language_Amharic, "am");
        add(LanguageConstant.ARABIC, R.string.language_Arabic, "ar");
        add(LanguageConstant.ARMENIAN, R.string.language_Armenian, "hy");
        add(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "az");
        add(LanguageConstant.BASHKIR, R.string.language_Bashkir, "ba");
        add(LanguageConstant.BASQUE, R.string.language_Basque, "eu");
        add(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be");
        add(LanguageConstant.BENGALI, R.string.language_Bengali, "bn");
        add(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bs");
        add(LanguageConstant.BULGARIAN, R.string.language_Bulgaria, "bg");
        add(LanguageConstant.BURMESE, R.string.language_Burmese, "my");
        add(LanguageConstant.BURYAT, R.string.language_Buryat, "bua");
        add(LanguageConstant.CATALAN, R.string.language_Catalan, "ca");
        add(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb");
        add(LanguageConstant.CHECHEN, R.string.language_Chechen, "ce");
        add(LanguageConstant.CHINESE, R.string.language_Chinese, "zh");
        add(LanguageConstant.CHUVASH, R.string.language_Chuvash, "cv");
        add(LanguageConstant.CROATIAN, R.string.language_Croatian, "hr");
        add(LanguageConstant.CZECH, R.string.language_Czech, "cs");
        add(LanguageConstant.DANISH, R.string.language_Danish, "da");
        add(LanguageConstant.DUTCH, R.string.language_Dutch, "nl");
        add(LanguageConstant.SINDARIN, R.string.provider_language_yandex_sjn, "sjn");
        add(LanguageConstant.EMOJI, R.string.provider_language_yandex_emj, "emj");
        add(LanguageConstant.ENGLISH, R.string.language_English, "en");
        add(LanguageConstant.ERZYA, R.string.provider_language_yandex_myv, "myv");
        add(LanguageConstant.ESPERANTO, R.string.language_Esperanto, "eo");
        add(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et");
        add(LanguageConstant.FINNISH, R.string.language_Finnish, "fi");
        add(LanguageConstant.FRENCH, R.string.language_French, "fr");
        add(LanguageConstant.GALICIAN, R.string.language_Galician, "gl");
        add(LanguageConstant.GALTARAN, R.string.provider_language_yandex_glt, "glt");
        add(LanguageConstant.GEORGIAN, R.string.language_Georgian, "ka");
        add(LanguageConstant.GERMAN, R.string.language_German, "de");
        add(LanguageConstant.GREEK, R.string.language_Greek, "el");
        add(LanguageConstant.GUJARATI, R.string.language_Gujarati, "gu");
        add(LanguageConstant.HAITIAN, R.string.language_Haitian, "ht");
        add(LanguageConstant.HEBREW, R.string.language_Hebrew, "he");
        add(LanguageConstant.HILL_MARI, R.string.provider_language_yandex_mrj, "mrj");
        add(LanguageConstant.HINDI, R.string.language_Hindi, "hi");
        add(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu");
        add(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "is");
        add(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id");
        add(LanguageConstant.IRISH, R.string.language_Irish, "ga");
        add(LanguageConstant.ITALIAN, R.string.language_Italian, "it");
        add(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja");
        add(LanguageConstant.JAVANESE, R.string.language_Javanese, "jv");
        add(LanguageConstant.JUHURI, R.string.provider_language_yandex_jdt, "jdt");
        add(LanguageConstant.KABARDIAN, R.string.provider_language_yandex_kbd, "kbd");
        add(LanguageConstant.KANNADA, R.string.language_Kannada, "kn");
        add(LanguageConstant.KARACHAY_BALKAR, R.string.provider_language_yandex_krc, "krc");
        add(LanguageConstant.KARELIAN, R.string.provider_language_yandex_olo, "olo");
        add(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk");
        add(LanguageConstant.KAZAKH_LATIN, R.string.provider_language_yandex_kazlat, "kazlat");
        add(LanguageConstant.KHAKAS, R.string.provider_language_yandex_kjh, "kjh");
        add(LanguageConstant.KHMER, R.string.language_Khmer, "km");
        add(LanguageConstant.KOMI, R.string.language_Komi, "kv");
        add(LanguageConstant.KOREAN, R.string.language_Korean, "ko");
        add(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz, "ky");
        add(LanguageConstant.LAO, R.string.language_Lao, "lo");
        add(LanguageConstant.LATIN, R.string.language_Latin, "la");
        add(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv");
        add(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt");
        add(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb");
        add(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mk");
        add(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg");
        add(LanguageConstant.MALAY, R.string.language_Malay, "ms");
        add(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "ml");
        add(LanguageConstant.MALTESE, R.string.language_Maltese, "mt");
        add(LanguageConstant.MANSI, R.string.provider_language_yandex_mns, "mns");
        add(LanguageConstant.MAORI, R.string.language_Maori, "mi");
        add(LanguageConstant.MARATHI, R.string.language_Marathi, "mr");
        add(LanguageConstant.MARI, R.string.language_Mari, "mhr");
        add(LanguageConstant.MOKSHA, R.string.provider_language_yandex_mdf, "mdf");
        add(LanguageConstant.MONGOLIAN, R.string.language_Mongolian, "mn");
        add(LanguageConstant.NEPALI, R.string.language_Nepali, "ne");
        add(LanguageConstant.NOGAI, R.string.provider_language_yandex_nog, "nog");
        add(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "no");
        add(LanguageConstant.OSSETIAN, R.string.language_Ossetian, "os");
        add(LanguageConstant.PAPIAMENTO, R.string.language_Papiamento, "pap");
        add(LanguageConstant.PERSIAN, R.string.language_Persian, "fa");
        add(LanguageConstant.POLISH, R.string.language_Polish, "pl");
        add(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt");
        add(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese_Brazil, "pt-BR");
        add(LanguageConstant.PUNJABI, R.string.language_Punjabi, "pa");
        add(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro");
        add(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru");
        add(LanguageConstant.SCOTTISH_GAELIC, R.string.language_Gaelic, "gd");
        add(LanguageConstant.SERBIAN, R.string.language_Serbian, "sr");
        add(LanguageConstant.SERBIAN_LATIN, R.string.language_Serbian_Latin, "sr-Latn");
        add(LanguageConstant.SINHALA, R.string.language_Sinhala, "si");
        add(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk");
        add(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl");
        add(LanguageConstant.SPANISH, R.string.language_Spanish, "es");
        add(LanguageConstant.SUNDANESE, R.string.language_Sundanese, "su");
        add(LanguageConstant.SWAHILI, R.string.language_Swahili, "sw");
        add(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv");
        add(LanguageConstant.TAGALOG, R.string.language_Tagalog, "tl");
        add(LanguageConstant.TAJIK, R.string.language_Tajik, "tg");
        add(LanguageConstant.TAMIL, R.string.language_Tamil, "ta");
        add(LanguageConstant.TATAR, R.string.language_Tatar, "tt");
        add(LanguageConstant.TELUGU, R.string.language_Telugu, "te");
        add(LanguageConstant.THAI, R.string.language_Thai, "th");
        add(LanguageConstant.TURKISH, R.string.language_Turkish, "tr");
        add(LanguageConstant.TUVAN, R.string.language_Tuvan, "tyv");
        add(LanguageConstant.UDMURT, R.string.language_Udmurt, "udm");
        add(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk");
        add(LanguageConstant.URDU, R.string.language_Urdu, "ur");
        add(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz");
        add(LanguageConstant.UZBEK_CYRILLIC, R.string.provider_language_yandex_uzbcyr, "uzbcyr");
        add(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi");
        add(LanguageConstant.WELSH, R.string.language_Welsh, "cy");
        add(LanguageConstant.XHOSA, R.string.language_Xhosa, "xh");
        add(LanguageConstant.SAKHA, R.string.language_Sakha, "sah");
        add(LanguageConstant.YIDDISH, R.string.language_Yiddish, "yi");
        add(LanguageConstant.ZULU, R.string.language_Zulu, "zu");
    }

    private void add(String id, int label, String providerCode) {
        mDestLanguageList.add(new LanguageVO(id, label, providerCode));
    }

    @Override public String getTranslateTypeName() {
        return context.getString(R.string.brand_yandex_translate);
    }
    @Override public int getTranslateType() { return TranslatorId.SELF_HOSTED_YANDEX.legacyCode; }
}
