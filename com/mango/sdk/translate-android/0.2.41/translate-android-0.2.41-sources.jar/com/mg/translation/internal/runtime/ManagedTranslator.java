package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.Translator;
import com.mg.translation.sdk.TranslationCall;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationHost;
import com.mg.translation.sdk.TranslationMode;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.LongFunction;
import java.util.function.BiFunction;

/** Owns isolated chains, bounded scheduling, exact in-flight coalescing and bounded memory results. */
public final class ManagedTranslator implements Translator {
    private static final ScheduledThreadPoolExecutor TIMER = deadlineTimer();
    private static ScheduledThreadPoolExecutor deadlineTimer() {
        ScheduledThreadPoolExecutor timer = new ScheduledThreadPoolExecutor(1, r -> {
            Thread thread = new Thread(r, "mango-deadline"); thread.setDaemon(true); return thread;
        });
        timer.setRemoveOnCancelPolicy(true);
        return timer;
    }
    private static volatile long cacheTtlMs = 15_000L;
    private static final java.util.concurrent.atomic.AtomicLong NEXT_REQUEST = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.AtomicLong NEXT_CHAIN = new java.util.concurrent.atomic.AtomicLong();
    private static final int MAX_CACHE_CHARS = 128 * 1024;
    private static final long PARTIAL_CACHE_TTL_MS = 1_000L;
    private static final long EMERGENCY_BUDGET_MS = 8_000L;
    /** A 4004 (no engine produced a translation) may start the rescue chain this often per process. */
    static final long FAILURE_RESCUE_INTERVAL_MS = 10_000L;
    private static final long FAILURE_RESCUE_CACHE_TTL_MS = FAILURE_RESCUE_INTERVAL_MS;
    private static final long NEVER = Long.MIN_VALUE;
    private static final java.util.concurrent.atomic.AtomicLong LAST_FAILURE_RESCUE_NANOS =
            new java.util.concurrent.atomic.AtomicLong(NEVER);
    private static final long SELF_HOSTED_COMPLETION_GRACE_MS = 2_000L;
    private static final ScheduledThreadPoolExecutor EMERGENCY_EXECUTOR =
            new ScheduledThreadPoolExecutor(2, r -> {
                Thread thread = new Thread(r, "mango-emergency"); thread.setDaemon(true); return thread;
            });
    // A permit covers both asynchronous rescue attempts, not just their launch runnable.
    private static final TranslationDispatchQueue EMERGENCY_DISPATCH =
            new TranslationDispatchQueue(8, 64, EMERGENCY_EXECUTOR);
    private final int engineId;
    private final boolean cacheAllowed;
    private final LongFunction<Translator> factory;
    private final BiFunction<Integer, Long, Translator> emergencyFactory;
    private final TranslationDispatchQueue dispatch;
    private final long testBudgetMs;
    private final java.util.function.Consumer<Runnable> delivery;
    private final Map<List<Object>, Operation> active = new HashMap<>();
    private final Set<Subscription> subscriptions = new HashSet<>();
    private final LinkedHashMap<List<Object>, Cached> cache = new LinkedHashMap<>(16, .75f, true);
    private int cacheChars;
    private boolean closed;
    private Object cacheRuntime;
    private boolean cacheVip;

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), null);
    }

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), emergencyFactory);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery) {
        this(engineId, cacheAllowed, factory, dispatch, testBudgetMs, delivery, null);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this.engineId = engineId; this.cacheAllowed = cacheAllowed; this.factory = factory;
        this.dispatch = dispatch; this.testBudgetMs = testBudgetMs; this.delivery = delivery;
        this.emergencyFactory = emergencyFactory;
    }

    public static void configureResultCache(long ttlMs) {
        if (ttlMs < 0 || ttlMs > 60_000) throw new IllegalArgumentException("Cache TTL must be 0..60000 ms");
        cacheTtlMs = ttlMs;
    }

    @Override public int getEngineId() { return engineId; }
    @Override public void translate(TranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public TranslationCall translateCancellable(TranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }
    @Override public TranslationCall translateCancellable(BatchTranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }

    private synchronized TranslationCall submit(Object request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        TranslationDiagnosticContext.markSubmitted();
        Subscription subscriber = new Subscription(callback);
        if (closed) { subscriber.cancelled.set(true); return subscriber; }
        subscriptions.add(subscriber);
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        boolean vip = runtime != null && runtime.host().isVip();
        if (cacheRuntime != runtime || cacheVip != vip || cacheTtlMs == 0) {
            cache.clear(); cacheChars = 0; cacheRuntime = runtime; cacheVip = vip;
        }
        if (request == null) {
            deliver(subscriber, null, TranslationErrorMapper.invalidRequest(engineId)); return subscriber;
        }
        List<Object> key = key(request, runtime, vip);
        Cached cached = cache.get(key);
        if (cached != null && cacheAllowed && cacheTtlMs > 0
                && System.nanoTime() - cached.created < Math.min(cached.ttlNanos,
                        TimeUnit.MILLISECONDS.toNanos(cacheTtlMs))) {
            subscriber.source = "cache";
            deliver(subscriber, cached.result, null); return subscriber;
        }
        if (cached != null) {
            cache.remove(key);
            cacheChars -= cached.chars;
        }
        Operation operation = active.get(key);
        if (operation != null) subscriber.source = "merged";
        if (operation == null) {
            operation = new Operation(key, request, runtime, vip);
            active.put(key, operation);
        }
        subscriber.operation = operation;
        operation.listeners.add(subscriber);
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            int items = request instanceof BatchTranslationRequest
                    ? ((BatchTranslationRequest) request).getTexts().size() : 1;
            int chars = request instanceof BatchTranslationRequest
                    ? ((BatchTranslationRequest) request).getTexts().stream().mapToInt(String::length).sum()
                    : ((TranslationRequest) request).getText().length();
            ProviderAttemptTelemetry.debugLog("submit host=" + subscriber.diagnostic.hostRequestId
                    + " request=" + subscriber.id + " chain=" + operation.chainId
                    + " scene=" + subscriber.diagnostic.scenario + " engine=" + engineId
                    + " source=" + subscriber.source + " items=" + items + " chars=" + chars);
        }
        // Each subscriber has its own delivery gate. A merged caller shares the original chain deadline.
        if (operation.ticket == null) {
            Operation scheduled = operation;
            operation.timeout = TIMER.schedule(() -> deadlineReached(scheduled),
                    Math.max(0L, operation.deadline - System.nanoTime()), TimeUnit.NANOSECONDS);
            operation.ticket = dispatch.submit(() -> start(scheduled));
            if ((operation.done || operation.emergencyStarted) && operation.ticket != null) operation.ticket.finish();
            if (operation.ticket == null) complete(operation, null,
                    TranslationErrorMapper.fromInternalCode(TranslationErrorCode.RATE_LIMITED, engineId));
        }
        return subscriber;
    }

    private List<Object> key(Object request, TranslationRuntime runtime, boolean vip) {
        boolean batch = request instanceof BatchTranslationRequest;
        TranslationTimeoutPolicy.Settings settings = TranslationTimeoutPolicy.get();
        if (batch) {
            BatchTranslationRequest r = (BatchTranslationRequest) request;
            return Arrays.asList(runtime, vip, engineId, true, r.getSourceLanguageId(), r.getTargetLanguageId(),
                    r.getTexts(), settings, r.getMode());
        }
        TranslationRequest r = (TranslationRequest) request;
        return Arrays.asList(runtime, vip, engineId, false, r.getSourceLanguageId(), r.getTargetLanguageId(),
                Collections.singletonList(r.getText()), settings, r.getMode());
    }

    private void start(Operation operation) {
        try {
            synchronized (this) {
                if (operation.done || operation.emergencyStarted) return;
                operation.started = System.nanoTime();
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                    ProviderAttemptTelemetry.debugLog("chain_start chain=" + operation.chainId
                            + " engine=" + engineId + " queueMs="
                            + TimeUnit.NANOSECONDS.toMillis(operation.started - operation.created));
                }
                if (operation.runtime != TranslationRuntime.currentOrNull()) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.SDK_NOT_INITIALIZED, engineId)); return;
                }
                if (operation.runtime != null && operation.vip != operation.runtime.host().isVip()) {
                    complete(operation, null, TranslationErrorMapper.vipRequired(engineId)); return;
                }
                operation.translator = TranslationRuntime.callWithSnapshot(operation.runtime,
                        () -> factory.apply(operation.deadline));
                if (operation.translator == null) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.ENGINE_NOT_CONFIGURED, engineId)); return;
                }
            }
                TranslationCallback callback = new TranslationCallback() {
                    @Override public void onSuccess(TranslationResult result) {
                        completeOrdinary(operation, result, null);
                    }
                    @Override public void onError(TranslationError error) {
                        completeOrdinary(operation, null, error);
                    }
                };
                TranslationRuntime.withSnapshot(operation.runtime, () ->
                com.mg.translation.internal.base.http.RequestContext.withTrace(operation.chainId, () -> {
                    if (operation.request instanceof BatchTranslationRequest)
                        operation.translator.translate((BatchTranslationRequest) operation.request, callback);
                    else operation.translator.translate((TranslationRequest) operation.request, callback);
                }));
        } catch (RuntimeException error) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(TranslationErrorCode.UNKNOWN, engineId));
        }
    }

    private synchronized void completeOrdinary(Operation operation, TranslationResult result, TranslationError error) {
        if (operation.done || operation.emergencyStarted) return;
        if (error == null && !TranslationResultValidation.matches(operation.request, result)) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(
                    TranslationErrorCode.INVALID_PROVIDER_RESPONSE,
                    result == null ? lastAttemptedEngineId(operation) : result.getActualEngineId()));
            return;
        }
        if (error != null && error.getCode() == TranslationErrorCode.REQUEST_TIMEOUT) {
            deadlineReached(operation);
        } else if (error != null && error.getCode() == TranslationErrorCode.ALL_ENGINES_FAILED
                && hasEnabledRescueEngine(operation) && tryReserveFailureRescue(System.nanoTime())) {
            // Every ordinary engine is cooling down or failed (including after the transport
            // cooldown reset): the final rescue chain gets one try; its failure reports this 4004.
            startRescue(operation, error);
        } else {
            complete(operation, result, error);
        }
    }

    /** Moves a deadline-expired request to the independent final rescue chain. */
    private void deadlineReached(Operation operation) {
        startRescue(operation, null);
    }

    /**
     * Starts the independent final rescue chain. {@code failure} is the ordinary chain's 4004
     * when the rescue follows it (reported again if the rescue also fails), or null after a
     * deadline (a failed rescue then reports a timeout).
     */
    private void startRescue(Operation operation, TranslationError failure) {
        synchronized (this) {
            if (operation.done || operation.emergencyStarted) return;
            // An echo already seen on this chain is its answer; the rescue chain is not started.
            if (operation.translator instanceof SdkTranslatorAdapter
                    && ((SdkTranslatorAdapter) operation.translator).deliverPendingEcho()
                    && operation.done) return;
            operation.emergencyStarted = true;
            operation.rescueFailure = failure;
            if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                ProviderAttemptTelemetry.debugLog((failure == null ? "deadline_rescue" : "failure_rescue")
                        + " chain=" + operation.chainId
                        + " engine=" + engineId + " started=" + (operation.started != 0));
            }
            operation.emergencyDeadline = System.nanoTime()
                    + TimeUnit.MILLISECONDS.toNanos(EMERGENCY_BUDGET_MS);
            if (operation.translator != null) operation.translator.close();
            if (operation.ticket != null) operation.ticket.finish();
            operation.emergencyTimeout = TIMER.schedule(
                    () -> complete(operation, null, rescueExhausted(operation)),
                    EMERGENCY_BUDGET_MS, TimeUnit.MILLISECONDS);
            operation.emergencyTicket = EMERGENCY_DISPATCH.submit(() -> runEmergency(operation));
            if (operation.emergencyTicket == null) {
                complete(operation, null, operation.rescueFailure != null ? operation.rescueFailure
                        : TranslationErrorMapper.fromInternalCode(
                        TranslationErrorCode.RATE_LIMITED, lastAttemptedEngineId(operation)));
            } else if (operation.done) operation.emergencyTicket.finish();
        }
    }

    private void runEmergency(Operation operation) {
        runEmergencyAttempt(operation, 0);
    }

    private synchronized void runEmergencyAttempt(Operation operation, int index) {
        if (operation.done) return;
        if (operation.runtime != TranslationRuntime.currentOrNull()) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(
                    TranslationErrorCode.SDK_NOT_INITIALIZED, engineId));
            return;
        }
        if (index >= 2 || System.nanoTime() >= operation.emergencyDeadline) {
            complete(operation, null, rescueExhausted(operation));
            return;
        }
        int id = rescueEngineId(operation, index);
        if (id == com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE) {
            complete(operation, null, rescueExhausted(operation));
            return;
        }
        if (operation.rescueFailure != null) operation.rescueAttemptedEngines.add(id);
        int generation = ++operation.emergencyGeneration;
        long attemptDeadline = index == 0
                ? Math.min(operation.emergencyDeadline, System.nanoTime() + TimeUnit.SECONDS.toNanos(3))
                : operation.emergencyDeadline;
        try {
            Translator rescue = emergencyFactory == null ? null : TranslationRuntime.callWithSnapshot(operation.runtime,
                    () -> emergencyFactory.apply(id, attemptDeadline));
            if (rescue == null) {
                runEmergencyAttempt(operation, index + 1);
                return;
            }
            int previousEngine = operation.lastAttemptedEngineId > 0
                    ? operation.lastAttemptedEngineId : engineId;
            ProviderAttemptTelemetry.fallback(previousEngine, id, operation.chainId);
            operation.lastAttemptedEngineId = id;
            operation.emergencyTranslator = rescue;
            operation.attemptTimeout = TIMER.schedule(
                    () -> finishEmergencyAttempt(operation, generation, index, null),
                    Math.max(0L, attemptDeadline - System.nanoTime()), TimeUnit.NANOSECONDS);
            TranslationCallback callback = new TranslationCallback() {
                public void onSuccess(TranslationResult result) {
                    finishEmergencyAttempt(operation, generation, index, result);
                }
                public void onError(TranslationError error) {
                    finishEmergencyAttempt(operation, generation, index, null);
                }
            };
            TranslationRuntime.withSnapshot(operation.runtime, () ->
            com.mg.translation.internal.base.http.RequestContext.withTrace(operation.chainId,
                    () -> {
                if (operation.request instanceof BatchTranslationRequest)
                    rescue.translate((BatchTranslationRequest) operation.request, callback);
                else rescue.translate((TranslationRequest) operation.request, callback);
            }));
        } catch (RuntimeException error) {
            finishEmergencyAttempt(operation, generation, index, null);
        }
    }

    /** The engine the chain last tried: a rescue engine, else the ordinary chain's last attempt. */
    private int lastAttemptedEngineId(Operation operation) {
        if (operation.lastAttemptedEngineId > 0) return operation.lastAttemptedEngineId;
        Translator translator = operation.translator;
        return translator instanceof SdkTranslatorAdapter
                ? ((SdkTranslatorAdapter) translator).lastAttemptedEngineId() : engineId;
    }

    private synchronized void finishEmergencyAttempt(Operation operation, int generation,
                                                      int index, TranslationResult result) {
        if (operation.done || generation != operation.emergencyGeneration) return;
        ++operation.emergencyGeneration;
        if (operation.attemptTimeout != null) operation.attemptTimeout.cancel(false);
        Translator previous = operation.emergencyTranslator;
        operation.emergencyTranslator = null;
        if (previous != null) previous.close();
        if (result != null && !result.isUnaligned()
                && TranslationResultValidation.matches(operation.request, result)) {
            complete(operation, result, null);
        } else {
            EMERGENCY_EXECUTOR.execute(() -> runEmergencyAttempt(operation, index + 1));
        }
    }

    private synchronized void complete(Operation operation, TranslationResult result, TranslationError error) {
        if (operation.done) return;
        operation.done = true;
        if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
            ProviderAttemptTelemetry.debugLog("chain_complete chain=" + operation.chainId
                    + " engine=" + engineId + " actual="
                    + (result == null ? 0 : result.getActualEngineId())
                    + " outcome=" + resultOutcome(result, error)
                    + " missingIds=" + (result == null
                            ? Collections.emptyList() : result.getUntranslatedSourceIds())
                    + " error=" + (error == null ? 0 : error.getCode())
                    + " rescue=" + operation.emergencyStarted + " durationMs="
                    + TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - operation.created));
        }
        active.remove(operation.key, operation);
        if (operation.timeout != null) operation.timeout.cancel(false);
        if (operation.emergencyTimeout != null) operation.emergencyTimeout.cancel(false);
        if (operation.attemptTimeout != null) operation.attemptTimeout.cancel(false);
        if (operation.translator != null) operation.translator.close();
        if (operation.emergencyTranslator != null) operation.emergencyTranslator.close();
        if (operation.ticket != null) operation.ticket.finish();
        if (operation.emergencyTicket != null) operation.emergencyTicket.finish();
        // Ordinary fallbacks must not pin the selected engine. A successful 4004 rescue may
        // be reused only for the exact same request, within the rescue throttle interval: otherwise repeated
        // frames immediately hit the process-wide rescue throttle and report an avoidable 4004.
        boolean failureRescue = operation.emergencyStarted && operation.rescueFailure != null;
        if (result != null && result.getStatus() != TranslationResult.Status.UNALIGNED
                && !EchoGuard.isEcho(operation.request, result)
                && ((!operation.emergencyStarted && result.getActualEngineId() == engineId)
                    || failureRescue)
                && cacheAllowed && cacheTtlMs > 0
                && operation.runtime == TranslationRuntime.currentOrNull()
                && (operation.runtime == null || operation.vip == operation.runtime.host().isVip())) {
            putCache(operation.key, result, failureRescue);
        }
        for (Subscription subscriber : operation.listeners) deliver(subscriber, result, error);
        operation.listeners.clear();
    }

    private void putCache(List<Object> key, TranslationResult result, boolean failureRescue) {
        int chars = 0;
        for (Object item : (List<?>) key.get(6)) chars += ((String) item).length();
        for (String item : result.getTranslations()) chars += item.length();
        if (chars > MAX_CACHE_CHARS) return;
        Cached previous = cache.remove(key);
        if (previous != null) cacheChars -= previous.chars;
        long ttlMs = result.isPartial() ? Math.min(cacheTtlMs, PARTIAL_CACHE_TTL_MS)
                : failureRescue ? Math.min(cacheTtlMs, FAILURE_RESCUE_CACHE_TTL_MS) : cacheTtlMs;
        cache.put(key, new Cached(result, chars, ttlMs)); cacheChars += chars;
        Iterator<Cached> iterator = cache.values().iterator();
        while ((cache.size() > 64 || cacheChars > MAX_CACHE_CHARS) && iterator.hasNext()) {
            cacheChars -= iterator.next().chars; iterator.remove();
        }
    }

    private void deliver(Subscription subscriber, TranslationResult result, TranslationError error) {
        long ready = System.nanoTime();
        delivery.accept(() -> {
            synchronized (ManagedTranslator.this) {
                subscriptions.remove(subscriber);
                if (closed || subscriber.cancelled.get() || !subscriber.delivered.compareAndSet(false, true)) return;
            }
            TranslationError deliveredError = error;
            if (subscriber.runtime != TranslationRuntime.currentOrNull())
                deliveredError = TranslationErrorMapper.fromInternalCode(TranslationErrorCode.SDK_NOT_INITIALIZED, engineId);
            else if ((subscriber.operation == null || !subscriber.operation.emergencyStarted)
                    && subscriber.runtime != null && subscriber.vip != subscriber.runtime.host().isVip())
                deliveredError = TranslationErrorMapper.vipRequired(engineId);
            if (deliveredError != null && subscriber.operation != null
                    && requestMode(subscriber.operation.request) == TranslationMode.CONTINUOUS
                    && recoverableContinuousError(deliveredError))
                deliveredError = deliveredError.asNonInterrupting();
            // A completed result must not become a timeout merely because UI delivery was delayed.
            long now = System.nanoTime();
            Operation op = subscriber.operation;
            long queue = op == null ? 0 : Math.max(0L,
                    (op.started == 0 ? ready : op.started) - subscriber.created);
            if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                ProviderAttemptTelemetry.debugLog("done host=" + subscriber.diagnostic.hostRequestId
                        + " request=" + subscriber.id + " chain=" + (op == null ? 0 : op.chainId)
                        + " scene=" + subscriber.diagnostic.scenario + " engine=" + engineId
                        + " actual=" + (result == null ? 0 : result.getActualEngineId())
                        + " source=" + subscriber.source
                        + " outcome=" + resultOutcome(result, deliveredError)
                        + " error=" + (deliveredError == null ? 0 : deliveredError.getCode())
                        + " queueMs=" + TimeUnit.NANOSECONDS.toMillis(queue)
                        + " callbackWaitMs=" + TimeUnit.NANOSECONDS.toMillis(now - ready)
                        + " totalMs=" + TimeUnit.NANOSECONDS.toMillis(now - subscriber.created));
            }
            if (subscriber.host != null) {
                int reportedEngineId = result != null ? result.getActualEngineId()
                        : deliveredError != null ? deliveredError.getEngineId() : engineId;
                try { subscriber.host.onTranslationFinished(subscriber.id, op == null ? 0 : op.chainId, reportedEngineId,
                        resultOutcome(result, deliveredError), subscriber.source,
                        TimeUnit.NANOSECONDS.toMillis(queue), TimeUnit.NANOSECONDS.toMillis(now - ready),
                        TimeUnit.NANOSECONDS.toMillis(now - subscriber.created)); }
                catch (RuntimeException ignored) { }
            }
            try { if (deliveredError == null) subscriber.callback.onSuccess(result); else subscriber.callback.onError(deliveredError); }
            catch (RuntimeException ignored) { /* Host observers never trigger retries. */ }
        });
    }

    private static TranslationMode requestMode(Object request) {
        if (request instanceof BatchTranslationRequest)
            return ((BatchTranslationRequest) request).getMode();
        return request instanceof TranslationRequest
                ? ((TranslationRequest) request).getMode() : TranslationMode.STANDARD;
    }

    /** The failure a rescue reports when it produces nothing. */
    private TranslationError rescueExhausted(Operation operation) {
        return operation.rescueFailure != null ? operation.rescueFailure
                : TranslationErrorMapper.fromInternalCode(
                        TranslationErrorCode.REQUEST_TIMEOUT, lastAttemptedEngineId(operation));
    }

    private static int rescueEngineId(Operation operation, int index) {
        if (operation.rescueFailure == null) return emergencyEngineId(operation.request, index);
        for (int candidateIndex = 0; candidateIndex < 2; candidateIndex++) {
            int candidate = failureRescueEngineId(operation.request, candidateIndex);
            if (candidate == com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE) break;
            if (!operation.rescueAttemptedEngines.contains(candidate)) return candidate;
        }
        return com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
    }

    private boolean hasEnabledRescueEngine(Operation operation) {
        return emergencyFactory != null && operation.runtime == TranslationRuntime.currentOrNull()
                && failureRescueEngineId(operation.request, 0)
                != com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
    }

    /**
     * Rescue engines after a 4004, configured ones only so both attempts can be used: standard
     * requests try Baidu then Qwen, then this App's free non-AI engines; continuous requests use
     * the free non-AI engines. The free Google direct engines are never used: their 90 minute
     * block protects the device's IP address and is not lifted because every other engine is
     * unavailable. Rescue attempts bypass cooldown and membership, like the deadline rescue.
     */
    static int failureRescueEngineId(Object request, int index) {
        if (index < 0 || index >= 2) return com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
        boolean batch = request instanceof BatchTranslationRequest;
        List<Integer> candidates = new ArrayList<>();
        if (requestMode(request) != TranslationMode.CONTINUOUS) {
            for (com.mg.translation.engine.TranslatorId id : new com.mg.translation.engine.TranslatorId[] {
                    com.mg.translation.engine.TranslatorId.BAIDU, com.mg.translation.engine.TranslatorId.QWEN}) {
                if ((!batch || id.supportsBatch())
                        && com.mg.translation.sdk.TranslationSdk.isEngineEnabled(id.legacyCode)
                        && supportsRescueLanguages(request, id.legacyCode))
                    candidates.add(id.legacyCode);
            }
        }
        for (int candidate : com.mg.translation.utils.TranslateUtils.fallbackOrder()) {
            if (candidates.size() > index) break;
            com.mg.translation.engine.TranslatorId id =
                    com.mg.translation.engine.TranslatorId.fromLegacyCode(candidate);
            if (id == null || (batch && !id.supportsBatch()) || candidates.contains(candidate)
                    || id == com.mg.translation.engine.TranslatorId.GOOGLE
                    || id == com.mg.translation.engine.TranslatorId.GOOGLE_CLIENT) continue;
            if (com.mg.translation.sdk.TranslationSdk.isContinuousEngineAllowed(candidate)
                    && supportsRescueLanguages(request, candidate))
                candidates.add(candidate);
        }
        return candidates.size() > index ? candidates.get(index)
                : com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
    }

    /** Check the owning Translator's catalog before spending one of the two rescue attempts. */
    private static boolean supportsRescueLanguages(Object request, int engineId) {
        TranslationRuntime runtime = TranslationRuntime.snapshot();
        if (runtime == null || runtime != TranslationRuntime.currentOrNull()) return false;
        Integer dailyLimit = runtime.dailyLimit(engineId);
        // The documented Baidu/Qwen final-rescue exception intentionally bypasses their daily caps.
        if (engineId != 16 && engineId != 45 && dailyLimit != null
                && !DailyLimitTranslateControl.hasCapacity(runtime.context(), engineId, dailyLimit)) return false;
        String source;
        String target;
        if (request instanceof BatchTranslationRequest) {
            BatchTranslationRequest batch = (BatchTranslationRequest) request;
            source = batch.getSourceLanguageId(); target = batch.getTargetLanguageId();
        } else if (request instanceof TranslationRequest) {
            TranslationRequest single = (TranslationRequest) request;
            source = single.getSourceLanguageId(); target = single.getTargetLanguageId();
        } else return false;
        source = com.mg.translation.internal.text.LanguageIdentifier.routingSource(source, target);
        com.mg.translation.translate.base.TranslateControl control = null;
        try {
            control = com.mg.translation.utils.TranslateUtils.getTranslateByType(
                    engineId, source, target, runtime.context());
            return control != null;
        } catch (RuntimeException invalidCandidate) {
            return false;
        } finally {
            if (control != null) try { control.close(); } catch (RuntimeException ignored) { }
        }
    }

    static boolean tryReserveFailureRescue(long nowNanos) {
        long interval = TimeUnit.MILLISECONDS.toNanos(FAILURE_RESCUE_INTERVAL_MS);
        while (true) {
            long last = LAST_FAILURE_RESCUE_NANOS.get();
            if (last != NEVER && nowNanos - last < interval) return false;
            if (LAST_FAILURE_RESCUE_NANOS.compareAndSet(last, nowNanos)) return true;
        }
    }

    /** Test hook: forget the last 4004 rescue. */
    static void resetFailureRescueForTest() { LAST_FAILURE_RESCUE_NANOS.set(NEVER); }

    /** Rescue keeps its two-attempt bound and never constructs an AI/VIP control for continuous work. */
    static int emergencyEngineId(Object request, int index) {
        if (index < 0 || index >= 2)
            return com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
        if (requestMode(request) != TranslationMode.CONTINUOUS)
            return index == 0 ? com.mg.translation.engine.TranslatorId.BAIDU.legacyCode
                    : com.mg.translation.engine.TranslatorId.QWEN.legacyCode;
        int eligible = 0;
        boolean batch = request instanceof BatchTranslationRequest;
        for (int candidate : com.mg.translation.utils.TranslateUtils.fallbackOrder()) {
            com.mg.translation.engine.TranslatorId id =
                    com.mg.translation.engine.TranslatorId.fromLegacyCode(candidate);
            if (id == null || (batch && !id.supportsBatch())) continue;
            if (com.mg.translation.sdk.TranslationSdk.isContinuousEngineAllowed(candidate)
                    && eligible++ == index) return candidate;
        }
        return com.mg.translation.sdk.EngineSelectionResult.NO_ENGINE;
    }

    static boolean recoverableContinuousError(TranslationError error) {
        switch (error.getCode()) {
            case TranslationErrorCode.NETWORK_UNAVAILABLE:
            case TranslationErrorCode.REQUEST_TIMEOUT:
            case TranslationErrorCode.RATE_LIMITED:
            case TranslationErrorCode.PROVIDER_UNAVAILABLE:
            case TranslationErrorCode.INVALID_PROVIDER_RESPONSE:
            case TranslationErrorCode.ALL_ENGINES_FAILED:
                return true;
            default:
                return false;
        }
    }

    private static String resultOutcome(TranslationResult result, TranslationError error) {
        if (error != null || result == null) return "error";
        if (result.isUnaligned()) return "unaligned";
        return result.isPartial() ? "partial" : "success";
    }

    @Override public synchronized void clearResultCache() { cache.clear(); cacheChars = 0; }
    @Override public synchronized void close() {
        closed = true;
        for (Subscription subscriber : new ArrayList<>(subscriptions)) subscriber.cancel();
        clearResultCache();
    }

    private final class Subscription implements TranslationCall {
        final long id = NEXT_REQUEST.incrementAndGet();
        final long created = System.nanoTime();
        final long deadline = created + TimeUnit.MILLISECONDS.toNanos(budgetMs());
        final TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        final TranslationHost host = runtime == null ? null : runtime.host();
        final TranslationDiagnosticContext.State diagnostic = TranslationDiagnosticContext.snapshot();
        final boolean vip = host != null && host.isVip();
        String source = "network";
        final TranslationCallback callback;
        final AtomicBoolean cancelled = new AtomicBoolean();
        final AtomicBoolean delivered = new AtomicBoolean();
        Operation operation;
        Subscription(TranslationCallback callback) { this.callback = callback; }
        @Override public boolean isCancelled() { return cancelled.get(); }
        @Override public void cancel() {
            synchronized (ManagedTranslator.this) {
                if (!cancelled.compareAndSet(false, true)) return;
                if (ProviderAttemptTelemetry.isDebugLoggingEnabled()) {
                    ProviderAttemptTelemetry.debugLog("cancel host=" + diagnostic.hostRequestId
                            + " request=" + id + " chain="
                            + (operation == null ? 0 : operation.chainId)
                            + " scene=" + diagnostic.scenario + " engine=" + engineId);
                }
                subscriptions.remove(this);
                if (operation != null && !operation.done) {
                    operation.listeners.remove(this);
                    if (operation.listeners.isEmpty()) complete(operation, null,
                            TranslationErrorMapper.fromInternalCode(TranslationErrorCode.CANCELLED, engineId));
                }
            }
        }
    }

    private final class Operation {
        final long chainId = NEXT_CHAIN.incrementAndGet();
        final long created = System.nanoTime();
        final List<Object> key;
        final Object request;
        final TranslationRuntime runtime;
        final boolean vip;
        final long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(operationBudgetMs());
        final List<Subscription> listeners = new ArrayList<>();
        Translator translator;
        TranslationDispatchQueue.Ticket ticket;
        TranslationDispatchQueue.Ticket emergencyTicket;
        ScheduledFuture<?> timeout;
        ScheduledFuture<?> emergencyTimeout;
        boolean emergencyStarted;
        final Set<Integer> rescueAttemptedEngines = new HashSet<>();
        TranslationError rescueFailure;
        long emergencyDeadline;
        int emergencyGeneration;
        int lastAttemptedEngineId;
        ScheduledFuture<?> attemptTimeout;
        Translator emergencyTranslator;
        boolean done;
        long started;
        Operation(List<Object> key, Object request, TranslationRuntime runtime, boolean vip) {
            this.key = key; this.request = request; this.runtime = runtime; this.vip = vip;
        }
    }
    private static final class Cached {
        final TranslationResult result;
        final int chars;
        final long ttlNanos;
        final long created = System.nanoTime();
        Cached(TranslationResult result, int chars, long ttlMs) {
            this.result = result;
            this.chars = chars;
            this.ttlNanos = TimeUnit.MILLISECONDS.toNanos(ttlMs);
        }
    }

    private long budgetMs() { return testBudgetMs > 0 ? testBudgetMs : TranslationTimeoutPolicy.get().requestBudgetMs; }
    private long operationBudgetMs() {
        long configured = budgetMs();
        if (testBudgetMs > 0) return configured;
        com.mg.translation.engine.TranslatorId id =
                com.mg.translation.engine.TranslatorId.fromLegacyCode(engineId);
        boolean selfHosted = id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_GOOGLE
                || id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_YOUDAO
                || id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_DEEPL
                || id == com.mg.translation.engine.TranslatorId.SELF_HOSTED_YANDEX
                || id == com.mg.translation.engine.TranslatorId.BD;
        return configured + (selfHosted ? SELF_HOSTED_COMPLETION_GRACE_MS : 0L);
    }
}
