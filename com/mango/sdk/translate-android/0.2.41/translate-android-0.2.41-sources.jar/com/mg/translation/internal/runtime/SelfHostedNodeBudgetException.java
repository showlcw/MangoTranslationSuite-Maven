package com.mg.translation.internal.runtime;

/** The node exhausted this request's budget; it does not establish global Provider health. */
public final class SelfHostedNodeBudgetException extends java.io.InterruptedIOException {
    public SelfHostedNodeBudgetException() { super("self-hosted node request budget exhausted"); }
    public SelfHostedNodeBudgetException(Throwable cause) { this(); initCause(cause); }
}
