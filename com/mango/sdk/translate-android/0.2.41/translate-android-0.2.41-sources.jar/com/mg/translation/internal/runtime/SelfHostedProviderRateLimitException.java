package com.mg.translation.internal.runtime;

import java.io.IOException;
import retrofit2.HttpException;

/** Preserves a gateway-reported Provider rate limit while retaining the actual HTTP status. */
final class SelfHostedProviderRateLimitException extends IOException {
    SelfHostedProviderRateLimitException(HttpException cause) {
        super("Self-hosted Provider rate limited", cause);
    }
}
