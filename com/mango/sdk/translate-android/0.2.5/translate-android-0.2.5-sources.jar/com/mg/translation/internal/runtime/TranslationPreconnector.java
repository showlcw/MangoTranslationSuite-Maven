package com.mg.translation.internal.runtime;

import com.mg.translation.engine.EngineCategory;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.http.RetrofitServiceManager;

/** Resolves one configured Provider origin and warms only the SDK-owned transport. */
public final class TranslationPreconnector {
    private TranslationPreconnector() { }

    public static boolean preconnect(TranslatorId engine) {
        TranslationRuntime runtime = TranslationRuntime.get();
        if (!NetworkUtils.isConnectedAvailableNetwork(runtime.context())) return false;
        String baseUrl = baseUrl(runtime, engine);
        if (baseUrl == null) return false;
        try {
            return RetrofitServiceManager.getInstance().preconnect(
                    baseUrl, engine.category == EngineCategory.AI, engine.legacyCode);
        } catch (RuntimeException invalidEndpointOrSchedule) {
            return false;
        }
    }

    private static String baseUrl(TranslationRuntime runtime, TranslatorId engine) {
        switch (engine) {
            case BAIDU: return TranslateRepository.BAIDU_URL;
            case GOOGLE: return TranslateRepository.GOOGLE_TRANSLATE_URL;
            case GOOGLE_CLIENT: return TranslateRepository.GOOGLE_TRANSLATE_CLIENT_URL;
            case GOOGLE_V: return TranslateRepository.GOOGLE_TRANSLATE_VIP_URL;
            case MICROSOFT:
            case MICROSOFT_VIP: return TranslateRepository.MICROSOFT_TRANSLATE_URL;
            case MYMEMORY: return TranslateRepository.MEMORY_TRANSLATE_URL;
            case YOUDAO: return TranslateRepository.YOUDAO_TRANSLATE_URL;
            case RAPID_AI: return TranslateRepository.AI_TRANSLATE_URL;
            case RAPID_DEEP: return TranslateRepository.DEEP_TRANSLATE_URL;
            case RAPID_PLUS: return TranslateRepository.PLUS_TRANSLATE_URL;
            case RAPID_WEBSITE_PLUS: return TranslateRepository.WEBSITE_PLUS_TRANSLATE_URL;
            case RAPID_MULTI: return TranslateRepository.MULTI_TRANSLATE_URL;
            case RAPID_IRCTCAPI: return TranslateRepository.IRCTCAPI_TRANSLATE_URL;
            case DEEPSEEK:
                return runtime.peekProviderBaseUrl(
                        engine.legacyCode, TranslateRepository.DEEPSEEK_TRANSLATE_URL);
            case QWEN:
            case ZHIPU_FLASH:
            case HY_MT2:
            case GPT_4O_MINI:
            case GEMMA:
            case GEMINI:
            case BD:
            case SELF_HOSTED_GOOGLE:
            case SELF_HOSTED_YOUDAO:
                return runtime.peekProviderBaseUrl(engine.legacyCode, null);
            default: return null;
        }
    }
}
