package com.mg.translation.http;


import com.mg.translation.internal.base.http.RetrofitServiceManager;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.http.translate.ai.AiTranslateService;
import com.mg.translation.http.translate.baidu.BaiduTranslateService;
import com.mg.translation.http.translate.deep.DeepTranslateService;
import com.mg.translation.http.translate.google.GoogleClientTranslateService;
import com.mg.translation.http.translate.google.GoogleTranslateService;
import com.mg.translation.http.translate.google.GoogleVipTranslateService;
import com.mg.translation.http.translate.irctcapi.IrctcapiTranslateService;
import com.mg.translation.http.translate.me.MeTranslateService;
import com.mg.translation.http.translate.memory.MemoryTranslateService;
import com.mg.translation.http.translate.microsoft.MicrosoftTranslateService;
import com.mg.translation.http.translate.multi.MultiTranslateService;
import com.mg.translation.http.translate.plus.PlusTranslateService;
import com.mg.translation.http.translate.websiteplus.WebSitePlusTranslateService;
import com.mg.translation.http.translate.youdao.YoudaoService;

public final class ApiServiceCenter {
    // 使用 volatile 保证多线程可见性
    private static volatile ApiServiceCenter mInstance = null;
    /**
     * 双重检查锁定单例模式（线程安全）
     */
    public static ApiServiceCenter getInstance() {
        if (mInstance == null) {
            synchronized (ApiServiceCenter.class) {
                if (mInstance == null) {
                    mInstance = new ApiServiceCenter();
                }
            }
        }
        return mInstance;
    }

    private ApiServiceCenter() { }


    public IrctcapiTranslateService getIrctcapiTranslateService() {
        return IrctcapiHolder.INSTANCE;
    }

    public WebSitePlusTranslateService getWebSitePlusTranslateService() {
        return WebsitePlusHolder.INSTANCE;
    }
    public MemoryTranslateService getMemoryTranslateService() {
        return MemoryHolder.INSTANCE;
    }

    public GoogleTranslateService getGoogleTranslateService() {
        return GoogleHolder.INSTANCE;
    }


    public MeTranslateService getMeTranslateService() {
        return MeHolder.INSTANCE;
    }


    public GoogleClientTranslateService getGoogleClientTranslateService() {
        return GoogleClientHolder.INSTANCE;
    }

    public YoudaoService getYoudaoTranslateService() {
        return YoudaoHolder.INSTANCE;
    }

    public BaiduTranslateService getBaiduTranslateService() {
        return BaiduHolder.INSTANCE;
    }

    public GoogleVipTranslateService getGoogleVipTranslateService() {
        return GoogleVipHolder.INSTANCE;
    }

    public DeepTranslateService getDeepTranslateService() {
        return DeepHolder.INSTANCE;
    }


    public MicrosoftTranslateService getMicrosoftTranslateService() {
        return MicrosoftHolder.INSTANCE;
    }

    public AiTranslateService getAiTranslateService() {
        return AiHolder.INSTANCE;
    }


    public MultiTranslateService getMultiTranslateService() {
        return MultiHolder.INSTANCE;
    }

    public PlusTranslateService getPlusTranslateService() {
        return PlusHolder.INSTANCE;
    }

    private static final class GoogleHolder {
        static final GoogleTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createString(TranslateRepository.GOOGLE_TRANSLATE_URL,
                        GoogleTranslateService.class);
    }
    private static final class GoogleClientHolder {
        static final GoogleClientTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createString(TranslateRepository.GOOGLE_TRANSLATE_CLIENT_URL,
                        GoogleClientTranslateService.class);
    }
    private static final class MeHolder {
        static final MeTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.ME_TRANSLATE_URL, MeTranslateService.class);
    }
    private static final class YoudaoHolder {
        static final YoudaoService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.YOUDAO_TRANSLATE_URL, YoudaoService.class);
    }
    private static final class BaiduHolder {
        static final BaiduTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.BAIDU_URL, BaiduTranslateService.class);
    }
    private static final class GoogleVipHolder {
        static final GoogleVipTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.GOOGLE_TRANSLATE_VIP_URL,
                        GoogleVipTranslateService.class);
    }
    private static final class DeepHolder {
        static final DeepTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.DEEP_TRANSLATE_URL, DeepTranslateService.class);
    }
    private static final class MicrosoftHolder {
        static final MicrosoftTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.MICROSOFT_TRANSLATE_URL,
                        MicrosoftTranslateService.class);
    }
    private static final class AiHolder {
        static final AiTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.AI_TRANSLATE_URL, AiTranslateService.class);
    }
    private static final class PlusHolder {
        static final PlusTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.PLUS_TRANSLATE_URL, PlusTranslateService.class);
    }
    private static final class MemoryHolder {
        static final MemoryTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.MEMORY_TRANSLATE_URL,
                        MemoryTranslateService.class);
    }
    private static final class WebsitePlusHolder {
        static final WebSitePlusTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.WEBSITE_PLUS_TRANSLATE_URL,
                        WebSitePlusTranslateService.class);
    }
    private static final class MultiHolder {
        static final MultiTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.MULTI_TRANSLATE_URL, MultiTranslateService.class);
    }
    private static final class IrctcapiHolder {
        static final IrctcapiTranslateService INSTANCE = RetrofitServiceManager.getInstance()
                .createTranslate(TranslateRepository.IRCTCAPI_TRANSLATE_URL,
                        IrctcapiTranslateService.class);
    }


}
