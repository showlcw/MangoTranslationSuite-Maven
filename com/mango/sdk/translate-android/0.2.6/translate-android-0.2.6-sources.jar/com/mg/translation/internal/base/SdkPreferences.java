package com.mg.translation.internal.base;

import android.content.Context;
import android.content.SharedPreferences;

/** SDK-private Provider cooldown and request-gate persistence. */
public final class SdkPreferences {
    private static volatile SdkPreferences instance;
    private final SharedPreferences preferences;

    private SdkPreferences(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(
                "mango_translation_sdk", Context.MODE_PRIVATE);
    }

    public static SdkPreferences getInstance(Context context) {
        if (instance == null) {
            synchronized (SdkPreferences.class) {
                if (instance == null) instance = new SdkPreferences(context);
            }
        }
        return instance;
    }

    public long getLong(String key, long fallback) { return preferences.getLong(key, fallback); }
    public void put(String key, long value) {
        preferences.edit().putLong(key, value).remove(cooldownKey(key)).apply();
    }

    public void putCooldown(String key, long startedAtMs, long durationMs) {
        preferences.edit().putLong(key, startedAtMs)
                .putLong(cooldownKey(key), durationMs).apply();
    }

    public long getCooldown(String key, long fallbackMs) {
        return preferences.getLong(cooldownKey(key), fallbackMs);
    }

    private String cooldownKey(String key) { return key + "_COOLDOWN_MS"; }

    /** Atomically reserves one request attempt for an engine on the supplied local epoch day. */
    public synchronized boolean tryAcquireDailyRequest(int engineId, int limit, long epochDay) {
        String prefix = "DAILY_ENGINE_" + engineId;
        String dayKey = prefix + "_DAY";
        String countKey = prefix + "_COUNT";
        long storedDay = preferences.getLong(dayKey, Long.MIN_VALUE);
        long count = storedDay == epochDay ? preferences.getLong(countKey, 0L) : 0L;
        if (count >= limit) return false;
        return preferences.edit()
                .putLong(dayKey, epochDay)
                .putLong(countKey, count + 1L)
                .commit();
    }
}
