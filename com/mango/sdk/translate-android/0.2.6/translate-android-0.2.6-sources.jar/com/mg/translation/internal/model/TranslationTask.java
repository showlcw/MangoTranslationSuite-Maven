package com.mg.translation.internal.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/** SDK-internal mutable state for one translation and its fallback attempts. */
public class TranslationTask {
    public static final long TOTAL_REQUEST_BUDGET_MS = 30_000L;
    private final long requestBudgetMs = com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().requestBudgetMs;

    private final long startedNanos = System.nanoTime();
    private String content;
    private String sourceLanguageId;
    private String targetLanguageId;
    private List<Integer> attemptedEngineIds;
    private String translatedText;
    private boolean freeOnlyForRequest;

    public TranslationTask() {
    }

    public TranslationTask(String content, String sourceLanguageId, String targetLanguageId) {
        this.content = content;
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }

    public TranslationTask(String sourceLanguageId, String targetLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }


    public String getTranslatedText() {
        return translatedText;
    }

    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceLanguageId() {
        return sourceLanguageId;
    }

    public void setSourceLanguageId(String sourceLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
    }

    public String getTargetLanguageId() {
        return targetLanguageId;
    }

    public void setTargetLanguageId(String targetLanguageId) {
        this.targetLanguageId = targetLanguageId;
    }

    public List<Integer> getAttemptedEngineIds() {
        return attemptedEngineIds == null ? Collections.emptyList()
                : Collections.unmodifiableList(attemptedEngineIds);
    }

    public void setAttemptedEngineIds(List<Integer> attemptedEngineIds) {
        this.attemptedEngineIds = attemptedEngineIds == null ? new ArrayList<>()
                : new ArrayList<>(attemptedEngineIds);
    }

    public boolean isFreeOnlyForRequest() { return freeOnlyForRequest; }
    public void requireFreeEngines() { freeOnlyForRequest = true; }

    public long remainingBudgetMs() {
        long elapsedNanos = Math.max(0L, System.nanoTime() - startedNanos);
        long elapsedMs = elapsedNanos / 1_000_000L;
        return Math.max(0L, requestBudgetMs - elapsedMs);
    }

    public boolean hasBudgetFor(long requestTimeoutMs) {
        return requestTimeoutMs > 0L && remainingBudgetMs() >= requestTimeoutMs;
    }

}
