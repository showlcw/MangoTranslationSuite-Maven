package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.model.BatchTranslationTask;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.utils.TranslateUtils;

import java.util.ArrayList;
import java.util.List;

/** Rechecks live membership and routes non-VIP paid requests exclusively to free engines. */
public final class NonVipFallbackTranslateControl implements TranslateControl {
    private final Context context;
    private final TranslateControl requested;

    public NonVipFallbackTranslateControl(Context context, TranslateControl requested) {
        this.context = context.getApplicationContext();
        this.requested = requested;
    }

    @Override public void translate(TranslationTask task, TranslateListener listener) {
        if (task == null || listener == null) return;
        if (!task.isFreeOnlyForRequest() && TranslationRuntime.get().host().isVip()) {
            requested.translate(task, listener);
            return;
        }
        List<Integer> attempted = new ArrayList<>(task.getAttemptedEngineIds());
        if (!attempted.contains(getTranslateType())) attempted.add(getTranslateType());
        task.setAttemptedEngineIds(attempted);
        TranslateControl free = TranslateUtils.getCanTranslateType(
                context, task, task instanceof BatchTranslationTask);
        if (free != null) {
            free.translate(task, listener);
            return;
        }
        listener.onFail(TranslationErrorCode.ALL_ENGINES_FAILED,
                context.getString(R.string.translation_error_all_engines_failed));
    }

    @Override public BaseReq createBaseReq(String content, String source, String target) {
        return requested.createBaseReq(content, source, target);
    }
    @Override public List<LanguageVO> getSupportLanguage() { return requested.getSupportLanguage(); }
    @Override public int getIndexByLanguage(String country, boolean useDefault) {
        return requested.getIndexByLanguage(country, useDefault);
    }
    @Override public LanguageVO getSelectLanguageVO(String country, boolean useDefault) {
        return requested.getSelectLanguageVO(country, useDefault);
    }
    @Override public String getTranslateTypeName() { return requested.getTranslateTypeName(); }
    @Override public int getTranslateType() { return requested.getTranslateType(); }
    @Override public boolean isSupportAuto() { return requested.isSupportAuto(); }
    @Override public void close() { requested.close(); }
}
