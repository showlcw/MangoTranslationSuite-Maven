package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.TranslationHost;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;

import retrofit2.HttpException;

/** Metadata-only timing for every Provider attempt. */
public final class ProviderAttemptTelemetry {
    private ProviderAttemptTelemetry() { }

    public static void report(int engineId, String outcome,
                              long startedNanos, int httpStatus) {
        reportDuration(engineId, outcome, elapsedMs(startedNanos), httpStatus);
    }

    public static long elapsedMs(long startedNanos) {
        return Math.max(0L, System.nanoTime() - startedNanos) / 1_000_000L;
    }

    public static void reportDuration(int engineId, String outcome,
                                      long durationMs, int httpStatus) {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null) return;
        TranslationHost host = runtime.host();
        try {
            host.onProviderAttemptFinished(
                    engineId, outcome, Math.max(0L, durationMs), httpStatus);
        } catch (RuntimeException ignored) {
            // Host telemetry must never delay or break translation.
        }
    }

    public static String outcome(Throwable failure, boolean cancelled) {
        if (cancelled) return "cancelled";
        if (findHttpException(failure) != null) return "http_error";
        Throwable cause = rootCause(failure);
        if (cause instanceof SocketTimeoutException
                || cause instanceof InterruptedIOException) return "timeout";
        if (cause instanceof IOException) return "network_error";
        return "error";
    }

    public static int httpStatus(Throwable failure) {
        HttpException http = findHttpException(failure);
        return http == null ? 0 : http.code();
    }

    private static Throwable rootCause(Throwable failure) {
        Throwable current = failure;
        while (current != null && current.getCause() != null
                && current.getCause() != current) current = current.getCause();
        return current;
    }

    private static HttpException findHttpException(Throwable failure) {
        Throwable current = failure;
        while (current != null) {
            if (current instanceof HttpException) return (HttpException) current;
            if (current.getCause() == current) return null;
            current = current.getCause();
        }
        return null;
    }
}
