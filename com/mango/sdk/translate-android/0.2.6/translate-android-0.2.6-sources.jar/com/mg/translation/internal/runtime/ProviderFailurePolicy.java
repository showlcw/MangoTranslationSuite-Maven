package com.mg.translation.internal.runtime;

import android.content.Context;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.SdkPreferences;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;

import retrofit2.HttpException;

/** Classifies Provider failures so one transient network event cannot cause a long cooldown. */
public final class ProviderFailurePolicy {
    static final long TRANSIENT_NETWORK_COOLDOWN_MS = 5_000L;
    static final long SERVER_COOLDOWN_MS = 15_000L;
    static final long DEFAULT_RATE_LIMIT_COOLDOWN_MS = 30_000L;

    private ProviderFailurePolicy() { }

    public static void record(Context context, String stateKey,
                              TranslatorId engine, Throwable failure) {
        if (context == null || stateKey == null || engine == null
                || !NetworkUtils.isConnectedAvailableNetwork(context)) return;
        long cooldownMs = cooldownMs(failure, engine.defaultCooldownMs);
        if (cooldownMs <= 0L) return;
        SdkPreferences.getInstance(context).putCooldown(
                stateKey, System.currentTimeMillis(), cooldownMs);
    }

    static long cooldownMs(Throwable failure, long configuredCooldownMs) {
        Throwable cause = rootCause(failure);
        HttpException http = findHttpException(failure);
        if (http != null) {
            int status = http.code();
            if (status == 401 || status == 403) return configuredCooldownMs;
            if (status == 429) return retryAfterMs(http, configuredCooldownMs);
            if (status == 408 || status >= 500) {
                return Math.min(configuredCooldownMs, SERVER_COOLDOWN_MS);
            }
            return configuredCooldownMs;
        }
        if (cause instanceof SSLHandshakeException
                || cause instanceof SSLPeerUnverifiedException) {
            return configuredCooldownMs;
        }
        if (cause instanceof SocketTimeoutException
                || cause instanceof InterruptedIOException
                || cause instanceof UnknownHostException
                || cause instanceof ConnectException
                || cause instanceof NoRouteToHostException
                || cause instanceof IOException) {
            return Math.min(configuredCooldownMs, TRANSIENT_NETWORK_COOLDOWN_MS);
        }
        return Math.min(configuredCooldownMs, SERVER_COOLDOWN_MS);
    }

    private static long retryAfterMs(HttpException failure, long maximumMs) {
        String value = failure.response() == null ? null
                : failure.response().headers().get("Retry-After");
        if (value != null) {
            try {
                long seconds = Long.parseLong(value.trim());
                if (seconds > 0L) {
                    long millis = seconds > Long.MAX_VALUE / 1_000L
                            ? Long.MAX_VALUE : seconds * 1_000L;
                    return Math.min(maximumMs, millis);
                }
            } catch (NumberFormatException ignored) {
                // HTTP-date Retry-After values use the bounded default below.
            }
        }
        return Math.min(maximumMs, DEFAULT_RATE_LIMIT_COOLDOWN_MS);
    }

    private static Throwable rootCause(Throwable failure) {
        Throwable current = failure;
        while (current != null && current.getCause() != null
                && current.getCause() != current) current = current.getCause();
        return current;
    }

    private static HttpException findHttpException(Throwable failure) {
        Throwable current = failure;
        while (current != null) {
            if (current instanceof HttpException) return (HttpException) current;
            if (current.getCause() == current) return null;
            current = current.getCause();
        }
        return null;
    }
}
