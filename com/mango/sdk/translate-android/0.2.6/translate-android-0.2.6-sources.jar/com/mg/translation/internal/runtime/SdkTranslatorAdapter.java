package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.Translator;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.Collections;

public final class SdkTranslatorAdapter implements Translator {
    private final TranslateControl delegate;

    public SdkTranslatorAdapter(TranslateControl delegate) {
        if (delegate == null) throw new IllegalArgumentException("delegate is required");
        this.delegate = delegate;
    }

    @Override
    public int getEngineId() {
        return delegate.getTranslateType();
    }

    @Override
    public void translate(TranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (rejectRestrictedAccess(callback)) return;
        TranslationTask task = new TranslationTask(request.getText(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        applyMembershipPolicy(task);
        delegate.translate(task, callback(callback));
    }

    @Override
    public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (rejectRestrictedAccess(callback)) return;
        BatchTranslationTask task = new BatchTranslationTask(request.getTexts(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        applyMembershipPolicy(task);
        delegate.translate(task, callback(callback));
    }

    private TranslateListener callback(TranslationCallback callback) {
        return new TranslateListener() {
            @Override
            public void onSuccess(TranslationTask result, int actualEngineId, boolean isList) {
                if (result instanceof BatchTranslationTask) {
                    callback.onSuccess(new TranslationResult(
                            ((BatchTranslationTask) result).getTranslations(), actualEngineId, true));
                } else {
                    callback.onSuccess(new TranslationResult(
                            Collections.singletonList(result.getTranslatedText()), actualEngineId,
                            false));
                }
            }

            @Override
            public void onFail(int code, String message) {
                callback.onError(TranslationErrorMapper.fromInternalCode(
                        code, delegate.getTranslateType()));
            }
        };
    }

    private void applyMembershipPolicy(TranslationTask task) {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null || !runtime.host().isVip()) task.requireFreeEngines();
    }

    private boolean rejectRestrictedAccess(TranslationCallback callback) {
        int engineId = delegate.getTranslateType();
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (!(delegate instanceof NonVipFallbackTranslateControl)
                && com.mg.translation.sdk.TranslationSdk.isVipOnly(engineId)
                && (runtime == null || !runtime.host().isVip())) {
            callback.onError(TranslationErrorMapper.vipRequired(engineId));
            return true;
        }
        return false;
    }

    @Override
    public void close() {
        delegate.close();
    }
}
