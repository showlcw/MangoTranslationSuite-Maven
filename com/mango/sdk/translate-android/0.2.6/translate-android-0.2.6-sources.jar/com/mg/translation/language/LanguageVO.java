package com.mg.translation.language;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import java.util.Objects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by lion on 2016/10/28.
 * 语言简写配置，目前的几种语言使用的是google翻译的标准
 */
public class LanguageVO implements Cloneable {

    private String value;
    private int country;
    private String key;
    private int ocrFlag = -1;
    private String topTitle;

    private String sourceLanguageIdName;

    private int languageCountry;//国家
    private String languageKey;//语言
    private transient boolean frozen;

    public LanguageVO(String topTitle) {
        this.topTitle = topTitle;
    }

    public LanguageVO(String key, int country, String value) {
        this.value = value;
        this.country = country;
        this.key = key;
    }

    public LanguageVO(String key, int country, String value, String languageKey, int languageCountry) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.languageKey = languageKey;
        this.languageCountry = languageCountry;
    }
    public LanguageVO(String key, int country, String value, int ocrFlag) {
        this.value = value;
        this.country = country;
        this.key = key;
        this.ocrFlag = ocrFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LanguageVO)) return false;
        LanguageVO that = (LanguageVO) o;
        return key != null && Objects.equals(key, that.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }

    public int getLanguageCountry() {
        return languageCountry;
    }

    public String getLanguageKey() {
        return languageKey;
    }

    public void setLanguageKey(String languageKey) {
        requireMutable();
        this.languageKey = languageKey;
    }

    public String getSourceLanguageIdName() {
        return sourceLanguageIdName;
    }

    public void setSourceLanguageIdName(String sourceLanguageIdName) {
        requireMutable();
        this.sourceLanguageIdName = sourceLanguageIdName;
    }

    public String getTopTitle() {
        return topTitle;
    }

    public int getOcrFlag() {
        return ocrFlag;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        requireMutable();
        this.value = value;
    }

    public int getCountry() {
        return country;
    }

    public String getKey() {
        return key;
    }

    @NonNull
    @Override
    public LanguageVO clone() throws CloneNotSupportedException {
        LanguageVO copy = (LanguageVO) super.clone();
        copy.frozen = false;
        return copy;
    }

    /** Freezes engine-owned entries before they are shared across Translator instances. */
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    public static List<LanguageVO> immutableList(List<LanguageVO> source) {
        if (source == null || source.isEmpty()) return Collections.emptyList();
        List<LanguageVO> copy = new ArrayList<>(source);
        for (LanguageVO language : copy) {
            if (language != null) language.frozen = true;
        }
        return Collections.unmodifiableList(copy);
    }

    private void requireMutable() {
        if (frozen) throw new UnsupportedOperationException("engine language entries are read-only");
    }
}
