package com.mg.translation.translate.ai.chatgpt;

import android.content.Context;

import com.mango.sdk.translation.R;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.ai.common.OpenAiCompatibleTranslateControl;

import java.util.ArrayList;
import java.util.List;

/** Independent ChatGPT translation engine, including its owned language IDs and Provider codes. */
public final class ChatGptTranslate extends OpenAiCompatibleTranslateControl {
    private static final List<LanguageVO> LANGUAGES = createLanguages();

    public ChatGptTranslate(Context context) {
        super(context, TranslatorId.GPT_4O_MINI, "ChatGPT", null,
                PromptPlacement.SYSTEM, LANGUAGES);
    }

    private static List<LanguageVO> createLanguages() {
        List<LanguageVO> languages = new ArrayList<>();
        languages.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        languages.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian,
                "sq"));
        languages.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic,
                "am"));
        languages.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic,
                "ar"));
        languages.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian,
                "hy"));
        languages.add(new LanguageVO(LanguageConstant.ASSAMESE, R.string.language_Assamese,
                "as"));
        languages.add(new LanguageVO(LanguageConstant.AYMARA, R.string.language_Aymara,
                "ay"));
        languages.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani,
                "az"));
        languages.add(new LanguageVO(LanguageConstant.BAMBARA, R.string.language_Bambara,
                "bm"));
        languages.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque,
                "eu"));
        languages.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian,
                "be"));
        languages.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali,
                "bn"));
        languages.add(new LanguageVO(LanguageConstant.BHOJPURI, R.string.language_Bhojpuri,
                "bho"));
        languages.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian,
                "bs"));
        languages.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian,
                "bg"));
        languages.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan,
                "ca"));
        languages.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano,
                "ceb"));
        languages.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese,
                "zh-CN"));
        languages.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE,
                R.string.language_Traditional_Chinese,
                "zh-TW"));
        languages.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican,
                "co"));
        languages.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian,
                "hr"));
        languages.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech,
                "cs"));
        languages.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish,
                "da"));
        languages.add(new LanguageVO(LanguageConstant.DHIVEHI, R.string.language_Dhivehi,
                "dv"));
        languages.add(new LanguageVO(LanguageConstant.DOGRI, R.string.language_Dogri,
                "doi"));
        languages.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch,
                "nl"));
        languages.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English,
                "en"));
        languages.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto,
                "eo"));
        languages.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian,
                "et"));
        languages.add(new LanguageVO(LanguageConstant.EWE, R.string.language_Ewe,
                "ee"));
        languages.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino,
                "fil"));
        languages.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish,
                "fi"));
        languages.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French,
                "fr"));
        languages.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian,
                "fy"));
        languages.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician,
                "gl"));
        languages.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian,
                "ka"));
        languages.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German,
                "de"));
        languages.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek,
                "el"));
        languages.add(new LanguageVO(LanguageConstant.GUARANI, R.string.language_Guarani,
                "gn"));
        languages.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati,
                "gu"));
        languages.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian,
                "ht"));
        languages.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa,
                "ha"));
        languages.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian,
                "haw"));
        languages.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew,
                "he"));
        languages.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi,
                "hi"));
        languages.add(new LanguageVO(LanguageConstant.HMONG, R.string.language_Hmong,
                "hmn"));
        languages.add(new LanguageVO(LanguageConstant.HUNGARIAN,
                R.string.language_Hungarian,
                "hu"));
        languages.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic,
                "is"));
        languages.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo,
                "ig"));
        languages.add(new LanguageVO(LanguageConstant.ILOCANO, R.string.language_Ilocano,
                "ilo"));
        languages.add(new LanguageVO(LanguageConstant.INDONESIAN,
                R.string.language_Indonesian,
                "id"));
        languages.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish,
                "ga"));
        languages.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian,
                "it"));
        languages.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese
                , "ja"));
        languages.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese,
                "jv"));
        languages.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada,
                "kn"));
        languages.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh,
                "kk"));
        languages.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer,
                "km"));
        languages.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda,
                "rw"));
        languages.add(new LanguageVO(LanguageConstant.KONKANI, R.string.language_Konkani,
                "gom"));
        languages.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean,
                "ko"));
        languages.add(new LanguageVO(LanguageConstant.KRIO, R.string.language_Krio,
                "kri"));
        languages.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish,
                "ku"));
        languages.add(new LanguageVO(LanguageConstant.SORANI, R.string.language_Sorani,
                "ckb"));
        languages.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz,
                "ky"));
        languages.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao,
                "lo"));
        languages.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin,
                "la"));
        languages.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian,
                "lv"));
        languages.add(new LanguageVO(LanguageConstant.LINGALA, R.string.language_Lingala,
                "ln"));
        languages.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian,
                "lt"));
        languages.add(new LanguageVO(LanguageConstant.LUGANDA, R.string.language_Luganda,
                "lg"));
        languages.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish,
                "lb"));
        languages.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian,
                "mk"));
        languages.add(new LanguageVO(LanguageConstant.MAITHILI, R.string.language_Maithili,
                "mai"));
        languages.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy,
                "mg"));
        languages.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay,
                "ms"));
        languages.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam,
                "ml"));
        languages.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese,
                "mt"));
        languages.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori,
                "mi"));
        languages.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi,
                "mr"));
        languages.add(new LanguageVO(LanguageConstant.MEITEILON, R.string.language_Meiteilon,
                "mni-Mtei"));
        languages.add(new LanguageVO(LanguageConstant.MIZO, R.string.language_Mizo,
                "lus"));
        languages.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian,
                "mn"));
        languages.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese,
                "my"));
        languages.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali,
                "ne"));
        languages.add(new LanguageVO(LanguageConstant.NORWEGIAN,
                R.string.language_Norwegian,
                "no"));
        languages.add(new LanguageVO(LanguageConstant.CHICHEWA, R.string.language_Chichewa,
                "ny"));
        languages.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya,
                "or"));
        languages.add(new LanguageVO(LanguageConstant.OROMO, R.string.language_Oromo,
                "om"));
        languages.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto,
                "ps"));
        languages.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian,
                "fa"));
        languages.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish,
                "pl"));
        languages.add(new LanguageVO(LanguageConstant.PORTUGUESE,
                R.string.language_Portuguese, "pt"));
        languages.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));
        languages.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi,
                "pa"));
        languages.add(new LanguageVO(LanguageConstant.QUECHUA, R.string.language_Quechua,
                "qu"));
        languages.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian,
                "ro"));
        languages.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian,
                "ru"));
        languages.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan,
                "sm"));
        languages.add(new LanguageVO(LanguageConstant.SANSKRIT, R.string.language_Sanskrit,
                "sa"));
        languages.add(new LanguageVO(LanguageConstant.GAELIC, R.string.language_Gaelic,
                "gd"));
        languages.add(new LanguageVO(LanguageConstant.SEPEDI, R.string.language_Sepedi,
                "nso"));
        languages.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian,
                "sr"));
        languages.add(new LanguageVO(LanguageConstant.SOUTHERN_SOTHO, R.string.language_Southern_Sotho,
                "st"));
        languages.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona,
                "sn"));
        languages.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi,
                "sd"));
        languages.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala,
                "si"));
        languages.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak,
                "sk"));
        languages.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian,
                "sl"));
        languages.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali,
                "so"));
        languages.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish,
                "es"));
        languages.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese,
                "su"));
        languages.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili,
                "sw"));
        languages.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish,
                "sv"));
        languages.add(new LanguageVO(LanguageConstant.TAGALOG, R.string.language_Tagalog,
                "tl"));
        languages.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik,
                "tg"));
        languages.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil,
                "ta"));
        languages.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar,
                "tt"));
        languages.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu,
                "te"));
        languages.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai,
                "th"));
        languages.add(new LanguageVO(LanguageConstant.TIGRINYA, R.string.language_Tigrinya,
                "ti"));
        languages.add(new LanguageVO(LanguageConstant.TSONGA, R.string.language_Tsonga,
                "ts"));
        languages.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish,
                "tr"));
        languages.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen,
                "tk"));
        languages.add(new LanguageVO(LanguageConstant.AKAN, R.string.language_Akan,
                "ak"));
        languages.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian,
                "uk"));
        languages.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu,
                "ur"));
        languages.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur,
                "ug"));
        languages.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek,
                "uz"));
        languages.add(new LanguageVO(LanguageConstant.VIETNAMESE,
                R.string.language_Vietnamese,
                "vi"));
        languages.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh,
                "cy"));
        languages.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa,
                "xh"));
        languages.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish,
                "yi"));
        languages.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba,
                "yo"));
        languages.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu,
                "zu"));
        return LanguageVO.immutableList(languages);
    }
}
