package com.mg.translation.translate.base;

import com.mg.translation.engine.TranslatorId;
import com.mg.translation.engine.EngineCategory;
import com.mg.translation.internal.runtime.EntitlementCheckingTranslateControl;
import com.mg.translation.internal.runtime.DailyLimitTranslateControl;
import com.mg.translation.internal.runtime.TranslationRuntime;


import android.content.Context;

import com.mg.translation.translate.baidu.BaiduTranslate;
import com.mg.translation.translate.baidu.BdTranslate;
import com.mg.translation.translate.ai.chatgpt.ChatGptTranslate;
import com.mg.translation.translate.ai.deepseek.DeepSeekTranslate;
import com.mg.translation.translate.ai.gemma.GemmaTranslate;
import com.mg.translation.translate.ai.gemini.GeminiTranslate;
import com.mg.translation.translate.ai.hunyuan.HunyuanTranslate;
import com.mg.translation.translate.ai.qwen.QwenTranslate;
import com.mg.translation.translate.ai.zhipu.ZhipuFlashTranslate;
import com.mg.translation.translate.google.GoogleClientTranslate;
import com.mg.translation.translate.google.GoogleTranslate;
import com.mg.translation.translate.google.GoogleVTranslate;
import com.mg.translation.translate.microsoft.MicrosoftTranslate;
import com.mg.translation.translate.microsoft.MicrosoftVipTranslate;
import com.mg.translation.translate.mymemory.MyMemoryTranslate;
import com.mg.translation.translate.rapid.RapidAiTranslate;
import com.mg.translation.translate.rapid.RapidApiDeepTranslate;
import com.mg.translation.translate.rapid.RapidApiIrctcapiTranslate;
import com.mg.translation.translate.rapid.RapidApiPlusTranslate;
import com.mg.translation.translate.rapid.RapidMultiTranslate;
import com.mg.translation.translate.rapid.WebSitePlusTranslate;
import com.mg.translation.translate.selfhosted.SelfHostedGoogleTranslate;
import com.mg.translation.translate.youdao.YoudaoTranslate;

/**
 * @author LiChunWei
 * @description:
 * @date :2021/5/6 18:27
 */
public final class TranslateFactory {
    private TranslateFactory() { }

    public static TranslateControl createTranslate(Context context, int type) {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        TranslatorId translatorId = TranslatorId.fromLegacyCode(type);
        if (runtime == null
                || translatorId == null
                || translatorId.isRetired()
                || !runtime.configStore().isEngineEnabled(type)) {
            return new GoogleClientTranslate(context);
        }
        TranslateControl control;
        switch (translatorId) {
            case BAIDU: control = new BaiduTranslate(context); break;
            case GOOGLE: control = new GoogleTranslate(context); break;
            case SELF_HOSTED_GOOGLE: control = new SelfHostedGoogleTranslate(context); break;
            case SELF_HOSTED_YOUDAO: control = new com.mg.translation.translate.selfhosted.SelfHostedYoudaoTranslate(context); break;
            case MICROSOFT: control = new MicrosoftTranslate(context); break;
            case MICROSOFT_VIP: control = new MicrosoftVipTranslate(context); break;
            case RAPID_DEEP: control = new RapidApiDeepTranslate(context); break;
            case BD: control = new BdTranslate(context); break;
            case RAPID_AI: control = new RapidAiTranslate(context); break;
            case RAPID_PLUS: control = new RapidApiPlusTranslate(context); break;
            case GOOGLE_CLIENT: control = new GoogleClientTranslate(context); break;
            case GOOGLE_V: control = new GoogleVTranslate(context); break;
            case YOUDAO: control = new YoudaoTranslate(context); break;
            case MYMEMORY: control = new MyMemoryTranslate(context); break;
            case RAPID_WEBSITE_PLUS: control = new WebSitePlusTranslate(context); break;
            case RAPID_MULTI: control = new RapidMultiTranslate(context); break;
            case RAPID_IRCTCAPI: control = new RapidApiIrctcapiTranslate(context); break;
            case DEEPSEEK: control = new DeepSeekTranslate(context); break;
            case HY_MT2: control = new HunyuanTranslate(context); break;
            case GPT_4O_MINI: control = new ChatGptTranslate(context); break;
            case GEMMA: control = new GemmaTranslate(context); break;
            case GEMINI: control = new GeminiTranslate(context); break;
            case ZHIPU_FLASH: control = new ZhipuFlashTranslate(context); break;
            case QWEN: control = new QwenTranslate(context); break;
            default: return new GoogleClientTranslate(context);
        }
        Integer dailyLimit = runtime.dailyLimit(type);
        if (dailyLimit != null) {
            control = new DailyLimitTranslateControl(context, control, type, dailyLimit);
        }
        // AI Translators enforce the backend vip flag in their own concrete request path.
        // Avoid hiding their engine-owned implementation behind a duplicate entitlement wrapper.
        boolean accessControlled = runtime.configStore().isVipOnly(type)
                && translatorId.category != EngineCategory.AI;
        return accessControlled
                ? new EntitlementCheckingTranslateControl(control, translatorId)
                : control;
    }

}
