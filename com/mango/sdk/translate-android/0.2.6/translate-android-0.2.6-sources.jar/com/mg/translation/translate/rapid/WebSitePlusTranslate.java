package com.mg.translation.translate.rapid;

import com.mg.translation.engine.TranslatorId;



import android.content.Context;
import android.text.TextUtils;

import com.mg.translation.internal.base.http.req.BaseReq;
import com.mango.sdk.translation.R;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateReq;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusBatchTranslateResult;
import com.mg.translation.http.translate.websiteplus.dto.WebsitePlusTranslateReq;
import com.mg.translation.http.translate.TranslateRepository;
import com.mg.translation.language.LanguageConstant;
import com.mg.translation.language.LanguageVO;
import com.mg.translation.translate.base.BaseTranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.ArrayList;
import java.util.List;


/**
 * @author LiChunWei
 * @description: Translo  翻译  1秒
 * @date :2021/5/7 10:15
 */
public class WebSitePlusTranslate extends BaseTranslateControl {
    private final Context mContext;
    private static final Object LANGUAGE_LOCK = new Object();
    private static volatile List<LanguageVO> languageCache;
    private List<LanguageVO> mDestLanguageList;

    public WebSitePlusTranslate(Context context) {
        mContext = context;
    }

    @Override
    public void translate(TranslationTask task, TranslateListener translateListener) {
        if (translateListener == null || task == null) {
            return;
        }

        if (task instanceof BatchTranslationTask) {//是列表翻译
            BatchTranslationTask batchTask = (BatchTranslationTask) task;
            translateListApi(batchTask, translateListener);
            return;
        }
        //文本翻译
        translateContent(task, translateListener);
    }

    /** 批量翻译使用 WebsitePlus 自己的请求和响应协议。 */
    public synchronized void translateListApi(BatchTranslationTask batchTask,
                                              TranslateListener translateListener) {
        BaseReq batchReq = createBatchRequest(batchTask.getSourceTexts(),
                batchTask.getSourceLanguageId(), batchTask.getTargetLanguageId());
        if (batchReq == null) {//目标语言不支持,不发无效请求直接降级
            dealTranslateError(mContext, batchTask, translateListener);
            return;
        }
        executeRequest(TranslateRepository.getInstance().webSitePlusBatchTranslate(mContext, batchReq),
                result -> handleBatchResult(batchTask, result, translateListener));
    }

    public void translateContent(TranslationTask task, TranslateListener translateListener) {
        if (TextUtils.isEmpty(task.getContent())) {
            translateListener.onSuccess(task, getTranslateType(), false);
            return;
        }

        executeRequest(TranslateRepository.getInstance().webSitePlusTranslate(mContext, createBaseReq(task.getContent(), task.getSourceLanguageId(), task.getTargetLanguageId())), plusTranslateResult -> {
            if (plusTranslateResult == null || plusTranslateResult.getCode() != 0 || plusTranslateResult.getTranslations() == null) {
                dealTranslateError(mContext, task, translateListener);
                return;
            }
            task.setTranslatedText(plusTranslateResult.getTranslations().getTranslation());
            translateListener.onSuccess(task, getTranslateType(), false);
        });
    }

    /**
     * 获取支持的语音
     */
    @Override
    public List<LanguageVO> getSupportLanguage() {
        List<LanguageVO> cached = languageCache;
        if (cached == null) {
            synchronized (LANGUAGE_LOCK) {
                cached = languageCache;
                if (cached == null) {
                    initLanguage();
                    cached = LanguageVO.immutableList(mDestLanguageList);
                    languageCache = cached;
                }
            }
        }
        return cached;
    }

    @Override
    public void close() {
        super.close();
    }

    private void initLanguage() {
        mDestLanguageList = new ArrayList<>();
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AFRIKAANS, R.string.language_Afrikaans, "af"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ALBANIAN, R.string.language_Albanian, "sq"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AMHARIC, R.string.language_Amharic, "am"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARABIC, R.string.language_Arabic, "ar"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ARMENIAN, R.string.language_Armenian, "hy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.AZERBAIJANI, R.string.language_Azerbaijani, "az"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BASQUE, R.string.language_Basque, "eu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BELARUSIAN, R.string.language_Belarusian, "be"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BENGALI, R.string.language_Bengali, "bn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BOSNIAN, R.string.language_Bosnian, "bs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.BULGARIAN, R.string.language_Bulgarian, "bg"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.CATALAN, R.string.language_Catalan, "ca"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CEBUANO, R.string.language_Cebuano, "ceb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CHINESE, R.string.language_Chinese, "zh-CN"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TRADITIONAL_CHINESE, R.string.language_Traditional_Chinese, "zh-TW"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CORSICAN, R.string.language_Corsican, "co"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CROATIAN, R.string.language_Croatian, "hr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.CZECH, R.string.language_Czech, "cs"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DANISH, R.string.language_Danish, "da"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.DUTCH, R.string.language_Dutch, "nl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ENGLISH, R.string.language_English, "en"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESPERANTO, R.string.language_Esperanto, "eo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ESTONIAN, R.string.language_Estonian, "et"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.FINNISH, R.string.language_Finnish, "fi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRENCH, R.string.language_French, "fr"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.FRISIAN, R.string.language_Frisian, "fy"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.GALICIAN, R.string.language_Galician, "gl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.GEORGIAN, R.string.language_Georgian, "ka"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.GERMAN, R.string.language_German, "de"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.GREEK, R.string.language_Greek, "el"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.GUJARATI, R.string.language_Gujarati, "gu"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAITIAN, R.string.language_Haitian, "ht"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAUSA, R.string.language_Hausa, "ha"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.HAWAIIAN, R.string.language_Hawaiian, "haw"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.HEBREW, R.string.language_Hebrew, "iw"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.HINDI, R.string.language_Hindi, "hi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.HUNGARIAN, R.string.language_Hungarian, "hu"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ICELANDIC, R.string.language_Icelandic, "is"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.IGBO, R.string.language_Igbo, "ig"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.INDONESIAN, R.string.language_Indonesian, "id"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.IRISH, R.string.language_Irish, "ga"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ITALIAN, R.string.language_Italian, "it"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAPANESE, R.string.language_Japanese, "ja"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.JAVANESE, R.string.language_Javanese, "jv"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KANNADA, R.string.language_Kannada, "kn"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KAZAKH, R.string.language_Kazakh, "kk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KHMER, R.string.language_Khmer, "km"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KINYARWANDA, R.string.language_Kinyarwanda, "rw"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KOREAN, R.string.language_Korean, "ko"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.KURDISH, R.string.language_Kurdish, "ku"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.KYRGYZ, R.string.language_Kyrgyz, "ky"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LAO, R.string.language_Lao, "lo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATIN, R.string.language_Latin, "la"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.LATVIAN, R.string.language_Latvian, "lv"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.LITHUANIAN, R.string.language_Lithuanian, "lt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.LUXEMBOURGISH, R.string.language_Luxembourgish, "lb"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MACEDONIAN, R.string.language_Macedonian, "mk"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAGASY, R.string.language_Malagasy, "mg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAY, R.string.language_Malay, "ms"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALAYALAM, R.string.language_Malayalam, "ml"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MALTESE, R.string.language_Maltese, "mt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MAORI, R.string.language_Maori, "mi"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.MARATHI, R.string.language_Marathi, "mr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.MONGOLIAN, R.string.language_Mongolian, "mn"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.BURMESE, R.string.language_Burmese, "my"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.NEPALI, R.string.language_Nepali, "ne"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.NORWEGIAN, R.string.language_Norwegian, "no"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.NYANJA, R.string.language_Nyanja, "ny"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ORIYA, R.string.language_Oriya, "or"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.PASHTO, R.string.language_Pashto, "ps"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.PERSIAN, R.string.language_Persian, "fa"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.POLISH, R.string.language_Polish, "pl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE, R.string.language_Portuguese, "pt"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.PORTUGUESE_BR, R.string.language_Portuguese,
                "pt", LanguageConstant.PORTUGUESE_BR, R.string.country_Brazil));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.PUNJABI, R.string.language_Punjabi, "pa"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.ROMANIAN, R.string.language_Romanian, "ro"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.RUSSIAN, R.string.language_Russian, "ru"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.SAMOAN, R.string.language_Samoan, "sm"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SCOTS, R.string.language_Scots, "gd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SERBIAN, R.string.language_Serbian, "sr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SHONA, R.string.language_Shona, "sn"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINDHI, R.string.language_Sindhi, "sd"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SINHALA, R.string.language_Sinhala, "si"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVAK, R.string.language_Slovak, "sk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SLOVENIAN, R.string.language_Slovenian, "sl"));


        mDestLanguageList.add(new LanguageVO(LanguageConstant.SOMALI, R.string.language_Somali, "so"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SPANISH, R.string.language_Spanish, "es"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SUNDANESE, R.string.language_Sundanese, "su"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWAHILI, R.string.language_Swahili, "sw"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.SWEDISH, R.string.language_Swedish, "sv"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.FILIPINO, R.string.language_Filipino, "tl"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAJIK, R.string.language_Tajik, "tg"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TAMIL, R.string.language_Tamil, "ta"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TATAR, R.string.language_Tatar, "tt"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.TELUGU, R.string.language_Telugu, "te"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.THAI, R.string.language_Thai, "th"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKISH, R.string.language_Turkish, "tr"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.TURKMEN, R.string.language_Turkmen, "tk"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UKRAINIAN, R.string.language_Ukrainian, "uk"));

        mDestLanguageList.add(new LanguageVO(LanguageConstant.URDU, R.string.language_Urdu, "ur"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UYGHUR, R.string.language_Uyghur, "ug"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.UZBEK, R.string.language_Uzbek, "uz"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.VIETNAMESE, R.string.language_Vietnamese, "vi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.WELSH, R.string.language_Welsh, "cy"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.XHOSA, R.string.language_Xhosa, "xh"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YIDDISH, R.string.language_Yiddish, "yi"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.YORUBA, R.string.language_Yoruba, "yo"));
        mDestLanguageList.add(new LanguageVO(LanguageConstant.ZULU, R.string.language_Zulu, "zu"));
    }

    @Override
    public String getTranslateTypeName() {
        return mContext.getString(R.string.translate_type_google);
    }

    @Override
    public BaseReq createBaseReq(String content, String sourceCountry, String toCountry) {

        WebsitePlusTranslateReq googleTranslateReq = new WebsitePlusTranslateReq();
        LanguageVO sourcelanguageVO = getSelectLanguageVO(sourceCountry, false);
        if (sourcelanguageVO != null) {
            googleTranslateReq.setSource(sourcelanguageVO.getValue());
        }
        LanguageVO tolanguageVO = getSelectLanguageVO(toCountry, false);
        if (tolanguageVO != null) {
            googleTranslateReq.setTarget(tolanguageVO.getValue());
        }
        googleTranslateReq.setText(content);
        return googleTranslateReq;
    }

    private BaseReq createBatchRequest(List<String> sourceTexts, String sourceCountry,
                                       String targetCountry) {
        LanguageVO target = getSelectLanguageVO(targetCountry, false);
        if (target == null) {
            return null;
        }
        WebsitePlusBatchTranslateReq request = new WebsitePlusBatchTranslateReq();
        request.setTarget(target.getValue());
        LanguageVO source = getSelectLanguageVO(sourceCountry, false);
        if (source != null) {
            request.setSource(source.getValue());
        }
        request.setTexts(new ArrayList<>(sourceTexts));
        return request;
    }

    private void handleBatchResult(BatchTranslationTask task,
                                   WebsitePlusBatchTranslateResult result,
                                   TranslateListener listener) {
        if (result == null || result.getLocalErrorCode() != 0
                || result.getTranslations() == null
                || result.getTranslations().size() != task.getSourceTexts().size()) {
            dealTranslateError(mContext, task, listener);
            return;
        }
        for (WebsitePlusBatchTranslateResult.TranslationItem item : result.getTranslations()) {
            if (!item.isSuccess()) {
                dealTranslateError(mContext, task, listener);
                return;
            }
        }
        for (int i = 0; i < result.getTranslations().size(); i++) {
            task.setTranslation(i, result.getTranslations().get(i).getTranslation());
        }
        listener.onSuccess(task, getTranslateType(), true);
    }

    @Override
    public int getTranslateType() {
        return TranslatorId.RAPID_WEBSITE_PLUS.legacyCode;
    }
}
