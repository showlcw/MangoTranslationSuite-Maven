package com.mg.translation.http.translate.plus;

import static com.mg.translation.utils.TranslationPreferenceKeys.PLUS_TRANSLATE_STATE;

import android.content.Context;

import com.mg.translation.http.ApiServiceCenter;
import com.mg.translation.http.translate.plus.dto.PlusBatchTranslateResult;
import com.mg.translation.http.translate.plus.dto.PlusTranslateResult;
import com.mg.translation.internal.base.GsonUtil;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.req.BaseReq;
import com.mg.translation.internal.runtime.TranslationRuntime;
import com.mg.translation.sdk.TranslationErrorCode;

import io.reactivex.Single;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/** Owns the RapidAPI Translate Plus wire protocol and failure cooldown. */
public final class RapidPlusGateway {
    private static final String RAPID_API_HOST = "translate-plus.p.rapidapi.com";
    private static final RapidPlusGateway INSTANCE = new RapidPlusGateway();

    private RapidPlusGateway() { }

    public static RapidPlusGateway getInstance() {
        return INSTANCE;
    }

    public Single<PlusBatchTranslateResult> translateBatch(Context context, BaseReq request) {
        return ApiServiceCenter.getInstance().getPlusTranslateService()
                .plusBatchTranslate(RAPID_API_HOST, TranslationRuntime.get().plusRapidKey(),
                        "application/json", jsonBody(request))
                .doOnError(error -> com.mg.translation.internal.runtime.ProviderFailurePolicy.recordAttemptFailure(
                        com.mg.translation.engine.TranslatorId.RAPID_PLUS.legacyCode, error))
                .onErrorReturn(error -> batchError(context));
    }

    public Single<PlusTranslateResult> translate(Context context, BaseReq request) {
        return ApiServiceCenter.getInstance().getPlusTranslateService()
                .plusTranslate(RAPID_API_HOST, TranslationRuntime.get().plusRapidKey(),
                        "application/json", jsonBody(request))
                .doOnError(error -> com.mg.translation.internal.runtime.ProviderFailurePolicy.recordAttemptFailure(
                        com.mg.translation.engine.TranslatorId.RAPID_PLUS.legacyCode, error))
                .onErrorReturn(error -> singleError(context));
    }

    private RequestBody jsonBody(BaseReq request) {
        return RequestBody.create(MediaType.parse("application/json"), GsonUtil.toJson(request));
    }

    private PlusBatchTranslateResult batchError(Context context) {
        PlusBatchTranslateResult result = new PlusBatchTranslateResult();
        if (!NetworkUtils.isConnectedAvailableNetwork(context)) {
            result.setLocalErrorCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
        } else {
            result.setLocalErrorCode(TranslationErrorCode.UNKNOWN);
            markFailure(context);
        }
        return result;
    }

    private PlusTranslateResult singleError(Context context) {
        PlusTranslateResult result = new PlusTranslateResult();
        if (!NetworkUtils.isConnectedAvailableNetwork(context)) {
            result.setCode(TranslationErrorCode.NETWORK_UNAVAILABLE);
        } else {
            result.setCode(TranslationErrorCode.UNKNOWN);
            markFailure(context);
        }
        return result;
    }

    private void markFailure(Context context) {
        SdkPreferences.getInstance(context).put(PLUS_TRANSLATE_STATE, System.currentTimeMillis());
    }
}
