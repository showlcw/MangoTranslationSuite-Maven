package com.mg.translation.internal.base;

import android.content.Context;
import android.content.SharedPreferences;

/** SDK-private Provider cooldown and request-gate persistence. */
public final class SdkPreferences {
    private static volatile SdkPreferences instance;
    private final SharedPreferences preferences;

    private SdkPreferences(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(
                "mango_translation_sdk", Context.MODE_PRIVATE);
    }

    public static SdkPreferences getInstance(Context context) {
        if (instance == null) {
            synchronized (SdkPreferences.class) {
                if (instance == null) instance = new SdkPreferences(context);
            }
        }
        return instance;
    }

    public long getLong(String key, long fallback) { return preferences.getLong(key, fallback); }
    public synchronized void put(String key, long value) {
        preferences.edit().putLong(key, value).remove(cooldownKey(key)).apply();
    }

    public synchronized void putCooldown(String key, long startedAtMs, long durationMs) {
        preferences.edit().putLong(key, startedAtMs)
                .putLong(cooldownKey(key), durationMs).apply();
    }

    /** A late shorter failure must not shorten an already active block. */
    public synchronized void putCooldownAtLeast(String key, long startedAtMs, long durationMs) {
        long previous = preferences.getLong(key, 0L);
        long previousDuration = preferences.getLong(cooldownKey(key), 0L);
        if (previous > 0L && previous <= startedAtMs
                && previousDuration - (startedAtMs - previous) >= durationMs) return;
        putCooldown(key, startedAtMs, durationMs);
    }

    public long getCooldown(String key, long fallbackMs) {
        return preferences.getLong(cooldownKey(key), fallbackMs);
    }

    /** Read/expiry cleanup and failure writes share one lock; a new cooldown cannot be erased. */
    public synchronized boolean isCooldownReady(String key, long fallbackMs, long nowMs) {
        return isCooldownReady(key, fallbackMs, nowMs, 0L);
    }

    public synchronized boolean isCooldownReady(String key, long fallbackMs, long nowMs, long minimumMs) {
        long startedAt = preferences.getLong(key, 0L);
        if (startedAt == 0L) return true;
        long storedDurationMs = preferences.getLong(cooldownKey(key), fallbackMs);
        long durationMs = Math.max(minimumMs, storedDurationMs);
        if (durationMs != storedDurationMs) putCooldown(key, startedAt, durationMs);
        if (startedAt > nowMs) {
            // Preserve the failure-specific duration when repairing a backwards wall clock.
            putCooldown(key, nowMs, durationMs);
            return false;
        }
        if (nowMs - startedAt >= durationMs) {
            put(key, 0L);
            return true;
        }
        return false;
    }

    private String cooldownKey(String key) { return key + "_COOLDOWN_MS"; }

    /** Atomically reserves one request attempt for an engine on the supplied local epoch day. */
    public synchronized boolean tryAcquireDailyRequest(int engineId, int limit, long epochDay) {
        String prefix = "DAILY_ENGINE_" + engineId;
        String dayKey = prefix + "_DAY";
        String countKey = prefix + "_COUNT";
        long storedDay = preferences.getLong(dayKey, Long.MIN_VALUE);
        long count = storedDay == epochDay ? preferences.getLong(countKey, 0L) : 0L;
        if (count >= limit) return false;
        return preferences.edit()
                .putLong(dayKey, epochDay)
                .putLong(countKey, count + 1L)
                .commit();
    }
}
