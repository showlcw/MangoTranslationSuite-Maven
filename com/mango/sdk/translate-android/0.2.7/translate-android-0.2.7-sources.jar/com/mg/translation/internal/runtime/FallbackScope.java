package com.mg.translation.internal.runtime;

import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** Owns dynamically created fallback controllers, including their nested fallback scopes. */
public final class FallbackScope implements AutoCloseable {
    private final AtomicBoolean closed = new AtomicBoolean();
    private final Set<Entry> active = ConcurrentHashMap.newKeySet();

    public boolean isClosed() { return closed.get(); }

    public void execute(TranslateControl control, TranslationTask task, TranslateListener listener) {
        Entry entry = new Entry(control);
        active.add(entry);
        if (closed.get()) { release(entry); return; }
        try {
            control.translate(task, new TranslateListener() {
                @Override public void onSuccess(TranslationTask result, int id, boolean batch) {
                    if (!entry.terminal.compareAndSet(false, true)) return;
                    try { if (!closed.get()) listener.onSuccess(result, id, batch); }
                    finally { release(entry); }
                }
                @Override public void onFail(int code, String message) {
                    if (!entry.terminal.compareAndSet(false, true)) return;
                    try { if (!closed.get()) listener.onFail(code, message); }
                    finally { release(entry); }
                }
            });
        } catch (RuntimeException failure) {
            entry.terminal.set(true);
            release(entry);
            throw failure;
        }
    }

    private void release(Entry entry) {
        active.remove(entry);
        if (entry.released.compareAndSet(false, true)) entry.control.close();
    }

    @Override public void close() {
        closed.set(true);
        for (Entry entry : active) {
            entry.terminal.set(true);
            release(entry);
        }
    }

    private static final class Entry {
        final TranslateControl control;
        final AtomicBoolean terminal = new AtomicBoolean();
        final AtomicBoolean released = new AtomicBoolean();
        Entry(TranslateControl control) { this.control = control; }
    }
}
