package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.TranslationHost;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;

import retrofit2.HttpException;

/** Metadata-only timing for every Provider attempt. */
public final class ProviderAttemptTelemetry {
    private static volatile boolean debugLogging;
    private ProviderAttemptTelemetry() { }

    public static void setDebugLogging(boolean enabled) { debugLogging = enabled; }

    private static void log(String message) {
        if (debugLogging) android.util.Log.d("MangoTranslation", message);
    }

    public static void skipped(int engineId, String reason) {
        log("engine_skipped engine=" + engineId + " reason=" + reason);
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null) return;
        try { runtime.host().onEngineSkipped(engineId, reason); }
        catch (RuntimeException ignored) { }
    }

    public static void fallback(int fromEngineId, int toEngineId) {
        log("fallback_to from=" + fromEngineId + " to=" + toEngineId);
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null) return;
        try { runtime.host().onFallback(fromEngineId, toEngineId); }
        catch (RuntimeException ignored) { }
    }

    public static void report(int engineId, String outcome,
                              long startedNanos, int httpStatus) {
        reportDuration(engineId, outcome, elapsedMs(startedNanos), httpStatus);
    }

    public static long elapsedMs(long startedNanos) {
        return Math.max(0L, System.nanoTime() - startedNanos) / 1_000_000L;
    }

    public static void reportDuration(int engineId, String outcome,
                                      long durationMs, int httpStatus) {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null) return;
        log("provider_attempt engine=" + engineId + " outcome=" + outcome
                + " durationMs=" + Math.max(0L, durationMs) + " httpStatus=" + httpStatus);
        TranslationHost host = runtime.host();
        try {
            host.onProviderAttemptFinished(
                    engineId, outcome, Math.max(0L, durationMs), httpStatus);
        } catch (RuntimeException ignored) {
            // Host telemetry must never delay or break translation.
        }
    }

    public static String outcome(Throwable failure, boolean cancelled) {
        if (cancelled) return "cancelled";
        if (findHttpException(failure) != null) return "http_error";
        Throwable cause = rootCause(failure);
        if (cause instanceof SocketTimeoutException
                || cause instanceof InterruptedIOException) return "timeout";
        if (cause instanceof IOException) return "network_error";
        return "error";
    }

    public static int httpStatus(Throwable failure) {
        HttpException http = findHttpException(failure);
        return http == null ? 0 : http.code();
    }

    private static Throwable rootCause(Throwable failure) {
        Throwable current = failure;
        while (current != null && current.getCause() != null
                && current.getCause() != current) current = current.getCause();
        return current;
    }

    private static HttpException findHttpException(Throwable failure) {
        Throwable current = failure;
        while (current != null) {
            if (current instanceof HttpException) return (HttpException) current;
            if (current.getCause() == current) return null;
            current = current.getCause();
        }
        return null;
    }
}
