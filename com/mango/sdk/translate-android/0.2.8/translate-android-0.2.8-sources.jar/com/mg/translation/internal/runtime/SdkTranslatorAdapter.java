package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.Translator;
import com.mg.translation.translate.base.TranslateControl;
import com.mg.translation.translate.base.TranslateListener;
import com.mg.translation.internal.model.TranslationTask;
import com.mg.translation.internal.model.BatchTranslationTask;

import java.util.Collections;

public final class SdkTranslatorAdapter implements Translator {
    private final TranslateControl delegate;
    private final long deadlineNanos;
    private final boolean requiresRuntime = TranslationRuntime.isInitialized();
    private final FallbackScope fallbacks = new FallbackScope();
    private final java.util.concurrent.atomic.AtomicBoolean closed = new java.util.concurrent.atomic.AtomicBoolean();

    public SdkTranslatorAdapter(TranslateControl delegate) {
        this(delegate, Long.MAX_VALUE);
    }

    public SdkTranslatorAdapter(TranslateControl delegate, long deadlineNanos) {
        if (delegate == null) throw new IllegalArgumentException("delegate is required");
        this.delegate = delegate;
        this.deadlineNanos = deadlineNanos;
    }

    @Override
    public int getEngineId() {
        return delegate.getTranslateType();
    }

    @Override
    public void translate(TranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (rejectRestrictedAccess(callback)) return;
        TranslationTask task = new TranslationTask(request.getText(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        applyMembershipPolicy(task);
        execute(task, callback);
    }

    @Override
    public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        if (request == null) {
            callback.onError(TranslationErrorMapper.invalidRequest(delegate.getTranslateType()));
            return;
        }
        if (rejectRestrictedAccess(callback)) return;
        BatchTranslationTask task = new BatchTranslationTask(request.getTexts(),
                request.getSourceLanguageId(), request.getTargetLanguageId());
        applyMembershipPolicy(task);
        execute(task, callback);
    }

    private void execute(TranslationTask task, TranslationCallback callback) {
        task.setDeadlineNanos(deadlineNanos);
        task.setTraceId(com.mg.translation.internal.base.http.RequestContext.trace());
        com.mg.translation.internal.base.http.RequestContext.withDeadline(deadlineNanos,
                () -> executeInternal(task, callback));
    }

    private void executeInternal(TranslationTask task, TranslationCallback callback) {
        if (closed.get()) return;
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null && requiresRuntime) {
            callback(callback).onFail(com.mg.translation.sdk.TranslationErrorCode.SDK_NOT_INITIALIZED, "");
            return;
        }
        String reason = runtime == null ? null : com.mg.translation.utils.TranslateUtils.engineSkipReason(
                runtime.context(), getEngineId(), task.isFreeOnlyForRequest());
        if ("cooldown".equals(reason) || "unreachable".equals(reason) || "gate".equals(reason)
                || "not_configured".equals(reason)) {
            ProviderAttemptTelemetry.skipped(getEngineId(), reason);
            task.setAttemptedEngineIds(new java.util.ArrayList<>(Collections.singletonList(getEngineId())));
            TranslateControl fallback = com.mg.translation.utils.TranslateUtils.getCanTranslateType(
                    runtime.context(), task, task instanceof BatchTranslationTask);
            if (fallback != null) {
                ProviderAttemptTelemetry.fallback(getEngineId(), fallback.getTranslateType());
                fallbacks.execute(fallback, task, callback(callback));
            } else {
                callback(callback).onFail(com.mg.translation.sdk.TranslationErrorCode.ALL_ENGINES_FAILED, "");
            }
            return;
        }
        delegate.translate(task, callback(callback));
    }

    private TranslateListener callback(TranslationCallback callback) {
        java.util.concurrent.atomic.AtomicBoolean terminal = new java.util.concurrent.atomic.AtomicBoolean();
        return new TranslateListener() {
            @Override
            public void onSuccess(TranslationTask result, int actualEngineId, boolean isList) {
                if (closed.get() || terminal.get()) return;
                TranslationResult mapped = result instanceof BatchTranslationTask
                        ? new TranslationResult(((BatchTranslationTask) result).getTranslations(), actualEngineId, true)
                        : new TranslationResult(Collections.singletonList(result.getTranslatedText()), actualEngineId, false);
                if (!terminal.compareAndSet(false, true)) return;
                ProviderFailurePolicy.recordSuccess(actualEngineId);
                try {
                    callback.onSuccess(mapped);
                } catch (RuntimeException hostFailure) {
                    // Translation already completed; never turn host callback failures into fallback.
                }
            }

            @Override
            public void onFail(int code, String message) {
                if (closed.get() || !terminal.compareAndSet(false, true)) return;
                com.mg.translation.sdk.TranslationError mapped =
                        TranslationErrorMapper.fromInternalCode(code, delegate.getTranslateType());
                try {
                    callback.onError(mapped);
                } catch (RuntimeException hostFailure) {
                    // A host observer failure must not cause another Provider attempt.
                }
            }
        };
    }

    private void applyMembershipPolicy(TranslationTask task) {
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (runtime == null || !runtime.host().isVip()) task.requireFreeEngines();
    }

    private boolean rejectRestrictedAccess(TranslationCallback callback) {
        int engineId = delegate.getTranslateType();
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        if (!(delegate instanceof NonVipFallbackTranslateControl)
                && com.mg.translation.sdk.TranslationSdk.isVipOnly(engineId)
                && (runtime == null || !runtime.host().isVip())) {
            callback.onError(TranslationErrorMapper.vipRequired(engineId));
            return true;
        }
        return false;
    }

    @Override
    public void close() {
        closed.set(true);
        delegate.close();
        fallbacks.close();
    }
}
