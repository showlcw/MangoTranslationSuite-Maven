package com.mg.translation.internal.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/** SDK-internal mutable state for one translation and its fallback attempts. */
public class TranslationTask {
    public static final long TOTAL_REQUEST_BUDGET_MS = 40_000L;
    private final long requestBudgetMs = com.mg.translation.internal.runtime.TranslationTimeoutPolicy.get().requestBudgetMs;

    private final long startedNanos = System.nanoTime();
    private long deadlineNanos = Long.MAX_VALUE;
    private long traceId;
    public void setTraceId(long trace) { traceId = trace; }
    public long getTraceId() { return traceId; }

    public void setDeadlineNanos(long deadline) { deadlineNanos = deadline; }
    public long getDeadlineNanos() { return deadlineNanos; }
    private String content;
    private String sourceLanguageId;
    private String targetLanguageId;
    private List<Integer> attemptedEngineIds;
    private String translatedText;
    private boolean freeOnlyForRequest;
    private boolean emergencyRequest;
    private final java.util.Set<Integer> timeoutEngineIds = new java.util.HashSet<>();
    private boolean nonTimeoutFailure;

    public TranslationTask() {
    }

    public TranslationTask(String content, String sourceLanguageId, String targetLanguageId) {
        this.content = content;
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }

    public TranslationTask(String sourceLanguageId, String targetLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
        this.targetLanguageId = targetLanguageId;
    }


    public String getTranslatedText() {
        return translatedText;
    }

    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceLanguageId() {
        return sourceLanguageId;
    }

    public void setSourceLanguageId(String sourceLanguageId) {
        this.sourceLanguageId = sourceLanguageId;
    }

    public String getTargetLanguageId() {
        return targetLanguageId;
    }

    public void setTargetLanguageId(String targetLanguageId) {
        this.targetLanguageId = targetLanguageId;
    }

    public List<Integer> getAttemptedEngineIds() {
        return attemptedEngineIds == null ? Collections.emptyList()
                : Collections.unmodifiableList(attemptedEngineIds);
    }

    public void setAttemptedEngineIds(List<Integer> attemptedEngineIds) {
        this.attemptedEngineIds = attemptedEngineIds == null ? new ArrayList<>()
                : new ArrayList<>(attemptedEngineIds);
    }

    public boolean isFreeOnlyForRequest() { return freeOnlyForRequest; }
    public void requireFreeEngines() { freeOnlyForRequest = true; }
    public boolean isEmergencyRequest() { return emergencyRequest; }
    public void markEmergencyRequest() { emergencyRequest = true; }
    public void markAttemptedEngine(int engineId) {
        if (attemptedEngineIds == null) attemptedEngineIds = new ArrayList<>();
        if (!attemptedEngineIds.contains(engineId)) attemptedEngineIds.add(engineId);
    }
    public void markAttemptFailure(int engineId, boolean timeout) {
        markAttemptedEngine(engineId);
        if (timeout) timeoutEngineIds.add(engineId); else nonTimeoutFailure = true;
    }
    public boolean allAttemptedFailuresTimedOut() {
        return !attemptedEngineIds.isEmpty() && !nonTimeoutFailure
                && timeoutEngineIds.containsAll(attemptedEngineIds);
    }

    public long remainingBudgetMs() {
        long elapsedNanos = Math.max(0L, System.nanoTime() - startedNanos);
        long elapsedMs = elapsedNanos / 1_000_000L;
        return Math.max(0L, Math.min(requestBudgetMs - elapsedMs,
                java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(deadlineNanos - System.nanoTime())));
    }

    public boolean hasBudgetFor(long requestTimeoutMs) {
        return requestTimeoutMs > 0L && remainingBudgetMs() >= requestTimeoutMs;
    }

}
