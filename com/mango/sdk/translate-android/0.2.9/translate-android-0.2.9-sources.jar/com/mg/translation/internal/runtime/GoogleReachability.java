package com.mg.translation.internal.runtime;

import android.content.Context;
import com.mg.translation.engine.TranslatorId;
import com.mg.translation.internal.base.NetworkUtils;
import com.mg.translation.internal.base.SdkPreferences;
import com.mg.translation.internal.base.http.RetrofitServiceManager;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/** Fail-closed, asynchronous reachability cache for the two free Google endpoints. */
public final class GoogleReachability {
    static final long SUCCESS_TTL_MS = 120_000L;
    interface Probe { void start(int engineId, Consumer<Boolean> completion); }
    private final SdkPreferences preferences;
    private final Probe probe;
    private final LongSupplier clock;
    private final BooleanSupplier online;
    private final LongSupplier networkIdentity;
    private final Map<Integer, State> states = new HashMap<>();
    private long lastNetwork = Long.MIN_VALUE;
    private boolean closed;

    private static final class State {
        long succeededAt = -1L;
        long generation;
        boolean pending;
    }

    GoogleReachability(Context context) {
        this(context, (id, done) -> RetrofitServiceManager.getInstance().probeGoogle(id, done),
                System::currentTimeMillis, () -> NetworkUtils.isConnectedAvailableNetwork(context),
                () -> {
                    android.net.ConnectivityManager manager = (android.net.ConnectivityManager)
                            context.getSystemService(Context.CONNECTIVITY_SERVICE);
                    android.net.Network network = manager == null ? null : manager.getActiveNetwork();
                    return network == null ? -1L : network.getNetworkHandle();
                });
    }

    GoogleReachability(Context context, Probe probe, LongSupplier clock, BooleanSupplier online) {
        this(context, probe, clock, online, () -> 0L);
    }

    GoogleReachability(Context context, Probe probe, LongSupplier clock, BooleanSupplier online,
                       LongSupplier networkIdentity) {
        this.preferences = SdkPreferences.getInstance(context);
        this.probe = probe;
        this.clock = clock;
        this.online = online;
        this.networkIdentity = networkIdentity;
    }

    private static String failureKey(int id) { return "GOOGLE_PROBE_FAILED_AT_" + id; }

    public synchronized boolean isReachable(int engineId) {
        if (closed) return false;
        refreshNetwork();
        TranslatorId engine = TranslatorId.fromLegacyCode(engineId);
        if (engine != TranslatorId.GOOGLE && engine != TranslatorId.GOOGLE_CLIENT) return false;
        if (!online.getAsBoolean()) {
            invalidateSuccess();
            return false;
        }
        State state = states.computeIfAbsent(engineId, ignored -> new State());
        long now = clock.getAsLong();
        if (!preferences.isCooldownReady(failureKey(engineId), engine.defaultCooldownMs, now)) return false;
        if (state.succeededAt >= 0L && now >= state.succeededAt
                && now - state.succeededAt < SUCCESS_TTL_MS) return true;
        if (state.pending) return false;
        state.pending = true;
        long generation = ++state.generation;
        try {
            probe.start(engineId, reachable -> complete(engineId, generation, reachable));
        } catch (RuntimeException scheduleFailure) {
            complete(engineId, generation, false);
        }
        // Never wait for a probe in the translation path, including the first cold request.
        return false;
    }

    private synchronized void complete(int engineId, long generation, boolean reachable) {
        if (closed) return;
        refreshNetwork();
        State state = states.get(engineId);
        if (state == null || state.generation != generation) return;
        state.pending = false;
        if (!online.getAsBoolean()) { state.succeededAt = -1L; return; }
        if (reachable) {
            state.succeededAt = clock.getAsLong();
            preferences.put(failureKey(engineId), 0L);
        } else {
            recordFailure(engineId);
        }
    }

    /** A real request failure must invalidate a prior or in-flight successful probe. */
    public synchronized void recordFailure(int engineId) {
        if (closed) return;
        State state = states.computeIfAbsent(engineId, ignored -> new State());
        state.generation++;
        state.pending = false;
        state.succeededAt = -1L;
        preferences.put(failureKey(engineId), clock.getAsLong());
    }

    private void refreshNetwork() {
        long currentNetwork = networkIdentity.getAsLong();
        if (lastNetwork == currentNetwork) return;
        lastNetwork = currentNetwork;
        invalidateSuccess();
    }

    private void invalidateSuccess() {
        for (State state : states.values()) {
            state.generation++;
            state.pending = false;
            state.succeededAt = -1L;
        }
    }

    synchronized void close() { closed = true; }
}
