package com.mg.translation.internal.runtime;

import com.mg.translation.sdk.Translator;
import com.mg.translation.sdk.TranslationCall;
import com.mg.translation.sdk.TranslationCallback;
import com.mg.translation.sdk.TranslationRequest;
import com.mg.translation.sdk.BatchTranslationRequest;
import com.mg.translation.sdk.TranslationResult;
import com.mg.translation.sdk.TranslationError;
import com.mg.translation.sdk.TranslationErrorCode;
import com.mg.translation.sdk.TranslationHost;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.LongFunction;
import java.util.function.BiFunction;

/** Owns isolated chains, bounded scheduling, exact in-flight coalescing and bounded memory results. */
public final class ManagedTranslator implements Translator {
    private static final ScheduledThreadPoolExecutor TIMER = deadlineTimer();
    private static ScheduledThreadPoolExecutor deadlineTimer() {
        ScheduledThreadPoolExecutor timer = new ScheduledThreadPoolExecutor(1, r -> {
            Thread thread = new Thread(r, "mango-deadline"); thread.setDaemon(true); return thread;
        });
        timer.setRemoveOnCancelPolicy(true);
        return timer;
    }
    private static volatile long cacheTtlMs = 15_000L;
    private static final java.util.concurrent.atomic.AtomicLong NEXT_REQUEST = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.AtomicLong NEXT_CHAIN = new java.util.concurrent.atomic.AtomicLong();
    private static final int MAX_CACHE_CHARS = 128 * 1024;
    private static final long EMERGENCY_BUDGET_MS = 8_000L;
    private static final ScheduledThreadPoolExecutor EMERGENCY_EXECUTOR =
            new ScheduledThreadPoolExecutor(2, r -> {
                Thread thread = new Thread(r, "mango-emergency"); thread.setDaemon(true); return thread;
            });
    private final int engineId;
    private final boolean cacheAllowed;
    private final LongFunction<Translator> factory;
    private final BiFunction<Integer, Long, Translator> emergencyFactory;
    private final TranslationDispatchQueue dispatch;
    private final long testBudgetMs;
    private final java.util.function.Consumer<Runnable> delivery;
    private final Map<List<Object>, Operation> active = new HashMap<>();
    private final Set<Subscription> subscriptions = new HashSet<>();
    private final LinkedHashMap<List<Object>, Cached> cache = new LinkedHashMap<>(16, .75f, true);
    private int cacheChars;
    private boolean closed;
    private Object cacheRuntime;
    private boolean cacheVip;

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), null);
    }

    public ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this(engineId, cacheAllowed, factory, TranslationDispatchQueue.SHARED, 0,
                action -> AndroidSchedulers.mainThread().scheduleDirect(action), emergencyFactory);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery) {
        this(engineId, cacheAllowed, factory, dispatch, testBudgetMs, delivery, null);
    }

    ManagedTranslator(int engineId, boolean cacheAllowed, LongFunction<Translator> factory,
            TranslationDispatchQueue dispatch, long testBudgetMs, java.util.function.Consumer<Runnable> delivery,
            BiFunction<Integer, Long, Translator> emergencyFactory) {
        this.engineId = engineId; this.cacheAllowed = cacheAllowed; this.factory = factory;
        this.dispatch = dispatch; this.testBudgetMs = testBudgetMs; this.delivery = delivery;
        this.emergencyFactory = emergencyFactory;
    }

    public static void configureResultCache(long ttlMs) {
        if (ttlMs < 0 || ttlMs > 60_000) throw new IllegalArgumentException("Cache TTL must be 0..60000 ms");
        cacheTtlMs = ttlMs;
    }

    @Override public int getEngineId() { return engineId; }
    @Override public void translate(TranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public void translate(BatchTranslationRequest request, TranslationCallback callback) {
        translateCancellable(request, callback);
    }
    @Override public TranslationCall translateCancellable(TranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }
    @Override public TranslationCall translateCancellable(BatchTranslationRequest request, TranslationCallback callback) {
        return submit(request, callback);
    }

    private synchronized TranslationCall submit(Object request, TranslationCallback callback) {
        if (callback == null) throw new IllegalArgumentException("callback is required");
        Subscription subscriber = new Subscription(callback);
        if (closed) { subscriber.cancelled.set(true); return subscriber; }
        subscriptions.add(subscriber);
        TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        boolean vip = runtime != null && runtime.host().isVip();
        if (cacheRuntime != runtime || cacheVip != vip || cacheTtlMs == 0) {
            cache.clear(); cacheChars = 0; cacheRuntime = runtime; cacheVip = vip;
        }
        if (request == null) {
            deliver(subscriber, null, TranslationErrorMapper.invalidRequest(engineId)); return subscriber;
        }
        List<Object> key = key(request, runtime, vip);
        Cached cached = cache.get(key);
        if (cached != null && cacheAllowed && cacheTtlMs > 0
                && System.nanoTime() - cached.created < TimeUnit.MILLISECONDS.toNanos(cacheTtlMs)) {
            subscriber.source = "cache";
            deliver(subscriber, cached.result, null); return subscriber;
        }
        Operation operation = active.get(key);
        if (operation != null) subscriber.source = "merged";
        if (operation == null) {
            operation = new Operation(key, request, runtime, vip);
            active.put(key, operation);
        }
        subscriber.operation = operation;
        operation.listeners.add(subscriber);
        // Each subscriber has its own delivery gate. A merged caller shares the original chain deadline.
        if (operation.ticket == null) {
            Operation scheduled = operation;
            operation.timeout = TIMER.schedule(() -> deadlineReached(scheduled),
                    Math.max(0L, operation.deadline - System.nanoTime()), TimeUnit.NANOSECONDS);
            operation.ticket = dispatch.submit(() -> start(scheduled));
            if (operation.done && operation.ticket != null) operation.ticket.finish();
            if (operation.ticket == null) complete(operation, null,
                    TranslationErrorMapper.fromInternalCode(TranslationErrorCode.RATE_LIMITED, engineId));
        }
        return subscriber;
    }

    private List<Object> key(Object request, TranslationRuntime runtime, boolean vip) {
        boolean batch = request instanceof BatchTranslationRequest;
        TranslationTimeoutPolicy.Settings settings = TranslationTimeoutPolicy.get();
        if (batch) {
            BatchTranslationRequest r = (BatchTranslationRequest) request;
            return Arrays.asList(runtime, vip, engineId, true, r.getSourceLanguageId(), r.getTargetLanguageId(),
                    r.getTexts(), settings);
        }
        TranslationRequest r = (TranslationRequest) request;
        return Arrays.asList(runtime, vip, engineId, false, r.getSourceLanguageId(), r.getTargetLanguageId(),
                Collections.singletonList(r.getText()), settings);
    }

    private void start(Operation operation) {
        try {
            synchronized (this) {
                if (operation.done) return;
                operation.started = System.nanoTime();
                if (operation.runtime != TranslationRuntime.currentOrNull()) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.SDK_NOT_INITIALIZED, engineId)); return;
                }
                if (operation.runtime != null && operation.vip != operation.runtime.host().isVip()) {
                    complete(operation, null, TranslationErrorMapper.vipRequired(engineId)); return;
                }
                operation.translator = factory.apply(operation.deadline);
                if (operation.translator == null) {
                    complete(operation, null, TranslationErrorMapper.fromInternalCode(
                            TranslationErrorCode.ENGINE_NOT_CONFIGURED, engineId)); return;
                }
            }
                TranslationCallback callback = new TranslationCallback() {
                    @Override public void onSuccess(TranslationResult result) {
                        completeOrdinary(operation, result, null);
                    }
                    @Override public void onError(TranslationError error) {
                        completeOrdinary(operation, null, error);
                    }
                };
                com.mg.translation.internal.base.http.RequestContext.withTrace(operation.chainId, () -> {
                    if (operation.request instanceof BatchTranslationRequest)
                        operation.translator.translate((BatchTranslationRequest) operation.request, callback);
                    else operation.translator.translate((TranslationRequest) operation.request, callback);
                });
        } catch (RuntimeException error) {
            complete(operation, null, TranslationErrorMapper.fromInternalCode(TranslationErrorCode.UNKNOWN, engineId));
        }
    }

    private void completeOrdinary(Operation operation, TranslationResult result, TranslationError error) {
        synchronized (this) {
            if (operation.done || operation.emergencyStarted) return;
        }
        complete(operation, result, error);
    }

    /** Moves a deadline-expired request to the independent final rescue chain. */
    private void deadlineReached(Operation operation) {
        synchronized (this) {
            if (operation.done || operation.emergencyStarted) return;
            operation.emergencyStarted = true;
            operation.emergencyDeadline = System.nanoTime()
                    + TimeUnit.MILLISECONDS.toNanos(EMERGENCY_BUDGET_MS);
            if (operation.translator != null) operation.translator.close();
            if (operation.ticket != null) operation.ticket.finish();
            operation.emergencyTimeout = TIMER.schedule(
                    () -> complete(operation, null,
                            TranslationErrorMapper.fromInternalCode(
                                    TranslationErrorCode.REQUEST_TIMEOUT, engineId)),
                    EMERGENCY_BUDGET_MS, TimeUnit.MILLISECONDS);
        }
        EMERGENCY_EXECUTOR.execute(() -> runEmergency(operation));
    }

    private void runEmergency(Operation operation) {
        int[] rescue = { com.mg.translation.engine.TranslatorId.BAIDU.legacyCode,
                com.mg.translation.engine.TranslatorId.QWEN.legacyCode };
        for (int id : rescue) {
            synchronized (this) {
                if (operation.done || System.nanoTime() >= operation.emergencyDeadline) return;
                operation.emergencyEngineId = id;
            }
            Translator translator = emergencyFactory == null ? null
                    : emergencyFactory.apply(id, operation.emergencyDeadline);
            if (translator == null) continue;
            synchronized (this) {
                if (operation.done) { translator.close(); return; }
                operation.emergencyTranslator = translator;
            }
            CountDownLatch finished = new CountDownLatch(1);
            TranslationCallback callback = new TranslationCallback() {
                @Override public void onSuccess(TranslationResult result) {
                    try { complete(operation, result, null); } finally { finished.countDown(); }
                }
                @Override public void onError(TranslationError error) { finished.countDown(); }
            };
            try {
                com.mg.translation.internal.base.http.RequestContext.withEmergency(true, () -> {
                    if (operation.request instanceof BatchTranslationRequest)
                        translator.translate((BatchTranslationRequest) operation.request, callback);
                    else translator.translate((TranslationRequest) operation.request, callback);
                });
                long waitMs = Math.max(1L, TimeUnit.NANOSECONDS.toMillis(
                        operation.emergencyDeadline - System.nanoTime()));
                finished.await(waitMs, TimeUnit.MILLISECONDS);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
            } catch (RuntimeException ignored) {
                // Try the next emergency engine.
            } finally {
                translator.close();
            }
            synchronized (this) {
                if (operation.done) return;
            }
        }
        complete(operation, null, TranslationErrorMapper.fromInternalCode(
                TranslationErrorCode.REQUEST_TIMEOUT, engineId));
    }

    private synchronized void complete(Operation operation, TranslationResult result, TranslationError error) {
        if (operation.done) return;
        operation.done = true;
        active.remove(operation.key, operation);
        if (operation.timeout != null) operation.timeout.cancel(false);
        if (operation.emergencyTimeout != null) operation.emergencyTimeout.cancel(false);
        if (operation.translator != null) operation.translator.close();
        if (operation.emergencyTranslator != null) operation.emergencyTranslator.close();
        if (operation.ticket != null) operation.ticket.finish();
        // Never pin a fallback result to the selected engine, or cache a result across runtime/membership changes.
        if (result != null && result.getActualEngineId() == engineId && cacheAllowed && cacheTtlMs > 0
                && operation.runtime == TranslationRuntime.currentOrNull()
                && (operation.runtime == null || operation.vip == operation.runtime.host().isVip())) {
            putCache(operation.key, result);
        }
        for (Subscription subscriber : operation.listeners) deliver(subscriber, result, error);
        operation.listeners.clear();
    }

    private void putCache(List<Object> key, TranslationResult result) {
        int chars = 0;
        for (Object item : (List<?>) key.get(6)) chars += ((String) item).length();
        for (String item : result.getTranslations()) chars += item.length();
        if (chars > MAX_CACHE_CHARS) return;
        Cached previous = cache.remove(key);
        if (previous != null) cacheChars -= previous.chars;
        cache.put(key, new Cached(result, chars)); cacheChars += chars;
        Iterator<Cached> iterator = cache.values().iterator();
        while ((cache.size() > 64 || cacheChars > MAX_CACHE_CHARS) && iterator.hasNext()) {
            cacheChars -= iterator.next().chars; iterator.remove();
        }
    }

    private void deliver(Subscription subscriber, TranslationResult result, TranslationError error) {
        long ready = System.nanoTime();
        delivery.accept(() -> {
            synchronized (ManagedTranslator.this) {
                subscriptions.remove(subscriber);
                if (closed || subscriber.cancelled.get() || !subscriber.delivered.compareAndSet(false, true)) return;
            }
            TranslationError deliveredError = error;
            if (subscriber.runtime != TranslationRuntime.currentOrNull())
                deliveredError = TranslationErrorMapper.fromInternalCode(TranslationErrorCode.SDK_NOT_INITIALIZED, engineId);
            else if (subscriber.runtime != null && subscriber.vip != subscriber.runtime.host().isVip())
                deliveredError = TranslationErrorMapper.vipRequired(engineId);
            if ((subscriber.operation == null || !subscriber.operation.emergencyStarted)
                    && System.nanoTime() >= (subscriber.operation == null ? subscriber.deadline : subscriber.operation.deadline))
                deliveredError = TranslationErrorMapper.fromInternalCode(TranslationErrorCode.REQUEST_TIMEOUT, engineId);
            long now = System.nanoTime();
            if (subscriber.host != null) {
                Operation op = subscriber.operation;
                long queue = op == null ? 0 : Math.max(0L, (op.started == 0 ? ready : op.started) - subscriber.created);
                try { subscriber.host.onTranslationFinished(subscriber.id, op == null ? 0 : op.chainId, engineId,
                        deliveredError == null ? "success" : "error", subscriber.source,
                        TimeUnit.NANOSECONDS.toMillis(queue), TimeUnit.NANOSECONDS.toMillis(now - ready),
                        TimeUnit.NANOSECONDS.toMillis(now - subscriber.created)); }
                catch (RuntimeException ignored) { }
            }
            try { if (deliveredError == null) subscriber.callback.onSuccess(result); else subscriber.callback.onError(deliveredError); }
            catch (RuntimeException ignored) { /* Host observers never trigger retries. */ }
        });
    }

    @Override public synchronized void clearResultCache() { cache.clear(); cacheChars = 0; }
    @Override public synchronized void close() {
        closed = true;
        for (Subscription subscriber : new ArrayList<>(subscriptions)) subscriber.cancel();
        clearResultCache();
    }

    private final class Subscription implements TranslationCall {
        final long id = NEXT_REQUEST.incrementAndGet();
        final long created = System.nanoTime();
        final long deadline = created + TimeUnit.MILLISECONDS.toNanos(budgetMs());
        final TranslationRuntime runtime = TranslationRuntime.currentOrNull();
        final TranslationHost host = runtime == null ? null : runtime.host();
        final boolean vip = host != null && host.isVip();
        String source = "network";
        final TranslationCallback callback;
        final AtomicBoolean cancelled = new AtomicBoolean();
        final AtomicBoolean delivered = new AtomicBoolean();
        Operation operation;
        Subscription(TranslationCallback callback) { this.callback = callback; }
        @Override public boolean isCancelled() { return cancelled.get(); }
        @Override public void cancel() {
            synchronized (ManagedTranslator.this) {
                if (!cancelled.compareAndSet(false, true)) return;
                subscriptions.remove(this);
                if (operation != null && !operation.done) {
                    operation.listeners.remove(this);
                    if (operation.listeners.isEmpty()) complete(operation, null,
                            TranslationErrorMapper.fromInternalCode(TranslationErrorCode.CANCELLED, engineId));
                }
            }
        }
    }

    private final class Operation {
        final long chainId = NEXT_CHAIN.incrementAndGet();
        final List<Object> key;
        final Object request;
        final TranslationRuntime runtime;
        final boolean vip;
        final long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(budgetMs());
        final List<Subscription> listeners = new ArrayList<>();
        Translator translator;
        TranslationDispatchQueue.Ticket ticket;
        ScheduledFuture<?> timeout;
        ScheduledFuture<?> emergencyTimeout;
        boolean emergencyStarted;
        long emergencyDeadline;
        int emergencyEngineId;
        Translator emergencyTranslator;
        boolean done;
        long started;
        Operation(List<Object> key, Object request, TranslationRuntime runtime, boolean vip) {
            this.key = key; this.request = request; this.runtime = runtime; this.vip = vip;
        }
    }
    private static final class Cached {
        final TranslationResult result;
        final int chars;
        final long created = System.nanoTime();
        Cached(TranslationResult result, int chars) { this.result = result; this.chars = chars; }
    }

    private long budgetMs() { return testBudgetMs > 0 ? testBudgetMs : TranslationTimeoutPolicy.get().requestBudgetMs; }
}
