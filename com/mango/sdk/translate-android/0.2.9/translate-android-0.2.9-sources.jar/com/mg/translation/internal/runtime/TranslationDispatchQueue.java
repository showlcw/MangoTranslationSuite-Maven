package com.mg.translation.internal.runtime;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/** Limits complete translation chains, including fallback, rather than just HTTP enqueue calls. */
final class TranslationDispatchQueue {
    static final TranslationDispatchQueue SHARED = new TranslationDispatchQueue(8, 64,
            Executors.newFixedThreadPool(8, runnable -> {
                Thread thread = new Thread(runnable, "mango-translation");
                thread.setDaemon(true);
                return thread;
            }));
    private final int concurrency;
    private final int capacity;
    private final Executor executor;
    private final ArrayDeque<Ticket> waiting = new ArrayDeque<>();
    private int running;

    TranslationDispatchQueue(int concurrency, int capacity, Executor executor) {
        this.concurrency = concurrency;
        this.capacity = capacity;
        this.executor = executor;
    }

    synchronized Ticket submit(Runnable action) {
        if (running >= concurrency && waiting.size() >= capacity) return null;
        Ticket ticket = new Ticket(action);
        waiting.add(ticket);
        drain();
        return ticket;
    }

    private void drain() {
        while (running < concurrency && !waiting.isEmpty()) {
            Ticket ticket = waiting.remove();
            ticket.started = true;
            running++;
            ticket.dispatched = () -> {
                synchronized (TranslationDispatchQueue.this) { if (ticket.finished) return; }
                ticket.action.run();
            };
            executor.execute(ticket.dispatched);
        }
    }

    final class Ticket {
        final Runnable action;
        boolean started;
        boolean finished;
        Runnable dispatched;
        Ticket(Runnable action) { this.action = action; }
        void finish() {
            synchronized (TranslationDispatchQueue.this) {
                if (finished) return;
                finished = true;
                if (dispatched != null && executor instanceof java.util.concurrent.ThreadPoolExecutor)
                    ((java.util.concurrent.ThreadPoolExecutor) executor).remove(dispatched);
                if (started) running--; else waiting.remove(this);
                drain();
            }
        }
    }
}
