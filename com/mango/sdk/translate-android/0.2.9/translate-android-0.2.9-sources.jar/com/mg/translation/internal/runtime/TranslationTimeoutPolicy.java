package com.mg.translation.internal.runtime;

/** Process-local client policy, independent of platform settings. */
public final class TranslationTimeoutPolicy {
    private static volatile Settings settings = new Settings(5_000, 40_000);
    private TranslationTimeoutPolicy() { }
    public static Settings get() { return settings; }
    public static void configure(int callMs, int requestMs) {
        if (callMs < 1000 || callMs > 60_000 || requestMs < Math.max(callMs, 10_000)
                || requestMs > 120_000) throw new IllegalArgumentException("Invalid client timeout budget");
        settings = new Settings(callMs, requestMs);
    }
    public static final class Settings {
        public final int selfHostedCallMs;
        public final int requestBudgetMs;
        private Settings(int callMs, int requestMs) { selfHostedCallMs = callMs; requestBudgetMs = requestMs; }
    }
}
