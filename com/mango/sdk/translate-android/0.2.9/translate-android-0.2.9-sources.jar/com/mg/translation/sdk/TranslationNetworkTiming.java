package com.mg.translation.sdk;

/** Transport metadata only. Missing phases are -1; repeated connection phases are accumulated.
 * connectMs includes TLS; do not add tlsMs again. Connection IDs are process-local opaque numbers.
 */
public final class TranslationNetworkTiming {
    public final int engineId, httpStatus, connectionAttempts;
    public final String purpose, outcome;
    public final long totalMs, connectionWaitMs, dnsMs, connectMs, tlsMs, responseWaitMs, bodyMs, connectionId;
    public final boolean reusedConnection;
    public final long chainId;
    public TranslationNetworkTiming(long chainId, int engineId, String purpose, String outcome, int httpStatus,
            long totalMs, long connectionWaitMs, long dnsMs, long connectMs, long tlsMs,
            long responseWaitMs, long bodyMs, long connectionId, boolean reusedConnection, int connectionAttempts) {
        this.engineId = engineId; this.purpose = purpose; this.outcome = outcome; this.httpStatus = httpStatus;
        this.chainId = chainId;
        this.totalMs = totalMs; this.connectionWaitMs = connectionWaitMs; this.dnsMs = dnsMs;
        this.connectMs = connectMs; this.tlsMs = tlsMs; this.responseWaitMs = responseWaitMs;
        this.bodyMs = bodyMs; this.connectionId = connectionId; this.reusedConnection = reusedConnection;
        this.connectionAttempts = connectionAttempts;
    }
}
