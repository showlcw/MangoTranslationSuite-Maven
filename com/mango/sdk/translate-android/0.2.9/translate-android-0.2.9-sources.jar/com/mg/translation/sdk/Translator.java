package com.mg.translation.sdk;

public interface Translator extends AutoCloseable {
    int getEngineId();
    void translate(TranslationRequest request, TranslationCallback callback);
    void translate(BatchTranslationRequest request, TranslationCallback callback);

    /** SDK-created translators support cancellation without closing other requests. */
    default TranslationCall translateCancellable(TranslationRequest request, TranslationCallback callback) {
        throw new UnsupportedOperationException("Cancellable requests require an SDK-created Translator");
    }

    default TranslationCall translateCancellable(BatchTranslationRequest request, TranslationCallback callback) {
        throw new UnsupportedOperationException("Cancellable requests require an SDK-created Translator");
    }

    /** Clears this Translator's in-memory results. */
    default void clearResultCache() { }

    @Override
    void close();
}
